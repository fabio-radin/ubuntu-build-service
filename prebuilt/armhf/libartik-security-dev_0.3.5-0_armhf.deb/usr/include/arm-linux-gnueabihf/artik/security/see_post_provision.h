/*
 * Copyright (c) 2016 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the License);
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __ARTIK_SEE_POST_PROVISION__H
#define __ARTIK_SEE_POST_PROVISION__H

#include <artik/security/see_common.h>

/**
 * @file see_post_provision.h
 * @brief Post Provision API
 *
 * @example see-postprovision-test.c
 */

/**
 * @ingroup security
 * @defgroup see_post_provision See_Post_Provision
 * @brief post provision api
 *
 * This API provides a Post Provision mechanism.
 * @{
 */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Post Provisioning
 *
 * - Provision credentials.
 *
 * @param[in] admin_id  : Admin id for post provisioning.
 * @param[in] admin_key : Admin key for post provisioning.
 * @param[in] pp_data   : Post provisioned data.
 * @returns 0 if succeeded. Returns other value if failed.
 * @see struct see_data
 */
int see_post_provision(const char *admin_id, const char *admin_key,
		see_data pp_data);

/**
 * @brief Post provisioning
 *
 * - Provision credentials.
 * - It is possible to provision credentials only once,
 *   so the user makes sure the credentials before provision.
 *
 * @param[in] admin_id Admin id for post provision.
 * @param[in] admin_key Admin key for post provision.
 * @param[in] pp_data Post provisioned data
 * @returns 0 if succeeded. Returns other value if failed.
 * @see struct see_data
 */
int see_post_provision_lock(const char *admin_id, const char *admin_key,
		see_data pp_data);

#ifdef __cplusplus
}
#endif
/**
 * @}
 */
#endif
