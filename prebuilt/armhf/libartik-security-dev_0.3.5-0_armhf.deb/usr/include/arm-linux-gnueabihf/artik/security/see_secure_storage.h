/*
 * Copyright (c) 2016 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the License);
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __ARTIK_SEE_SECURE_STORAGE__H
#define __ARTIK_SEE_SECURE_STORAGE__H

#include <artik/security/see_common.h>

/**
 * @file see_secure_storage.h
 * @brief Secure Storage API
 *
 * @example see-securestorage-test.c
 */

/**
 * @ingroup security
 * @defgroup see_secure_storage See_Secure_Storage
 * @brief secure storage api
 *
 * This API provides a Secure Storage mechanism.
 * @{
 */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Read a file from Secure Storage
 *
 * - Read a file from secure storage.
 * - If a user wants to read a data in special storage,
 *   the user should prefix a location with index.
 * <PRE>
 * 	1. SE Storage       : SE/
 * 	2. TEMP Storage     : TMP/
 * 	   TEMP Storage save a data on volatile memory,
 * 	   so the data is discarded when finalizing API.
 * </PRE>
 * - Limitations
 * <PRE>
 * 	1. TEE Storage
 * 		1) Name      : 20 characters max length
 * 		2) File size : 32 KB
 * 		3) Capacity  : Irrespective of data type, 1024 files in TEE Storage
 * 	2. SE Storage
 * 		1) Name      : 5 characters max length include “SE/” prefix (“SE/”)
 * 		2) File size : 192 Bytes
 * 		3) Capacity  : SE/0 ~ 26
 * 		4) Offset    : SE Storage does not support offset.
 * 	3. TEMP Storage
 * 		1) Name      : 6 characters max length include “TMP/” prefix (“TMP/”)
 * 		2) File size : 32KB
 * 		3) Capacity  : TMP/0 ~ 3 for Irrespective of data type
 * </PRE>
 *
 * @param[in] name   : File name in secure storage.
 * @param[in] offset : File offset.
 * @param[in] size   : Read size.
 * @param[out] data  : File data will be returned from secure storage.
 * @returns 0 if succeeded. Returns other value if failed.
 * @see struct see_data
 */
int see_read_secure_storage(const char *name, unsigned int offset,
		unsigned int size, see_data *data);

/**
 * @brief Write a file into Secure Storage
 *
 * - Write a file into secure storage.
 * - If a user wants to write a data in special storage,
 *   the user should prefix a location with index.
 * <PRE>
 * 	1. SE Storage       : SE/
 * 	2. TEMP Storage     : TMP/
 * 	   TEMP Storage save a data on volatile memory,
 * 	   so the data is discarded when finalizing API.
 * </PRE>
 * - Limitations
 * <PRE>
 * 	1. TEE Storage
 * 		1) Name      : 20 characters max length
 * 		2) File size : 32 KB
 * 		3) Capacity  : Irrespective of data type, 1024 files in TEE Storage
 * 	2.SE Storage
 * 		1) Name      : 5 characters max length include “SE/” prefix (“SE/”)
 * 		2) File size : 192 Bytes
 * 		3) Capacity  : SE/0 ~ 26
 * 		4) Offset    : SE Storage doesn’t support offset.
 * 	3.TEMP Storage
 * 		1) Name      : 6 characters max length include “TMP/” prefix (“TMP/”)
 * 		2) File size : 32 KB
 * 		3) Capacity  : TMP/0 ~ 3 for Irrespective of data type
 * </PRE>
 *
 * @param[in] name   : File name in secure storage.
 * @param[in] offset : File offset.
 * @param[in] data   : File data.
 * @returns 0 if succeeded. Returns other value if failed.
 * @see struct see_data
 */
int see_write_secure_storage(const char *name, unsigned int offsest,
		see_data data);

/**
 * @brief Deletes a file from Secure Storage
 *
 * - Delete a file from secure storage.
 * - If a user wants to remove a data in special storage,
 *   the user should prefix a location with index.
 * <PRE>
 * 	1. SE Storage       : SE/
 * 	2. TEMP Storage     : TMP/
 * 	   TEMP Storage save a data on volatile memory,
 * 	   so the data is discarded when finalizing API.
 * </PRE>
 * - Limitations
 * <PRE>
 * 	1. TEE Storage
 * 		1) Name : 20 characters max length
 * 	2. SE Storage
 * 		1) Name : 5 characters max length include “SE/” prefix (“SE/”)
 * 	3. TEMP Storage
 * 		1) Name : 6 characters max length include “TMP/” prefix (“TMP/”)
 * </PRE>
 *
 * @param[in] name : File name in secure storage.
 * @returns 0 if succeeded. Returns other value if failed.
 * @see struct see_data
 */
int see_delete_secure_storage(const char *name);

/**
 * @brief Get file size from Secure Storage
 *
 * - Get size of a file from Secure Storage.
 * - If a user wants to remove a data in special storage,
 *   the user should prefix a location with index.
 * <PRE>
 * 	1. SE Storage       : SE/
 * 	2. TEMP Storage     : TMP/
 * 	   TEMP Storage save a data on volatile memory,
 * 	   so the data is discarded when finalizing API.
 * </PRE>
 * - Limitations
 * <PRE>
 * 	1. TEE Storage
 * 		1) Name : 20 characters max length
 * 	2. SE Storage
 * 		1) Name : 5 characters max length include “SE/” prefix (“SE/”)
 * 	3. TEMP Storage
 * 		1) Name : 6 characters max length include “TMP/” prefix (“TMP/”)
 * </PRE>
 *
 * @param[in] name  : File name.
 * @param[out] size : File size will be returned
 * @returns 0 if succeeded. Returns other value if failed.
 * @see struct see_data
 */
int see_get_size_secure_storage(const char *name, unsigned int *size);

/**
 * @brief Get file list from Secure Storage
 *
 * - List all files from both SE Storage and TEE Storage.
 * - File Attributes
 * <PRE>
 * 	1. File Type MASK        : 0xF0000000
 * 		1) Key Type          : 0x10000000
 * 		2) Cert Type         : 0x20000000
 * 		3) Other Type        : 0xF0000000
 * 	2. File Permission MASK  : 0x0000000F
 * 		1) Write Permission  : 0x00000001
 * 		2) Read Permission   : 0x00000002
 * 		3) Delete Permission : 0x00000004
 * </PRE>
 *
 * @param[out] count : The number of files
 * @param[out] list  : File list includes name and type information
 * @returns 0 if succeeded. Returns other value if failed.
 * @see struct see_storage_list
 */
int see_get_list_secure_storage(unsigned int *count, see_storage_list *list);

#ifdef __cplusplus
}
#endif
/**
 * @}
 */
#endif
