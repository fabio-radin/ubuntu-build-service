#!/bin/sh

if [ $# -ne 4 ]
then
echo 'ZigBee_firmware_flash.sh [ARTIK520 f/w file] [ARTIK710 f/w file] [ARTIK530 f/w file] [f/w version]'
exit 0
fi

ARTIK520_FIRMWARE_FILE=$1
ARTIK710_FIRMWARE_FILE=$2
ARTIK530_FIRMWARE_FILE=$3
VERSION=$4
MAJOR_VERSION=${VERSION:0:5}
ZIGBEE_VERSION_TOOL='/usr/bin/zigbee_version'
THREAD_VERSION_TOOL='/usr/bin/thread_version'
FIRMWARE_FLASHING_TOOL='/etc/zigbee/Firmware/flash_firmware'

if [ ! -e "$ARTIK520_FIRMWARE_FILE" ]; then
echo 'No ARTIK520 firmware file'
exit 0
fi

if [ ! -e "$ARTIK710_FIRMWARE_FILE" ]; then
echo 'No ARTIK710 firmware file'
exit 0
fi

if [ ! -e "$ARTIK530_FIRMWARE_FILE" ]; then
echo 'No ARTIK530 firmware file'
exit 0
fi

if [ ! -e "$ZIGBEE_VERSION_TOOL" ]; then
echo 'No zigbee_version file'
exit 0
fi

if [ ! -e "$THREAD_VERSION_TOOL" ]; then
echo 'No thread_version file'
exit 0
fi

if [ ! -e "$FIRMWARE_FLASHING_TOOL" ]; then
echo 'No flash_firmware file'
exit 0
fi

ARTIK5=`cat /proc/cpuinfo | grep -i EXYNOS3`
ARTIK530=`cat /proc/cpuinfo | grep -i s5p4418`
ARTIK10=`cat /proc/cpuinfo | grep -i EXYNOS5`
ARTIK710=`cat /proc/device-tree/model | grep -i -a artik710`

if [ "$ARTIK5" != "" ]; then
        ZIGBEE_TTY="-p /dev/ttySAC1"
	THREAD_TTY="-u /dev/ttySAC1"
	FIRMWARE_FILE=$ARTIK520_FIRMWARE_FILE
	VERSION=$MAJOR_VERSION
	echo "Target is ARTIK520, firmware file $FIRMWARE_FILE will be used"
elif [ "$ARTIK530" != "" ]; then
        ZIGBEE_TTY="-p /dev/ttyAMA1"
	THREAD_TTY="-f x -u /dev/ttyAMA1"
	FIRMWARE_FILE=$ARTIK530_FIRMWARE_FILE
	echo "Target is ARTIK530, firmware file $FIRMWARE_FILE will be used"
elif [ "$ARTIK10" != "" ]; then
        ZIGBEE_TTY="-p /dev/ttySAC0"
        THREAD_TTY="-u /dev/ttySAC0"
	echo "Target is ARTIK1020 that is not supported yet, so stop flashing firmware."
	exit 0
elif [ "$ARTIK710" != "" ]; then # ARTIK 710
        ZIGBEE_TTY="-n 1 -p /dev/ttySAC0"
        THREAD_TTY="-f x -u /dev/ttySAC0"
	FIRMWARE_FILE=$ARTIK710_FIRMWARE_FILE
	VERSION=$MAJOR_VERSION
	echo "Target is ARTIK710, firmware file $FIRMWARE_FILE will be used"
else
	echo "Not supported artik module or inside chroot"
	exit 0
fi

echo "Required firmware version is $VERSION"

echo 'Checking the current firmware'
ZIGBEE_FIRMWARE=$($ZIGBEE_VERSION_TOOL $ZIGBEE_TTY)
#echo "Testing...$ZIGBEE_FIRMWARE"
case "$ZIGBEE_FIRMWARE" in
*"ezsp ver"*)
echo 'Found ZigBee firmware'
	case "$ZIGBEE_FIRMWARE" in
	*"$VERSION"*)
	echo 'Version matched, skip flashing';;
	*)
	echo "Firmware v$VERSION flashing"
	exec $FIRMWARE_FLASHING_TOOL $ZIGBEE_TTY -f $FIRMWARE_FILE -n
	;;
	esac
;;
*)
THREAD_FIRMWARE=$($THREAD_VERSION_TOOL $THREAD_TTY)
#echo "Testing...$THREAD_FIRMWARE"
	case "$THREAD_FIRMWARE" in
	*"Thread"*)
	echo 'Found Thread firmware, skip flashing';;
	*)
	THREAD_FIRMWARE=$($THREAD_VERSION_TOOL $THREAD_TTY)
	#echo "Testing2...$THREAD_FIRMWARE"
		case "$THREAD_FIRMWARE" in
		*"Thread"*)
		echo 'Found Thread firmware, skip flahsing';;
		*)	
		echo 'Both ZigBee firmware and Thread firmware are not detected'
		echo "Firmware v$VERSION flashing"
		exec $FIRMWARE_FLASHING_TOOL $ZIGBEE_TTY -f $FIRMWARE_FILE -n
		;;
		esac
	;;
	esac
;;	
esac
