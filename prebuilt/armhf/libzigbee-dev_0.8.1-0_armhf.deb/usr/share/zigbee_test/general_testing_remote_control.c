#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <string.h>
#include <assert.h>
#include "zigbee.h"

#define KEYBOARD_INPUT_SIZE			100
#define ENDPOINT_REMOTE_CONTROL		10
#define DISCOVERY_MAX_RETRY_COUNT	5
#define TIMEOUT_MSEC				(10*1000)

/* Illuminance attributes */
#define ATTR_ID_00	0x0000	/* MeasuredValue, 16-bit unsigned integer */
#define ATTR_ID_01	0x0001	/* MinMeasuredValue, 16-bit unsigned integer */
#define ATTR_ID_02	0x0002	/* MaxMeasuredValue, 16-bit unsigned integer */
#define ATTR_ID_04	0x0004	/* LightSensorType, 8-bit enum */

enum operation {
	OPT_REQUEST_REPORTING = 1,
	OPT_STOP_REPORTING,
	OPT_ILLUM_READ_REMOTE_ATTRIBUTE,
	OPT_IDENTIFY_READ_REMOTE_ATTRIBUTE,
	OPT_IDENTIRY_WRITE_REMOTE_ATTRIBUTE,
	OPT_READ_REPORTING,
	OPT_DISCOVER_ATTRIBUTE
};

static int discover_timeout_id = -1;
static int discovery_retry_count = 0;
static GMainLoop *mainloop = NULL;

static void _loop_run(void)
{
	if (!mainloop)
		mainloop = g_main_loop_new(NULL, FALSE);

	g_main_loop_run(mainloop);
}

static void _loop_quit(void)
{
	if (!mainloop)
		return;

	g_main_loop_quit(mainloop);
}

static void _illum_request_reporting(const zigbee_endpoint *endpoint,
		ZIGBEE_ATTRIBUTE_ID attribute_id, zigbee_attribute_data_type attribute_type)
{
	struct zigbee_sending_info sending_info;
	int ret = EZ_OK;
	int min_interval = 1;
	int max_interval = 10;
	int threshold = 2;

	sending_info.type = ZIGBEE_SENDING_BY_ENDPOINT;
	memcpy(&sending_info.data.dest_endpoint, endpoint, sizeof(zigbee_endpoint));
	ret = zigbee_general_request_reporting(&sending_info, ZCL_ILLUM_MEASUREMENT_CLUSTER_ID, attribute_id,
			attribute_type, min_interval, max_interval, threshold, ENDPOINT_REMOTE_CONTROL);

	if (EZ_OK == ret)
		printf("Reporting: request reporting for attribute 0x%04X success\n", attribute_id);
	else
		printf("Reporting: request reporting for attribute 0x%04X failed %d\n", attribute_id, ret);
}

static void _request_reporting_test(void)
{
	zigbee_endpoint_list endpoint_list;
	const zigbee_endpoint *endpoint = NULL;
	int i = 0;

	printf("Request reporting test\n");
	zigbee_device_find_by_cluster(&endpoint_list, ZCL_ILLUM_MEASUREMENT_CLUSTER_ID, 1);

	if (endpoint_list.num <= 0) {
		printf("There is no endpoint to send request reporting command\n");
		return;
	}

	for (i = 0; i < endpoint_list.num; i++) {
		endpoint = &endpoint_list.endpoint[i];

		_illum_request_reporting(endpoint, ATTR_ID_00, ZIGBEE_INT16U_ATTRIBUTE_TYPE);
		_illum_request_reporting(endpoint, ATTR_ID_04, ZIGBEE_ENUM8_ATTRIBUTE_TYPE);
	}
}

static void _illum_stop_reporting(const zigbee_endpoint *endpoint, ZIGBEE_ATTRIBUTE_ID attribute_id,
		zigbee_attribute_data_type attribute_type)
{
	struct zigbee_sending_info sending_info;
	int ret = EZ_OK;

	sending_info.type = ZIGBEE_SENDING_BY_ENDPOINT;
	memcpy(&sending_info.data.dest_endpoint, endpoint, sizeof(zigbee_endpoint));
	ret = zigbee_general_stop_reporting(&sending_info, ZCL_ILLUM_MEASUREMENT_CLUSTER_ID, attribute_id,
			attribute_type, ENDPOINT_REMOTE_CONTROL);

	if (EZ_OK == ret)
		printf("Reporting: stop reporting for attribute 0x%04X success\n", attribute_id);
	else
		printf("Reporting: stop reporting for attribute 0x%04X failed %d\n", attribute_id, ret);
}

static void _stop_reporting_test(void)
{
	zigbee_endpoint_list endpoint_list;
	zigbee_endpoint *endpoint = NULL;
	int i = 0;

	printf("Stop reporting test\n");
	zigbee_device_find_by_cluster(&endpoint_list, ZCL_ILLUM_MEASUREMENT_CLUSTER_ID, 1);

	if (endpoint_list.num <= 0) {
		printf("There is no endpoint to send stop reporting command\n");
		return;
	}

	for (i = 0; i < endpoint_list.num; i++) {
		endpoint = &endpoint_list.endpoint[i];

		_illum_stop_reporting(endpoint, ATTR_ID_00, ZIGBEE_INT16U_ATTRIBUTE_TYPE);
		_illum_stop_reporting(endpoint, ATTR_ID_04, ZIGBEE_ENUM8_ATTRIBUTE_TYPE);
	}
}

static void _illum_read_remote_attribute(const zigbee_endpoint *dest_endpoint, ZIGBEE_ATTRIBUTE_ID attribute)
{
	char value[MAX_ATTRIBUTE_SIZE];
	struct zigbee_sending_info sending_info;
	int ret = EZ_OK;
	short short_value = -1;
	char char_value = -1;
	unsigned int read_len = 0;
	zigbee_attribute_data_type value_type = ZIGBEE_UNKNOWN_ATTRIBUTE_TYPE;

	memset(&value, 0, MAX_ATTRIBUTE_SIZE);
	sending_info.type = ZIGBEE_SENDING_BY_ENDPOINT;
	memcpy(&sending_info.data.dest_endpoint, dest_endpoint, sizeof(zigbee_endpoint));
	ret = zigbee_general_read_remote_attribute(&sending_info, ZCL_ILLUM_MEASUREMENT_CLUSTER_ID,
			attribute, value, &read_len, &value_type, ENDPOINT_REMOTE_CONTROL);

	if (EZ_OK == ret) {
		printf("General read remote attribute 0x%04X ", attribute);
		if (sizeof(short_value) == read_len) {
			memcpy(&short_value, value, read_len);
			printf("value %d value length %d value type %d\n", short_value, read_len, value_type);
		} else if (sizeof(char_value) == read_len) {
			memcpy(&char_value, value, read_len);
			printf("value 0x%02X value length %d value type %d\n", char_value, read_len,
					value_type);
		} else
			printf("with unhandled value length %d value type %d\n", read_len, value_type);
	} else
		printf("General read remote attribute 0x%04X value failed %d\n", attribute, ret);
}

static void _illum_read_remote_attribute_test(void)
{
	zigbee_endpoint_list endpoint_list;
	const zigbee_endpoint *endpoint = NULL;
	int i = 0;

	printf("Read remote Illuminance attribute test\n");
	zigbee_device_find_by_cluster(&endpoint_list, ZCL_ILLUM_MEASUREMENT_CLUSTER_ID, 1);
	if (endpoint_list.num <= 0) {
		printf("There is no endpoint to send read remote attribute command\n");
		return;
	}

	for (i = 0; i < endpoint_list.num; i++) {
		endpoint = &endpoint_list.endpoint[i];

		_illum_read_remote_attribute(endpoint, ATTR_ID_00);
		_illum_read_remote_attribute(endpoint, ATTR_ID_01);
		_illum_read_remote_attribute(endpoint, ATTR_ID_02);
		_illum_read_remote_attribute(endpoint, ATTR_ID_04);
	}
}

static void _identify_read_remote_attribute_test(void)
{
	zigbee_endpoint_list endpoint_list;
	struct zigbee_sending_info sending_info;
	int i = 0;

	char value[MAX_ATTRIBUTE_SIZE];
	int ret = EZ_OK;
	unsigned short short_value = 0;
	unsigned int read_len = 0, value_type = 0;

	printf("Read remote Identify attribute test\n");
	zigbee_device_find_by_cluster(&endpoint_list, ZCL_IDENTIFY_CLUSTER_ID, 1);
	if (endpoint_list.num <= 0) {
		printf("There is no endpoint to send read remote attribute command\n");
		return;
	}

	sending_info.type = ZIGBEE_SENDING_BY_ENDPOINT;
	for (i = 0; i < endpoint_list.num; i++) {
		memcpy(&sending_info.data.dest_endpoint, &endpoint_list.endpoint[i], sizeof(zigbee_endpoint));
		memset(&value, 0, MAX_ATTRIBUTE_SIZE);
		ret = zigbee_general_read_remote_attribute(&sending_info, ZCL_IDENTIFY_CLUSTER_ID,
				ZCL_IDENTIFY_TIME_ATTRIBUTE_ID, value, &read_len, &value_type,
				ENDPOINT_REMOTE_CONTROL);

		printf("General read remote attribute 0x%04X value", ZCL_IDENTIFY_TIME_ATTRIBUTE_ID);
		if (EZ_OK == ret) {
			if (sizeof(short_value) == read_len) {
				memcpy(&short_value, value, read_len);
				printf(" %d value length %d value type %d\n", short_value, read_len, value_type);
			} else
				printf(" with unhandled value length %d value type %d\n", read_len, value_type);
		} else
			printf(" failed %d\n", ret);
	}
}

static void _identify_write_remote_attribute_test(void)
{
	zigbee_endpoint_list endpoint_list;
	struct zigbee_sending_info sending_info;
	int i = 0;
	unsigned short ushort_val = 0;
	int ret = EZ_OK;

	printf("Write remote identify attribute test\n");
	zigbee_device_find_by_cluster(&endpoint_list, ZCL_IDENTIFY_CLUSTER_ID, 1);
	if (endpoint_list.num <= 0) {
		printf("There is no endpoint to send write remote identify attribute command\n");
		return;
	}

	for (i = 0; i < endpoint_list.num; i++) {
		sending_info.type = ZIGBEE_SENDING_BY_ENDPOINT;
		memcpy(&sending_info.data.dest_endpoint, &endpoint_list.endpoint[i], sizeof(zigbee_endpoint));

		ushort_val = 60;
		printf("General write remote value %d attribute 0x%04X type 0x%02X", ushort_val,
				ZCL_IDENTIFY_TIME_ATTRIBUTE_ID, ZIGBEE_INT16U_ATTRIBUTE_TYPE);

		ret = zigbee_general_write_remote_attribute(&sending_info, ZCL_IDENTIFY_CLUSTER_ID,
				ZCL_IDENTIFY_TIME_ATTRIBUTE_ID, &ushort_val, sizeof(ushort_val),
				ZIGBEE_INT16U_ATTRIBUTE_TYPE, ENDPOINT_REMOTE_CONTROL);

		if (EZ_OK == ret) {
			printf(" success\n");
		} else
			printf(" failed %d\n", ret);
	}
}

static void _illum_read_reporting(const zigbee_endpoint *dest_endpoint,
								  ZIGBEE_ATTRIBUTE_ID attribute)
{
	struct zigbee_sending_info sending_info;
	zigbee_reporting_info reporting_info;
	int ret = EZ_OK;

	sending_info.type = ZIGBEE_SENDING_BY_ENDPOINT;
	memcpy(&sending_info.data.dest_endpoint, dest_endpoint, sizeof(zigbee_endpoint));
	ret = zigbee_general_read_reporting_config(&sending_info, ZCL_ILLUM_MEASUREMENT_CLUSTER_ID,
											   attribute, &reporting_info, ENDPOINT_REMOTE_CONTROL);

	if (EZ_OK == ret)
		printf("get read reporting cluster:0x%04X attr:0x%04X min_interval:"
			   "%d max_interval:%d reportable_change:%d\n",
				reporting_info.cluster_id,
				reporting_info.attribute_id,
				reporting_info.reported.min_interval,
				reporting_info.reported.max_interval,
				reporting_info.reported.reportable_change);
	else if (EZ_NOT_FOUND == ret) {
		printf("not configurated reporting for cluster:0x%04X attr:0x%04X\n",
				ZCL_ILLUM_MEASUREMENT_CLUSTER_ID, attribute);
		printf("Done\n");
	} else {
		printf("read reporting failed\n");
		printf("Done\n");
	}
}

static void _read_reporting_test(void)
{
	zigbee_endpoint_list endpoint_list;
	const zigbee_endpoint *endpoint = NULL;
	int i = 0;

	zigbee_device_find_by_cluster(&endpoint_list,
								  ZCL_ILLUM_MEASUREMENT_CLUSTER_ID, 1);
	if (endpoint_list.num <= 0) {
		printf("There is no endpoint to send read reporting command\n");
		return;
	}

	for (i = 0; i < endpoint_list.num; i++) {
		endpoint = &endpoint_list.endpoint[i];
		_illum_read_reporting(endpoint, ATTR_ID_00);
		_illum_read_reporting(endpoint, ATTR_ID_04);
	}
}

static void _discover_attribute_test(void)
{
	zigbee_endpoint_list endpoint_list;
	struct zigbee_discovery_attributes attr_list;
	struct zigbee_sending_info sending_info;
	int i = 0, j = 0;
	int ret = EZ_OK;

	printf("Discover attribute test\n");
	zigbee_device_find_by_cluster(&endpoint_list, ZCL_IDENTIFY_CLUSTER_ID, 1);
	if (endpoint_list.num <= 0) {
		printf("There is no endpoint to send discover attribute command\n");
		return;
	}

	for (i = 0; i < endpoint_list.num; i++) {
		sending_info.type = ZIGBEE_SENDING_BY_ENDPOINT;
		memcpy(&sending_info.data.dest_endpoint, &endpoint_list.endpoint[i], sizeof(zigbee_endpoint));

		printf("General discover for cluster 0x%04X ", ZCL_IDENTIFY_CLUSTER_ID);

		ret = zigbee_general_discover_attribute(&sending_info, ZCL_IDENTIFY_CLUSTER_ID,
				ZCL_IDENTIFY_TIME_ATTRIBUTE_ID, MAX_DISCOVER_ATTRITUTES, &attr_list,
				ENDPOINT_REMOTE_CONTROL);

		if (EZ_OK == ret) {
			printf("attribute count %d discovery complete %d\n", attr_list.attribute_count,
					attr_list.discovery_complete);
			for (j = 0; j < attr_list.attribute_count; j++)
				printf("index %d attribute 0x%04X attribute type 0x%02X\n", j,
						attr_list.attributes[j].id, attr_list.attributes[j].type);
		} else
			printf("failed %d\n", ret);
	}
}

static void _show_operations(void)
{
	printf("======================\n");
	printf("q: Quit\n");
	printf("%d: Request Illuminance reporting\n", OPT_REQUEST_REPORTING);
	printf("%d: Stop Illuminance reporting\n", OPT_STOP_REPORTING);
	printf("%d: Read remote illuminance attributes\n", OPT_ILLUM_READ_REMOTE_ATTRIBUTE);
	printf("%d: Read remote identify attributes\n", OPT_IDENTIFY_READ_REMOTE_ATTRIBUTE);
	printf("%d: Write remote identify attribute\n", OPT_IDENTIRY_WRITE_REMOTE_ATTRIBUTE);
	printf("%d: Read reporting\n", OPT_READ_REPORTING);
	printf("%d: Discover attribute\n", OPT_DISCOVER_ATTRIBUTE);
	printf("Please select operation: ");
	fflush(stdout);
}

bool _read_q(char *input, int max_size)
{
	if (input[0] == 'q' || input[0] == 'Q')
		return true;
	else
		return false;
}

bool _read_lf(char *input, int max_size)
{
	if (input[0] == '\n')
		return true;
	else
		return false;
}

static int _get_digit(char c)
{
	if (c >= '0' && c <= '9')
		return c - '0';

	return -1;
}

static int _get_hex(char c)
{
	if (c >= '0' && c <= '9')
		return c - '0';

	if (c >= 'A' && c <= 'F')
		return c - 'A' + 10;

	if (c >= 'a' && c <= 'f')
		return c - 'a' + 10;

	return -1;
}

static int _read_hex(char *input, int max_size)
{
	int i;
	int result;
	char c;

	result = 0;

	for (i = 0; i < max_size; i++) {
		c = input[i];

		if (_get_hex(c) < 0)
			break;

		result *= 16;
		result += _get_hex(c);
	}

	return result;
}

static int _read_digit(char *input, int max_size)
{
	int i;
	int result;
	char c;

	result = 0;

	for (i = 0; i < max_size; i++) {
		c = input[i];

		if (_get_digit(c) < 0)
			break;

		result *= 10;
		result += _get_digit(c);
	}

	return result;
}

static int _read_int(char *input, int max_size, int default_value)
{
	int i;
	char c;

	for (i = 0; i < max_size; i++) {
		c = input[i];

		if (c == 0 || c == '\n')
			break;

		if (c == '0' && (i + 3) < max_size && (input[i + 1] == 'x' || input[i + 1] == 'X')
				&& _get_hex(input[i + 2]) >= 0 && _get_hex(input[i + 3]) >= 0) {
			return _read_hex(&input[i + 2], max_size - (i + 2));
		}

		if (_get_digit(c) >= 0)
			return _read_digit(&input[i], max_size - i);
	}

	return default_value;
}

static void _on_handle_input_data(char *input, int max_size)
{
	int n = 0;

	if (NULL == input) {
		_show_operations();
		return;
	}

	if (_read_q(input, max_size) == true) {
		_loop_quit();
		return;
	}

	if (_read_lf(input, max_size) == true) {
		_show_operations();
		return;
	}

	n = _read_int(input, max_size, -1);

	switch (n) {
	case OPT_REQUEST_REPORTING:
		_request_reporting_test();
		return;

	case OPT_STOP_REPORTING:
		_stop_reporting_test();
		return;

	case OPT_ILLUM_READ_REMOTE_ATTRIBUTE:
		_illum_read_remote_attribute_test();
		return;

	case OPT_IDENTIFY_READ_REMOTE_ATTRIBUTE:
		_identify_read_remote_attribute_test();
		return;

	case OPT_IDENTIRY_WRITE_REMOTE_ATTRIBUTE:
		_identify_write_remote_attribute_test();
		return;

	case OPT_READ_REPORTING:
		_read_reporting_test();
		return;

	case OPT_DISCOVER_ATTRIBUTE:
		_discover_attribute_test();
		return;

	default:
		break;
	}

	printf("\ninvalid input, please try again: ");
	fflush(stdout);
}

static gboolean _on_keyboard_received(GIOChannel *channel, GIOCondition cond, gpointer user_data)
{
	char input[KEYBOARD_INPUT_SIZE];
	int fd = g_io_channel_unix_get_fd(channel);

	if (fd != STDIN_FILENO)
		printf("Wrong fd: %d\n", fd);

	if (cond != G_IO_IN && cond != G_IO_ERR && cond != G_IO_HUP && cond != G_IO_NVAL)
		printf("Wrong cond: %d\n", cond);

	if (user_data)
		printf("Wrong user data: %p\n", user_data);

	if (fgets(input, KEYBOARD_INPUT_SIZE, stdin) == NULL)
		return TRUE;

	_on_handle_input_data(input, KEYBOARD_INPUT_SIZE);

	return TRUE;
}

static int _network_start(zigbee_network_state *state)
{
	int ret = EZ_OK;

	ret = zigbee_network_start(state);
	if (EZ_OK != ret)
		printf("network_start error %d\n", ret);

	return ret;
}

static void _device_discover(void)
{
	int ret = EZ_OK;

	printf("Device discovery ...\n");
	ret = zigbee_device_discover();
	if (EZ_OK != ret) {
		printf("Device discover error %d", ret);
		_loop_quit();
	}
}

static int _commissioning_target_start(void)
{
	int ret = EZ_OK;

	/* Commissioning target start */
	ret = zigbee_ezmode_commissioning(ENDPOINT_REMOTE_CONTROL, false, true);

	if (EZ_OK == ret) {
		printf("Commissioning target start...\n");
	} else
		printf("Commissioning target start failed: %d\n", ret);

	return ret;
}

static void _on_commissioning_status(zigbee_commissioning_state commissioning_state)
{
	switch (commissioning_state) {
	case COMMISSIONING_ERROR:
		printf("Commissioning: error\n");
		_loop_quit();
		break;
	case COMMISSIONING_ERR_IN_PROGRESS:
		printf("Commissioning: error in progress, please wait\n");
		break;
	case COMMISSIONING_NETWORK_STEERING_FORM:
		printf("Commissioning: network steering form\n");
		break;
	case COMMISSIONING_NETWORK_STEERING_SUCCESS:
		printf("Commissioning: network steering success\n");
		break;
	case COMMISSIONING_NETWORK_STEERING_FAILED:
		printf("Commissioning: network steering failed\n");
		_loop_quit();
		break;
	case COMMISSIONING_WAIT_NETWORK_STEERING:
		printf("Commissioning: wait for network steering\n");
		break;
	case COMMISSIONING_TARGET_SUCCESS:
		printf("Commissioning: target success, Please run initiator\n");
		_device_discover();
		break;
	case COMMISSIONING_TARGET_FAILED:
		printf("Commissioning: target failed\n");
		_loop_quit();
		break;
	case COMMISSIONING_TARGET_STOP:
		printf("Commissioning: target stopped\n");
		break;
	default:
		printf("Commissioning: Other status\n");
		_loop_quit();
		break;
	}
}

static void _on_report_attribute(zigbee_report_attribute_info * report_attr_info)
{
	if (report_attr_info->attribute_type == ZIGBEE_ATTR_ILLUMINANCE) {
		printf("Report attribute: Illuminance: %d\n", report_attr_info->data.value);
	}
}

static void _on_report_general_attribute(struct zigbee_general_report_attribute_info *general_report)
{
	unsigned char value_ch = 0;

	printf("Genearal report: cluster 0x%04X attribute 0x%04X data type 0x%02X data length %d ",
			general_report->cluster_id, general_report->attribute_id, general_report->data_type,
			general_report->data_length);
	if (ZIGBEE_ENUM8_ATTRIBUTE_TYPE == general_report->data_type
			&& sizeof(value_ch) == general_report->data_length) {
		memcpy(&value_ch, general_report->data, general_report->data_length);
		printf("value 0x%02X\n", value_ch);
	} else
		printf("Unhandled\n");
}

static gboolean _discover_timeout_callback(gpointer user_data)
{
	discover_timeout_id = -1;
	discovery_retry_count++;
	if (discovery_retry_count <= DISCOVERY_MAX_RETRY_COUNT) {
		printf("Device discover timeout, retry\n");
		_device_discover();
	} else {
		printf("Retry Discovery Max\n");
		_loop_quit();
	}
	return TRUE;
}

static int _loop_add_timeout_callback(int *timeout_id, unsigned int msec, GSourceFunc callback,
		void *user_data)
{
	GSource *source = NULL;

	if (NULL == callback || NULL == timeout_id)
		return EZ_BAD_ARGS;

	source = g_timeout_source_new(msec);
	g_source_set_priority(source, G_PRIORITY_HIGH);
	g_source_set_callback(source, callback, user_data, NULL);
	*timeout_id = g_source_attach(source, NULL);
	g_source_unref(source);

	return EZ_OK;
}

static int _loop_remove_timeout_callback(int timeout_id)
{
	gboolean ret;

	if (timeout_id < 0)
		return EZ_BAD_ARGS;

	ret = g_source_remove((guint)timeout_id);
	if (FALSE == ret)
		return EZ_BAD_ARGS;

	return EZ_OK;
}

static void _on_device_discovery(zigbee_device_discovery *device_discovery)
{
	switch (device_discovery->status) {
	case ZIGBEE_DEVICE_DISCOVERY_START:
		printf("Device discovery start\n");
		break;
	case ZIGBEE_DEVICE_DISCOVERY_FOUND:
		printf("Device discovery found device id 0x%04X\n", device_discovery->device.node_id);
		break;
	case ZIGBEE_DEVICE_DISCOVERY_IN_PROGRESS:
		printf("Device discovery in progress\n");
		/* When discover_timeout_id is not -1, there has existed a timer,
		 * so we just remove the timer and add a new timer */
		if (discover_timeout_id >= 0) {
			_loop_remove_timeout_callback(discover_timeout_id);
			discover_timeout_id = -1;
		}

		if (EZ_OK != _loop_add_timeout_callback(&discover_timeout_id, TIMEOUT_MSEC,
						_discover_timeout_callback, NULL))
			_loop_quit();
		break;
	case ZIGBEE_DEVICE_DISCOVERY_DONE:
		printf("Device discovery finished\n");
		if (discover_timeout_id >= 0) {
			_loop_remove_timeout_callback(discover_timeout_id);
			discover_timeout_id = -1;
		}
		_show_operations();
		break;
	case ZIGBEE_DEVICE_DISCOVERY_NO_DEVICE:
		printf("Device discovery no device\n");
		if (discover_timeout_id >= 0) {
			_loop_remove_timeout_callback(discover_timeout_id);
			discover_timeout_id = -1;
		}
		discovery_retry_count++;
		if (discovery_retry_count <= DISCOVERY_MAX_RETRY_COUNT) {
			sleep(5);
			_device_discover();
		} else {
			printf("Retry Discovery Max\n");
			_loop_quit();
		}
		break;
	case ZIGBEE_DEVICE_DISCOVERY_ERROR:
		printf("Device discovery error\n");
		_loop_quit();
		break;
	case ZIGBEE_DEVICE_DISCOVERY_CHANGED:
		printf("Device discovery changed device id 0x%04X\n", device_discovery->device.node_id);
		break;
	case ZIGBEE_DEVICE_DISCOVERY_LOST:
		printf("Device discovery lost device id 0x%04X\n", device_discovery->device.node_id);
		break;
	default:
		printf("Discovery device unknown result\n");
		_loop_quit();
		break;
	}
}

static void _on_callback(void *user_data, zigbee_response_type response_type, void *payload)
{
	switch (response_type) {
	case ZIGBEE_RESPONSE_DEVICE_DISCOVER:
		_on_device_discovery((zigbee_device_discovery *)payload);
		break;
	case ZIGBEE_RESPONSE_COMMISSIONING_STATUS:
		_on_commissioning_status(*(zigbee_commissioning_state *)payload);
		break;
	case ZIGBEE_RESPONSE_REPORT_ATTRIBUTE:
		_on_report_attribute((zigbee_report_attribute_info *)payload);
		break;
	case ZIGBEE_RESPONSE_GENERAL_REPORT_ATTRIBUTE:
		_on_report_general_attribute((struct zigbee_general_report_attribute_info *)payload);
		break;
	default:
		break;
	}
}

static int _create_REMOTE_CONTROL_device(void)
{
	int ret = EZ_OK;
	zigbee_local_endpoint_info endpoint_info;

	memset(&endpoint_info, 0, sizeof(zigbee_local_endpoint_info));
	endpoint_info.endpoints[endpoint_info.count].profile = ZIGBEE_PROFILE_HA;
	endpoint_info.endpoints[endpoint_info.count].endpoint_id = ENDPOINT_REMOTE_CONTROL;
	endpoint_info.endpoints[endpoint_info.count].device_id = DEVICE_REMOTE_CONTROL;
	endpoint_info.count++;

	ret = zigbee_set_local_endpoint(&endpoint_info);
	if (EZ_OK != ret)
		printf("Set local endpoint error %d", ret);

	return ret;
}

static int _reset(void)
{
	int ret = EZ_OK;

	printf("Start reset\n");
	ret = zigbee_reset_local();
	if (EZ_OK != ret)
		printf("Reset failed: %d\n", ret);

	return ret;
}

static void _show_usage(void)
{
	printf("===================================================================================\n");
	printf("usage:\n");
	printf("<application name> [arguments]\n");
	printf("[--reset]         , Reset device\n");
	printf("without argument  , Run ezmode commissioning to establish a network\n");
	printf("===================================================================================\n");
}

int main(int argc, char *argv[])
{
	zigbee_network_state state = ZIGBEE_NO_NETWORK;
	int i = 0;
	int ret = EZ_OK;
	bool need_reset = false;
	GIOChannel *channel = NULL;

	if (argc > 1) {
		for (i = 1; i < argc; i++) {
			if (!strcmp(argv[i], "--reset"))
				need_reset = true;
			if (!strcmp(argv[i], "--help")) {
				_show_usage();
				return -1;
			}
		}
	}

	ret = _create_REMOTE_CONTROL_device();
	if (EZ_OK != ret)
		goto free_quit;

	ret = zigbee_initialize(_on_callback, NULL);
	if (EZ_OK != ret)
		goto free_quit;

	ret = _network_start(&state);
	if (EZ_OK != ret)
		goto free_quit;

	if (true == need_reset) {
		ret = _reset();
		if (EZ_OK != ret)
			goto free_quit;
		state = ZIGBEE_NO_NETWORK;
	}

	ret = _commissioning_target_start();
	if (EZ_OK != ret)
		goto free_quit;

	channel = g_io_channel_unix_new(STDIN_FILENO);
	g_io_add_watch(channel, G_IO_IN | G_IO_ERR | G_IO_HUP | G_IO_NVAL, _on_keyboard_received, NULL);
	g_io_channel_set_flags(channel, G_IO_FLAG_NONBLOCK, NULL);
	g_io_channel_unref(channel);

	_loop_run();

free_quit:
	zigbee_deinitialize();

	return 0;
}
