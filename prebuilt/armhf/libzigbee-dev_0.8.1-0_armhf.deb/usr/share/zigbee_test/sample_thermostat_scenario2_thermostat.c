#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <string.h>
#include <assert.h>
#include "zigbee.h"

#define KEYBOARD_INPUT_SIZE					100
#define ENDPOINT_THERMOSTAT_CONTROL			32
#define EASY_PJOIN_DURATION					0x3C
#define SERVICE_MONITOR_TIME				1000
#define TIMEOUT_MSEC						(10*1000)
#define DISCOVERY_MAX_RETRY_COUNT			5

static const char *mode_off = "Off";
static const char *mode_heat = "Heat";
static const char *mode_cool = "Cool";
static const char *mode_unsupport = "Unsupport";

static int discover_timeout_id = -1;
static int discovery_retry_count;
static GMainLoop *mainloop;
static short g_temperature;
static short g_requested_heating_point;
static short g_requested_cooling_point;
static zigbee_thermostat_system_mode g_requested_system_mode;
static zigbee_occupancy_status g_occupy_status;
static struct zigbee_sending_info sending_info_temp;
static struct zigbee_sending_info sending_info_occupy;
static struct zigbee_sending_info sending_info_fan;
static int _node_count;

typedef void(*func)(char *input, int max_size);
static func current_func;
static void _func_entrance(char *input, int max_size);

enum operation {
	OPT_SYSTEM_MODE_TO_HEAT = 1,
	OPT_SYSTEM_MODE_TO_COOL,
	OPT_SYSTEM_MODE_TO_OFF,
	OPT_SET_HEATING_SETPOINT,
	OPT_SET_COOLING_SETPOINT
};

static void _func_entry(func func)
{
	current_func = func;
	current_func(NULL, 0);
}

static void _show_operations(void)
{
	printf("======================\n");
	printf("%d: Set system mode to heat\n", OPT_SYSTEM_MODE_TO_HEAT);
	printf("%d: Set system mode to cool\n", OPT_SYSTEM_MODE_TO_COOL);
	printf("%d: Set system mode to off\n", OPT_SYSTEM_MODE_TO_OFF);
	printf("%d: Set heating setpoint\n", OPT_SET_HEATING_SETPOINT);
	printf("%d: Set cooling setpoint\n", OPT_SET_COOLING_SETPOINT);
	printf("Please select operation: ");
	fflush(stdout);
}

static bool _read_lf(char *input, int max_size)
{
	if (input[0] == '\n')
		return true;
	else
		return false;
}

static int _get_digit(char c)
{
	if (c >= '0' && c <= '9')
		return c - '0';

	return -1;
}

static int _read_digit(char *input, int max_size)
{
	int i;
	int result;
	char c;

	result = 0;

	for (i = 0; i < max_size; i++) {
		c = input[i];

		if (_get_digit(c) < 0)
			break;

		result *= 10;
		result += _get_digit(c);
	}

	return result;
}

static int _get_hex(char c)
{
	if (c >= '0' && c <= '9')
		return c - '0';

	if (c >= 'A' && c <= 'F')
		return c - 'A' + 10;

	if (c >= 'a' && c <= 'f')
		return c - 'a' + 10;

	return -1;
}

static int _read_hex(char *input, int max_size)
{
	int i;
	int result;
	char c;

	result = 0;

	for (i = 0; i < max_size; i++) {
		c = input[i];

		if (_get_hex(c) < 0)
			break;

		result *= 16;
		result += _get_hex(c);
	}

	return result;
}

static int _read_int(char *input, int max_size, int default_value)
{
	int i;
	char c;

	for (i = 0; i < max_size; i++) {
		c = input[i];

		if (c == 0 || c == '\n')
			break;

		if (c == '0' && (i + 3) < max_size && (input[i + 1] == 'x' || input[i + 1] == 'X')
				&& _get_hex(input[i + 2]) >= 0 && _get_hex(input[i + 3]) >= 0) {
			return _read_hex(&input[i + 2], max_size - (i + 2));
		}

		if (_get_digit(c) >= 0)
			return _read_digit(&input[i], max_size - i);
	}

	return default_value;
}

static void _loop_quit(void)
{
	if (!mainloop)
		return;

	g_main_loop_quit(mainloop);
}

static void _device_discover(void)
{
	int ret = EZ_OK;

	printf("Device discovery ...\n");
	ret = zigbee_device_discover();
	if (EZ_OK != ret) {
		printf("Device discover error %d", ret);
		_loop_quit();
	}
}

static int _network_start(zigbee_network_state *state)
{
	int ret = EZ_OK;

	ret = zigbee_network_start(state);
	if (EZ_OK != ret)
		printf("network_start error %d\n", ret);

	return ret;
}

static const char *_get_system_mode_description(zigbee_thermostat_system_mode mode)
{
	switch (mode) {
	case ZIGBEE_SYSTEM_MODE_OFF:
		return mode_off;
	case ZIGBEE_SYSTEM_MODE_COOL:
		return mode_cool;
	case ZIGBEE_SYSTEM_MODE_HEAT:
		return mode_heat;
	default:
		return mode_unsupport;
	}
}

static void _set_thermostat_mode(zigbee_thermostat_system_mode mode)
{
	int ret = EZ_OK;

	ret = zigbee_thermostat_set_system_mode(ENDPOINT_THERMOSTAT_CONTROL, mode);

	if (EZ_OK != ret)
		printf("Set thermostat mode (%d) failed\n", mode);
}

static void _open_fan(bool open)
{
	int ret = EZ_OK;
	uint8_t mode = ZIGBEE_FAN_MODE_AUTO;	/* Auto mode */

	if (false == open)
		mode = ZIGBEE_FAN_MODE_OFF;

	ret = zigbee_general_write_remote_attribute(&sending_info_fan,
												ZCL_FAN_CONTROL_CLUSTER_ID,
												ZCL_FAN_CONTROL_FAN_MODE_ATTRIBUTE_ID,
												&mode, sizeof(uint8_t),
												ZIGBEE_ENUM8_ATTRIBUTE_TYPE,
												ENDPOINT_THERMOSTAT_CONTROL);
	if (EZ_OK != ret)
		printf("Set fan mode failed\n");
}

static bool _service_monitor(void)
{
	zigbee_thermostat_system_mode mode = 0;

	if (EZ_OK != zigbee_thermostat_get_system_mode(ENDPOINT_THERMOSTAT_CONTROL, &mode)) {
		printf("get local system mode error\n");
		return false;
	}

	/* if room is empty, turn off thermostat and fan */
	if (ZIGBEE_UNOCCUPIED == g_occupy_status) {
		if (ZIGBEE_SYSTEM_MODE_OFF != mode) {
			_set_thermostat_mode(ZIGBEE_SYSTEM_MODE_OFF);
			_open_fan(false);
			printf("Room is empty, thermostat won't work\n");
		}
		return true;
	}

	if (ZIGBEE_SYSTEM_MODE_COOL == g_requested_system_mode) {
		if (g_temperature > g_requested_cooling_point && ZIGBEE_SYSTEM_MODE_COOL != mode) {
			_set_thermostat_mode(ZIGBEE_SYSTEM_MODE_COOL);
			_open_fan(true);
			printf("Current temperature(%d) is higher than (%d), start cooling\n",
					g_temperature/100, g_requested_cooling_point/100);
		}

		if (g_temperature <= g_requested_cooling_point && ZIGBEE_SYSTEM_MODE_OFF != mode) {
			_set_thermostat_mode(ZIGBEE_SYSTEM_MODE_OFF);
			_open_fan(false);
			printf("Current temperature(%d) is lower or equal than (%d), stop cooling\n",
					g_temperature/100, g_requested_cooling_point/100);
		}
	} else if (ZIGBEE_SYSTEM_MODE_HEAT == g_requested_system_mode) {
		if (g_temperature < g_requested_heating_point && ZIGBEE_SYSTEM_MODE_HEAT != mode) {
			_set_thermostat_mode(ZIGBEE_SYSTEM_MODE_HEAT);
			_open_fan(true);
			printf("Current temperature(%d) is lower than (%d), start heating\n",
					g_temperature/100, g_requested_heating_point/100);
		}

		if (g_temperature >= g_requested_heating_point && ZIGBEE_SYSTEM_MODE_OFF != mode) {
			_set_thermostat_mode(ZIGBEE_SYSTEM_MODE_OFF);
			_open_fan(false);
			printf("Current temperature(%d) is higher or equal than (%d), stop heating\n",
					g_temperature/100, g_requested_heating_point/100);
		}
	} else if (ZIGBEE_SYSTEM_MODE_OFF == g_requested_system_mode) {
		if (ZIGBEE_SYSTEM_MODE_OFF != mode)
			_set_thermostat_mode(ZIGBEE_SYSTEM_MODE_OFF);
		_open_fan(false);
	} else
		printf("unsupport system mode (%d)\n", mode);

	return true;
}

static void _func_set_heating_setpoint(char *input, int max_size)
{
	int n = 0;
	short temp =  0;
	int ret = EZ_ERROR;

	if (NULL == input)
		return;

	if (_read_lf(input, max_size) == true) {
		_show_operations();
		return;
	}

	n = _read_int(input, max_size, -1);

	temp = n * 100;

	ret = zigbee_thermostat_set_occupied_heating_setpoint(ENDPOINT_THERMOSTAT_CONTROL, temp);

	if (EZ_OK == ret) {
		g_requested_heating_point = temp;
		printf("Set heating setpoint to %d degree success\n", n);
		if (!_service_monitor())
			_loop_quit();
	} else
		printf("Set heating setpoint to %d degree error: %d\n", n, ret);

	_func_entry(_func_entrance);
}

static void _func_set_cooling_setpoint(char *input, int max_size)
{
	int n = 0;
	short temp =  0;
	int ret = EZ_ERROR;

	if (NULL == input)
		return;

	if (_read_lf(input, max_size) == true) {
		_show_operations();
		return;
	}

	n = _read_int(input, max_size, -1);

	temp = n * 100;

	ret = zigbee_thermostat_set_occupied_cooling_setpoint(ENDPOINT_THERMOSTAT_CONTROL, temp);

	if (EZ_OK == ret) {
		g_requested_cooling_point = temp;
		printf("Set cooling setpoint to %d degree success\n", n);
		if (!_service_monitor())
			_loop_quit();
	} else
		printf("Set cooling setpoint to %d degree error: %d\n", n, ret);

	_func_entry(_func_entrance);
}

static void _func_entrance(char *input, int max_size)
{
	int n = 0;
	int ret = EZ_ERROR;

	if (NULL == input) {
		_show_operations();
		return;
	}

	if (_read_lf(input, max_size) == true) {
		_show_operations();
		return;
	}

	n = _read_int(input, max_size, -1);

	switch (n) {
	case OPT_SYSTEM_MODE_TO_HEAT:
		ret = zigbee_thermostat_set_system_mode(ENDPOINT_THERMOSTAT_CONTROL, ZIGBEE_SYSTEM_MODE_HEAT);
		if (EZ_OK == ret)
			printf("Write heat system mode %d success\n", ZIGBEE_SYSTEM_MODE_HEAT);
		else
			printf("Write heat system mode %d error: %d\n", ZIGBEE_SYSTEM_MODE_HEAT, ret);
		return;

	case OPT_SYSTEM_MODE_TO_COOL:
		ret = zigbee_thermostat_set_system_mode(ENDPOINT_THERMOSTAT_CONTROL, ZIGBEE_SYSTEM_MODE_COOL);
		if (EZ_OK == ret)
			printf("Write cool system mode %d success\n", ZIGBEE_SYSTEM_MODE_COOL);
		else
			printf("Write cool system mode %d error: %d\n", ZIGBEE_SYSTEM_MODE_COOL, ret);
		return;

	case OPT_SYSTEM_MODE_TO_OFF:
		ret = zigbee_thermostat_set_system_mode(ENDPOINT_THERMOSTAT_CONTROL, ZIGBEE_SYSTEM_MODE_OFF);
		if (EZ_OK == ret)
			printf("Write off system mode %d success\n", ZIGBEE_SYSTEM_MODE_OFF);
		else
			printf("Write off system mode %d error: %d\n", ZIGBEE_SYSTEM_MODE_OFF, ret);
		return;

	case OPT_SET_HEATING_SETPOINT:
		printf("Please set the heating setpoint:\n");
		_func_entry(_func_set_heating_setpoint);
		return;

	case OPT_SET_COOLING_SETPOINT:
		printf("Please set the cooling setpoint:\n");
		_func_entry(_func_set_cooling_setpoint);
		return;

	default:
		break;
	}

	printf("\ninvalid input, please try again: ");
	fflush(stdout);
}

static gboolean _on_keyboard_received(GIOChannel *channel, GIOCondition cond, gpointer user_data)
{
	char input[KEYBOARD_INPUT_SIZE];
	int fd = g_io_channel_unix_get_fd(channel);

	if (fd != STDIN_FILENO)
		printf("Wrong fd: %d\n", fd);

	if (cond != G_IO_IN && cond != G_IO_ERR && cond != G_IO_HUP && cond != G_IO_NVAL)
		printf("Wrong cond: %d\n", cond);

	if (user_data)
		printf("Wrong user data: %p\n", user_data);

	if (fgets(input, KEYBOARD_INPUT_SIZE, stdin) == NULL)
		return TRUE;

	current_func(input, KEYBOARD_INPUT_SIZE);

	return TRUE;
}

static int _set_sending_info_temp(void)
{
	int ret = EZ_ERROR;
	zigbee_endpoint *remote_ep = NULL;
	zigbee_endpoint_list remote_eps;

	ret = zigbee_device_find_by_cluster(&remote_eps, ZCL_TEMP_MEASUREMENT_CLUSTER_ID, 1);
	if (EZ_OK != ret) {
		printf("Find remote device by server cluster 0x%04X error: %d\n", ZCL_TEMP_MEASUREMENT_CLUSTER_ID, ret);
		return ret;
	}

	if (remote_eps.num <= 0) {
		printf("There is no remote endpoint for server cluster 0x%04X\n", ZCL_TEMP_MEASUREMENT_CLUSTER_ID);
		return ret;
	}

	remote_ep = &remote_eps.endpoint[0];
	sending_info_temp.type = ZIGBEE_SENDING_BY_ENDPOINT;
	memcpy(&sending_info_temp.data.dest_endpoint, remote_ep, sizeof(zigbee_endpoint));

	return EZ_OK;
}

static int _set_sending_info_occupy(void)
{
	int ret = EZ_ERROR;
	zigbee_endpoint *remote_ep = NULL;
	zigbee_endpoint_list remote_eps;

	ret = zigbee_device_find_by_cluster(&remote_eps, ZCL_OCCUPANCY_SENSING_CLUSTER_ID, 1);
	if (EZ_OK != ret) {
		printf("Find remote device by server cluster 0x%04X error: %d\n", ZCL_OCCUPANCY_SENSING_CLUSTER_ID, ret);
		return ret;
	}

	if (remote_eps.num <= 0) {
		printf("There is no remote endpoint for server cluster 0x%04X\n", ZCL_OCCUPANCY_SENSING_CLUSTER_ID);
		return ret;
	}

	remote_ep = &remote_eps.endpoint[0];
	sending_info_occupy.type = ZIGBEE_SENDING_BY_ENDPOINT;
	memcpy(&sending_info_occupy.data.dest_endpoint, remote_ep, sizeof(zigbee_endpoint));

	return EZ_OK;
}

static int _set_sending_info_fan(void)
{
	int ret = EZ_ERROR;
	zigbee_endpoint *remote_ep = NULL;
	zigbee_endpoint_list remote_eps;

	ret = zigbee_device_find_by_cluster(&remote_eps, ZCL_FAN_CONTROL_CLUSTER_ID, 1);
	if (EZ_OK != ret) {
		printf("Find remote device by server cluster 0x%04X error: %d\n", ZCL_FAN_CONTROL_CLUSTER_ID, ret);
		return ret;
	}

	if (remote_eps.num <= 0) {
		printf("There is no remote endpoint for server cluster 0x%04X\n", ZCL_FAN_CONTROL_CLUSTER_ID);
		return ret;
	}

	remote_ep = &remote_eps.endpoint[0];
	sending_info_fan.type = ZIGBEE_SENDING_BY_ENDPOINT;
	memcpy(&sending_info_fan.data.dest_endpoint, remote_ep, sizeof(zigbee_endpoint));

	return EZ_OK;
}

static void _ZDO_bind_remote_cluster(void)
{
	zigbee_node_info node_info;
	zigbee_endpoint_list src_endpoint_list;
	zigbee_endpoint *src_endpoint = NULL;
	int ret = EZ_ERROR;
	int i = 0;

	ret = zigbee_get_node_info(&node_info);
	if (EZ_OK != ret) {
		printf("Get node info error: %d\n", ret);
		return;
	}

	ret = zigbee_device_find_by_cluster(&src_endpoint_list, ZCL_TEMP_MEASUREMENT_CLUSTER_ID, 1);
	if (EZ_OK != ret) {
		printf("Device find by server cluster 0x%04X error: %d\n", ZCL_TEMP_MEASUREMENT_CLUSTER_ID, ret);
		return;
	}

	if (src_endpoint_list.num <= 0) {
		printf("There is no remote src endpoint for server cluster 0x%04X\n", ZCL_TEMP_MEASUREMENT_CLUSTER_ID);
		return;
	}

	src_endpoint = &src_endpoint_list.endpoint[0];
	ret = zigbee_zdo_bind_unicast_request(src_endpoint->node_id, src_endpoint->endpoint_id, ZCL_TEMP_MEASUREMENT_CLUSTER_ID,
										  node_info.node_id, ENDPOINT_THERMOSTAT_CONTROL);
	if (EZ_OK != ret)
		printf("Zdo Temperature cluster error: %d\n", ret);

	ret = zigbee_device_find_by_cluster(&src_endpoint_list, ZCL_OCCUPANCY_SENSING_CLUSTER_ID, 1);
	if (EZ_OK != ret) {
		printf("Device find by server cluster 0x%04X error: %d\n", ZCL_OCCUPANCY_SENSING_CLUSTER_ID, ret);
		return;
	}

	if (src_endpoint_list.num <= 0) {
		printf("There is no remote src endpoint for server cluster 0x%04X\n", ZCL_OCCUPANCY_SENSING_CLUSTER_ID);
		return;
	}

	src_endpoint = &src_endpoint_list.endpoint[0];
	ret = zigbee_zdo_bind_unicast_request(src_endpoint->node_id, src_endpoint->endpoint_id, ZCL_OCCUPANCY_SENSING_CLUSTER_ID,
										  node_info.node_id, ENDPOINT_THERMOSTAT_CONTROL);
	if (EZ_OK != ret)
		printf("Zdo Occupancy cluster error: %d\n", ret);
}

static void _set_temperature_reporting(void)
{
	int ret = EZ_ERROR;
	int min_interval = 1;
	int max_interval = 10;
	int temperature = 10;

	ret = zigbee_request_reporting(ZCL_TEMP_MEASUREMENT_CLUSTER_ID, &sending_info_temp, ZIGBEE_REPORTING_MEASURED_TEMPERATURE,
								   min_interval, max_interval, temperature, ENDPOINT_THERMOSTAT_CONTROL);

	if (EZ_OK != ret)
		printf("Failed to request measured temperature reporting: %d\n", ret);
}

static void _set_occupancy_reporting(void)
{
	int ret = EZ_ERROR;
	int min_interval = 4;
	int max_interval = 10;

	/* The change_threshold has no meaning for Occupancy Reporting */
	ret = zigbee_request_reporting(ZCL_OCCUPANCY_SENSING_CLUSTER_ID, &sending_info_occupy, ZIGBEE_REPORTING_OCCUPANCY_SENSING,
								   min_interval, max_interval, 0, ENDPOINT_THERMOSTAT_CONTROL);

	if (EZ_OK != ret)
		printf("Failed to request Occupancy reporting : %d\n", ret);
}

static void _loop_run(void)
{
	if (!mainloop)
		mainloop = g_main_loop_new(NULL, FALSE);

	g_main_loop_run(mainloop);
}

static gboolean _discover_timeout_callback(gpointer user_data)
{
	discover_timeout_id = -1;
	discovery_retry_count++;
	if (discovery_retry_count <= DISCOVERY_MAX_RETRY_COUNT) {
		printf("Device discover timeout, retry\n");
		_device_discover();
	}
	return FALSE;
}

static int _loop_remove_timeout_callback(int timeout_id)
{
	gboolean ret;

	if (timeout_id < 0)
		return EZ_BAD_ARGS;

	ret = g_source_remove((guint)timeout_id);
	if (FALSE == ret)
		return EZ_BAD_ARGS;

	return EZ_OK;
}

static int _loop_add_timeout_callback(int *timeout_id, unsigned int msec, GSourceFunc callback,
									  void *user_data)
{
	GSource *source = NULL;

	if (NULL == callback || NULL == timeout_id)
		return EZ_BAD_ARGS;

	source = g_timeout_source_new(msec);
	g_source_set_priority(source, G_PRIORITY_HIGH);
	g_source_set_callback(source, callback, user_data, NULL);
	*timeout_id = g_source_attach(source, NULL);
	g_source_unref(source);

	return EZ_OK;
}

static void _on_device_discovery(zigbee_device_discovery *device_discovery)
{
	switch (device_discovery->status) {
	case ZIGBEE_DEVICE_DISCOVERY_START:
		printf("Device discovery start\n");
		break;
	case ZIGBEE_DEVICE_DISCOVERY_FOUND:
		printf("Device discovery found device id 0x%04X\n", device_discovery->device.node_id);
		break;
	case ZIGBEE_DEVICE_DISCOVERY_IN_PROGRESS:
		printf("Device discovery in progress\n");
		if (discover_timeout_id >= 0) {
			_loop_remove_timeout_callback(discover_timeout_id);
			discover_timeout_id = -1;
		}

		if (EZ_OK != _loop_add_timeout_callback(&discover_timeout_id, TIMEOUT_MSEC,
						_discover_timeout_callback, NULL))
			_loop_quit();
		break;
	case ZIGBEE_DEVICE_DISCOVERY_DONE:
		printf("Device discovery finished\n");
		if (discover_timeout_id >= 0) {
			_loop_remove_timeout_callback(discover_timeout_id);
			discover_timeout_id = -1;
		}

		if (EZ_OK != _set_sending_info_temp() || EZ_OK != _set_sending_info_occupy() || EZ_OK != _set_sending_info_fan())
			_loop_quit();

		_ZDO_bind_remote_cluster();		/* remote node bind to current node on Temperature/Occupancy cluster */
		_set_temperature_reporting();
		_set_occupancy_reporting();
		_func_entry(_func_entrance);
		break;
	case ZIGBEE_DEVICE_DISCOVERY_NO_DEVICE:
		printf("Device discovery no device\n");
		if (discover_timeout_id >= 0) {
			_loop_remove_timeout_callback(discover_timeout_id);
			discover_timeout_id = -1;
		}
		discovery_retry_count++;
		if (discovery_retry_count <= DISCOVERY_MAX_RETRY_COUNT) {
			sleep(5);
			_device_discover();
		} else {
			printf("Retry Discovery Max\n");
			_loop_quit();
		}
		break;
	case ZIGBEE_DEVICE_DISCOVERY_ERROR:
		printf("Device discovery error\n");
		_loop_quit();
		break;
	case ZIGBEE_DEVICE_DISCOVERY_CHANGED:
		printf("Device discovery changed device id 0x%04X\n", device_discovery->device.node_id);
		break;
	case ZIGBEE_DEVICE_DISCOVERY_LOST:
		printf("Device discovery lost device id 0x%04X\n", device_discovery->device.node_id);
		break;
	default:
		printf("Discovery device unknown result\n");
		_loop_quit();
		break;
	}
}

void _on_callback_attr_changed(zigbee_attribute_changed_response *info)
{
	zigbee_thermostat_system_mode mode = 0;

	if (ZIGBEE_ATTR_SYSTEM_MODE == info->type) {
		if (EZ_OK == zigbee_thermostat_get_system_mode(ENDPOINT_THERMOSTAT_CONTROL, &mode)) {
			if (g_requested_system_mode != mode) {
				printf("Mode is changed from %s to %s\n",
					   _get_system_mode_description(g_requested_system_mode),
					   _get_system_mode_description(mode));
				g_requested_system_mode = mode;
				if (!_service_monitor())
					_loop_quit();
			}
		} else {
			printf("Read system mode failed\n");
			_loop_quit();
		}
	}
}

static void _on_callback(void *user_data, zigbee_response_type response_type, void *payload)
{
	zigbee_network_notification network_notification;
	int ret = EZ_OK;
	zigbee_report_attribute_info *report_attr_info;

	switch (response_type) {
	case ZIGBEE_RESPONSE_NETWORK_NOTIFICATION:
		network_notification = *((zigbee_network_notification *) payload);
		switch (network_notification) {
		case ZIGBEE_NETWORK_JOIN:
			printf("NETWORK_NOTIFICATION: JOIN\n");
			break;

		case ZIGBEE_NETWORK_LEAVE:
			printf("NETWORK_NOTIFICATION: LEAVE\n");
			break;

		case ZIGBEE_NETWORK_EXIST:
			printf("NETWORK_NOTIFICATION: Network exist, please leave current network and try again\n");
			_loop_quit();
			break;

		case ZIGBEE_NETWORK_FIND_FORM_SUCCESS:
			printf("NETWORK_NOTIFICATION: FIND FORM SUCCESS\n");
			ret = zigbee_network_permitjoin(EASY_PJOIN_DURATION);
			if (ret != EZ_OK)
				printf("zigbee_network_permitjoin failed:%d\n", ret);
			printf("Please start up other applications on other boards.\n");
			break;

		case ZIGBEE_NETWORK_FIND_FORM_FAILED:
			printf("NETWORK_NOTIFICATION: FIND FORM FAILED\n");
			_loop_quit();
			break;

		case ZIGBEE_NETWORK_FIND_JOIN_SUCCESS:
			printf("NETWORK_NOTIFICATION: FIND JOIN SUCCESS\n");
			break;

		case ZIGBEE_NETWORK_FIND_JOIN_FAILED:
			printf("NETWORK_NOTIFICATION: FIND JOIN FAILED\n");
			_loop_quit();
			break;

		default:
			printf("NETWORK_NOTIFICATION: %d\n", network_notification);
			_loop_quit();
			break;
		}
		break;
	case ZIGBEE_RESPONSE_DEVICE_ANNOUNCE:
		_node_count++;
		if (_node_count >= 2)
			_device_discover();
		break;
	case ZIGBEE_RESPONSE_DEVICE_DISCOVER:
		_on_device_discovery((zigbee_device_discovery *)payload);
		break;
	case ZIGBEE_RESPONSE_ATTRIBUTE_CHANGE:
		_on_callback_attr_changed((zigbee_attribute_changed_response *)payload);
		break;
	case ZIGBEE_RESPONSE_REPORT_ATTRIBUTE:
		report_attr_info = (zigbee_report_attribute_info *)payload;
		switch (report_attr_info->attribute_type) {
		case ZIGBEE_ATTR_OCCUPANCY:
			g_occupy_status = report_attr_info->data.occupancy;
			if (!_service_monitor())
				_loop_quit();
			break;

		case ZIGBEE_ATTR_TEMPERATURE:
			g_temperature = report_attr_info->data.value;
			if (!_service_monitor())
				_loop_quit();
			break;

		default:
			printf("Not supported attribute\n");
			break;
		}
		break;
	default:
		break;
	}
}

static int _create_THERMOSTAT_device(void)
{
	int ret = EZ_OK;
	zigbee_local_endpoint_info endpoint_info;

	memset(&endpoint_info, 0, sizeof(zigbee_local_endpoint_info));
	endpoint_info.endpoints[endpoint_info.count].profile = ZIGBEE_PROFILE_HA;
	endpoint_info.endpoints[endpoint_info.count].endpoint_id = ENDPOINT_THERMOSTAT_CONTROL;
	endpoint_info.endpoints[endpoint_info.count].device_id = DEVICE_THERMOSTAT;
	endpoint_info.count++;

	ret = zigbee_set_local_endpoint(&endpoint_info);
	if (EZ_OK != ret)
		printf("Set local endpoint error %d", ret);

	return ret;
}

static int _reset(void)
{
	int ret = EZ_OK;

	printf("Start reset\n");
	ret = zigbee_reset_local();
	if (EZ_OK != ret)
		printf("Reset failed: %d\n", ret);

	return ret;
}

static void _show_usage(void)
{
	printf("===================================================================================\n");
	printf("usage:\n");
	printf("<application name> [arguments]\n");
	printf("[--reset]         , Reset device\n");
	printf("without argument  , Form a network\n");
	printf("===================================================================================\n");
}

int main(int argc, char *argv[])
{
	zigbee_network_state state = ZIGBEE_NO_NETWORK;
	int i = 0;
	int ret = EZ_OK;
	bool need_reset = false;
	GIOChannel *channel = NULL;

	if (argc > 1) {
		for (i = 1; i < argc; i++) {
			if (!strcmp(argv[i], "--reset"))
				need_reset = true;
			if (!strcmp(argv[i], "--help")) {
				_show_usage();
				return -1;
			}
		}
	}

	ret = _create_THERMOSTAT_device();
	if (EZ_OK != ret)
		return -1;

	ret = zigbee_initialize(_on_callback, NULL);
	if (EZ_OK != ret)
		goto free_quit;

	ret = _network_start(&state);
	if (EZ_OK != ret)
		goto free_quit;

	if (true == need_reset) {
		ret = _reset();
		if (EZ_OK != ret)
			goto free_quit;
		state = ZIGBEE_NO_NETWORK;
	}

	if (ZIGBEE_NO_NETWORK == state) {
		ret = zigbee_network_form();
		if (EZ_OK != ret)
			goto free_quit;
	}

	_set_thermostat_mode(ZIGBEE_SYSTEM_MODE_OFF);

	channel = g_io_channel_unix_new(STDIN_FILENO);
	g_io_add_watch(channel, G_IO_IN | G_IO_ERR | G_IO_HUP | G_IO_NVAL, _on_keyboard_received, NULL);
	g_io_channel_set_flags(channel, G_IO_FLAG_NONBLOCK, NULL);
	g_io_channel_unref(channel);

	_loop_run();

free_quit:
	zigbee_deinitialize();

	return 0;
}
