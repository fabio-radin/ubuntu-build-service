#ifndef INCLUDE_ZIGBEE_ERROR_H_
#define INCLUDE_ZIGBEE_ERROR_H_

/*! \file zigbee_error.h
 *
 *  \brief Error codes
 *
 *  Error codes returned by most of the functions
 *  of the API
 */

#define MAX_ERRR_MSG_LEN	64
/*!
 *  \brief Error type
 */
typedef int zigbee_error;
/*!
 *  \brief Error message definition
 *
 *  Structure defining an error and
 *  its user-friendly message
 */
typedef struct {
	int err;
	char msg[MAX_ERRR_MSG_LEN];
} zigbee_error_msg_string;

static const zigbee_error_msg_string error_msg_strings[] = {
	{EZ_OK, "OK"},
	{EZ_ERROR, "ZigBee error"},
	{EZ_BAD_ARGS, "Bad arguments"},
	{EZ_NOT_INITIALIZED, "Not initialized"},
	{EZ_NO_MEM, "No memory"},
	{EZ_NOT_SUPPORTED, "Not supported"},
	{EZ_INVALID_VALUE, "Invalid value"},
	{EZ_INVALID_DAEMON, "Invalid zigbee daemon"},
	{EZ_NO_DAEMON, "No zigbee daemon"},
	{EZ_NO_MESSAGE, "No zigbee message"},
	{EZ_INVALID_ATTR, "Invalid attribute"},
	{EZ_NOT_FOUND, "Not found"},
	{EZ_ERR_SOCK, "Socket error"},
	{EZ_MSG_SEND_ERROR, "Send message error"},
	{EZ_NETWORK_EXIST, "Network has existed"},
	{EZ_NO_NETWORK, "No network"},
	{EZ_IN_PROGRESS, "In progress"}
};

static inline const char *zigbee_error_msg(int err)
{
	const zigbee_error_msg_string *msgs = error_msg_strings;
	int i, size;

	size = sizeof(error_msg_strings) / sizeof(error_msg_strings[0]);
	for (i = 0; i < size; i++) {
		if (msgs[i].err == err) {
			return (char *)msgs[i].msg;
		}
	}

	return "null";
}

static inline const char *zigbee_zdp_msg(zigbee_zdo_response_status status)
{
	switch (status) {
	case ZIGBEE_ZDP_SUCCESS:
		return "SUCCESS";

	case ZIGBEE_ZDP_INVALID_REQUEST_TYPE:
		return "INVALID_REQUEST_TYPE";

	case ZIGBEE_ZDP_DEVICE_NOT_FOUND:
		return "DEVICE_NOT_FOUND";

	case ZIGBEE_ZDP_INVALID_ENDPOINT:
		return "INVALID_ENDPOINT";

	case ZIGBEE_ZDP_NOT_ACTIVE:
		return "NOT_ACTIVE";

	case ZIGBEE_ZDP_NOT_SUPPORTED:
		return "NOT_SUPPORTED";

	case ZIGBEE_ZDP_TIMEOUT:
		return "TIMEOUT";

	case ZIGBEE_ZDP_NO_MATCH:
		return "NO_MATCH";

	case ZIGBEE_ZDP_NO_ENTRY:
		return "NO_ENTRY";

	case ZIGBEE_ZDP_NO_DESCRIPTOR:
		return "NO_DESCRIPTOR";

	case ZIGBEE_ZDP_INSUFFICIENT_SPACE:
		return "INSUFFICIENT_SPACE";

	case ZIGBEE_ZDP_NOT_PERMITTED:
		return "NOT_PERMITTED";

	case ZIGBEE_ZDP_TABLE_FULL:
		return "TABLE_FULL";

	case ZIGBEE_ZDP_NOT_AUTHORIZED:
		return "NOT_AUTHORIZED";

	case ZIGBEE_NWK_ALREADY_PRESENT:
		return "NWK_ALREADY_PRESENT";

	case ZIGBEE_NWK_TABLE_FULL:
		return "NWK_TABLE_FULL";

	case ZIGBEE_NWK_UNKNOWN_DEVICE:
		return "NWK_UNKNOWN_DEVICE";

	default:
		return "UNKNOWN";
	}
}

#endif /* INCLUDE_ZIGBEE_ERROR_H_ */
