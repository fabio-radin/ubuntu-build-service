#ifndef	__ZIGBEE_CLUSTERS_H__
#define	__ZIGBEE_CLUSTERS_H__

#ifdef __cplusplus
extern "C" {
#endif
/*! \file zigbee_clusters.h
 *
 *	\brief ZigBee cluster definition
 *
 *	Definitions and functions for accessing
 *	the ZigBee clusters
 *
 */

// Cluster domain specification levels:
//   * General: zcl-6.0-15-02017-001
//   * Lighting & Occupancy: l&o-1.0-15-0014-04
//   * HA: ha-1.2.1-05-3520-30
//   * Closures: zcl-6.0-15-02018-001
//   * HVAC: zcl-6.0-15-02018-001
//   * Lighting: zcl-6.0-15-02018-001
//   * Measurement & Sensing: zcl-6.0-15-02018-001
//   * Security & Safety: zcl-6.0-15-02018-001
//   * Home Automation: UNKNOWN
//   * CBA: cba-1.0-05-3516-12
//   * SE: se-1.2b-15-0131-02
//   * ZLL: zll-1.0-11-0037-10
//   * Telecom Applications: ta-1.0-07-5307-07
//   * Protocol Interfaces: ta-1.0-07-5307-07
//   * Telecommunication: ta-1.0-07-5307-07
//   * Financial: ta-1.0-07-5307-07
//   * Ember: UNKNOWN
//   * HC: hc-1.0-07-5360-15
//   * GP: gp-1.0a-09-5499-26
#define ZCL_BASIC_CLUSTER_ID                         0x0000
#define ZCL_POWER_CONFIG_CLUSTER_ID                  0x0001
#define ZCL_DEVICE_TEMP_CLUSTER_ID                   0x0002
#define ZCL_IDENTIFY_CLUSTER_ID                      0x0003
#define ZCL_GROUPS_CLUSTER_ID                        0x0004
#define ZCL_SCENES_CLUSTER_ID                        0x0005
#define ZCL_ON_OFF_CLUSTER_ID                        0x0006
#define ZCL_ON_OFF_SWITCH_CONFIG_CLUSTER_ID          0x0007
#define ZCL_LEVEL_CONTROL_CLUSTER_ID                 0x0008
#define ZCL_ALARM_CLUSTER_ID                         0x0009
#define ZCL_TIME_CLUSTER_ID                          0x000A
#define ZCL_RSSI_LOCATION_CLUSTER_ID                 0x000B
#define ZCL_BINARY_INPUT_BASIC_CLUSTER_ID            0x000F
#define ZCL_COMMISSIONING_CLUSTER_ID                 0x0015
#define ZCL_PARTITION_CLUSTER_ID                     0x0016
#define ZCL_OTA_BOOTLOAD_CLUSTER_ID                  0x0019
#define ZCL_POWER_PROFILE_CLUSTER_ID                 0x001A
#define ZCL_APPLIANCE_CONTROL_CLUSTER_ID             0x001B
#define ZCL_POLL_CONTROL_CLUSTER_ID                  0x0020
#define ZCL_GREEN_POWER_CLUSTER_ID                   0x0021
#define ZCL_KEEPALIVE_CLUSTER_ID                     0x0025
#define ZCL_SHADE_CONFIG_CLUSTER_ID                  0x0100
#define ZCL_DOOR_LOCK_CLUSTER_ID                     0x0101
#define ZCL_WINDOW_COVERING_CLUSTER_ID               0x0102
#define ZCL_PUMP_CONFIG_CONTROL_CLUSTER_ID           0x0200
#define ZCL_THERMOSTAT_CLUSTER_ID                    0x0201
#define ZCL_FAN_CONTROL_CLUSTER_ID                   0x0202
#define ZCL_DEHUMID_CONTROL_CLUSTER_ID               0x0203
#define ZCL_THERMOSTAT_UI_CONFIG_CLUSTER_ID          0x0204
#define ZCL_COLOR_CONTROL_CLUSTER_ID                 0x0300
#define ZCL_BALLAST_CONFIGURATION_CLUSTER_ID         0x0301
#define ZCL_ILLUM_MEASUREMENT_CLUSTER_ID             0x0400
#define ZCL_ILLUM_LEVEL_SENSING_CLUSTER_ID           0x0401
#define ZCL_TEMP_MEASUREMENT_CLUSTER_ID              0x0402
#define ZCL_PRESSURE_MEASUREMENT_CLUSTER_ID          0x0403
#define ZCL_FLOW_MEASUREMENT_CLUSTER_ID              0x0404
#define ZCL_RELATIVE_HUMIDITY_MEASUREMENT_CLUSTER_ID 0x0405
#define ZCL_OCCUPANCY_SENSING_CLUSTER_ID             0x0406
#define ZCL_IAS_ZONE_CLUSTER_ID                      0x0500
#define ZCL_IAS_ACE_CLUSTER_ID                       0x0501
#define ZCL_IAS_WD_CLUSTER_ID                        0x0502
#define ZCL_GENERIC_TUNNEL_CLUSTER_ID                0x0600
#define ZCL_BACNET_PROTOCOL_TUNNEL_CLUSTER_ID        0x0601
#define ZCL_11073_PROTOCOL_TUNNEL_CLUSTER_ID         0x0614
#define ZCL_ISO7816_PROTOCOL_TUNNEL_CLUSTER_ID       0x0615
#define ZCL_PRICE_CLUSTER_ID                         0x0700
#define ZCL_DEMAND_RESPONSE_LOAD_CONTROL_CLUSTER_ID  0x0701
#define ZCL_SIMPLE_METERING_CLUSTER_ID               0x0702
#define ZCL_MESSAGING_CLUSTER_ID                     0x0703
#define ZCL_TUNNELING_CLUSTER_ID                     0x0704
#define ZCL_PREPAYMENT_CLUSTER_ID                    0x0705
#define ZCL_ENERGY_MANAGEMENT_CLUSTER_ID             0x0706
#define ZCL_CALENDAR_CLUSTER_ID                      0x0707
#define ZCL_DEVICE_MANAGEMENT_CLUSTER_ID             0x0708
#define ZCL_EVENTS_CLUSTER_ID                        0x0709
#define ZCL_MDU_PAIRING_CLUSTER_ID                   0x070A
#define ZCL_KEY_ESTABLISHMENT_CLUSTER_ID             0x0800
#define ZCL_INFORMATION_CLUSTER_ID                   0x0900
#define ZCL_DATA_SHARING_CLUSTER_ID                  0x0901
#define ZCL_GAMING_CLUSTER_ID                        0x0902
#define ZCL_DATA_RATE_CONTROL_CLUSTER_ID             0x0903
#define ZCL_VOICE_OVER_ZIGBEE_CLUSTER_ID             0x0904
#define ZCL_CHATTING_CLUSTER_ID                      0x0905
#define ZCL_PAYMENT_CLUSTER_ID                       0x0A01
#define ZCL_BILLING_CLUSTER_ID                       0x0A02
#define ZCL_APPLIANCE_IDENTIFICATION_CLUSTER_ID      0x0B00
#define ZCL_METER_IDENTIFICATION_CLUSTER_ID          0x0B01
#define ZCL_APPLIANCE_EVENTS_AND_ALERT_CLUSTER_ID    0x0B02
#define ZCL_APPLIANCE_STATISTICS_CLUSTER_ID          0x0B03
#define ZCL_ELECTRICAL_MEASUREMENT_CLUSTER_ID        0x0B04
#define ZCL_DIAGNOSTICS_CLUSTER_ID                   0x0B05
#define ZCL_ZLL_COMMISSIONING_CLUSTER_ID             0x1000
#define ZCL_SAMPLE_MFG_SPECIFIC_CLUSTER_ID           0xFC00
#define ZCL_OTA_CONFIGURATION_CLUSTER_ID             0xFC01
#define ZCL_MFGLIB_CLUSTER_ID                        0xFC02

/*!
 * \brief	Attribute size, which is related to zigbee_attribute_data_type
 */
#define ZIGBEE_BITMAP16_ATTRIBUTE_SIZE		2
#define ZIGBEE_BITMAP24_ATTRIBUTE_SIZE		3
#define ZIGBEE_BITMAP32_ATTRIBUTE_SIZE		4
#define ZIGBEE_BITMAP48_ATTRIBUTE_SIZE		6
#define ZIGBEE_BITMAP64_ATTRIBUTE_SIZE		8
#define ZIGBEE_BITMAP8_ATTRIBUTE_SIZE		1
#define ZIGBEE_BOOLEAN_ATTRIBUTE_SIZE		1
#define ZIGBEE_DATA8_ATTRIBUTE_SIZE			1
#define ZIGBEE_ENUM16_ATTRIBUTE_SIZE		2
#define ZIGBEE_ENUM8_ATTRIBUTE_SIZE			1
#define ZIGBEE_IEEE_ADDRESS_ATTRIBUTE_SIZE	8
#define ZIGBEE_INT16S_ATTRIBUTE_SIZE		2
#define ZIGBEE_INT16U_ATTRIBUTE_SIZE		2
#define ZIGBEE_INT24S_ATTRIBUTE_SIZE		3
#define ZIGBEE_INT24U_ATTRIBUTE_SIZE		3
#define ZIGBEE_INT32S_ATTRIBUTE_SIZE		4
#define ZIGBEE_INT32U_ATTRIBUTE_SIZE		4
#define ZIGBEE_INT48U_ATTRIBUTE_SIZE		6
#define ZIGBEE_INT56U_ATTRIBUTE_SIZE		7
#define ZIGBEE_INT8S_ATTRIBUTE_SIZE			1
#define ZIGBEE_INT8U_ATTRIBUTE_SIZE			1
#define ZIGBEE_SECURITY_KEY_ATTRIBUTE_SIZE	16
#define ZIGBEE_UTC_TIME_ATTRIBUTE_SIZE		4
#define ZIGBEE_CHAR_STRING_ATTRIBUTE_SIZE	33

/*!
 * \brief	Group command for Group cluster
 *			This is used when both sending and receiving command
 */
typedef enum {
	ZIGBEE_GROUPS_ADD = 3230,
	ZIGBEE_GROUPS_VIEW,
	ZIGBEE_GROUPS_GET_MEMBERSHIP,
	ZIGBEE_GROUPS_REMOVE,
	ZIGBEE_GROUPS_REMOVE_ALL,
	ZIGBEE_GROUPS_ADD_IF_IDENTIFYING
} zigbee_group_command;
/*!
 * \brief	Maximum length of group name according to Ember
 */
#define ZCL_GROUPS_CLUSTER_MAXIMUM_NAME_LENGTH 16
/*!
 * \brief	Maximum count (unsigned 8 bit integer) of groups according to ZCL spec.
 */
#define GROUP_LIST_SIZE 255
/*!
 * \brief	Structure for Groups cluster command
 *			This is used when both sending command and receiving response
 *
 * \group_cmd:	ZIGBEE_GROUPS_ADD
 * \param [in]	group_id[0]		group id of entry that will be added
 * \param [in]	group_name		group name of entry that will be added
 *
 * \group_cmd:	ZIGBEE_GROUPS_VIEW
 * \param [in]	group_id[0]		group id of entry that will be checked
 * \param [out]	group_id[0]		group id of entry that is received
 * \param [out]	group_name		group name of entry that is received
 *
 * \group_cmd:	ZIGBEE_GROUPS_GET_MEMBERSHIP
 * \param [in]	group_count		requesting count of group list.
 *								If this param is 0, all the group ids will be gotten.
 * \param [in]	group_id		requesting list of group id.
 * \param [out] group_count		received count of group list
 * \param [out] group_id		received group list
 * \param [out] capacity		received remaining capacity of the group table.
 *								The range of the capcity is from 0 to 255,
 *								0: No further groups may be added
 *								0 < capacity < 254 number of groups that may be added
 *								255 unknown if any further groups may be added.
 *								Because the binding table is used for other purposes
 *								besides groups, so this value may be changed.
 *
 * \group_cmd: ZIGBEE_GROUPS_REMOVE
 * \param [in]	group_id[0]		group id of entry that will be removed
 *
 * \group_cmd: ZIGBEE_GROUPS_REMOVE_ALL
 * \param[in]	no input param.
 * \param[out]	no output param.
 *
 * \group_cmd: ZIGBEE_GROUPS_ADD_IF_IDENTIFYING
 * \param[in]	group_id[0]		group id of entry that will be added
 * \param[in]	group_name		group name of entry that will be added
 */
typedef struct {
	unsigned short group_id[GROUP_LIST_SIZE];
	unsigned char group_name[ZCL_GROUPS_CLUSTER_MAXIMUM_NAME_LENGTH + 1];
	int endpoint_id;
	unsigned char group_count;
	unsigned char capacity;
	zigbee_group_command group_cmd;
} zigbee_groups_info;
/*!
 * \brief	Structure for saving Scene information
 */
typedef struct {
	unsigned char scene_count;
	unsigned char current_scene;
	unsigned short current_group;
	unsigned char scene_valid;
} zigbee_scene_mgmt_info;
/*!
 * \brief	On/Off status for On/Off cluster
 *			This is used when both sending and receiving command
 */
typedef enum {
	ZIGBEE_ONOFF_OFF = 3220,
	ZIGBEE_ONOFF_ON,
	ZIGBEE_ONOFF_TOGGLE
} zigbee_onoff_status;
/*!
 * \brief	Structure for receiving a command notification of On/Off cluster
 *			from ZigBee Daemon
 */
typedef struct {
	zigbee_onoff_status prev_value;
	zigbee_onoff_status curr_value;
	zigbee_onoff_status command;
	int endpoint_id;
} zigbee_onoff_info;
/*!
 * \brief	Level Control cluster command type
 */
typedef enum {
	ZIGBEE_MOVE_TO_LEVEL = 0x00,
	ZIGBEE_MOVE = 0x01,
	ZIGBEE_STEP = 0x02,
	ZIGBEE_STOP = 0x03,
	ZIGBEE_MOVE_TO_LEVEL_ONOFF = 0x04,
	ZIGBEE_MOVE_ONOFF = 0x05,
	ZIGBEE_STEP_ONOFF = 0x06,
	ZIGBEE_STOP_ONOFF = 0x07
} zigbee_level_control_type;
/*!
 * \brief	Level Control cluster command mode
 */
typedef enum {
	ZIGBEE_LEVEL_CONTROL_UP = 0x00,
	ZIGBEE_LEVEL_CONTROL_DOWN = 0x01
} zigbee_level_control_mode;
/*!
 * \brief	Structure for Level Control cluster command
 */
typedef struct {
	zigbee_level_control_type control_type;
	union {
		struct {
			int level;              /* The range is from 0 to 0xFF */
			int transition_time;	/* tenths of a second   The range is from 0 to 0xFFFF */
		} move_to_level;
		struct {
			zigbee_level_control_mode control_mode;
			int rate;				/* changes per second   The range is from 1 to 0xFF */
		} move;
		struct {
			zigbee_level_control_mode control_mode;
			int step_size;          /* The range is from 1 to 0xFF */
			int transition_time;	/* tehnths of a second   The range is from 1 to 0xFFFF */
		} step;
	} parameters;
} zigbee_level_control_command;
/*!
 * \brief	Structure for receiving a update notification of Level Control
 *			cluster from ZigBee Daemon
 */
typedef struct {
	int prev_level;
	int curr_level;
	int endpoint_id;
} zigbee_level_control_update;
/*!
 * \brief	Color Control cluster command type
 */
typedef enum {
	ZIGBEE_MOVE_TO_HUE = 0x00,
	ZIGBEE_MOVE_HUE,
	ZIGBEE_STEP_HUE,
	ZIGBEE_MOVE_TO_SATURATION,
	ZIGBEE_MOVE_SATURATION,
	ZIGBEE_STEP_SATURATION,
	ZIGBEE_MOVE_TO_HUE_SATURATION,
	ZIGBEE_MOVE_TO_COLOR,
	ZIGBEE_MOVE_COLOR,
	ZIGBEE_STEP_COLOR,
	ZIGBEE_MOVE_TO_COLOR_TEMP,
	ZIGBEE_EMOVE_TO_HUE = 0x40,
	ZIGBEE_EMOVE_HUE,
	ZIGBEE_ESTEP_HUE,
	ZIGBEE_EMOVE_TO_HUE_SATURATION,
	ZIGBEE_COLOR_LOOP_SET,
	ZIGBEE_STOP_MOVE_STEP = 0x47,
	ZIGBEE_MOVE_COLOR_TEMP = 0x4b,
	ZIGBEE_STEP_COLOR_TEMP = 0x4c
} zigbee_color_control_type;
/*!
 * \brief	Color Control cluster command direction
 */
typedef enum {
	ZIGBEE_COLOR_CONTROL_DIRECTION_SHORTEST_DISTANCE = 0x00,
	ZIGBEE_COLOR_CONTROL_DIRECTION_LONGEST_DISTANCE = 0x01,
	ZIGBEE_COLOR_CONTROL_DIRECTION_UP = 0x02,
	ZIGBEE_COLOR_CONTROL_DIRECTION_DOWN = 0x03
} zigbee_color_control_direction;
/*!
 * \brief	The move mode for Color Control
 */
typedef enum {
	ZIGBEE_COLOR_CONTROL_MOVE_MODE_STOP = 0x00,
	ZIGBEE_COLOR_CONTROL_MOVE_MODE_UP = 0x01,
	ZIGBEE_COLOR_CONTROL_MOVE_MODE_DOWN = 0x03
} zigbee_color_control_move_mode;
/*!
 * \brief	The step mode for Color Control
 */
typedef enum {
	ZIGBEE_COLOR_CONTROL_STEP_MODE_UP = 0x01,
	ZIGBEE_COLOR_CONTROL_STEP_MODE_DOWN = 0x03
} zigbee_color_control_step_mode;
/*!
 * \brief	The loop action for Color Control
 */
typedef enum {
	ZIGBEE_COLOR_CONTROL_LOOP_ACTION_DEACTIVATE							= 0x00,
	ZIGBEE_COLOR_CONTROL_LOOP_ACTION_ACTIVATE_FROM_START_ENHANCED_HUE	= 0x01,
	ZIGBEE_COLOR_CONTROL_LOOP_ACTION_ACTIVATE_FROM_ENHANCED_CURRENT_HUE	= 0x02
} zigbee_color_control_loop_set_action;
/*!
 * \brief	The command for cluster Color Control
 */
typedef struct {
	zigbee_color_control_type control_type;
	union {
		struct {
			int hue;
			zigbee_color_control_direction direction;
			int transition_time;
		} move_to_hue;
		struct {
			zigbee_color_control_move_mode move_mode;
			int rate;
		} move_hue;
		struct {
			zigbee_color_control_step_mode step_mode;
			int step_size;
			int transition_time;
		} step_hue;
		struct {
			int saturation;
			int transition_time;
		} move_to_sat;
		struct {
			zigbee_color_control_move_mode move_mode;
			int rate;
		} move_sat;
		struct {
			zigbee_color_control_step_mode step_mode;
			int step_size;
			int transition_time;
		} step_sat;
		struct {
			int hue;
			int saturation;
			int transition_time;
		} move_to_hue_sat;
		struct {
			int color_x;
			int color_y;
			int transition_time;
		} move_to_color;
		struct {
			int rate_x;
			int rate_y;
		} move_color;
		struct {
			int step_x;
			int step_y;
			int transition_time;
		} step_color;
		struct {
			int color_temp;
			int transition_time;
		} move_to_color_temp;
		struct {
			int update_flag;
			zigbee_color_control_loop_set_action action;
			zigbee_color_control_direction direction;
			int time;
			int start_hue;
		} color_loop_set;
		struct {
			zigbee_color_control_move_mode move_mode;
			int rate;
			int min_color_temp;
			int max_color_temp;
		} move_color_temp;
		struct {
			zigbee_color_control_step_mode step_mode;
			int step_size;
			int transition_time;
			int min_color_temp;
			int max_color_temp;
		} step_color_temp;
	} parameters;
} zigbee_color_control_command;
/*!
 * \brief	The Color current values
 */
typedef struct {
	int hue;
	int saturation;
	int color_x;
	int color_y;
	int color_temp;
} zigbee_color_control_value;

/*!
 * \brief	The status of occupancy
 */
typedef enum {
	ZIGBEE_OCCUPIED,
	ZIGBEE_UNOCCUPIED
} zigbee_occupancy_status;

/*!
 * \brief	The sensor type of occupancy
 */
typedef enum {
	ZIGBEE_OCCUPANCY_PIR,
	ZIGBEE_OCCUPANCY_ULTRASONIC,
	ZIGBEE_OCCUPANCY_PIR_ULTRASONIC
} zigbee_occupancy_type;

typedef enum {
	ZIGBEE_FAN_MODE_OFF,
	ZIGBEE_FAN_MODE_LOW,
	ZIGBEE_FAN_MODE_MEDIUM,
	ZIGBEE_FAN_MODE_HIGH,
	ZIGBEE_FAN_MODE_ON,
	ZIGBEE_FAN_MODE_AUTO,
	ZIGBEE_FAN_MODE_SMART,
	ZIGBEE_FAN_MODE_RESERVED
} zigbee_fan_mode;

typedef enum {
	ZIGBEE_FAN_MODE_SEQUENCE_LOW_MED_HIGH,
	ZIGBEE_FAN_MODE_SEQUENCE_LOW_HIGH,
	ZIGBEE_FAN_MODE_SEQUENCE_LOW_MED_HIGH_AUTO,
	ZIGBEE_FAN_MODE_SEQUENCE_LOW_HIGH_AUTO,
	ZIGBEE_FAN_MODE_SEQUENCE_ON_AUTO,
	ZIGBEE_FAN_MODE_SEQUENCE_RESERVED
} zigbee_fan_mode_sequence;

/*!
 * \brief	The Thermostat setpoint mode
 */
typedef enum {
	ZIGBEE_SETPOINT_MODE_HEAT = 0x00,
	ZIGBEE_SETPOINT_MODE_COOL,
	ZIGBEE_SETPOINT_MODE_BOTH,
	ZIGBEE_SETPOINT_MODE_RESERVED
} zigbee_thermostat_setpoint_mode;

/*!
 * \brief	The Thermostat system mode
 */
typedef enum {
	ZIGBEE_SYSTEM_MODE_OFF = 0x00,
	ZIGBEE_SYSTEM_MODE_AUTO,
	ZIGBEE_SYSTEM_MODE_COOL,
	ZIGBEE_SYSTEM_MODE_HEAT,
	ZIGBEE_SYSTEM_MODE_EMERGENCY_HEATING,
	ZIGBEE_SYSTEM_MODE_PRECOOLING,
	ZIGBEE_SYSTEM_MODE_FAN_ONLY,
	ZIGBEE_SYSTEM_MODE_RESERVED
} zigbee_thermostat_system_mode;

/*!
 * \brief	The Thermostat control sequence of operation
 */
typedef enum {
	ZIGBEE_CONTROL_SEQUENCE_COOLING_ONLY = 0x00,
	ZIGBEE_CONTROL_SEQUENCE_COOLING_WITH_REHEAT,
	ZIGBEE_CONTROL_SEQUENCE_HEATING_ONLY,
	ZIGBEE_CONTROL_SEQUENCE_HEATING_WITH_REHEAT,
	ZIGBEE_CONTROL_SEQUENCE_COOLING_HEATING,
	ZIGBEE_CONTROL_SEQUENCE_COOLING_HEATING_WITH_REHEAT,
	ZIGBEE_CONTROL_SEQUENCE_RESERVED
} zigbee_thermostat_control_sequence;

/*!
 * \brief	The data type of attribute
 */
typedef enum {
	ZIGBEE_NO_DATA_ATTRIBUTE_TYPE			= 0x00, /* No data */
	ZIGBEE_DATA8_ATTRIBUTE_TYPE				= 0x08, /* 8-bit data */
	ZIGBEE_DATA16_ATTRIBUTE_TYPE 			= 0x09, /* 16-bit data */
	ZIGBEE_DATA24_ATTRIBUTE_TYPE 			= 0x0A, /* 24-bit data */
	ZIGBEE_DATA32_ATTRIBUTE_TYPE 			= 0x0B, /* 32-bit data */
	ZIGBEE_DATA40_ATTRIBUTE_TYPE 			= 0x0C, /* 40-bit data */
	ZIGBEE_DATA48_ATTRIBUTE_TYPE 			= 0x0D, /* 48-bit data */
	ZIGBEE_DATA56_ATTRIBUTE_TYPE 			= 0x0E, /* 56-bit data */
	ZIGBEE_DATA64_ATTRIBUTE_TYPE 			= 0x0F, /* 64-bit data */
	ZIGBEE_BOOLEAN_ATTRIBUTE_TYPE 			= 0x10, /* Boolean */
	ZIGBEE_BITMAP8_ATTRIBUTE_TYPE 			= 0x18, /* 8-bit bitmap */
	ZIGBEE_BITMAP16_ATTRIBUTE_TYPE			= 0x19, /* 16-bit bitmap */
	ZIGBEE_BITMAP24_ATTRIBUTE_TYPE			= 0x1A, /* 24-bit bitmap */
	ZIGBEE_BITMAP32_ATTRIBUTE_TYPE			= 0x1B, /* 32-bit bitmap */
	ZIGBEE_BITMAP40_ATTRIBUTE_TYPE			= 0x1C, /* 40-bit bitmap */
	ZIGBEE_BITMAP48_ATTRIBUTE_TYPE			= 0x1D, /* 48-bit bitmap */
	ZIGBEE_BITMAP56_ATTRIBUTE_TYPE			= 0x1E, /* 56-bit bitmap */
	ZIGBEE_BITMAP64_ATTRIBUTE_TYPE			= 0x1F, /* 64-bit bitmap */
	ZIGBEE_INT8U_ATTRIBUTE_TYPE				= 0x20, /* Unsigned 8-bit integer */
	ZIGBEE_INT16U_ATTRIBUTE_TYPE			= 0x21, /* Unsigned 16-bit integer */
	ZIGBEE_INT24U_ATTRIBUTE_TYPE			= 0x22, /* Unsigned 24-bit integer */
	ZIGBEE_INT32U_ATTRIBUTE_TYPE			= 0x23, /* Unsigned 32-bit integer */
	ZIGBEE_INT40U_ATTRIBUTE_TYPE			= 0x24, /* Unsigned 40-bit integer */
	ZIGBEE_INT48U_ATTRIBUTE_TYPE			= 0x25, /* Unsigned 48-bit integer */
	ZIGBEE_INT56U_ATTRIBUTE_TYPE			= 0x26, /* Unsigned 56-bit integer */
	ZIGBEE_INT64U_ATTRIBUTE_TYPE			= 0x27, /* Unsigned 64-bit integer */
	ZIGBEE_INT8S_ATTRIBUTE_TYPE				= 0x28, /* Signed 8-bit integer */
	ZIGBEE_INT16S_ATTRIBUTE_TYPE			= 0x29, /* Signed 16-bit integer */
	ZIGBEE_INT24S_ATTRIBUTE_TYPE			= 0x2A, /* Signed 24-bit integer */
	ZIGBEE_INT32S_ATTRIBUTE_TYPE			= 0x2B, /* Signed 32-bit integer */
	ZIGBEE_INT40S_ATTRIBUTE_TYPE			= 0x2C, /* Signed 40-bit integer */
	ZIGBEE_INT48S_ATTRIBUTE_TYPE			= 0x2D, /* Signed 48-bit integer */
	ZIGBEE_INT56S_ATTRIBUTE_TYPE			= 0x2E, /* Signed 56-bit integer */
	ZIGBEE_INT64S_ATTRIBUTE_TYPE			= 0x2F, /* Signed 64-bit integer */
	ZIGBEE_ENUM8_ATTRIBUTE_TYPE				= 0x30, /* 8-bit enumeration */
	ZIGBEE_ENUM16_ATTRIBUTE_TYPE			= 0x31, /* 16-bit enumeration */
	ZIGBEE_FLOAT_SEMI_ATTRIBUTE_TYPE		= 0x38, /* Semi-precision */
	ZIGBEE_FLOAT_SINGLE_ATTRIBUTE_TYPE		= 0x39, /* Single precision */
	ZIGBEE_FLOAT_DOUBLE_ATTRIBUTE_TYPE		= 0x3A, /* Double precision */
	ZIGBEE_OCTET_STRING_ATTRIBUTE_TYPE		= 0x41, /* Octet string */
	ZIGBEE_CHAR_STRING_ATTRIBUTE_TYPE		= 0x42, /* Character string */
	ZIGBEE_LONG_OCTET_STRING_ATTRIBUTE_TYPE	= 0x43, /* Long octet string */
	ZIGBEE_LONG_CHAR_STRING_ATTRIBUTE_TYPE	= 0x44, /* Long character string */
	ZIGBEE_ARRAY_ATTRIBUTE_TYPE 			= 0x48, /* Array */
	ZIGBEE_STRUCT_ATTRIBUTE_TYPE 			= 0x4C, /* Structure */
	ZIGBEE_SET_ATTRIBUTE_TYPE				= 0x50, /* Set */
	ZIGBEE_BAG_ATTRIBUTE_TYPE				= 0x51, /* Bag */
	ZIGBEE_TIME_OF_DAY_ATTRIBUTE_TYPE		= 0xE0, /* Time of day */
	ZIGBEE_DATE_ATTRIBUTE_TYPE				= 0xE1, /* Date */
	ZIGBEE_UTC_TIME_ATTRIBUTE_TYPE			= 0xE2, /* UTC Time */
	ZIGBEE_CLUSTER_ID_ATTRIBUTE_TYPE		= 0xE8, /* Cluster ID */
	ZIGBEE_ATTRIBUTE_ID_ATTRIBUTE_TYPE		= 0xE9, /* Attribute ID */
	ZIGBEE_BACNET_OID_ATTRIBUTE_TYPE		= 0xEA, /* BACnet OID */
	ZIGBEE_IEEE_ADDRESS_ATTRIBUTE_TYPE		= 0xF0, /* IEEE address */
	ZIGBEE_SECURITY_KEY_ATTRIBUTE_TYPE		= 0xF1, /* 128-bit security key */
	ZIGBEE_UNKNOWN_ATTRIBUTE_TYPE			= 0xFF  /* Unknown */
} zigbee_attribute_data_type;

#ifdef __cplusplus
}
#endif
#endif	/* __ZIGBEE_CLUSTERS_H__ */
