#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "zigbee.h"
#include "zigbee_error.h"

#define ENDPOINT_IAS_CIE			35
#define ENDPOINT_ON_OFF_SWITCH		1
#define DISCOVERY_MAX_RETRY_COUNT	5
#define TIMEOUT_MSEC				(10*1000)
#define EASY_PJOIN_DURATION			0xB4

static int discover_timeout_id = -1;
static int discovery_retry_count;
static GMainLoop *mainloop;

static void _loop_run(void)
{
	if (!mainloop)
		mainloop = g_main_loop_new(NULL, FALSE);

	g_main_loop_run(mainloop);
}

static void _loop_quit(void)
{
	if (!mainloop) {
		printf("main loop error\n");
		return;
	}

	g_main_loop_quit(mainloop);
}

static int _network_start(void)
{
	int ret = EZ_OK;
	zigbee_network_state state;

	ret = zigbee_network_start(&state);

	if (state == ZIGBEE_JOINED_NETWORK) {
		printf("Network is already exist, please join the nodes\n");
		ret = zigbee_network_permitjoin(EASY_PJOIN_DURATION);
		if (ret != EZ_OK) {
			fprintf(stderr, "zigbee_network_permitjoin failed:%s\n", zigbee_error_msg(ret));
			_loop_quit();
		}
	}

	if (state == ZIGBEE_NO_NETWORK) {
		ret = zigbee_network_form();
		if (EZ_OK != ret)
			_loop_quit();
	}

	if (EZ_OK != ret)
		printf("network_start error %d\n", ret);

	return ret;
}

static void _device_discover(void)
{
	int ret = EZ_OK;

	printf("Device discovery ...\n");
	ret = zigbee_device_discover();
	if (EZ_OK != ret) {
		printf("Device discover error %d", ret);
		_loop_quit();
	}
}

static gboolean _discover_timeout_callback(gpointer user_data)
{
	discover_timeout_id = -1;
	discovery_retry_count++;
	if (discovery_retry_count <= DISCOVERY_MAX_RETRY_COUNT) {
		printf("Device discover timeout, retry\n");
		_device_discover();
	} else {
		printf("Retry Discovery Max\n");
		_loop_quit();
	}
	return FALSE;
}

static int _loop_add_timeout_callback(int *timeout_id, unsigned int msec, GSourceFunc callback,
		void *user_data)
{
	GSource *source = NULL;

	if (NULL == callback || NULL == timeout_id)
		return EZ_BAD_ARGS;

	source = g_timeout_source_new(msec);
	g_source_set_priority(source, G_PRIORITY_HIGH);
	g_source_set_callback(source, callback, user_data, NULL);
	*timeout_id = g_source_attach(source, NULL);
	g_source_unref(source);

	return EZ_OK;
}

static int _loop_remove_timeout_callback(int timeout_id)
{
	gboolean ret;

	if (timeout_id < 0)
		return EZ_BAD_ARGS;

	ret = g_source_remove((guint)timeout_id);
	if (FALSE == ret)
		return EZ_BAD_ARGS;

	return EZ_OK;
}

static void _show_zone_status(ZIGBEE_IAS_ZONE_STATUS zone_status)
{
	printf(" - ALARM1 : %s", ZIGBEE_IAS_ZONE_STATUS_BIT_ALARM1 & zone_status ?
					"opened or alarmed" : "closed or not alarmed");
	printf(" - ALARM2 : %s", ZIGBEE_IAS_ZONE_STATUS_BIT_ALARM2 & zone_status ?
					"opened or alarmed" : "closed or not alarmed");
	printf(" - TAMPER : %s", ZIGBEE_IAS_ZONE_STATUS_BIT_TAMPER & zone_status ?
					"Tampered" : "Not tampered");
	printf(" - BATTERY : %s", ZIGBEE_IAS_ZONE_STATUS_BIT_BATTERY & zone_status ?
					"Low battery" : "Battery OK");
	printf(" - SUPERVISION_REPORTS : %s",
			ZIGBEE_IAS_ZONE_STATUS_BIT_SUPERVISION_REPORTS & zone_status ?
					"Reports" : "Does not report");
	printf(" - RESTORE_REPORTS : %s",
			ZIGBEE_IAS_ZONE_STATUS_BIT_RESTORE_REPORTS & zone_status ?
					"Reports restore" : "Does not report restore");
	printf(" - TROUBLE : %s", ZIGBEE_IAS_ZONE_STATUS_BIT_TROUBLE & zone_status ?
					"Trouble/Failure" : "OK");
	printf(" - AC : %s", ZIGBEE_IAS_ZONE_STATUS_BIT_AC & zone_status ?
					"AC/Mains fault" : "AC/Mains OK");
	printf(" - TEST : %s", ZIGBEE_IAS_ZONE_STATUS_BIT_TEST & zone_status ?
					"Sensor is in test mode" : "Sensor is in operation mode");
	printf(" - BATTERY_DEFECT : %s", ZIGBEE_IAS_ZONE_STATUS_BIT_BATTERY_DEFECT & zone_status ?
					"Sensor detects a defective battery" :
					"Sensor battery is func-tioning normally");
}

static int _send_command_to_light(ZIGBEE_IAS_ZONE_STATUS zone_status)
{
	struct zigbee_sending_info sending_info;
	zigbee_endpoint_list endpoint_list;
	const zigbee_endpoint *endpoint = NULL;
	int ret = EZ_OK;

	memset(&sending_info, 0, sizeof(struct zigbee_sending_info));
	memset(&endpoint_list, 0, sizeof(zigbee_endpoint_list));

	ret = zigbee_device_find_by_cluster(&endpoint_list, ZCL_ON_OFF_CLUSTER_ID, 1);
	if (ret != EZ_OK) {
		printf("failed to find device's cluster\n");
		return ret;
	}

	sending_info.type = ZIGBEE_SENDING_BY_ENDPOINT;

	endpoint = &endpoint_list.endpoint[0];
	memcpy(&sending_info.data.dest_endpoint, endpoint, sizeof(zigbee_endpoint));

	/* open alarm --> switch on, close alarm --> switch off */
	if (ZIGBEE_IAS_ZONE_STATUS_BIT_ALARM1 & zone_status) {
		ret = zigbee_onoff_command(&sending_info, ZIGBEE_ONOFF_ON, ENDPOINT_ON_OFF_SWITCH);
		printf("Send command 'ON'\n");
		if (EZ_OK != ret)
			printf("failed to light ON: %d\n", ret);
	} else {
		ret = zigbee_onoff_command(&sending_info, ZIGBEE_ONOFF_OFF, ENDPOINT_ON_OFF_SWITCH);
		printf("Send command 'OFF'\n");
		if (EZ_OK != ret)
			printf("failed to light OFF: %d\n", ret);
	}

	return ret;
}

static void _show_alarm_zone_type(enum zigbee_ias_zone_type zone_type)
{
	switch (zone_type) {
	case ZIGBEE_IAS_ZONE_TYPE_STANDARD_CIE:
		printf("Zone Type: STANDARD_CIE, Alarm1: System Alarm, Alarm2: N/A");
		break;

	case ZIGBEE_IAS_ZONE_TYPE_MOTION_SENSOR:
		printf("Zone Type: MOTION_SENSOR, Alarm1: Intrusion indication, Alarm2: Presence indication");
		break;

	case ZIGBEE_IAS_ZONE_TYPE_CONTACT_SWITCH:
		printf("Zone Type: CONTACT_SWITCH, Alarm1: 1st portal Open-Close, Alarm2: 2nd portal Open-Close");
		break;

	case ZIGBEE_IAS_ZONE_TYPE_FIRE_SENSOR:
		printf("Zone Type: FIRE_SENSOR, Alarm1: Fire indication, Alarm2: N/A");
		break;

	case ZIGBEE_IAS_ZONE_TYPE_WATER_SENSOR:
		printf("Zone Type: WATER_SENSOR, Alarm1: Water overflow indication, Alarm2: N/A");
		break;

	case ZIGBEE_IAS_ZONE_TYPE_GAS_SENSOR:
		printf("Zone Type: GAS_SENSOR, Alarm1: Carbon Monoxide(CO) indication, Alarm2: Cooking indication");
		break;

	case ZIGBEE_IAS_ZONE_TYPE_PERSONAL_EMERGENCY_DEVICE:
		printf("Zone Type: PERSONAL_EMERGENCY_DEVICE, Alarm1: Fall/Concussion, Alarm2: Emergency button");
		break;

	case ZIGBEE_IAS_ZONE_TYPE_VIBRATION_MOVEMENT_SENSOR:
		printf("Zone Type: VIBRATION_MOVEMENT_SENSOR, Alarm1: Movement indication, Alarm2: Vibration");
		break;

	case ZIGBEE_IAS_ZONE_TYPE_REMOTE_CONTROL:
		printf("Zone Type: REMOTE_CONTROL, Alarm1: Panic, Alarm2: Emergency");
		break;

	case ZIGBEE_IAS_ZONE_TYPE_KEY_FOB:
		printf("Zone Type: KEY_FOB, Alarm1: Panic, Alarm2: Emergency");
		break;

	case ZIGBEE_IAS_ZONE_TYPE_KEYPAD:
		printf("Zone Type: KEYPAD, Alarm1: Panic, Alarm2: Emergency");
		break;

	case ZIGBEE_IAS_ZONE_TYPE_STANDARD_WARNING_DEVICE:
		printf("Zone Type: STANDARD_WARNING_DEVICE, European Standards Series for Intruder Alarm Systems");
		break;

	case ZIGBEE_IAS_ZONE_TYPE_GLASS_BREAK_SENSOR:
		printf("Zone Type: GLASS_BREAK_SENSOR, Alarm1: Glass breakage detected, Alarm2: N/A");
		break;

	case ZIGBEE_IAS_ZONE_TYPE_SECURITY_REPEATER:
		printf("Zone Type: SECURITY_REPEATER, A ZigBee repeater for security devices");
		break;

	case ZIGBEE_IAS_ZONE_TYPE_INVALID_ZONE_TYPE:
		printf("Zone Type: INVALID_ZONE_TYPE");
		break;

	default:
		printf("Zone Type: unknown 0x%04X", zone_type);
		break;
	}
}

static void _show_zone_type(const int node_id)
{
	zigbee_endpoint_list endpoint_list;
	struct zigbee_sending_info sending_info;
	char value[MAX_ATTRIBUTE_SIZE];
	unsigned int value_length = 0;
	int i = 0;
	bool support = false;
	zigbee_error ret = EZ_OK;
	zigbee_attribute_data_type value_type = ZIGBEE_NO_DATA_ATTRIBUTE_TYPE;
	uint16_t zone_type = 0x0000;
	const zigbee_endpoint *endpoint = NULL;

	zigbee_device_find_by_cluster(&endpoint_list, ZCL_IAS_ZONE_CLUSTER_ID, 1);
	for (i = 0; i < endpoint_list.num; i++) {
		if (node_id == endpoint_list.endpoint[i].node_id) {
			sending_info.type = ZIGBEE_SENDING_BY_ENDPOINT;
			endpoint = &endpoint_list.endpoint[i];
			memcpy(&sending_info.data.dest_endpoint, endpoint, sizeof(zigbee_endpoint));
			support = true;
			break;
		}
	}

	if (false == support) {
		printf("Find no remote device for IAS Zone server cluster");
		return;
	}

	ret = zigbee_general_read_remote_attribute(&sending_info, ZCL_IAS_ZONE_CLUSTER_ID,
			ZCL_ZONE_TYPE_ATTRIBUTE_ID, value, &value_length, &value_type,
			ENDPOINT_IAS_CIE);

	if (EZ_OK != ret)
		printf("Read IAS Zone Type attribute from node 0x%04X error: %s",
				sending_info.data.dest_endpoint.node_id, zigbee_error_msg(ret));
	else {
		if (ZIGBEE_ENUM16_ATTRIBUTE_TYPE != value_type) {
			printf("Read value type 0x%02X is not the expected type 0x%02X", value_type,
					ZIGBEE_ENUM16_ATTRIBUTE_TYPE);
			return;
		}

		if (ZIGBEE_ENUM16_ATTRIBUTE_SIZE != value_length) {
			printf("Read value length %d is not the expected length %d", value_length,
					ZIGBEE_ENUM16_ATTRIBUTE_SIZE);
			return;
		}

		memcpy(&zone_type, value, value_length);
		_show_alarm_zone_type(zone_type);
	}
}

static void _on_ias_zone_status_changed_callback(struct zigbee_ias_zone_status_changed_notification *changed_info)
{
	if (NULL == changed_info) {
		printf("Null IAS Zone status changed notification");
		return;
	}

	printf("IAS Zone status 0x%04X source node 0x%04X zone id 0x%02X delay %d",
			changed_info->zone_status, changed_info->node_id, changed_info->zone_id,
			changed_info->delay);

	_show_zone_status(changed_info->zone_status);
	_show_zone_type(changed_info->node_id);
	_send_command_to_light(changed_info->zone_status);
}

static void _on_device_discovery(zigbee_device_discovery *device_discovery)
{
	int ret;

	switch (device_discovery->status) {
	case ZIGBEE_DEVICE_DISCOVERY_START:
		printf("Device discovery start\n");
		break;
	case ZIGBEE_DEVICE_DISCOVERY_FOUND:
		printf("Device discovery found device id 0x%04X\n", device_discovery->device.node_id);
		break;
	case ZIGBEE_DEVICE_DISCOVERY_IN_PROGRESS:
		printf("Device discovery in progress\n");
		if (discover_timeout_id >= 0) {
			ret = _loop_remove_timeout_callback(discover_timeout_id);
			if (ret != EZ_OK)
				printf("failed to remove timeout\n");
		}
		if (EZ_OK != _loop_add_timeout_callback(&discover_timeout_id, TIMEOUT_MSEC,
						_discover_timeout_callback, NULL)) {
			printf("failed to add timeout for re-discovery\n");
			_loop_quit();
		}

		break;
	case ZIGBEE_DEVICE_DISCOVERY_DONE:
		printf("Device discovery finished\n");
		if (discover_timeout_id >= 0) {
			ret = _loop_remove_timeout_callback(discover_timeout_id);
			if (ret != EZ_OK)
				printf("failed to remove timeout\n");
			discovery_retry_count = 0;
		}
		break;
	case ZIGBEE_DEVICE_DISCOVERY_NO_DEVICE:
		printf("Device discovery no device\n");
		if (discover_timeout_id >= 0) {
			ret = _loop_remove_timeout_callback(discover_timeout_id);
			if (ret != EZ_OK)
				printf("failed to remove timeout\n");
		}
		discovery_retry_count++;
		if (discovery_retry_count <= DISCOVERY_MAX_RETRY_COUNT) {
			printf("Device discover timeout, retry\n");
			if (EZ_OK != _loop_add_timeout_callback(&discover_timeout_id, TIMEOUT_MSEC,
					_discover_timeout_callback, NULL)) {
				printf("failed to add timeout for re-discovery\n");
				_loop_quit();
			}
		}
		break;
	case ZIGBEE_DEVICE_DISCOVERY_ERROR:
		printf("Device discovery error\n");
		_loop_quit();
		break;
	case ZIGBEE_DEVICE_DISCOVERY_CHANGED:
		printf("Device discovery changed device id 0x%04X\n", device_discovery->device.node_id);
		break;
	case ZIGBEE_DEVICE_DISCOVERY_LOST:
		printf("Device discovery lost device id 0x%04X\n", device_discovery->device.node_id);
		break;
	default:
		printf("Discovery device unknown result\n");
		_loop_quit();
		break;
	}
}

static void _on_callback(void *user_data, zigbee_response_type response_type, void *payload)
{
	int ret = EZ_OK;

	zigbee_network_notification network_notification;

	switch (response_type) {
	case ZIGBEE_RESPONSE_DEVICE_DISCOVER:
		_on_device_discovery((zigbee_device_discovery *)payload);
		break;

	case ZIGBEE_RESPONSE_NETWORK_NOTIFICATION:
		network_notification = *((zigbee_network_notification *) payload);
		switch (network_notification) {

		case ZIGBEE_NETWORK_FIND_FORM_SUCCESS:
			printf("NETWORK_NOTIFICATION : FIND FORM SUCCESS\n");
			ret = zigbee_network_permitjoin(EASY_PJOIN_DURATION);
			if (ret != EZ_OK) {
				fprintf(stderr, "zigbee_network_permitjoin failed:%s\n", zigbee_error_msg(ret));
				_loop_quit();
			}
			break;

		case ZIGBEE_NETWORK_FIND_FORM_FAILED:
			printf("NETWORK_NOTIFICATION: FIND FORM FAILED");
			_loop_quit();
			break;

		case ZIGBEE_NETWORK_JOIN:
			printf("NETWORK_NOTIFICATION : JOIN\n");
			_device_discover();
			break;
		}
		break;

	case ZIGBEE_RESPONSE_IAS_ZONE_STATUS_CHANGED:
		_on_ias_zone_status_changed_callback((struct zigbee_ias_zone_status_changed_notification *)payload);
		break;
	}
}

static int _create_IAS_CIE_switch_device(void)
{
	int ret = EZ_OK;
	zigbee_local_endpoint_info endpoint_info;

	/* on/off switch create */
	memset(&endpoint_info, 0, sizeof(zigbee_local_endpoint_info));
	endpoint_info.endpoints[endpoint_info.count].profile = ZIGBEE_PROFILE_HA;
	endpoint_info.endpoints[endpoint_info.count].endpoint_id = ENDPOINT_ON_OFF_SWITCH;
	endpoint_info.endpoints[endpoint_info.count].device_id = DEVICE_ON_OFF_SWITCH;
	endpoint_info.count++;

	/* IAS CIE create */
	endpoint_info.endpoints[endpoint_info.count].profile = ZIGBEE_PROFILE_HA;
	endpoint_info.endpoints[endpoint_info.count].endpoint_id = ENDPOINT_IAS_CIE;
	endpoint_info.endpoints[endpoint_info.count].device_id = DEVICE_IAS_CONTROL_AND_INDICATING_EQUIPMENT;
	endpoint_info.count++;

	ret = zigbee_set_local_endpoint(&endpoint_info);
	if (EZ_OK != ret)
		printf("Set local endpoint error %d", ret);

	return ret;
}

static int _reset(void)
{
	int ret = EZ_OK;

	printf("Start reset\n");
	ret = zigbee_reset_local();
	if (EZ_OK != ret)
		printf("Reset failed: %d\n", ret);

	return ret;
}

static void _show_usage(void)
{
	printf("===================================================================================\n");
	printf("usage:\n");
	printf("sample_IAS_CIE_ONOFF_SWITCH [arguments]\n");
	printf("[--reset]         , Reset device\n");
	printf("===================================================================================\n");
}

int main(int argc, char *argv[])
{
	int i = 0;
	int ret = EZ_OK;
	bool need_reset = false;
	GIOChannel *channel = NULL;

	if (argc > 1) {
		for (i = 1; i < argc; i++) {
			if (!strcmp(argv[i], "--reset"))
				need_reset = true;
			if (!strcmp(argv[i], "--help")) {
				_show_usage();
				return -1;
			}
		}
	}

	ret = _create_IAS_CIE_switch_device();
	if (EZ_OK != ret)
		goto free_quit;

	ret = zigbee_initialize(_on_callback, NULL);
	if (EZ_OK != ret)
		goto free_quit;

	if (true == need_reset) {
		ret = _reset();
		if (EZ_OK != ret)
			goto free_quit;
	}

	ret = _network_start();
	if (EZ_OK != ret)
		goto free_quit;

	channel = g_io_channel_unix_new(STDIN_FILENO);
	g_io_channel_set_flags(channel, G_IO_FLAG_NONBLOCK, NULL);
	g_io_channel_unref(channel);

	_loop_run();

free_quit:
	zigbee_deinitialize();

	return 0;
}
