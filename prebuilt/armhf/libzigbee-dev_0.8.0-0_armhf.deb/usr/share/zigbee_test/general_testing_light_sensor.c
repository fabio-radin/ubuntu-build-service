#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <string.h>
#include <assert.h>
#include "zigbee.h"

#define KEYBOARD_INPUT_SIZE			100
#define ENDPOINT_LIGHT_SENSOR		1

#define ATTR_ID_00	0x0000	/* MeasuredValue, 16-bit unsigned integer */
#define ATTR_ID_01	0x0001	/* MinMeasuredValue, 16-bit unsigned integer */
#define ATTR_ID_02	0x0002	/* MaxMeasuredValue, 16-bit unsigned integer */
#define ATTR_ID_04	0x0004	/* LightSensorType, 8-bit enum */

static GMainLoop *mainloop = NULL;

enum operation {
	OPT_READ_LOCAL_ATTRIBUTE = 1,
	OPT_SET_VALUE_1,
	OPT_SET_VALUE_2,
	OPT_SET_VALUE_3,
	OPT_SET_VALUE_4,
	OPT_SET_VALUE_5,
	OPT_SET_VALUE_6,
	OPT_SET_VALUE_7,
	OPT_SET_VALUE_8,
	OPT_SET_VALUE_9,
	OPT_SET_VALUE_10,
	OPT_SET_VALUE_11,
	OPT_SET_VALUE_12,
	OPT_SET_VALUE_13
};

struct attribute_value {
	enum operation operation;		/* Operation code */
	unsigned char attr_04_value;	/* The value for ATTR_ID_04 */
	unsigned short attr_00_value;	/* The value for ATTR_ID_00 */
	unsigned short attr_01_value;	/* The value for ATTR_ID_01 */
	unsigned short attr_02_value;	/* The value for ATTR_ID_02 */
};

struct attribute_value set_values[] = {
	{ OPT_SET_VALUE_1, 0x02, 100, 10, 295 },
	{ OPT_SET_VALUE_2, 0x03, 101, 11, 296 },
	{ OPT_SET_VALUE_3, 0x04, 102, 12, 297 },
	{ OPT_SET_VALUE_4, 0x05, 103, 13, 298 },
	{ OPT_SET_VALUE_5, 0x06, 104, 14, 299 },
	{ OPT_SET_VALUE_6, 0x07, 105, 15, 300 },
	{ OPT_SET_VALUE_7, 0x08, 106, 16, 301 },
	{ OPT_SET_VALUE_8, 0x09, 107, 17, 302 },
	{ OPT_SET_VALUE_9, 0x0A, 108, 18, 303 },
	{ OPT_SET_VALUE_10, 0x0B, 109, 19, 304 },
	{ OPT_SET_VALUE_11, 0x0C, 110, 20, 305 },
	{ OPT_SET_VALUE_12, 0x0D, 111, 21, 306 },
	{ OPT_SET_VALUE_13, 0x0E, 112, 22, 307 },
	{ 0, 0, 0, 0, 0 }
};

static void _loop_run(void)
{
	if (!mainloop)
		mainloop = g_main_loop_new(NULL, FALSE);

	g_main_loop_run(mainloop);
}

static void _loop_quit(void)
{
	if (!mainloop)
		return;

	g_main_loop_quit(mainloop);
}

static void _on_write_local_attribute(int index)
{
	int ret = EZ_OK;
	ZIGBEE_ATTRIBUTE_ID attribute = ATTR_ID_00;
	ZIGBEE_CLUSTER_ID cluster = ZCL_ILLUM_MEASUREMENT_CLUSTER_ID;
	zigbee_attribute_data_type attribute_type = ZIGBEE_INT16U_ATTRIBUTE_TYPE;
	struct attribute_value set_value = set_values[index];

	printf("Write local attribute test\n");
	ret = zigbee_general_write_local_attribute(cluster, attribute, &set_value.attr_00_value,
			sizeof(unsigned short), attribute_type, ENDPOINT_LIGHT_SENSOR);
	if (EZ_OK == ret)
		printf("General write local attribute 0x%04X value %d\n", attribute,
				set_value.attr_00_value);
	else
		printf("General write local attribute 0x%04X value %d failed %d\n", attribute,
				set_value.attr_00_value, ret);

	attribute = ATTR_ID_01;
	ret = zigbee_general_write_local_attribute(cluster, attribute, &set_value.attr_01_value,
			sizeof(unsigned short), attribute_type, ENDPOINT_LIGHT_SENSOR);
	if (EZ_OK == ret)
		printf("General write local attribute 0x%04X value %d\n", attribute,
				set_value.attr_01_value);
	else
		printf("General write local attribute 0x%04X value %d failed %d\n", attribute,
				set_value.attr_01_value, ret);

	attribute = ATTR_ID_02;
	ret = zigbee_general_write_local_attribute(cluster, attribute, &set_value.attr_02_value,
			sizeof(unsigned short), attribute_type, ENDPOINT_LIGHT_SENSOR);
	if (EZ_OK == ret)
		printf("General write local attribute 0x%04X value %d\n", attribute,
				set_value.attr_02_value);
	else
		printf("General write local attribute 0x%04X value %d failed %d\n", attribute,
				set_value.attr_02_value, ret);

	attribute = ATTR_ID_04;
	attribute_type = ZIGBEE_ENUM8_ATTRIBUTE_TYPE;
	ret = zigbee_general_write_local_attribute(cluster, attribute, &set_value.attr_04_value,
			sizeof(char), attribute_type, ENDPOINT_LIGHT_SENSOR);
	if (EZ_OK == ret)
		printf("General write local attribute 0x%04X value 0x%02X\n", attribute,
				set_value.attr_04_value);
	else
		printf("General write local attribute 0x%04X value 0x%02X failed %d\n", attribute,
				set_value.attr_04_value, ret);
}

static void _illum_read_local_attribute(ZIGBEE_ATTRIBUTE_ID attribute)
{
	char value[MAX_ATTRIBUTE_SIZE];
	int ret = EZ_OK;
	int int_value = 0;
	unsigned int read_length = 0;
	zigbee_attribute_data_type value_type = ZIGBEE_UNKNOWN_ATTRIBUTE_TYPE;

	memset(&value, 0, MAX_ATTRIBUTE_SIZE);
	ret = zigbee_general_read_local_attribute(ZCL_ILLUM_MEASUREMENT_CLUSTER_ID, attribute, value,
			&read_length, &value_type, ENDPOINT_LIGHT_SENSOR);
	memcpy(&int_value, value, sizeof(int));

	if (EZ_OK == ret)
		printf("General read local attribute 0x%04X value %d value length %d value type %d\n",
				attribute, int_value, read_length, value_type);
	else
		printf("General read local attribute 0x%04X value failed %d\n", attribute, ret);
}

static void _read_local_attribute_test(void)
{
	printf("Read local attribute test\n");
	_illum_read_local_attribute(ATTR_ID_00);
	_illum_read_local_attribute(ATTR_ID_01);
	_illum_read_local_attribute(ATTR_ID_02);
	_illum_read_local_attribute(ATTR_ID_04);
}

static void _show_operations(void)
{
	int i = 0;

	printf("======================\n");
	printf("q: Quit\n");
	printf("%d: Read local attribute\n", OPT_READ_LOCAL_ATTRIBUTE);
	while (true) {
		if (set_values[i].operation <= 0)
			break;

		printf("%d: Set attribute value to 0x%02X(Attribute 0x%04X), 0x%04X(Attribute 0x%04X),"
				" 0x%04X(Attribute 0x%04X), 0x%04X(Attribute 0x%04X)\n", set_values[i].operation,
				set_values[i].attr_04_value, ATTR_ID_04, set_values[i].attr_00_value, ATTR_ID_00,
				set_values[i].attr_01_value, ATTR_ID_01, set_values[i].attr_02_value, ATTR_ID_02);
		i++;
	}
	printf("Please select operation: ");
	fflush(stdout);
}

bool _read_q(char *input, int max_size)
{
	if (input[0] == 'q' || input[0] == 'Q')
		return true;
	else
		return false;
}

bool _read_lf(char *input, int max_size)
{
	if (input[0] == '\n')
		return true;
	else
		return false;
}

static int _get_digit(char c)
{
	if (c >= '0' && c <= '9')
		return c - '0';

	return -1;
}

static int _get_hex(char c)
{
	if (c >= '0' && c <= '9')
		return c - '0';

	if (c >= 'A' && c <= 'F')
		return c - 'A' + 10;

	if (c >= 'a' && c <= 'f')
		return c - 'a' + 10;

	return -1;
}

static int _read_hex(char *input, int max_size)
{
	int i;
	int result;
	char c;

	result = 0;

	for (i = 0; i < max_size; i++) {
		c = input[i];

		if (_get_hex(c) < 0)
			break;

		result *= 16;
		result += _get_hex(c);
	}

	return result;
}

static int _read_digit(char *input, int max_size)
{
	int i;
	int result;
	char c;

	result = 0;

	for (i = 0; i < max_size; i++) {
		c = input[i];

		if (_get_digit(c) < 0)
			break;

		result *= 10;
		result += _get_digit(c);
	}

	return result;
}

static int _read_int(char *input, int max_size, int default_value)
{
	int i;
	char c;

	for (i = 0; i < max_size; i++) {
		c = input[i];

		if (c == 0 || c == '\n')
			break;

		if (c == '0' && (i + 3) < max_size && (input[i + 1] == 'x' || input[i + 1] == 'X')
				&& _get_hex(input[i + 2]) >= 0 && _get_hex(input[i + 3]) >= 0) {
			return _read_hex(&input[i + 2], max_size - (i + 2));
		}

		if (_get_digit(c) >= 0)
			return _read_digit(&input[i], max_size - i);
	}

	return default_value;
}

static void _on_handle_input_data(char *input, int max_size)
{
	int n = 0, i = 0;

	if (NULL == input) {
		_show_operations();
		return;
	}

	if (_read_q(input, max_size) == true) {
		_loop_quit();
		return;
	}

	if (_read_lf(input, max_size) == true) {
		_show_operations();
		return;
	}

	n = _read_int(input, max_size, -1);

	if (OPT_READ_LOCAL_ATTRIBUTE == n) {
		_read_local_attribute_test();
		return;
	}

	while (true) {
		if (set_values[i].operation <= 0)
			break;

		if (set_values[i].operation == n) {
			_on_write_local_attribute(i);
			return;
		}
		i++;
	}

	printf("\ninvalid input, please try again: ");
	fflush(stdout);
}

static gboolean _on_keyboard_received(GIOChannel *channel, GIOCondition cond, gpointer user_data)
{
	char input[KEYBOARD_INPUT_SIZE];
	int fd = g_io_channel_unix_get_fd(channel);

	if (fd != STDIN_FILENO)
		printf("Wrong fd: %d\n", fd);

	if (cond != G_IO_IN && cond != G_IO_ERR && cond != G_IO_HUP && cond != G_IO_NVAL)
		printf("Wrong cond: %d\n", cond);

	if (user_data)
		printf("Wrong user data: %p\n", user_data);

	if (fgets(input, KEYBOARD_INPUT_SIZE, stdin) == NULL)
		return TRUE;

	_on_handle_input_data(input, KEYBOARD_INPUT_SIZE);

	return TRUE;
}

static int _network_start(zigbee_network_state *state)
{
	int ret = EZ_OK;

	ret = zigbee_network_start(state);
	if (EZ_OK != ret)
		printf("network_start error %d\n", ret);

	return ret;
}

static int _commissioning_initiator_start(void)
{
	int ret = EZ_OK;

	ret = zigbee_ezmode_commissioning(ENDPOINT_LIGHT_SENSOR, true, true);

	if (EZ_OK == ret)
		printf("Commissioning initiator start...\n");
	else
		printf("Commissioning initiator start failed: %d\n", ret);

	return ret;
}

static void _on_commissioning_status(zigbee_commissioning_state commissioning_state)
{
	switch (commissioning_state) {
	case COMMISSIONING_ERROR:
		printf("Commissioning: error\n");
		_loop_quit();
		break;
	case COMMISSIONING_ERR_IN_PROGRESS:
		printf("Commissioning: error in progress, please wait\n");
		break;
	case COMMISSIONING_NETWORK_STEERING_FORM:
		printf("Commissioning: network steering form\n");
		break;
	case COMMISSIONING_NETWORK_STEERING_SUCCESS:
		printf("Commissioning: network steering success\n");
		break;
	case COMMISSIONING_NETWORK_STEERING_FAILED:
		printf("Commissioning: network steering failed\n");
		_loop_quit();
		break;
	case COMMISSIONING_WAIT_NETWORK_STEERING:
		printf("Commissioning: wait for network steering\n");
		break;
	case COMMISSIONING_INITIATOR_SUCCESS:
		printf("Commissioning: initiator success\n");
		_show_operations();
		break;
	case COMMISSIONING_INITIATOR_FAILED:
		printf("Commissioning: initiator failed\n");
		printf("Please run target first, application exit\n");
		_loop_quit();
		break;
	case COMMISSIONING_INITIATOR_STOP:
		printf("Commissioning: initiator stopped\n");
		break;
	default:
		printf("Commissioning: Other status\n");
		_loop_quit();
		break;
	}
}

static void _on_report_request(zigbee_reporting_info *reporting_info)
{
	if (reporting_info->used == true) {
		printf("get reporting configure ep:%d cluster:%d attr:%d min_interval:%d max_interval:%d reportable_change:%d\n",
			   reporting_info->endpoint_id, reporting_info->cluster_id,
			   reporting_info->attribute_id, reporting_info->reported.min_interval,
			   reporting_info->reported.max_interval, reporting_info->reported.reportable_change);
	} else {
		printf("removed reporting configure cluster:%d attr:%d min_interval:%d max_interval:%d reportable_change:%d\n",
			   reporting_info->cluster_id, reporting_info->attribute_id,
			   reporting_info->reported.min_interval, reporting_info->reported.max_interval,
			   reporting_info->reported.reportable_change);
	}
}

static void _on_callback(void *user_data, zigbee_response_type response_type, void *payload)
{
	zigbee_commissioning_target_info *target_info;
	zigbee_commissioning_bound_info *bound_info;

	switch (response_type) {
	case ZIGBEE_RESPONSE_COMMISSIONING_STATUS:
		_on_commissioning_status(*(zigbee_commissioning_state *)payload);
		break;
	case ZIGBEE_RESPONSE_COMMISSIONING_TARGET_INFO:
		target_info = (zigbee_commissioning_target_info *)payload;
		printf("Commissioning: found node id:0x%04X, endpoint:%d\n", target_info->node_id,
				target_info->endpoint_id);
		break;
	case ZIGBEE_RESPONSE_COMMISSIONING_BOUND_INFO:
		bound_info = (zigbee_commissioning_bound_info *)payload;
		printf("Commissioning: bound target endpoint:%d, clusterId:0x%04X, nodeId:0x%04X\n",
				bound_info->endpoint_id, bound_info->cluster_id, bound_info->node_id);
		break;
	case ZIGBEE_RESPONSE_REPORTING_CONFIGURE:
		_on_report_request((zigbee_reporting_info *)payload);
		break;
	default:
		break;
	}
}

static int _create_LIGHT_SENSOR_device(void)
{
	int ret = EZ_OK;

	zigbee_local_endpoint_info endpoint_info;

	memset(&endpoint_info, 0, sizeof(zigbee_local_endpoint_info));

	endpoint_info.endpoints[endpoint_info.count].profile = ZIGBEE_PROFILE_HA;
	endpoint_info.endpoints[endpoint_info.count].endpoint_id = ENDPOINT_LIGHT_SENSOR;
	endpoint_info.endpoints[endpoint_info.count].device_id = DEVICE_LIGHT_SENSOR;
	endpoint_info.count++;

	ret = zigbee_set_local_endpoint(&endpoint_info);
	if (EZ_OK != ret)
		printf("Set local endpoint error %d", ret);

	return ret;
}

static int _reset(void)
{
	int ret = EZ_OK;

	printf("Start reset\n");
	ret = zigbee_reset_local();
	if (EZ_OK != ret)
		printf("Reset failed: %d\n", ret);

	return ret;
}

static void _show_usage(void)
{
	printf("===================================================================================\n");
	printf("usage:\n");
	printf("<application name> [arguments]\n");
	printf("[--reset]         , Reset device\n");
	printf("without argument  , Run ezmode commissioning to establish a network\n");
	printf("===================================================================================\n");
}

int main(int argc, char *argv[])
{
	zigbee_network_state state = ZIGBEE_NO_NETWORK;
	int i = 0;
	int ret = EZ_OK;
	bool need_reset = false;
	GIOChannel *channel = NULL;

	if (argc > 1) {
		for (i = 1; i < argc; i++) {
			if (!strcmp(argv[i], "--reset"))
				need_reset = true;
			if (!strcmp(argv[i], "--help")) {
				_show_usage();
				return -1;
			}
		}
	}

	ret = _create_LIGHT_SENSOR_device();
	if (EZ_OK != ret)
		goto free_quit;

	ret = zigbee_initialize(_on_callback, NULL);
	if (EZ_OK != ret)
		goto free_quit;

	ret = _network_start(&state);
	if (EZ_OK != ret)
		goto free_quit;

	if (true == need_reset) {
		ret = _reset();
		if (EZ_OK != ret)
			goto free_quit;
		state = ZIGBEE_NO_NETWORK;
	}

	ret = _commissioning_initiator_start();
	if (EZ_OK != ret)
		goto free_quit;

	channel = g_io_channel_unix_new(STDIN_FILENO);
	g_io_add_watch(channel, G_IO_IN | G_IO_ERR | G_IO_HUP | G_IO_NVAL, _on_keyboard_received, NULL);
	g_io_channel_set_flags(channel, G_IO_FLAG_NONBLOCK, NULL);
	g_io_channel_unref(channel);

	_loop_run();

free_quit:
	zigbee_deinitialize();

	return 0;
}
