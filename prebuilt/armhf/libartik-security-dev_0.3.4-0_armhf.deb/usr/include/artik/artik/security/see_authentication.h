/*
 * Copyright (c) 2016 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the License);
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __ARTIK_SEE_AUTHENTICATION__H
#define __ARTIK_SEE_AUTHENTICATION__H

#include <artik/security/see_common.h>

/**
 * @file see_authentication.h
 * @brief basic authentication security API
 *
 * @example see-authentication-test.c
 */

/**
 * @ingroup security
 * @defgroup see_authentication See_Authentication
 * @brief basic authentication security API
 *
 * This API provides an easy way to create a secure solution.
 * You can connect to the Samsung Cloud using this security API with TLS.
 * @{
 */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Generate a random number
 *
 * - Generate a random number.
 * - Limitations
 * <PRE>
 * 	Size : 1 ~ 236   - true random number from SE
 * 	       237 ~ 512 - pseudo random number
 * </PRE>
 *
 * @param[in]  size   : Size of the random number.
 * @param[out] random : Random number will be returned.
 * @returns 0 if succeeded. Returns other value if failed.
 * @see struct see_data
 */
int see_generate_random(unsigned int size, see_data *random);

/**
 * @brief Generate certificate
 *
 * - Generate a certificate and store the generated certificate in secure storage.
 * - A certificate in secure storage cannot be overwritten.
 * - If a user wants to generate a certificate in special storage,
 *   the user should prefix a location with index.
 * <PRE>
 * 	1. SE Storage       : SE/
 * 	2. TEMP Storage     : TMP/
 * 	 - TEMP Storage save a data on volatile memory,
 * 	   so the data is discarded when finalizing API.
 * </PRE>
 * - Limitations
 * <PRE>
 * 	1. TEE Storage
 * 		1) Issuer/Subject Algorithm : RSA_1024,
 * 		                              RSA_2048,
 * 		                              ECC_BRAINPOOL_P256R1,
 * 		                              ECC_BRAINPOOL_P384R1,
 * 		                              ECC_BRAINPOOL_P512R1,
 * 		                              ECC_SEC_P256R1,
 * 		                              ECC_SEC_P384R1,
 * 		                              ECC_SEC_P521R1
 * 		2) Capacity  : Irrespective of data type, 1024 files in TEE Storage
 * 		3) Cert name : 20 character max length
 * 	2. SE Storage
 * 		1) Issuer/Subject Algorithm : RSA_1024,
 * 		                              RSA_2048,
 * 		                              ECC_BRAINPOOL_P256R1,
 * 		                              ECC_BRAINPOOL_P384R1,
 * 		                              ECC_BRAINPOOL_P512R1,
 * 		                              ECC_SEC_P256R1,
 * 		                              ECC_SEC_P384R1,
 * 		                              ECC_SEC_P521R1
 * 		2) Capacity  : SE/0 ~ 3
 * 		3) Cert name : 5 character max length include “SE/” prefix (“SE/”)
 * 	3. TEMP Storage
 * 		1) Issuer/Subject Algorithm : RSA_1024,
 * 		                              RSA_2048,
 * 		                              ECC_BRAINPOOL_P256R1,
 * 		                              ECC_BRAINPOOL_P384R1,
 * 		                              ECC_BRAINPOOL_P512R1,
 * 		                              ECC_SEC_P256R1,
 * 		                              ECC_SEC_P384R1,
 * 		                              ECC_SEC_P521R1
 * 		2) Capacity  : TMP/0 ~ 3 for Irrespective of data type
 * 		3) Cert name : 6 character max length include “TMP/” prefix (“TMP/”)
 * </PRE>
 *
 * @param[in] cert_name : Certificate name in secure storage.
 * @param[in] csr       : Certificate Signing Request is filled by user.
 * @param[in] cert      : Generated certificate will be returned.
 * @returns 0 if succeeded. Returns other value if failed.
 * @see struct see_csr
 */
int see_generate_certificate(const char *cert_name, see_csr *csr,
		see_data *cert);

/**
 * @brief Set certificate
 *
 * - Store a certificate in secure storage.
 * - A certificate in secure storage cannot be overwritten.
 * - If a user wants to store a certificate in special storage,
 *   the user should prefix a location with index.
 * <PRE>
 * 	1. SE Storage       : SE/
 * 	2. TEMP Storage     : TMP/
 * 	 - TEMP Storage save a data on volatile memory,
 * 	   so the data is discarded when finalizing API.
 * </PRE>
 * - Limitations
 * <PRE>
 * 	1. TEE Storage
 * 		1) Capacity  : Irrespective of data type, 1024 files in TEE Storage
 * 		2) Cert name : 20 character max length
 * 	2. SE Storage
 * 		1) Capacity  : SE/0 ~ 3
 * 		2) Cert name : 5 character max length include “SE/” prefix (“SE/”)
 * 	3. TEMP Storage
 * 		1) Capacity  : TMP/0 ~ 3 for Irrespective of data type
 * 		2) Cert name : 6 character max length include “TMP/” prefix (“TMP/”)
 * </PRE>
 *
 * @param[in] cert_name   : Certificate name in secure storage.
 * @param[in] certificate : Certificate data which a user enter.
 * @returns 0 if succeed. Returns other value if fail.
 * @see struct see_data
 */
int see_set_certificate(const char *cert_name, see_data cert);

/**
 * @brief Get certificate
 *
 * - Get a certificate from secure storage.
 * - If a user wants to get a certificate in special storage,
 *   the user should prefix a location with index.
 * <PRE>
 * 	1. SE Storage       : SE/
 * 	2. TEMP Storage     : TMP/
 * 	 - TEMP Storage save a data on volatile memory,
 * 	   so the data is discarded when finalizing API.
 * 	3. ARTIK Credential : ARTIK/
 * 	4. Post Provision   : POSTP/
 * </PRE>
 * - Limitation
 * <PRE>
 * 	1. TEE Storage
 * 		Cert name : 20 character max length
 * 	2. SE Storage
 * 		Cert name : 5 character max length include “SE/” prefix (“SE/”)
 * 	3. TEMP Storage
 * 		Cert name : 6 character max length include “TMP/” prefix (“TMP/”)
 * 	4. ARTIK Credential
 * 		Cert name : 7 character max length include “ARTIK/” prefix (“ARTIK/”)
 * 	5. Post Provision
 * 		Cert name : 7 character max length include “POSTP/” prefix (“POSTP/”)
 * </PRE>
 *
 * @param[in] cert_name    : Certificate name in secure storage.
 * @param[out] certificate : Certificate in secure storage will be returned.
 * @returns 0 if succeeded. Returns other value if failed.
 * @see struct see_data
 */
int see_get_certificate(const char *cert_name, see_data *cert);

/**
 * @brief Remove certificate
 *
 * - Remove a certificate in secure storage.
 * - If a user wants to remove a certificate in special storage,
 *   the user should prefix a location with index.
 * <PRE>
 * 	1. SE Storage  : SE/
 *  2. TEMP Storage  : TMP/
 * 	 - TEMP Storage save a data on volatile memory,
 * 	   so the data is discarded when finalizing API.
 * </PRE>
 * - Limitation
 * <PRE>
 * 	1. TEE Storage
 * 		Cert name : 20 character max length
 * 	2. SE Storage
 * 		Cert name : 5 character max length include “SE/” prefix (“SE/”)
 * 	3. TEMP Storage
 * 		Cert name : 6 character max length include “TMP/” prefix (“TMP/”)
 * </PRE>
 *
 * @param[in] cert_name : Certificate name in Secure storage.
 * @returns 0 if succeeded. Returns other value if failed.
 */
int see_remove_certificate(const char *cert_name);

/**
 * @brief Get RSA signature
 *
 * - Get a signed data by RSA Private Key from hashed data.
 * - If a user wants to get an RSA signature using a key in special storage,
 *   the user should prefix a location with index.
 * <PRE>
 * 	1. TEMP Storage : TMP/
 * 	 - TEMP Storage save a data on volatile memory,
 * 	   so the data is discarded when finalizing API.
 * 	2. Post Provision : POSTP/
 * </PRE>
 * Limitation
 * <PRE>
 * 	1. RSA Mode        : RSASSA_PKCS1_V1_5_MD5,
 * 	                     RSASSA_PKCS1_V1_5_SHA1,
 * 	                     RSASSA_PKCS1_V1_5_SHA224,
 * 	                     RSASSA_PKCS1_V1_5_SHA256,
 * 	                     RSASSA_PKCS1_V1_5_SHA384,
 * 	                     RSASSA_PKCS1_V1_5_SHA512,
 * 	                     RSASSA_PKCS1_PSS_MGF1_SHA1,
 * 	                     RSASSA_PKCS1_PSS_MGF1_SHA224,
 * 	                     RSASSA_PKCS1_PSS_MGF1_SHA256,
 * 	                     RSASSA_PKCS1_PSS_MGF1_SHA384,
 * 	                     RSASSA_PKCS1_PSS_MGF1_SHA512
 * 	for Post Provision : RSASSA_PKCS1_V1_5_SHA256,
 * 	                     RSASSA_PKCS1_PSS_MGF1_SHA256
 * 	2. Key name : 20 character max length for TEE Storage,
 * 	              6 character max length include “TMP/” prefix (“TMP/”)
 * 	              7 character max length include “POSTP/” prefix (“POSTP/”)
 * </PRE>
 *
 * @param[in] mode     : RSA mode.
 * @param[in] key_name : Key name for signing.
 * @param[in] hash     : Hashed data.
 * @param[out] sign    : Signed data from hashed data will be returned.
 * @returns 0 if succeeded. Returns other value if failed.
 * @see enum see_rsa_mode
 * @see struct see_data
 */
int see_get_rsa_signature(see_rsa_mode mode, const char *key_name,
		see_data hash, see_data *sign);

/**
 * @brief Verify RSA signature
 *
 * - Verify signed data with the original hashed data.
 * - If a user wants to verify an RSA signature using a key in special storage,
 *   the user should prefix a location with index.
 * <PRE>
 * 	1. TEMP Storage : TMP/
 *   - TEMP Storage save a data on volatile memory,
 *     so the data is discarded when finalizing API.
 * </PRE>
 * - Limitations
 * <PRE>
 * 	1. RSA Mode : RSASSA_PKCS1_V1_5_MD5,
 * 	              RSASSA_PKCS1_V1_5_SHA1,
 * 	              RSASSA_PKCS1_V1_5_SHA224,
 * 	              RSASSA_PKCS1_V1_5_SHA256,
 * 	              RSASSA_PKCS1_V1_5_SHA384,
 * 	              RSASSA_PKCS1_V1_5_SHA512,
 * 	              RSASSA_PKCS1_PSS_MGF1_SHA1,
 * 	              RSASSA_PKCS1_PSS_MGF1_SHA224,
 * 	              RSASSA_PKCS1_PSS_MGF1_SHA256,
 * 	              RSASSA_PKCS1_PSS_MGF1_SHA384,
 * 	              RSASSA_PKCS1_PSS_MGF1_SHA512
 * 	2. Key name : 20 characters max length for TEE Storage, SE Storage doesn’t support RSA
 * 	              6 character max length include “TMP/” prefix (“TMP/”)
 * </PRE>
 *
 * @param[in] mode     : RSA mode.
 * @param[in] key_name : Key name for verifing.
 * @param[in] hash     : Hashed data.
 * @param[in] sign     : Signed data from hashed data.
 * @returns 0 if succeeded. Returns other value if failed.
 * @see enum see_rsa_mode
 * @see struct see_data
 */
int see_verify_rsa_signature(see_rsa_mode mode, const char *key_name,
		see_data hash, see_data sign);

/**
 * @brief Get ECDSA signature
 *
 * - Get signed data by ECDSA key from hashed data.
 * - If a user wants to get ECDSA signature using a key in special storage,
 *   the user should prefix a location with index.
 * <PRE>
 *  1. TEMP Storage : TMP/
 *   - TEMP Storage save a data on volatile memory,
 *     so the data is discarded when finalizing API.
 * 	2. ARTIK Credential : ARTIK/
 * 	3. Post Provision   : POSTP/
 * </PRE>
 * - Limitation
 * <PRE>
 * 	1. ECDSA Curve       : ECDSA_BRAINPOOL_P256R1,
 * 	                       ECDSA_BRAINPOOL_P384R1,
 * 	                       ECDSA_BRAINPOOL_P512R1,
 * 	                       ECDSA_SEC_P256R1,
 * 	                       ECDSA_SEC_P384R1,
 * 	                       ECDSA_SEC_P521R1
 * 	for Post Provision   : ECDSA_BRAINPOOL_P256R1,
 * 	                       ECDSA_SEC_P256R1
 * 	for Artik credential : ECDSA_BRAINPOOL_P256R1
 * 	2. Key name    : 20 characters max length for TEE Storage, SE Storage doesn’t support ECDSA
 * 	                 6 character max length include “TMP/” prefix (“TMP/”)
 * 	                 7 character max length include “POSTP/” prefix (“POSTP/”)
 * 	                 7 character max length include “ARTIK/” prefix (“ARTIK/”)
 * </PRE>
 *
 * @param[in] curve    : ECDSA Curve.
 * @param[in] key_name : Key name for signing.
 * @param[in] hash     : Hashed data.
 * @param[out] sign    : Signed data from hashed data will be returned.
 * @returns 0 if succeeded. Returns other value if failed.
 * @see enum see_curve
 * @see struct see_data
 */
int see_get_ecdsa_signature(see_ecdsa_curve curve, const char *key_name,
		see_data hash, see_data *sign);

/**
 * @brief Verify ECDSA signature
 *
 * - Verify signed data using ECDSA Key with the original hashed data.
 * - If a user wants to verify ECDSA signature using a key in special storage,
 *   the user should prefix a location with index.
 * <PRE>
 *  1. TEMP Storage : TMP/
 *   - TEMP Storage save a data on volatile memory,
 *     so the data is discarded when finalizing API.
 * </PRE>
 * - Limitations
 * <PRE>
 * 	1. ECDSA Curve : ECDSA_BRAINPOOL_P256R1,
 * 	                 ECDSA_BRAINPOOL_P384R1,
 * 	                 ECDSA_BRAINPOOL_P512R1,
 * 	                 ECDSA_SEC_P256R1,
 * 	                 ECDSA_SEC_P384R1,
 * 	                 ECDSA_SEC_P521R1
 * 	2. Key name    : 20 characters max length for TEE Storage, SE Storage doesn’t support ECDSA
 * 	                 6 character max length include “TMP/” prefix (“TMP/”)
 * </PRE>
 *
 * @param[in] curve     : ECDSA Curve.
 * @param[in] key_name  : Key name for signing.
 * @param[in] hash      : Hashed data.
 * @param[in] sign      : Signed data from hashed data.
 * @returns 0 if succeeded. Returns other value if failed.
 * @see enum see_rsa_mode
 * @see struct see_data
 */
int see_verify_ecdsa_signature(see_ecdsa_curve curve, const char *key_name,
		see_data hash, see_data sign);

/**
 * @brief Get HASH
 *
 * - Get hashed data from input data.
 * - Limitations
 * <PRE>
 * 	1. Algorithm       : HASH_MD5,
 * 	                     HASH_SHA1,
 * 	                     HASH_SHA224,
 * 	                     HASH_SHA256,
 * 	                     HASH_SHA384,
 * 	                     HASH_SHA512
 * 	2. Input data size : Up to 2MB
 * </PRE>
 *
 * @param[in] algo : Hash algorithm.
 * @param[in] data : Input data.
 * @param[in] hash : Hashed data.
 * @returns 0 if succeeded. Returns other value if failed.
 * @see enum see_algorithm
 * @see struct see_data
 */
int see_get_hash(see_algorithm algo, see_data data, see_data *hash);

/**
 * @brief Get HMAC
 *
 * - Get HMAC from input data
 * - Limitations
 * <PRE>
 * 	1. Algorithm       : HMAC_MD5,
 * 	                     HMAC_SHA1,
 * 	                     HMAC_SHA224,
 * 	                     HMAC_SHA256,
 * 	                     HMAC_SHA384,
 * 	                     HMAC_SHA512
 * 	2. Input data size : 2 MB max size
 * </PRE>
 *
 * @param[in] algo     : HMAC algorithm.
 * @param[in] key_name : HMAC Key name in secure storage.
 * @param[in] data     : Input data.
 * @param[in] hash     : HMAC data.
 * @returns 0 if succeeded. Returns other value if failed.
 * @see enum see_algorithm
 * @see struct see_data
 */
int see_get_hmac(see_algorithm algo, const char *key_name, see_data data,
		see_data *hmac);

/**
 * @brief Generate DH Parameters
 *
 * - Generate DH Parameters and Get Public
 *
 * @param[out] params     : DH Parameters will be returned.
 * @param[out] public     : Public will be returned.
 * @returns 0 if succeeded. Returns other value if failed.
 * @see struct see_data
 */
int see_generate_dhparams(see_data *params, see_data *public);

/**
 * @brief Set DH Parameters
 *
 * - Set DH Parameters and Get Public
 *
 * @param[in] params      : DH Parameters
 * @param[out] public     : Public will be returned.
 * @returns 0 if succeeded. Returns other value if failed.
 * @see struct see_data
 */
int see_set_dhparams(see_data params, see_data *public);

/**
 * @brief Compute DH Parameters
 *
 * - Compute DH Parameters and Get Premaster Secret
 *
 * @param[in] public      : Public
 * @param[out] secret     : Premaster Secret will be returned.
 * @returns 0 if succeeded. Returns other value if failed.
 * @see struct see_data
 */
int see_compute_dhparams(see_data public, see_data *secret);

/**
 * @brief Generate ECDH Parameters
 *
 * - Generate ECDH Key Pair and Get Public Key
 * - Limitation
 * <PRE>
 * 	1. Algoritm : ECC_BRAINPOOL_P256R1,
 * 	              ECC_BRAINPOOL_P384R1,
 * 	              ECC_BRAINPOOL_P512R1,
 * 	              ECC_SEC_P256R1,
 * 	              ECC_SEC_P384R1,
 * 	              ECC_SEC_P521R1
 * </PRE>
 *
 * @param[in] algo         : ECC Algoritm
 * @param[out] public      : Public
 * @returns 0 if succeeded. Returns other value if failed.
 * @see struct see_data
 */
int see_generate_ecdhkey(see_algorithm algo, see_data *public);

/**
 * @brief Compute ECDH Parameters
 *
 * - Compute ECDH Key Pair and Get Pre Master Secret
 *
 * @param[in] public       : Public
 * @param[out] secret      : Premaster Secret will be returned.
 * @returns 0 if succeeded. Returns other value if failed.
 * @see struct see_data
 */
int see_compute_ecdhkey(see_data public, see_data *secret);

#ifdef __cplusplus
}
#endif

/**
 * @}
 */
#endif
