/*
 * Copyright (c) 2016 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the License);
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __ZIGBEE_H
#define __ZIGBEE_H

/**
 * @defgroup	zigbee ZigBee
 * @brief		Artik ZigBee API
 *
 * This module includes ZigBee API.
 * @{
 */

#include <glib.h>
#include <zigbee_def.h>
#include <zigbee_clusters.h>
#include <zigbee_attributes.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief		logging backend system
 */
enum zigbee_log_system {
	ZIGBEE_LOG_SYSTEM_STDERR,	/**< Standard error */
	ZIGBEE_LOG_SYSTEM_SYSLOG,	/**< syslog */
	ZIGBEE_LOG_SYSTEM_NONE,		/**< no log */
	ZIGBEE_LOG_SYSTEM_CUSTOM	/**< use custom log handler */
};

/**
 * @brief		Callback function type
 */
typedef void(*zigbee_client_callback)(void *user_data,
									  zigbee_response_type response_type,
									  void *payload);

/**
 * @brief		Set local endpoints, they are saved locally and used to create
 *				device when initialize() is called.
 *
 * @param [in]	endpoint_info	The local endpoints to be saved
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_set_local_endpoint(zigbee_local_endpoint_info *endpoint_info);

/**
 * @brief		Get local endpoints which are saved locally when last function
 *				set_local_endpoint() is called.
 *
 * @param [out]	endpoint_info	The local endpoints to be returned
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_get_local_endpoint(zigbee_local_endpoint_info *endpoint_info);

/**
 * @brief		Get device handle list
 *
 * @return		Return the local device handle list.
 */
GList *zigbee_get_handle_list(void);

/**
 * @brief		Deinitialize, release the data allocated in artik-sdk
 */
void zigbee_deinitialize(void);

/**
 * @brief		Initialize zigbee module
 * @param [in]	callback	User callback function for receiving,
 *							such a command results, it can be NULL.
 * @param [in]	user_data	Send user data, it can be NULL.
 * @return		 Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_initialize(zigbee_client_callback app_callback, void *user_data);

/**
 * @brief		Form a new network as a coordinator.
 *
 * This begins a search for an unused Channel and Pan Id.
 * Then this will automatically form a network on the first unused Channel
 * and Pan Id it finds.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 * Callback function is called for notifying the result.
 * -Response type : ZIGBEE_RESPONSE_NETWORK_NOTIFICATION
 * -Response payload : pointer of zigbee_network_notification
 *						ZIGBEE_NETWORK_FIND_FORM_SUCCESS (succeeded)
 *						ZIGBEE_NETWORK_FIND_FORM_FAILED (failed)
 */
int zigbee_network_form(void);

/**
 * @brief		Form a new network as a coordinator
 *
 * @param [in]	network_info	Network information for forming network
 *								including channel, tx power, pan ID
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_network_form_manually(const zigbee_network_info *network_info);

/**
 * @brief		Permit joining to the formed network from other nodes
 *
 * @param [in]	duration	Second value to permit joining, 0xff is unlimited
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_network_permitjoin(int duration_sec);

/**
 * @brief		Leave from the joined network
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_network_leave(void);

/**
 * @brief		Join to the existing network by other coordinator automatically.

 * Begins a search for a joinable network.
 * Will automatically join to the first found network.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 * Callback function is called for notifying the result.
 * -Response type : ZIGBEE_RESPONSE_NETWORK_NOTIFICATION
 * -Response payload : pointer of zigbee_network_notification
 *						ZIGBEE_NETWORK_FIND_JOIN_SUCCESS (succeeded)
 *						ZIGBEE_NETWORK_FIND_JOIN_FAILED (failed)
 */
int zigbee_network_join(void);

/**
 * @brief		Stop the network scanning.
 *				When 'network form', 'network join' and 'network find' are
 *				called, network scanning is conducted in zigbeed side, this
 *				api is provided to stop network scanning.
 *
 * @return		Result of operation, EZ_OK when succeeded, otherwise failed.
 */
int zigbee_network_stop_scan(void);

/**
 * @brief		Join to the formed network by other coordinator
 *
 * @param [in]	network_info	Network information for forming network
 *								including channel, tx power, pan ID
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_network_join_manually(const zigbee_network_info *network_info);

/**
 * @brief		Scan existing networks
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 * Callback function is called for notifying the result.
 * -Response type : ZIGBEE_RESPONSE_NETWORK_FIND
 * -Response payload : pointer of struct zigbee_network_find_result
 */
int zigbee_network_find(void);

/**
 * @brief		Request my current network status
 *
 * @param [out]	state	ZIGBEE_JOINED_NETWORK when succeeded
 *						ZIGBEE_NO_NETWORK if the node is not part of a network
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_network_request_my_network_status(zigbee_network_state *state);

/**
 * @brief		Request device/service discovery
 *				Device/service discovery is a cyclic call, for the cyclic
 *				duration setting, please check api 'set_discover_cycle_time'.
 *				If current api 'device_discover' is called, the discovery is
 *				triggered immediately.
 *
 * @return		Result of operation, EZ_OK when succeeded
 *
 * The result will be delivered through callback function.
 * Callback function is called for notifying the result.
 * -Response type : ZIGBEE_RESPONSE_DEVICE_DISCOVER
 * -Response payload : pointer of zigbee_device_discovery.
 *					zigbee_device_discovery_status will be sent in
 *					different phases.
 *					Initialization phase:
 *						ZIGBEE_DEVICE_DISCOVERY_START,
 *						ZIGBEE_DEVICE_DISCOVERY_IN_PROGRESS.
 *					Discovery phase:
 *						ZIGBEE_DEVICE_DISCOVERY_FOUND,
 *						ZIGBEE_DEVICE_DISCOVERY_ERROR.
 *					Complete phase:
 *						ZIGBEE_DEVICE_DISCOVERY_DONE,
 *						ZIGBEE_DEVICE_DISCOVERY_NO_DEVICE.
 */
int zigbee_device_discover(void);

/**
 * @brief		Set the cyclic duaration of device discovery cycle
 *
 * @param[in]	cycle_duration	The cyclic duaration, in minutes, in the range 0~60,
 *								positive value. The default cyclic duration is 1 minute.
 *								If the value is equal to 0 , the loop timer is stopped.
 *
 * @return		Result of operation, EZ_OK when succeeded
 */
int zigbee_set_discover_cycle_time(unsigned int cycle_duration);

/**
 * @brief		Request my current device type
 *
 * @param [out]	type	current device type
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_device_request_my_node_type(zigbee_node_type *type);

/**
 * @brief		Find endpoint list to filtered by cluster ID and SERVER/CLIENT
 *
 * @param [out]	endpoints	Endpoint list that are matched by other parameters
 * @param [in]	cluster_id	Cluster ID that is defined in artik-cluster-id.h
 * @param [in]	is_server	1 for SERVER, 0 for CLIENT
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_device_find_by_cluster(zigbee_endpoint_list *endpoints,
								   int cluster_id, int is_server);

/**
 * @brief		Send Command Line Interface(CLI) command
 *				This is normally used for certification testing
 *
 * @param [in]	command		String of CLI command
 */
void zigbee_raw_request(const char *command);

/**
 * @brief		Check if the endpoint contains the server/client cluster
 * @param [in]	endpoint	The endpoint to be checked
 * @param [in]	cluster_id	The cluster id defined in zigbee_def.h
 * @param [in]	is_server	Server cluster or client cluster,
 *							true for server, false for client.
 * @return		Result of operation, EZ_OK on contains, error code otherwise.
 */
int zigbee_check_local_endpoint_contains_cluster(zigbee_local_endpoint *endpoint,
												 int cluster_id,
												 bool is_server);

/**
 * @brief		Get endpoint information by endpoint_id
 * @param [out]	endpoint		The endpoint information to be returned.
 * @param [in]	endpoint_id		the endpoint id to be checked
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_get_local_endpoint_by_endpointid(zigbee_local_endpoint *endpoint,
											int endpoint_id);

/**
 * @brief		Send command "Identify", to request identify.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [in]	duration		Identify duration in seconds. in the range 0~0xffff
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_identify_request(const struct zigbee_sending_info *sending_info,
							int duration, int local_endpoint);

/**
 * @brief		Send command "Identify Query", to get remote identify time.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [out]	time			Remaining seconds of identifying.
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_identify_get_remaining_time(const struct zigbee_sending_info *sending_info,
									   int *time, int local_endpoint);

/**
 * @brief		Get attribute of "name support" of cluster "Groups".
 *
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		EZ_OK, group names is supported.
 *				E_NOT_SUPPORTED, group names isn't supported.
 *				otherwise is others error code.
 */
int zigbee_groups_get_local_name_support(int local_endpoint);

/**
 * @brief		Set local attribute of "name support" of cluster "Groups".
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	support			Set name support attribute.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_groups_set_local_name_support(int local_endpoint, bool support);

/**
 * @brief		Commands are defined here for discovering the group membership of a
 * 				device, adding a group, removing a group and removing all groups.
 *
 *				Any endpoint on any device MAY be assigned to one or more groups,
 *				each labeled with a 16-bit identifier (0x0001 - 0xfff7), which acts
 *				for all intents and purposes like a network address.
 *				Once a group is established, frames will be delivered to every endpoint
 *				assigned to the group address.
 *
 * @param [in]		sending_info	Command sending information, including sending type,
 *									source or destination information, etc.
 * @param [in/out]	groups_info		Group command to be sent or got.
 *									Refer to struct zigbee_groups_info.
 * @param [in]		local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_groups_command(const struct zigbee_sending_info *sending_info,
						  zigbee_groups_info *groups_info,
						  int local_endpoint);

/**
 * @brief		Send command to control remote on/off.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [in]	target_status	On/off command, please refer to
 *								"enum zigbee_onoff_status".
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_onoff_command(const struct zigbee_sending_info *sending_info,
						 const zigbee_onoff_status target_status,
						 int local_endpoint);

/**
 * @brief		Get attribute of "on/off" of cluster "On/off".
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [out]	status			On/off status(refer to enum zigbee_onoff_status).
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_onoff_get_value(int local_endpoint, zigbee_onoff_status *status);

/**
 * @brief		Send commands about level control, to control remote level.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [in]	command			Level control command, please refer
 *								to "struct zigbee_level_control_command".
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_level_control_request(const struct zigbee_sending_info *sending_info,
								 const zigbee_level_control_command *command,
								 int local_endpoint);

/**
 * @brief		Get attribute of "current level" of cluster "Levle Control".
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [out]	value			Current level of this device. The meaning of
 *								'level' is device dependent.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_level_control_get_value(int local_endpoint, int *value);

/**
 * @brief		Send commands about level control, to control remote level.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [in]	command			Color control command, please refer to
 *								"struct zigbee_color_control_command".
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_color_control_request(const struct zigbee_sending_info *sending_info,
								 const zigbee_color_control_command *command,
								 int local_endpoint);

/**
 * @brief		Get attributes of cluster "Color Control".
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [out]	value			Attributes values of cluster "Color Control",
 *								refer to "struct zigbee_color_control_value".
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_color_control_get_value(int local_endpoint,
								   zigbee_color_control_value *value);

/**
 * @brief		Set the range of illuminance in measured value(1 to 65534(0xFFFE))
 *				Max value shall be greater than min value.
 *				MeasuredValue represents the Illuminance in Lux (symbol lx)
 *				as follows:
 *				MeasuredValue = 10,000 x log10 Illuminance + 1
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	min				Min measured value.
 * @param [in]	max				Max measured value.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_illum_set_measured_value_range(int local_endpoint,
										  int min, int max);

/**
 * @brief		Set the measured illuminance value.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	value			Measured value, in the range 1 to 65534(0xfffe),
 *								which corresponding to illuminance of 1 lx to
 *								3.576 x 10^6 lx.
 *
 *								MeasuredValue represents the Illuminance in
 *								Lux (symbol lx) as follows:
 *								MeasuredValue = 10,000 x log10 Illuminance + 1
 *
 *								e.g. To set the sensor to 10 lx, use calculated value 10001.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_illum_set_measured_value(int local_endpoint, int value);

/**
 * @brief		Get the Illuminance value
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [out]	value			Measured value, in the range 1 to 65534(0xfffe).
 *
 *								MeasuredValue represents the Illuminance in
 *								Lux (symbol lx) as follows:
 *								MeasuredValue = 10,000 x log10 Illuminance + 1
 *
 *								e.g. The returned value 10001 means 10 lx.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_illum_get_measured_value(int local_endpoint, int *value);

/**
 * @brief		Set attribute "occupancy sensor type" of cluster
 *				"Occupancy Sensing".
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	type			occupancy sensor type.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_occupancy_set_type(int local_endpoint,
							  zigbee_occupancy_type type);

/**
 * @brief		Set attribute "occupancy" of cluster "Occupancy Sensing".
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	status			attribute value of "occupancy".
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_occupancy_set_value(int local_endpoint,
							   zigbee_occupancy_status status);

/* fan control server */
/**
 * @brief		Get "fan mode" attribute of cluster "Fan Control".
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [out]	mode			Local fan mode pointer(refer to enum fan_mode).
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_fan_get_mode(int local_endpoint, zigbee_fan_mode *mode);

/* fan control server */
/**
 * @brief		Get "fan mode sequence" attribute of cluster "Fan Control".
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [out]	seq				Local fan mode sequence pointer.
 *								(refer to enum fan_mode_sequence).
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_fan_get_mode_sequence(int local_endpoint,
								 zigbee_fan_mode_sequence *seq);

/* ezmode commissioning */
/**
 * @brief		Do ezmode commissioning procedure.
 *				Firstly do network steering.
 *				Secondly do find and bind target start, see zigbee_find_bind_target_start.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 * [Commissioning result in target side]
 *	-Response type : ZIGBEE_RESPONSE_COMMISSIONING_STATUS
 *	-Response payload : pointer of zigbee_commissioning_state
 */
int zigbee_ezmode_commissioning_target_start(int local_endpoint);

/* ezmode commissioning */
/**
 * @brief		Do ezmode commissioning procedure.
 *				Firstly do network steering.
 *				Secondly do find and bind initiator start, see zigbee_find_bind_initiator_start.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 * [Commissioning result in initiator side]
 *	-Response type : ZIGBEE_RESPONSE_COMMISSIONING_STATUS
 *	-Response payload : pointer of zigbee_commissioning_state
 *
 *	[Target information in initiator side]
 *	-Response type : ZIGBEE_RESPONSE_COMMISSIONING_TARGET_INFO
 *	-Response payload : pointer of zigbee_commissioning_target_info
 *
 *	[Bind information in initiator side]
 *	-Response type : ZIGBEE_RESPONSE_COMMISSIONING_TARGET_INFO
 *	-Response payload : pointer of zigbee_commissioning_target_info
 */
int zigbee_ezmode_commissioning_initiator_start(int local_endpoint);

/* factory reset */
/**
 * @brief		Factory reset operation, that clear bindings and groups.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_factory_reset(void);

/**
 * @brief		Reset local device attribute, binding list and initialize network.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_reset_local(void);

/* local attribute reset */
/**
 * @brief		Reset local attribute to default.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_reset_local_attr(int local_endpoint);

/* network steering */
/**
 * @brief		Do network steering
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 * Callback function is called for notifying the result.
 * -Response type : ZIGBEE_RESPONSE_COMMISSIONING_STATUS
 * -Response payload : pointer of zigbee_commissioning_state including
 *						COMMISSIONING_ERROR
 *						COMMISSIONING_ERR_IN_PROGRESS
 *						COMMISSIONING_NETWORK_STEERING_FORM
 *						COMMISSIONING_NETWORK_STEERING_SUCCESS
 *						COMMISSIONING_NETWORK_STEERING_FAILED
 *						COMMISSIONING_WAIT_NETWORK_STEERING
 */
int zigbee_network_steering(void);

/* finding and binding */
/**
 * @brief		Do finding and binding target process, which enable the target
 *				side can be bound to by the initiator side during the minimum
 *				identify time(3 minutes).
 *
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 *	[Commissioning result in target side]
 *	-Response type : ZIGBEE_RESPONSE_COMMISSIONING_STATUS
 *	-Response payload : pointer of zigbee_commissioning_state
 */
int zigbee_find_bind_target_start(int local_endpoint);

/* finding and binding */
/**
 * @brief		Do finding and binding initiator procedure, bind to the target
 *				side which is in the same network.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 *	[Commissioning result in initiator side]
 *	-Response type : ZIGBEE_RESPONSE_COMMISSIONING_STATUS
 *	-Response payload : pointer of zigbee_commissioning_state
 *
 *	[Target information in initiator side]
 *	-Response type : ZIGBEE_RESPONSE_COMMISSIONING_TARGET_INFO
 *	-Response payload : pointer of zigbee_commissioning_target_info
 *
 *	[Bind information in initiator side]
 *	-Response type : ZIGBEE_RESPONSE_COMMISSIONING_TARGET_INFO
 *	-Response payload : pointer of zigbee_commissioning_target_info
 */
int zigbee_find_bind_initiator_start(int local_endpoint);

/* broadcast permit joiin */
/**
 * @brief		Do broadcast permit join.
 *
 *\param [in]	duration		duration of join time.
 *
 *\return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_broadcast_permitjoin(int duration);

/* broadcast identify query request */
/**
 * @brief		Broadcast identify query request cmd of cluster "Identify"
 *
 * @param [in]	local_endpoint		Endpoint id that start broadcasting
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 * Callback function is called for notifying the result.
 * -Response type : ZIGBEE_RESPONSE_BROADCAST_IDENTIFY_QUERY
 * -Response payload : pointer of zigbee_broadcast_identify_query_response
 */
int zigbee_broadcast_identify_query(int local_endpoint);

/* Ieee address request */
/**
 * @brief		Send ieee address request
 *
 * @param [in]	node_id		Node id that need to resolve.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 * Callback function is called for notifying the result.
 * -Response type : ZIGBEE_RESPONSE_IEEE_ADDR_RESP
 * -Response payload : pointer of zigbee_ieee_addr_response
 */
int zigbee_ieee_addr_request(int node_id);

/* simple description request */
/**
 * @brief		Send simple description request
 *
 * @param [in]	node_id			Node id that the request send to
 * @param [in]	dest_endpoint	Target endpoint id
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 * Callback function is called for notifying the result.
 * -Response type : ZIGBEE_RESPONSE_SIMPLE_DESC_RESP
 * -Response payload : pointer of zigbee_simple_descriptor_response
 */
int zigbee_simple_descriptor_request(int node_id, int dest_endpoint);

/* broadcast match description request */
/**
 * @brief				Broadcast match description request to do device
 *						discovery
 *
 * @param [in]	profile_id	ZIGBEE_PROFILE_HA, ZIGBEE_PROFILE_ZLL and ZIGBEE_PROFILE_GP
 * @param [in]	cluster_id	Cluster id
 * @param [in]	server_cluster	true is cluster server, false is cluster client
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 * Callback function is called for notifying the result.
 * -Response type : ZIGBEE_RESPONSE_MATCH_DESC_RESP
 * -Response payload : pointer of zigbee_match_desc_response
 */
int zigbee_broadcast_match_descriptor_request(ZIGBEE_PROFILE profile_id,
											  int cluster_id,
											  bool server_cluster);

/* get max binding table size */
/*!
 * \brief	Get binding table size
 *
 * \param [out]	size	The binding table size to be returned
 * \return				Result of operation, EZ_OK on success,
 *						error code otherwise.
 */
int zigbee_get_binding_table_size(int *size);

/* get binding entry */
/**
 * @brief		Get binding entry content
 *
 * @param [in]	index		Index of binding entry
 * @param [out]	value		pointer that store the entry content
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_get_binding_entry(int index, zigbee_binding_table_entry *value);

/* set binding entry */
/**
 * @brief		Set binding entry to binding table
 *
 * @param [in]	index	Index of binding entry
 * @param [in]	value	pointer of binding entry
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_set_binding_entry(int index, zigbee_binding_table_entry *value);

/* delete entry */
/**
 * @brief		Delete an entry from the binding table
 *
 * @param [in]	index	Index of binding entry
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_delete_binding_entry(int index);

/* clear binding table */
/**
 * @brief		Clear the binding table
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_clear_binding_table();

/* end device bind request */
/*!
 * \brief		Send end device bind request to do binding between two devices.
 *				Note that, this function should be called in both target side
 *				and initiator side.
 *				When binding success, binding table is updated in initiator
 *				side, user can call function 'get_binding_entry' for checking.
 *
 * @param [in]	local_endpoint	Local endpoint id
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 * Callback function is called for notifying the result.
 * -Response type : ZIGBEE_RESPONSE_END_DEVICE_BIND
 * -Response payload : pointer of zigbee_end_device_bind_response
 */
int zigbee_end_device_bind_request(int local_endpoint);

/* fan control cluster client */
/**
 * @brief		Write fun mode to remote server.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [in]	mode			The new mode set to server.
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_fan_write_mode(const struct zigbee_sending_info *sending_info,
						  zigbee_fan_mode mode, int local_endpoint);

/* fan control cluster client */
/**
 * @brief		Write fun mode sequence to remote server.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [in]	seq				The new seq set to server.
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_fan_write_mode_sequence(const struct zigbee_sending_info *sending_info,
								   zigbee_fan_mode_sequence seq,
								   int local_endpoint);

/* fan control cluster client */
/**
 * @brief		Read fun mode from remote server.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [out]	fanmode			Fan Mode attribute value pointer.
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_fan_read_mode(const struct zigbee_sending_info *sending_info,
						 zigbee_fan_mode *fanmode, int local_endpoint);

/* fan control cluster client */
/**
 * @brief		Read fun mode sequence from remote server.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [out]	fanmode_sequence	Fan Mode Sequence attribute value pointer.
 * @param [in]	local_endpoint		Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_fan_read_mode_sequence(const struct zigbee_sending_info *sending_info,
								  zigbee_fan_mode_sequence *fanmode_sequence,
								  int local_endpoint);

/* thermostat server */
/**
 * @brief		Set "local temperature" attribute of cluster
 *				"Thermostat" locally.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	temperature		The LocalTemperature, in the range 0x954d to 0x7fff.
 *								LocalTemperature = 100 x temperature in degrees Celsius.
 *								Where -273.15 Celsius <= temperature <= 327.67 Celsius,
 *								corresponding to a LocalTemperature in the range 0x954d to 0x7fff.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_set_local_temperature(int local_endpoint,
											int temperature);

/* thermostat server */
/**
 * @brief		Get "local temperature" attribute of cluster
 *				"Thermostat" locally.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [out]	temperature		The LocalTemperature, in the range 0x954d to 0x7fff.
 *								LocalTemperature = 100 x temperature in degrees Celsius.
 *								Where -273.15 Celsius <= temperature <= 327.67 Celsius,
 *								corresponding to a LocalTemperature in the range 0x954d to 0x7fff.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
*/
int zigbee_thermostat_get_local_temperature(int local_endpoint,
											int *temperature);

/* thermostat server */
/**
 * @brief		Get "occupancy" attribute of cluster "Thermostat" locally.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	status			The occupancy status to be set.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_set_occupancy_status(int local_endpoint,
										   zigbee_occupancy_status status);

/* thermostat server */
/**
 * @brief		Get "occupancy" attribute of cluster "Thermostat" locally.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [out]	status			The occupancy status pointer.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_get_occupancy_status(int local_endpoint,
										   zigbee_occupancy_status *status);

/* thermostat server */
/**
 * @brief		Set "occupied cooling setpoint" attribute(temperature) of
 *				cluster "Thermostat" locally.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	temperature		The LocalTemperature, in the range 0x954d to 0x7fff.
 *								LocalTemperature = 100 x temperature in degrees Celsius.
 *								Where -273.15 Celsius <= temperature <= 327.67 Celsius,
 *								corresponding to a LocalTemperature in the range 0x954d to 0x7fff.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_set_occupied_cooling_setpoint(int local_endpoint,
													int temperature);

/* thermostat server */
/**
 * @brief		Get "occupied cooling setpoint" attribute(temperature) of
 *				cluster "Thermostat" locally.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [out]	temperature		The LocalTemperature, in the range 0x954d to 0x7fff.
 *								LocalTemperature = 100 x temperature in degrees Celsius.
 *								Where -273.15 Celsius <= temperature <= 327.67 Celsius,
 *								corresponding to a LocalTemperature in the range 0x954d to 0x7fff.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_get_occupied_cooling_setpoint(int local_endpoint,
													int *temperature);

/* thermostat server */
/**
 * @brief		Set "occupied heating setpoint" attribute(temperature) of
 *				cluster "Thermostat" locally.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	temperature		The LocalTemperature, in the range 0x954d to 0x7fff.
 *								LocalTemperature = 100 x temperature in degrees Celsius.
 *								Where -273.15 Celsius <= temperature <= 327.67 Celsius,
 *								corresponding to a LocalTemperature in the range 0x954d to 0x7fff.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_set_occupied_heating_setpoint(int local_endpoint,
													int temperature);

/* thermostat server */
/**
 * @brief		Get "occupied heating setpoint" attribute(temperature) of
 *				cluster "Thermostat" locally.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [out]	temperature		The LocalTemperature, in the range 0x954d to 0x7fff.
 *								LocalTemperature = 100 x temperature in degrees Celsius.
 *								Where -273.15 Celsius <= temperature <= 327.67 Celsius,
 *								corresponding to a LocalTemperature in the range 0x954d to 0x7fff.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_get_occupied_heating_setpoint(int local_endpoint,
													int *temperature);

/* thermostat server */
/**
 * @brief		Set "system mode" attribute of cluster "Thermostat" locally.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	mode			The system mode to be set.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_set_system_mode(int local_endpoint,
									  zigbee_thermostat_system_mode mode);

/* thermostat server */
/**
 * @brief		Get "system mode" attribute of cluster "Thermostat" locally.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [out]	mode			The system mode pointer.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_get_system_mode(int local_endpoint,
									  zigbee_thermostat_system_mode *mode);

/* thermostat server */
/**
 * @brief		Set "control sequence of operation" attribute of
 *				cluster "Thermostat" locally.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	seq				The control sequence to be set.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_set_control_sequence(int local_endpoint,
										   zigbee_thermostat_control_sequence seq);

/* thermostat server */
/**
 * @brief		Get "control sequence of operation" attribute of cluster
 *				"Thermostat" locally.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [out]	seq				The control sequence pointer.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_get_control_sequence(int local_endpoint,
										   zigbee_thermostat_control_sequence *seq);

/* temperature measurement server */
/**
 * @brief		Set local attribute "measured value" of cluster
 *				"Temperature Measurement".
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	value			The MeasuredValue which represents the temperature
 *								in degrees Celsius as follows:
 *								MeasuredValue = 100 x temperature in degrees Celsius.
 *								Where -273.15 Celsius <= temperature <= 327.67 Celsius,
 *								corresponding to a MeasuredValue in the range 0x954d to 0x7fff.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_temperature_set_measured_value(int local_endpoint, int value);

/**
 * @brief		Set local attribute "min measured value" and
 *				"max measured value" of cluster "Temperature Measurement".
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	min				Min MeasuredValue to be set.
 * @param [in]	max				Max MeasuredValue to be set.
 *
 *								The MeasuredValue(Min and Max) which represents the
 *								temperature in degrees Celsius as follows:
 *								MeasuredValue = 100 x temperature in degrees Celsius.
 *								Where -273.15 Celsius <= temperature <= 327.67 Celsius,
 *								corresponding to a MeasuredValue in the range 0x954d to 0x7fff.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
*/
int zigbee_temperature_set_measured_value_range(int local_endpoint,
												int min, int max);

/* basic client */
/**
 * @brief		Resets all attribute values to factory default.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_reset_to_factory_default(const struct zigbee_sending_info *sending_info,
									int local_endpoint);

/* thermostat cluster client */
/**
 * @brief		Send setpoint raise/lower control commands to remote server.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [in]	mode			The thermostat setpoint mode.
 * @param [in]	temperature		The amount of LocalTemperature is to be a
 *								increased/decreased by, in steps of 1 degree.
 *								Positive value for increase, negative
 *								one for decrease. The range is -127 ~ 127.
 *
 *								LocalTemperature = 10 x temperature in degrees Celsius.
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_request_setpoint_raise_lower(const struct zigbee_sending_info *sending_info,
												   zigbee_thermostat_setpoint_mode mode,
												   int temperature,
												   int local_endpoint);

/* thermostat cluster client */
/**
 * @brief		Read "occupied cooling setpoint" attribute (temperature)
 *				from remote server.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [out]	temperature		The LocalTemperature, in the range 0x954d to 0x7fff.
 *								LocalTemperature = 100 x temperature in degrees Celsius.
 *								Where -273.15 Celsius <= temperature <= 327.67 Celsius,
 *								corresponding to a LocalTemperature in the range 0x954d to 0x7fff.
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_read_occupied_cooling_setpoint(const struct zigbee_sending_info *sending_info,
													 int *temperature,
													 int local_endpoint);

/* thermostat cluster client */
/**
 * @brief		Read "heating setpoint" attribute (temperature) from
 *				remote server.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [out]	temperature		The LocalTemperature, in the range 0x954d to 0x7fff.
 *								LocalTemperature = 100 x temperature in degrees Celsius.
 *								Where -273.15 Celsius <= temperature <= 327.67 Celsius,
 *								corresponding to a LocalTemperature in the range 0x954d to 0x7fff.
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_read_occupied_heating_setpoint(const struct zigbee_sending_info *sending_info,
													 int *temperature,
													 int local_endpoint);

/* thermostat cluster client */
/**
 * @brief		Read "system mode" attribute from remote thermostat server.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [out]	mode			The system mode pointer.
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_read_system_mode(const struct zigbee_sending_info *sending_info,
									   zigbee_thermostat_system_mode *mode,
									   int local_endpoint);

/* thermostat cluster client */
/**
 * @brief		Write "system mode" attribute to remote thermostat server.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [in]	mode			The system mode set to remote server.
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_write_system_mode(const struct zigbee_sending_info *sending_info,
										zigbee_thermostat_system_mode mode,
										int local_endpoint);

/* thermostat cluster client */
/**
 * @brief		Read "control sequence of operation" attribute from remote
 *				thermostat server.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [out]	mode			The system mode pointer.
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_read_control_sequence(const struct zigbee_sending_info *sending_info,
											zigbee_thermostat_control_sequence *seq,
											int local_endpoint);

/* thermostat cluster client */
/**
 * @brief		Write "control sequence of operation" attribute to remote
 *				thermostat server.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [in]	mode			The system mode set to remote server.
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_write_control_sequence(const struct zigbee_sending_info *sending_info,
											 zigbee_thermostat_control_sequence seq,
											 int local_endpoint);

/* cluster client */
/**
 * @deprecated	This API is deprecated and will be removed, it is replaced
 *				by 'zigbee_general_request_reporting'.
 *
 * @brief		Notice server to report the attribute value.
 *
 * @param [in]	cluster_id			Remote device atturbite cluster id.
 * @param [in]	sending_info		Command sending information, including sending type,
 *									source or destination information, etc.
 * @param [in]	report_type			The reporting type to be requested.
 * @param [in]	min_interval		The reporting minimum interval. Greater than or equal to 0.
 * @param [in]	max_interval		The reporting maximum interval. Less than or equal to 0xFFFF.
 *									If set 0xFFFF, reporting stopped.
 * @param [in]	change_threshold	Minimum changed value to trigger reporting.
 * @param [in]	local_endpoint		Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_request_reporting(int cluster_id,
							 const struct zigbee_sending_info *sending_info,
							 zigbee_reporting_type report_type,
							 int min_interval, int max_interval,
							 int change_threshold, int local_endpoint);

/* cluster client */
/**
 * @brief		Notice server to stop report the attribute value.
 *
 * @param [in]	cluster_id		Remote device atturbite cluster id.
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [in]	report_type		The reporting type to be requested.
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_stop_reporting(int cluster_id,
						  const struct zigbee_sending_info *sending_info,
						  zigbee_reporting_type report_type,
						  int local_endpoint);

/**
 * @brief		Get device info from zigbee daemon
 *
 * @param[out]	device_info	the memory pointer for return device info list.
 * @return		Result of operation, EZ_OK when succeeded, EZ_NOT_FOUND
 *
 *				when no discovered device info returned, otherwise failed.
 */
int zigbee_get_discovered_device_list(zigbee_device_info *device_info);

/**
 * @brief		Check the if the device supports the specified reporting type
 *
 * @param[in]	device_id	The device id to be checked.
 * @param[in]	device_id	The reporting type to be checked.
 *
 * @return		Result of operation, EZ_OK when support, otherwise not support.
 */
int zigbee_check_reporting(ZIGBEE_DEVICEID device_id,
						   zigbee_reporting_type report_type);

/**
 * @brief		Set logging backend system
 *
 * @param[in]	system Log system
 *
 * @return		0 on success, -1 otherwise
 */
int zigbee_log_set_system (enum zigbee_log_system system);

/*!
 * \brief		Check if the device supports commissioning or not
 *
 * \param[in] device_id	The device id to be checked
 * \param[in] initiator	Check to support initiator or target.
 *						true for checking initiator supported,
 *						false for checking target supported.
 *
 * \return		Result of operation, EZ_OK for suported, EZ_NOT_SUPPORTED for
 *				not suported, error code otherwise.
 */
int zigbee_check_commissioning_support(const ZIGBEE_DEVICEID device_id,
									   bool initiator);

/**
 * @brief		Read the local endpoint's attribute value
 *
 * @param[in]	cluster			The cluster id to be checked
 * @param[in]	attribute		The server attribute id to be checked
 * @param[out]	value			The attribute value to be returned
 * @param[out]	value_length	The attribute value length to be returned, it can be NULL.
 * @param[out]	value_type		The attribute value type to be returned, it can be NULL.
 * @param[in]	local_endpoint	Local endpoint id
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_general_read_local_attribute(ZIGBEE_CLUSTER_ID cluster,
										ZIGBEE_ATTRIBUTE_ID attribute,
										char value[MAX_ATTRIBUTE_SIZE],
										unsigned int *value_length,
										zigbee_attribute_data_type *value_type,
										int local_endpoint);

/**
 * @brief		Write the local endpoint's attribute value
 *
 * @param[in]	cluster			The cluster id to be checked
 * @param[in]	attribute		The server attribute id to be checked
 * @param[in]	value			The attribute value to be written
 * @param[in]	value_length	The attribute value length to be written
 * @param[in]	value_type		The attribute value type to be written
 * @param[in]	local_endpoint	Local endpoint id
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_general_write_local_attribute(ZIGBEE_CLUSTER_ID cluster,
										ZIGBEE_ATTRIBUTE_ID attribute,
										void *value,
										unsigned int value_length,
										zigbee_attribute_data_type value_type,
										int local_endpoint);

/**
 * @brief		Read the remote endpoint's attribute value
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param[in]	cluster			The cluster id to be checked
 * @param[in]	attribute		The server attribute id to be checked
 * @param[out]	value			The attribute value to be returned
 * @param[out]	value_length	The attribute value length to be returned, it can be NULL.
 * @param[out]	value_type		The attribute value type to be returned, it can be NULL.
 * @param[in]	local_endpoint	Local endpoint id
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_general_read_remote_attribute(const struct zigbee_sending_info *sending_info,
										 ZIGBEE_CLUSTER_ID cluster,
										 ZIGBEE_ATTRIBUTE_ID attribute,
										 char value[MAX_ATTRIBUTE_SIZE],
										 unsigned int *value_length,
										 zigbee_attribute_data_type *value_type,
										 int local_endpoint);

/**
 * @brief		Write the remote endpoint's attribute value
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param[in]	cluster			The cluster id to be checked
 * @param[in]	attribute		The server attribute id to be checked
 * @param[in]	value			The attribute value to be written
 * @param[in]	value_length	The attribute value length to be written
 * @param[in]	value_type		The attribute value type to be written
 * @param[in]	local_endpoint	Local endpoint id
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_general_write_remote_attribute(const struct zigbee_sending_info *sending_info,
										  ZIGBEE_CLUSTER_ID cluster,
										  ZIGBEE_ATTRIBUTE_ID attribute,
										  void *value,
										  unsigned int value_length,
										  zigbee_attribute_data_type value_type,
										  int local_endpoint);

/**
 * @brief		Discover the identifiers and types of the attributes on a rmote
 *				device which are supported within the cluster.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param[in]	cluster			The cluster id to be checked
 * @param[in]	attribute		The start attribute identifier, which specifies
 *								the value of the identifier at which to begin
 *								the attribute discovery.
 * @param[out]	attr_list		The discovery attributse result to be returned
 * @param[in]	local_endpoint	Local endpoint id
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_general_discover_attribute(const struct zigbee_sending_info *sending_info,
									  ZIGBEE_CLUSTER_ID cluster,
									  ZIGBEE_ATTRIBUTE_ID attribute,
									  struct zigbee_discovery_attributes *attr_list,
									  int local_endpoint);

/* cluster client */
/**
 * @brief		Notice server to report the attribute value.
 *				This is an advanced API for users who should know the cluster id,
 *				attribute id and attribute data type and range of change threshold of
 *				the target endpoint.
 *
 * Parsed reporting or raw reporting be delivered through callback function.
 *	[Parsed reporting]
 *	This type reporting has been parsed, user can get value directory.
 *	- Response type : ZIGBEE_RESPONSE_REPORT_ATTRIBUTE
 *	- Response payload : pointer of zigbee_report_attribute_info
 *
 *	[Raw reporting]
 *	This is raw reporting data, user should parse the data all by himself.
 *	- Response type : ZIGBEE_RESPONSE_GENERAL_REPORT_ATTRIBUTE
 *	- Response payload : pointer of zigbee_general_report_attribute_info
 *
 * @param [in]	sending_info		Command sending information, including sending type,
 *									source or destination information, etc.
 * @param [in]	cluster_id			Remote device atturbite cluster id.
 * @param [in]	attribute_id		The reporting type to be requested.
 * @param [in]	attribute_data_type	The data type of attribute.
 * @param [in]	min_interval		The reporting minimum interval.
 * @param [in]	max_interval		The reporting maximum interval.
 *									If set 0xFFFF, reporting stopped.
 * @param [in]	change_threshold	Minimum changed value to trigger reporting.
 * @param [in]	local_endpoint		Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * << Some available cases in ZCL spec >>
 * << For more cases, please refer to ZCL spec >>
 *	[Illuminance Measurement cluster]
 *	- cluster_id:			0x0400
 *	- attribute_id:			0x0000	[measured value]
 *	- attribute_data_type:	ZIGBEE_INT16U_ATTRIBUTE_TYPE
 *	- attribute_id:			0x0003	[tolerance]
 *	- attribute_data_type:	ZIGBEE_INT16U_ATTRIBUTE_TYPE
 *
 *	[Occupancy Sensing cluster]
 *	- cluster_id:			0x0406
 *	- attribute_id:			0x0000	[occupancy]
 *	- attribute_data_type:	ZIGBEE_BITMAP8_ATTRIBUTE_TYPE
 *
 *	[Temperature Measurement cluster]
 *	- cluster_id:			0x0402
 *	- attribute_id:			0x0000	[measured value]
 *	- attribute_data_type:	ZIGBEE_INT16S_ATTRIBUTE_TYPE
 *	- attribute_id:			0x0003	[tolerance]
 *	- attribute_data_type:	ZIGBEE_INT16S_ATTRIBUTE_TYPE
 *
 *	[Thermostat cluster]
 *	- cluster_id:			0x0201
 *	- attribute_id:			0x0000	[local temperature]
 *	- attribute_data_type:	ZIGBEE_INT16S_ATTRIBUTE_TYPE
 *	- attribute_id:			0x0007	[pi cooling demand]
 *	- attribute_data_type:	ZIGBEE_INT8U_ATTRIBUTE_TYPE
 *	- attribute_id:			0x0008	[pi heating demand]
 *	- attribute_data_type:	ZIGBEE_INT8U_ATTRIBUTE_TYPE
 */
int zigbee_general_request_reporting(const struct zigbee_sending_info *sending_info,
									 ZIGBEE_CLUSTER_ID cluster_id,
									 ZIGBEE_ATTRIBUTE_ID attribute_id,
									 zigbee_attribute_data_type attribute_data_type,
									 int min_interval, int max_interval,
									 int change_threshold, int local_endpoint);

/**
 * @brief		Notice server to stop report the attribute value.
 *
 * @param [in]	sending_info		Command sending information, including sending type,
 *									source or destination information, etc.
 * @param [in]	cluster_id			Remote device atturbite cluster id.
 *									(For example: Illuminance Measurement 0x0400)
 * @param [in]	attribute_id		The reporting type to be requested.
 *									(For example: measured value 0x0000)
 * @param [in]	attribute_data_type	The data type of attribute.
 *									(For example: data type of cluster(0x0400)
 *									attribute(0x0000) is ZIGBEE_INT16U_ATTRIBUTE_TYPE)
 * @param [in]	local_endpoint		Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_general_stop_reporting(const struct zigbee_sending_info *sending_info,
								  ZIGBEE_CLUSTER_ID cluster_id,
								  ZIGBEE_ATTRIBUTE_ID attribute_id,
								  zigbee_attribute_data_type attribute_data_type,
								  int local_endpoint);

/**
 * @brief		Read the configuration details of the reporting mechanism
 *				for the attribute of a cluster.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param[in]	cluster			The cluster id to read configuration details.
 * @param[in]	attribute		The server attribute identifier to be read configuration details.
 * @param[out]	reporting_info	The read attribute value to be returned.
 * @param[in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_general_read_reporting_config(const struct zigbee_sending_info *sending_info,
										 ZIGBEE_CLUSTER_ID cluster,
										 ZIGBEE_ATTRIBUTE_ID attribute,
										 zigbee_reporting_info *reporting_info,
										 int local_endpoint);

/**
 * @deprecated	This api will be removed.
 *				When called zigbee_initialize, this API is called automatically
 *
 * @brief		Resume network operation after a reboot
 * This should be called on startup whether or not
 * the node was previously part of a network.
 *
 * @param [out] state		ZIGBEE_JOINED_NETWORK when succeeded
 *							ZIGBEE_NO_NETWORK if the node is not part of a
 *							network
 *							It can be NULL
 * @return		 Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_network_start(zigbee_network_state *state);

/**
 * @deprecated	This API is deprecated and will be removed, it is
 *				replaced by 'zigbee_get_local_endpoint_by_endpointid'.
 *
 * @brief		Get endpoint id by handle
 * @param [in]	handle		the handle id
 * @return		endpoint info pointer, NULL if failed.
 */
struct inner_endpoint_info *get_device_info_by_handle(zigbee_endpoint_handle handle);

/**
 * @deprecated	It is deprecated and will be removed, it is replaced
 *				by 'zigbee_check_local_endpoint_contains_cluster'.
 *
 * @brief		Check if the cluster match the endpoint or not
 * @param [in]	info		info of a endpoint
 * @param [in]	cluster_id	the cluster id defined in zigbee_def.h
 * @param [in]	is_server	server: 1
 *							client: 0
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_check_cluster(struct inner_endpoint_info *info, int cluster_id,
						 int is_server);

/**
 * @deprecated	It is deprecated and will be removed, it is replaced
 *				by 'zigbee_get_binding_entry'.
 *
 * @brief				Get binding entry content
 *
 * @param [in]	index	Index of binding entry
 * @param [out]	value	pointer that store the entry content
 *
 * @return				Result of operation, EZ_OK on success,
 *						error code otherwise.
 */
int zigbee_get_binding(int index, zigbee_binding_table_entry *value);

/**
 * @deprecated	It is deprecated and will be removed, it is replaced
 *				by 'zigbee_set_binding_entry'.
 *
 * @brief				Set binding entry to binding table
 *
 * @param [in]	index	Index of binding entry
 * @param [in]	value	pointer of binding entry
 *
 * @return				Result of operation, EZ_OK on success,
 *						error code otherwise.
 */
int zigbee_set_binding(int index, zigbee_binding_table_entry *value);

/**
 * @deprecated	It is deprecated and will be removed, it is replaced
 *				by 'zigbee_delete_binding_entry'.
 *
 * @brief				Delete an entry from the binding table
 *
 * @param [in]	index	Index of binding entry
 *
 * @return				Result of operation, EZ_OK on success,
 *						error code otherwise.
 */
int zigbee_delete_binding(int index);

/**
 * @deprecated	It is deprecated and will be removed, it is replaced
 *				by 'zigbee_clear_binding_table'.
 *
 * @brief		Clear the binding table
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_clear_binding();

/* finding and binding */
/**
 * @deprecated	It is deprecated and will be removed, it is replaced
 *				by zigbee_find_bind_target_start
 *				and zigbee_find_bind_initiator_start
 *
 * @brief		Do finding and binding procedure.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	initiator		True is initiator, false is target.
 * @param [in]	start			True is to start.
 *								False is to stop, and it is deprecated.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 *	[Commissioning result in both target and initiator sides]
 *	-Response type : ZIGBEE_RESPONSE_COMMISSIONING_STATUS
 *	-Response payload : pointer of zigbee_commissioning_state
 *
 *	[Target information in initiator side]
 *	-Response type : ZIGBEE_RESPONSE_COMMISSIONING_TARGET_INFO
 *	-Response payload : pointer of zigbee_commissioning_target_info
 *
 *	[Bind information in initiator side]
 *	-Response type : ZIGBEE_RESPONSE_COMMISSIONING_TARGET_INFO
 *	-Response payload : pointer of zigbee_commissioning_target_info
 */
int zigbee_find_bind(int local_endpoint, bool initiator, bool start);

/* ezmode commissioning */
/**
 * @deprecated	It is deprecated and will be removed, it is replaced
 *				by zigbee_ezmode_commissioning_target_start
 *				and zigbee_ezmode_commissioning_initiator_start
 *
 * @brief		Do ezmode commissioning procedure.
 *				Firstly do network steering.
 *				Secondly do find and bind, see zigbee_find_bind.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	initiator		True is initiator, false is target.
 * @param [in]	start			True is to start.
 *								False is to stop, and it is deprecated.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 *	[Commissioning result in both target and initiator sides]
 *	-Response type : ZIGBEE_RESPONSE_COMMISSIONING_STATUS
 *	-Response payload : pointer of zigbee_commissioning_state
 *
 *	[Target information in initiator side]
 *	-Response type : ZIGBEE_RESPONSE_COMMISSIONING_TARGET_INFO
 *	-Response payload : pointer of zigbee_commissioning_target_info
 *
 *	[Bind information in initiator side]
 *	-Response type : ZIGBEE_RESPONSE_COMMISSIONING_TARGET_INFO
 *	-Response payload : pointer of zigbee_commissioning_target_info
 */
int zigbee_ezmode_commissioning(int endpoint_id, bool initiator, bool start);

/**
 * @}
 */

#ifdef __cplusplus
}
#endif
#endif	/*__ZIGBEE_H*/

