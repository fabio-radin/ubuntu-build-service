#ifndef	__ZIGBEE_DEF_H__
#define	__ZIGBEE_DEF_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stdbool.h>
#include "zigbee_clusters.h"

/*! \file zigbee_def.h
 *
 *	\brief ZigBee definitions
 *
 *	Definitions and functions
 *
 */
#define REQUIRED_ZIGBEED_VERSION		"0.7.3"
#define ZIGBEED_VERSION_FILE			"/etc/zigbee/daemon_version"
#define ZIGBEED_PROCESS_NAME			"zigbeed"

/* why we not use profile id directly.
 * for most device type of ZLL, the profile id is 0x104, same to HA.
 * for more information, please check [UG1039-AppDevFundamentals-ZLL.pdf],
 * chapter [3.1 Clusters]. GP have same problem.
 */
typedef unsigned short ZIGBEE_PROFILE;
#define ZIGBEE_PROFILE_HA		0x0104
#define ZIGBEE_PROFILE_ZLL		0xC05E
#define ZIGBEE_PROFILE_GP		0xA1E0
/* Public profile - ranges from 0x0000 to 0x7fff
 * Manufacturer Specific Profile - ranges from 0xbf00 to 0xffff */
#define ZIGBEE_PROFILE_INVALID	0x8000

/**
 * Different profiles may have different minimum device versions,
 * HA, GP and ZLL minimum device versions are fixed here, for other
 * minimum device versions, please check the related specifications.
 **/
typedef unsigned char ZIGBEE_DEVICE_VERSION;
#define ZIGBEE_HA_MIN_DEVICE_VERSION	0x00
#define ZIGBEE_GP_MIN_DEVICE_VERSION	0x00
#define ZIGBEE_ZLL_MIN_DEVICE_VERSION	0x02

typedef unsigned short ZIGBEE_DEVICEID;
/* HA Device*/
#define DEVICE_ON_OFF_SWITCH						0x0000
#define DEVICE_LEVEL_CONTROL_SWITCH					0x0001
#define DEVICE_ON_OFF_OUTPUT						0x0002
#define DEVICE_LEVEL_CONTROLLABLE_OUTPUT			0x0003
#define DEVICE_SCENE_SELECTOR						0x0004
#define DEVICE_CONFIGURATION_TOOL					0x0005
#define DEVICE_REMOTE_CONTROL						0x0006
#define DEVICE_COMBINED_INTERFACE					0x0007
#define DEVICE_RANGE_EXTENDER						0x0008
#define DEVICE_MAINS_POWER_OUTLET					0x0009
#define DEVICE_DOOR_LOCK							0x000a
#define DEVICE_DOOR_LOCK_CONTROLLER					0x000b
#define DEVICE_SIMPLE_SENSOR						0x000c
#define DEVICE_CONSUMPTION_AWARENESS_DEVICE			0x000d
#define DEVICE_HOME_GATEWAY							0x0050
#define DEVICE_SMART_PLUG							0x0051
#define DEVICE_WHITE_GOODS							0x0052
#define DEVICE_METER_INTERFACE						0x0053
#define DEVICE_ON_OFF_LIGHT							0x0100
#define DEVICE_DIMMABLE_LIGHT						0x0101
#define DEVICE_COLOR_DIMMABLE_LIGHT					0x0102
#define DEVICE_ON_OFF_LIGHT_SWITCH					0x0103
#define DEVICE_DIMMER_SWITCH						0x0104
#define DEVICE_COLOR_DIMMER_SWITCH					0x0105
#define DEVICE_LIGHT_SENSOR							0x0106
#define DEVICE_OCCUPANCY_SENSOR						0x0107
#define DEVICE_SHADE								0x0200
#define DEVICE_SHADE_CONTROLLER						0x0201
#define DEVICE_WINDOW_COVERING_DEVICE				0x0202
#define DEVICE_WINDOW_COVERING_CONTROLLER			0x0203
#define DEVICE_HEATING_COOLING_UNIT					0x0300
#define DEVICE_THERMOSTAT							0x0301
#define DEVICE_TEMPERATURE_SENSOR					0x0302
#define DEVICE_PUMP									0x0303
#define DEVICE_PUMP_CONTROLLER						0x0304
#define DEVICE_PRESSURE_SENSOR						0x0305
#define DEVICE_FLOW_SENSOR							0x0306
#define DEVICE_MINI_SPLIT_AC						0x0307
#define DEVICE_IAS_CONTROL_AND_INDICATING_EQUIPMENT	0x0400
#define DEVICE_IAS_ANCILLARY_CONTROL_EQUIPMENT		0x0401
#define DEVICE_IAS_ZONE								0x0402
#define DEVICE_IAS_WARNING_DEVICE					0x0403
/* ZLL device*/
#define DEVICE_ZLL_ON_OFF_LIGHT						0x0000
#define DEVICE_ZLL_ON_OFF_PLUG_IN_UNIT				0x0010
#define DEVICE_ZLL_DIMMABLE_LIGHT					0x0100
#define DEVICE_ZLL_DIMMABLE_PLUG_IN_UNIT			0x0110
#define DEVICE_ZLL_COLOR_LIGHT						0x0200
#define DEVICE_ZLL_EXTENDED_COLOR_LIGHT				0x0210
#define DEVICE_ZLL_COLOR_TEMPERATURE_LIGHT			0x0220
#define DEVICE_ZLL_COLOR_CONTROLLER					0x0800
#define DEVICE_ZLL_COLOR_SCENE_CONTROLLER			0x0810
#define DEVICE_ZLL_NON_COLOR_CONTROLLER				0x0820
#define DEVICE_ZLL_NON_COLOR_SCENE_CONTROLLER		0x0830
#define DEVICE_ZLL_CONTROL_BRIDGE					0x0840
#define DEVICE_ZLL_ON_OFF_SENSOR					0x0850
/* GP device*/
#define DEVICE_GP_PROXY								0x0060
#define DEVICE_GP_PROXY_BASIC						0x0061
#define DEVICE_GP_TARGET_PLUS						0x0062
#define DEVICE_GP_TARGET							0x0063
#define DEVICE_GP_COMMISSIONING_TOOL				0x0064
#define DEVICE_GP_COMBO								0x0065
#define DEVICE_GP_COMBO_BASIC						0x0066
/* Invalidate device*/
#define DEVICE_INVALIDATE							0x7FFF

/**
 * @brief	Type for referring to ZCL attribute id
 *			For the attribute ids, please check zigbee_attributes.h
 */
typedef	unsigned short		ZIGBEE_ATTRIBUTE_ID;
#define	MAX_ATTRIBUTE_ID	0xFFFE

/**
 * @brief	Type for referring to ZCL cluster id
 *			For the cluster ids, please check zigbee_clusters.h
 */
typedef	unsigned short		ZIGBEE_CLUSTER_ID;
#define	MAX_CLUSTER_ID		0xFFFE

/**
* @brief IAS Zone Status attribute
*
* The Zone Status attribute is a bit map, The meaning of each bit is summarized
* by the macro ZIGBEE_IAS_ZONE_STATUS_BIT_XXX.
*/
typedef uint16_t ZIGBEE_IAS_ZONE_STATUS;
/* 1 - opened or alarmed
 * 0 - closed or not alarmed
 */
#define ZIGBEE_IAS_ZONE_STATUS_BIT_ALARM1				(1 << 0)
/* 1 - opened or alarmed
 * 0 - closed or not alarmed
 */
#define ZIGBEE_IAS_ZONE_STATUS_BIT_ALARM2				(1 << 1)
/* 1 - Tampered
 * 0 - Not tampered
 */
#define ZIGBEE_IAS_ZONE_STATUS_BIT_TAMPER				(1 << 2)
/* 1 - Low battery
 * 0 - Battery OK
 */
#define ZIGBEE_IAS_ZONE_STATUS_BIT_BATTERY				(1 << 3)
/* 1 - Reports
 * 0 - Does not report
 */
#define ZIGBEE_IAS_ZONE_STATUS_BIT_SUPERVISION_REPORTS	(1 << 4)
/* 1 - Reports restore
 * 0 - Does not report restore
 */
#define ZIGBEE_IAS_ZONE_STATUS_BIT_RESTORE_REPORTS		(1 << 5)
/* 1 - Trouble/Failure
 * 0 - OK
 */
#define ZIGBEE_IAS_ZONE_STATUS_BIT_TROUBLE				(1 << 6)
/* 1 - AC/Mains fault
 * 0 - AC/Mains OK
 */
#define ZIGBEE_IAS_ZONE_STATUS_BIT_AC					(1 << 7)
/* 1 - Sensor is in test mode
 * 0 - Sensor is in operation mode
 */
#define ZIGBEE_IAS_ZONE_STATUS_BIT_TEST					(1 << 8)
/* 1 - Sensor detects a defective battery
 * 0 - Sensor battery is func-tioning normally
 */
#define ZIGBEE_IAS_ZONE_STATUS_BIT_BATTERY_DEFECT		(1 << 9)

#define	MAX_COMMAND_BUFFER_SIZE	5000
#define MAX_RESPONSE_SIZE		10000
#define MAX_RECEIVED_COMMAND_PLAYLOAD_LENGTH	1024
#define MAX_DEVICE_INFO_SIZE	20
#define MAX_ENDPOINT_SIZE		5
#define MAX_CLUSTER_SIZE		9
#define EUI64_SIZE				8
#define COORDINATOR_NODEID		0x0000
#define ZIGBEE_BROADCAST_ENDPOINT	0xFF
/* The maximum attribute count for attribute discover */
#define MAX_DISCOVER_ATTRITUTES		0xFF

#define MIN_ENDPOINT_ID			    1
#define MAX_ENDPOINT_ID			    0xFE
#define MAX_DISCOVER_CYCLE_TIME		60	/* 60 minutes */

#define ILLUMINANCE_MAX_VALUE					0xfffe
#define ILLUMINANCE_MIN_VALUE					1
#define ILLUMINANCE_VALUE_TOO_LOW_BE_MEASSURED	0
#define ILLUMINANCE_INVALIED_VALUE				0xffff
#define ILLUMINANCE_MAX_THRESHOLD				(ILLUMINANCE_MAX_VALUE - ILLUMINANCE_MIN_VALUE)

#define TEMPERATURE_MAX_VALUE					0x7fff
#define TEMPERATURE_MIN_VALUE					(0x954d - 1 - 0xffff)
#define TEMPERATURE_INVALID_VALUE				0x8000
#define TEMPERATURE_MAX_THRESHOLD				(TEMPERATURE_MAX_VALUE - TEMPERATURE_MIN_VALUE)

/**
 * Error code
 */
#define EZ_OK					(0)
#define EZ_ERROR				(-1)
#define EZ_BAD_ARGS				(-2)
#define EZ_NOT_INITIALIZED		(-3)
#define EZ_NO_MEM				(-4)
#define EZ_NOT_SUPPORTED		(-5)
#define EZ_INVALID_VALUE		(-6)
#define EZ_INVALID_DAEMON		(-7)
#define EZ_NO_DAEMON			(-8)
#define EZ_NO_MESSAGE			(-9)
#define EZ_INVALID_ATTR			(-10)
#define EZ_NOT_FOUND			(-11)
#define EZ_ERR_SOCK				(-12)
#define EZ_MSG_SEND_ERROR		(-13)
#define EZ_NETWORK_EXIST		(-14)
/* Deprecated, it will be deleted and replaced by EZ_NOT_FOUND */
#define EZ_NO_DEVICE			(-11)

#define MAX_ATTRIBUTE_SIZE	16

/*!
 * \brief	The max attribute value size
 */
#define MAX_ATTRIBUTE_SIZE	16

/*!
 * \brief	Receiving command notification type from ZigBee Daemon
 *			This is one of response types
 */
typedef enum {
	ZIGBEE_CMD_SUCCESS = 0,
	ZIGBEE_CMD_ERR_PORT_PROBLEM = -3001,
	ZIGBEE_CMD_ERR_NO_SUCH_COMMAND = -3002,
	ZIGBEE_CMD_ERR_WRONG_NUMBER_OF_ARGUMENTS = -3003,
	ZIGBEE_CMD_ERR_ARGUMENT_OUT_OF_RANGE = -3004,
	ZIGBEE_CMD_ERR_ARGUMENT_SYNTAX_ERROR = -3005,
	ZIGBEE_CMD_ERR_STRING_TOO_LONG = -3006,
	ZIGBEE_CMD_ERR_INVALID_ARGUMENT_TYPE = -3007,
	ZIGBEE_CMD_ERR = -3008
} zigbee_notification;
/*!
 * \brief	Receiving network notification type from ZigBee Daemon
 *			This is one of response types
 */
typedef enum {
	/* It is notified in coordinator side when router joins current network */
	ZIGBEE_NETWORK_JOIN = 3100,
	/* It is notified in coordinator side when router leaves current network */
	ZIGBEE_NETWORK_LEAVE,
	ZIGBEE_NETWORK_FIND_FORM_SUCCESS,
	ZIGBEE_NETWORK_FIND_FORM_FAILED,
	ZIGBEE_NETWORK_FIND_JOIN_SUCCESS,
	ZIGBEE_NETWORK_FIND_JOIN_FAILED,
	/* If it is in a network currently and form/join is re-called, this type
	 * notification will be used*/
	ZIGBEE_NETWORK_EXIST,
	/* It is used when network_form_manually */
	ZIGBEE_NETWORK_FORM_SUCCESS,
	ZIGBEE_NETWORK_FORM_FAILED,
	/* It is used when network_join_manually */
	ZIGBEE_NETWORK_JOIN_SUCCESS,
	ZIGBEE_NETWORK_JOIN_FAILED
} zigbee_network_notification;
/*!
 * \brief	Receiving node type from ZigBee Daemon
 *			This is one of response types
 */
typedef enum {
	ZIGBEE_UNKNOWN_DEVICE = 3200,
	ZIGBEE_COORDINATOR = 3201,
	ZIGBEE_ROUTER = 3202,
	ZIGBEE_END_DEVICE = 3203,
	ZIGBEE_SLEEPY_END_DEVICE = 3204
} zigbee_node_type;
/*!
 * \brief	Receiving network state from ZigBee Daemon
 *			This is one of response types
 */
typedef enum {
	ZIGBEE_NO_NETWORK = 3210,
	ZIGBEE_JOINING_NETWORK,
	ZIGBEE_JOINED_NETWORK,
	ZIGBEE_JOINED_NETWORK_NO_PARENT,
	ZIGBEE_LEAVING_NETWORK
} zigbee_network_state;
/*!
 * \brief	Device discovery result
 */
typedef enum {
	ZIGBEE_DEVICE_DISCOVERY_NO_DEVICE = 3220,
	ZIGBEE_DEVICE_DISCOVERY_FOUND,
	ZIGBEE_DEVICE_DISCOVERY_DONE,
	ZIGBEE_DEVICE_DISCOVERY_START,
	ZIGBEE_DEVICE_DISCOVERY_ERROR,
	ZIGBEE_DEVICE_DISCOVERY_IN_PROGRESS,/* Cyclic discovery is in progress or last calling is not finished */
	ZIGBEE_DEVICE_DISCOVERY_CHANGED,	/* In cycle discovery, device is changed */
	ZIGBEE_DEVICE_DISCOVERY_LOST		/* In cycle discovery, device is lost */
} zigbee_device_discovery_status;
/*!
 * \brief	Network find status
 */
typedef enum {
	ZIGBEE_NETWORK_FOUND = 3230,
	ZIGBEE_NETWORK_FIND_FINISHED,
	ZIGBEE_NETWORK_FIND_ERR
} zigbee_network_find_status;

typedef enum {
	/* It is used for artik_zigbee_match_desc_response received */
	ZIGBEE_SERVICE_DISCOVERY_RECEIVED = 3240,
	ZIGBEE_SERVICE_DISCOVERY_DONE,
	ZIGBEE_SERVICE_DISCOVERY_ERROR
} zigbee_service_discovery_result;
/*!
 * \brief	Receiving response type from ZigBee Daemon
 */
typedef enum {
	/* Common response */
	ZIGBEE_RESPONSE_NOTIFICATION = 3300,
	ZIGBEE_RESPONSE_CLIENT_TO_SERVER_COMMAND_RECEIVED,
	ZIGBEE_RESPONSE_ATTRIBUTE_CHANGE,
	ZIGBEE_RESPONSE_REPORTING_CONFIGURE,
	ZIGBEE_RESPONSE_REPORT_ATTRIBUTE,
	ZIGBEE_RESPONSE_IDENTIFY_FEEDBACK_START,
	ZIGBEE_RESPONSE_IDENTIFY_FEEDBACK_STOP,
	/* Network response */
	ZIGBEE_RESPONSE_NETWORK_NOTIFICATION,
	ZIGBEE_RESPONSE_NETWORK_FIND,
	/* Device response */
	ZIGBEE_RESPONSE_DEVICE_DISCOVER,
	/* Cluster response */
	ZIGBEE_RESPONSE_BROADCAST_IDENTIFY_QUERY,
	ZIGBEE_RESPONSE_GROUPS_INFO,
	ZIGBEE_RESPONSE_COMMISSIONING_STATUS,
	ZIGBEE_RESPONSE_COMMISSIONING_TARGET_INFO,
	ZIGBEE_RESPONSE_COMMISSIONING_BOUND_INFO,
	ZIGBEE_RESPONSE_IEEE_ADDR_RESP,
	ZIGBEE_RESPONSE_SIMPLE_DESC_RESP,
	ZIGBEE_RESPONSE_MATCH_DESC_RESP,
	ZIGBEE_RESPONSE_BASIC_RESET_TO_FACTORY,	/* < Received basic reset to factory defaults requesting */
	ZIGBEE_RESPONSE_LEVEL_CONTROL,
	/* Raw reporting */
	ZIGBEE_RESPONSE_GENERAL_REPORT_ATTRIBUTE,
	ZIGBEE_RESPONSE_END_DEVICE_BIND,
	ZIGBEE_RESPONSE_IAS_ZONE_STATUS_CHANGED,
	/* Common response none */
	ZIGBEE_RESPONSE_NONE = 3399
} zigbee_response_type;
/*!
 * \brief	Attribute change type
 */
typedef enum {
	ZIGBEE_ATTR_ONOFF_STATUS,
	ZIGBEE_ATTR_LEVELCONTROL_LEVEL,
	ZIGBEE_ATTR_COLOR_HUE,
	ZIGBEE_ATTR_COLOR_SATURATION,
	ZIGBEE_ATTR_COLOR_CURRENT_X,
	ZIGBEE_ATTR_COLOR_CURRENT_Y,
	ZIGBEE_ATTR_COLOR_TEMP,
	ZIGBEE_ATTR_FAN_MODE,
	ZIGBEE_ATTR_FAN_MODE_SEQUENCE,
	ZIGBEE_ATTR_OCCUPIED_HEATING_SETPOINT,
	ZIGBEE_ATTR_OCCUPIED_COOLING_SETPOINT,
	ZIGBEE_ATTR_SYSTEM_MODE,
	ZIGBEE_ATTR_CONTROL_SEQUENCE,
	ZIGBEE_ATTR_ILLUMINANCE,	/* cls:0x0400, attr:0x0000 */
	ZIGBEE_ATTR_TEMPERATURE,	/* cls:0x0402, attr:0x0000 */
	ZIGBEE_ATTR_OCCUPANCY,		/* cls:0x0406, attr:0x0000 */
	ZIGBEE_ATTR_THERMOSTAT_TEMPERATURE,	/* cls:0x0201, attr:0x0000 */
	ZIGBEE_ATTR_NONE
} zigbee_attribute_type;
/*!
 * \brief	Selectable tx power level
 */
typedef enum {
	ZIGBEE_TX_POWER_8 = 8,
	ZIGBEE_TX_POWER_7 = 7,
	ZIGBEE_TX_POWER_6 = 6,
	ZIGBEE_TX_POWER_5 = 5,
	ZIGBEE_TX_POWER_4 = 4,
	ZIGBEE_TX_POWER_3 = 3,
	ZIGBEE_TX_POWER_2 = 2,
	ZIGBEE_TX_POWER_1 = 1,
	ZIGBEE_TX_POWER_0 = 0,
	ZIGBEE_TX_POWER_MINUS1 = -1,
	ZIGBEE_TX_POWER_MINUS2 = -2,
	ZIGBEE_TX_POWER_MINUS3 = -3,
	ZIGBEE_TX_POWER_MINUS4 = -4,
	ZIGBEE_TX_POWER_MINUS5 = -5,
	ZIGBEE_TX_POWER_MINUS6 = -6,
	ZIGBEE_TX_POWER_MINUS7 = -7,
	ZIGBEE_TX_POWER_MINUS8 = -8,
	ZIGBEE_TX_POWER_MINUS9 = -9,
	ZIGBEE_TX_POWER_MINUS11 = -11,
	ZIGBEE_TX_POWER_MINUS12 = -12,
	ZIGBEE_TX_POWER_MINUS14 = -14,
	ZIGBEE_TX_POWER_MINUS17 = -17,
	ZIGBEE_TX_POWER_MINUS20 = -20,
	ZIGBEE_TX_POWER_MINUS26 = -26,
	ZIGBEE_TX_POWER_MINUS43 = -43
} zigbee_tx_power;
/*!
 * \brief	Selectable channel
 */
typedef enum {
	ZIGBEE_CHANNEL_11 = 11,
	ZIGBEE_CHANNEL_12 = 12,
	ZIGBEE_CHANNEL_13 = 13,
	ZIGBEE_CHANNEL_14 = 14,
	ZIGBEE_CHANNEL_15 = 15,
	ZIGBEE_CHANNEL_16 = 16,
	ZIGBEE_CHANNEL_17 = 17,
	ZIGBEE_CHANNEL_18 = 18,
	ZIGBEE_CHANNEL_19 = 19,
	ZIGBEE_CHANNEL_20 = 20,
	ZIGBEE_CHANNEL_21 = 21,
	ZIGBEE_CHANNEL_22 = 22,
	ZIGBEE_CHANNEL_23 = 23,
	ZIGBEE_CHANNEL_24 = 24,
	ZIGBEE_CHANNEL_25 = 25,
	ZIGBEE_CHANNEL_26 = 26
} zigbee_channel;

/*!
 * \brief	Request for device attribute information reporting
 */
typedef enum {
	ZIGBEE_REPORTING_INVALID_MIN_VALUE = -1,
	/*
	 * The change_threshold should be in the range 0 ~ 60082
	 * */
	ZIGBEE_REPORTING_THERMOSTAT_TEMPERATURE,
	/*
	 * ZIGBEE_REPORTING_OCCUPANCY_SENSING for change_threshold parameter has
	 * no meaning, set change_threshold value to 0
	 * */
	ZIGBEE_REPORTING_OCCUPANCY_SENSING,
	/*
	 * The change_threshold should be in the range 0 ~ 65533
	 * */
	ZIGBEE_REPORTING_MEASURED_ILLUMINANCE,
	/*
	 * The change_threshold should be in the range 0 ~ 60082
	 * */
	ZIGBEE_REPORTING_MEASURED_TEMPERATURE,
	ZIGBEE_REPORTING_INVALID_MAX_VALUE
} zigbee_reporting_type;
/*!
 * \brief Local endpoint
 */
typedef struct {
	ZIGBEE_PROFILE profile;
	int endpoint_id;
	ZIGBEE_DEVICEID device_id;
	ZIGBEE_DEVICE_VERSION device_version;
} zigbee_local_endpoint;
/*!
 * \brief Local endpoint information
 */
typedef struct {
	int count;
	zigbee_local_endpoint endpoints[MAX_ENDPOINT_SIZE];
} zigbee_local_endpoint_info;
/*!
 * \brief	Structure for endpoint information
 */
typedef struct {
	int endpoint_id;
	int node_id;
	ZIGBEE_DEVICEID device_id;
	int server_cluster[MAX_CLUSTER_SIZE];
	int client_cluster[MAX_CLUSTER_SIZE];
} zigbee_endpoint;
/*!
 * \brief	Structure for endpoint list to find endpoints by cluster ID
 */
typedef struct {
	int num;
	zigbee_endpoint endpoint[MAX_ENDPOINT_SIZE * MAX_DEVICE_INFO_SIZE];
} zigbee_endpoint_list;
/*!
 * \brief	Structure for device information
 *			This is used when sending cluster commands to select device
 */
typedef struct {
	char eui64[EUI64_SIZE];
	int node_id;
	int endpoint_count;
	zigbee_endpoint endpoint[MAX_ENDPOINT_SIZE];
} zigbee_device;
/*!
 * \brief	List of device information
 */
typedef struct {
	int num;
	zigbee_device device[MAX_DEVICE_INFO_SIZE];
} zigbee_device_info;
/*!
 * \brief	Device discovery response
 */
typedef struct {
	zigbee_device_discovery_status status;
	zigbee_device device;
} zigbee_device_discovery;
/*!
 * \brief	ZigBee command sending type
 */
enum zigbee_sending_type {
	ZIGBEE_SENDING_BY_ENDPOINT	= 1024,
	ZIGBEE_SENDING_BY_BINDING	= 1025,
	ZIGBEE_SENDING_BY_GROUP		= 1026
};
/*!
 * \brief	ZigBee command sending information
 *			The varable of 'data' is used according to the sending type
 *			ZIGBEE_SENDING_BY_ENDPOINT	:	dest_endpoint
 *			ZIGBEE_SENDING_BY_BINDING	:	'data' is not used here, the in parameter local endpoint
 *											in the API calling is used, which should be configured
 *											in binding table.
 *			ZIGBEE_SENDING_BY_GROUP		:	group_id
 */
struct zigbee_sending_info {
	enum zigbee_sending_type type;
	union {
		/* It is used for unicast, actually target 'node_id' and 'endpoint_id' are used */
		zigbee_endpoint dest_endpoint;
		/* It is used for multicast */
		int group_id;
	} data;
};
/*!
 * \brief	Structure for network information
 */
typedef struct {
	zigbee_channel channel;
	zigbee_tx_power tx_power;
	int pan_id;         /* < in the range 0-0xFFFF */
} zigbee_network_info;
/*!
 * \brief	Network find result
 */
typedef struct {
	zigbee_network_find_status find_status;
	zigbee_network_info network_info;
} zigbee_network_find_result;
/*!
 * \brief	Received command from remote device
 */
typedef struct {
	bool is_global_command;
	int dest_endpoint_id;
	int cluster_id;
	int command_id;
	char payload[MAX_RECEIVED_COMMAND_PLAYLOAD_LENGTH];
	int payload_length;	/* -1 if buffer size isn't enough */
	int source_node_id;
	int source_endpoint_id;
} zigbee_received_command;
/*!
 * \brief	Attribute changed response from zigbeed
 */
typedef struct {
	zigbee_attribute_type type;
	int endpoint_id;
} zigbee_attribute_changed_response;
/*!
 * \brief	Attribute struct which includes attribute id and attribute type
 */
struct zigbee_attribute {
	ZIGBEE_ATTRIBUTE_ID id;
	zigbee_attribute_type type;
};
/*!
 * \brief	Discovery attributes response from zigbeed
 */
struct zigbee_discovery_attributes {
	ZIGBEE_CLUSTER_ID cluster;
	/**
	 * - true	indicates that there are no more attributes to be discovered
	 * - false	indicates that there are more attributes to be discovered
	 **/
	bool discovery_complete;
	int attribute_count;
	struct zigbee_attribute attributes[MAX_DISCOVER_ATTRITUTES];
};

/*!
 * \brief	A structure used to store reporting configurations. If endpoint
 *			field is ::EMBER_AF_PLUGIN_REPORTING_UNUSED_ENDPOINT_ID, this
 *			configure is unused.
 */
typedef struct {
	bool used;
	int endpoint_id;
	int cluster_id;
	int attribute_id;
	bool is_server;

	struct {
		/** The minimum reporting interval, measured in seconds. */
		uint16_t min_interval;
		/** The maximum reporting interval, measured in seconds. */
		uint16_t max_interval;
		/** The minimum change to the attribute that will result in a report
		 *  being sent.
		 */
		uint32_t reportable_change;
	} reported;
} zigbee_reporting_info;

/*!
 * \brief	Structure for reporting from remote server, it is used for
 *			ZIGBEE_RESPONSE_GENERAL_REPORT_ATTRIBUTE. This is raw reporting
 *			data, user should parse the 'data' all by himself.
 *			The parsing should consider the 'cluster_id', 'attribute_id',
 *			'data_type' and 'data_length'
 */
struct zigbee_general_report_attribute_info {
	ZIGBEE_CLUSTER_ID cluster_id;
	ZIGBEE_ATTRIBUTE_ID attribute_id;
	zigbee_attribute_data_type data_type;
	char data[MAX_ATTRIBUTE_SIZE];
	unsigned int data_length;
};

/*!
 * \brief	Structure for report attribute from remote server
 *			It is used for response ZIGBEE_RESPONSE_REPORT_ATTRIBUTE.
 *
 *			User can get the 'data.value' or 'data.occupancy' directly.
 *				- data.value:	ZIGBEE_ATTR_ILLUMINANCE
 *								ZIGBEE_ATTR_TEMPERATURE
 *								ZIGBEE_ATTR_THERMOSTAT_TEMPERATURE
 *				- data.occypancy:	ZIGBEE_ATTR_OCCUPANCY
 */
typedef struct {
	zigbee_attribute_type attribute_type;
	union {
		int value;
		zigbee_occupancy_status occupancy;
	} data;
} zigbee_report_attribute_info;

/*!
 * \brief	A structure for notifying identify feedback.
 */
typedef struct {
	int endpoint_id;
	int duration;	/* in seconds */
} zigbee_identify_feedback_info;

/*!
* \brief	Structure of target that ezmode commissioning find
*			Used in callback, to notify user
 */
typedef struct {
	int node_id;
	int endpoint_id;
} zigbee_commissioning_target_info;

/*!
* \brief	Structure of clusters that bound by ezmode commissioning
*			Used in callback, to notify user
*/
typedef struct {
	int node_id;
	int cluster_id;
	int endpoint_id;
} zigbee_commissioning_bound_info;

/*!
* \brief	Commissioning state
*			Used in callback, to notify user
*/
typedef enum {
	COMMISSIONING_ERROR = 0x00,				/* < Commissioning error */
	COMMISSIONING_ERR_IN_PROGRESS,			/* < Commissioning in progress error */
	COMMISSIONING_NETWORK_STEERING_FORM,	/* < Try to form a new network if network join failed */
	COMMISSIONING_NETWORK_STEERING_SUCCESS,	/* < Network steering successfully */
	COMMISSIONING_NETWORK_STEERING_FAILED,	/* < Network steering failed */
	COMMISSIONING_WAIT_NETWORK_STEERING,	/* < Network steering is in progress, wait */
	COMMISSIONING_TARGET_SUCCESS,			/* < Commissioning target successfully */
	COMMISSIONING_TARGET_STOP,				/* < Commissioning target stopped */
	COMMISSIONING_TARGET_FAILED,			/* < Commissioning target failed */
	COMMISSIONING_INITIATOR_SUCCESS,		/* < Commissioning initiator successfully */
	COMMISSIONING_INITIATOR_STOP,			/* < Commissioning initiator stopped */
	COMMISSIONING_INITIATOR_FAILED			/* < Commissioning initiator failed */
} zigbee_commissioning_state;

/*!
* \brief	Simple descriptor response
*			Used in callback, to notify user
*/
typedef struct {
	zigbee_service_discovery_result result;
	int target_node_id;
	int target_endpoint;
	int server_cluster_count;
	int server_cluster[MAX_CLUSTER_SIZE];
	int client_cluster_count;
	int client_cluster[MAX_CLUSTER_SIZE];
} zigbee_simple_descriptor_response;

/*!
* \brief	Broadcast identify query response
*			Used in callback, to notify user
*/
typedef struct {
	int node_id;
	int endpoint_id;
	int timeout;
} zigbee_broadcast_identify_query_response;

/*!
* \brief	Ieee addr response
*			Used in callback, to notify user
*/
typedef struct {
	zigbee_service_discovery_result result;
	int node_id;
	char eui64[EUI64_SIZE];
} zigbee_ieee_addr_response;

/*!
* \brief	Match descriptor response
*			Used in callback, to notify user
*/
typedef struct {
	zigbee_service_discovery_result result;
	int node_id;
	int endpoint_list[MAX_ENDPOINT_SIZE];
	int count;
} zigbee_match_desc_response;

/*!
* \brief	ZigBee Device Object (ZDO) response status.
*
*			Most responses to ZDO commands contain a status byte.
*			The meaning of this byte is defined by the ZigBee Device Profile.
*/
typedef enum {
	/* These values are taken from Table 48 of ZDP Errata 043238r003 and Table 2 */
	/* of NWK 02130r10. */
	ZIGBEE_ZDP_SUCCESS = 0x00,
	/* 0x01 to 0x7F are reserved */
	ZIGBEE_ZDP_INVALID_REQUEST_TYPE = 0x80,
	ZIGBEE_ZDP_DEVICE_NOT_FOUND = 0x81,
	ZIGBEE_ZDP_INVALID_ENDPOINT = 0x82,
	ZIGBEE_ZDP_NOT_ACTIVE = 0x83,
	ZIGBEE_ZDP_NOT_SUPPORTED = 0x84,
	ZIGBEE_ZDP_TIMEOUT = 0x85,
	ZIGBEE_ZDP_NO_MATCH = 0x86,
	/* 0x87 is reserved            = 0x87, */
	ZIGBEE_ZDP_NO_ENTRY = 0x88,
	ZIGBEE_ZDP_NO_DESCRIPTOR = 0x89,
	ZIGBEE_ZDP_INSUFFICIENT_SPACE = 0x8a,
	ZIGBEE_ZDP_NOT_PERMITTED = 0x8b,
	ZIGBEE_ZDP_TABLE_FULL = 0x8c,
	ZIGBEE_ZDP_NOT_AUTHORIZED = 0x8d,

	ZIGBEE_NWK_ALREADY_PRESENT = 0xC5,
	ZIGBEE_NWK_TABLE_FULL = 0xC7,
	ZIGBEE_NWK_UNKNOWN_DEVICE = 0xC8
} zigbee_zdo_response_status;

typedef enum {
	/* A binding that is currently not in use. */
	ZIGBEE_UNUSED_BINDING	 = 0,
	/* A unicast binding whose 64-bit identifier is the destination EUI64. */
	ZIGBEE_UNICAST_BINDING	 = 1,
	/* A unicast binding whose 64-bit identifier is the many-to-one
	 * destination EUI64.  Route discovery should be disabled when sending
	 * unicasts via many-to-one bindings.
	 */
	ZIGBEE_MANY_TO_ONE_BINDING	 = 2,
	/* A multicast binding whose 64-bit identifier is the group address. A
	 * multicast binding can be used to send messages to the group and to receive
	 * messages sent to the group.
	 */
	ZIGBEE_MULTICAST_BINDING	 = 3
} zigbee_binding_type;

/*!
* \brief Zigbee binding table entry
*/
typedef struct {
	/* The type of binding. */
	zigbee_binding_type type;
	/*The endpoint on the local node.*/
	int local;
	/* A cluster ID that matches one from the local endpoint's simple descriptor.
	 * This cluster ID is set by the provisioning application to indicate which
	 * part an endpoint's functionality is bound to this particular remote node
	 * and is used to distinguish between unicast and multicast bindings. Note
	 * that a binding can be used to to send messages with any cluster ID, not
	 * just that listed in the binding.
	 */
	int cluster_id;
	/* The endpoint on the remote node (specified by \c identifier).*/
	int remote;
	/* A 64-bit identifier.  This is either:
	 * - The destination EUI64, for unicasts
	 * - A 16-bit multicast group address, for multicasts
	 */
	char identifier[EUI64_SIZE];
	/* The index of the network the binding belongs to.*/
	int network_index;
} zigbee_binding_table_entry;

/*!
* \brief IAS Zone Status Change Notification
*
* It is sent in IAS Zone server cluster side and received in IAS Zone client
* cluster side when a change takes place in one or more bits of the Zone
* Status attribute.
*/
struct zigbee_ias_zone_status_changed_notification {
	/* The source node which reports this change */
	int node_id;
	/* It is the current value of the ZoneStatus attribute */
	ZIGBEE_IAS_ZONE_STATUS zone_status;
	/* It is reserved for additional status information and shall be set to zero */
	uint8_t extended_status;
	/* Zone ID is the index of the Zone in the CIE's zone table */
	uint8_t zone_id;
	/* The Delay is defined as the amount of time, in quarter-seconds, from
	 * the moment when a change takes place in one or more bits of the Zone
	 * Status attribute and the successful transmission of the Zone Status
	 * Change Notification. */
	uint16_t delay;
};

/**
 * @deprecated	This type is deprecated and will be removed, it is
 *				replaced by endpoint id(int type).
 *
 * @brief	endpoint instance
 */
typedef void *zigbee_endpoint_handle;

/**
 * @deprecated	This struct is deprecated and will be removed, it is
 *				replaced by zigbee_local_endpoint.
 *
 * @brief	Used to store endpoint info, get this info by
 *			get_device_info_by_handle()
 * @see		get_device_info_by_handle
 */
struct inner_endpoint_info {
	int endpoint_id;
	ZIGBEE_PROFILE profile;
	ZIGBEE_DEVICEID device_id;
	unsigned char version;
};

#ifdef __cplusplus
}
#endif
#endif				/* __ZIGBEE_DEF_H__ */
