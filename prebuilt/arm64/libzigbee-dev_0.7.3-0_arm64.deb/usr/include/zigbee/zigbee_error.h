#ifndef INCLUDE_ZIGBEE_ERROR_H_
#define INCLUDE_ZIGBEE_ERROR_H_

/*! \file zigbee_error.h
 *
 *  \brief Error codes
 *
 *  Error codes returned by most of the functions
 *  of the API
 */

#define MAX_ERRR_MSG_LEN	64
/*!
 *  \brief Error type
 */
typedef int zigbee_error;
/*!
 *  \brief Error message definition
 *
 *  Structure defining an error and
 *  its user-friendly message
 */
typedef struct {
	int err;
	char msg[MAX_ERRR_MSG_LEN];
} zigbee_error_msg_string;

static const zigbee_error_msg_string error_msg_strings[] = {
	{EZ_OK, "OK"},
	{EZ_ERROR, "ZigBee error"},
	{EZ_BAD_ARGS, "Bad arguments"},
	{EZ_NOT_INITIALIZED, "Not initialized"},
	{EZ_NO_MEM, "No memory"},
	{EZ_NOT_SUPPORTED, "Not supported"},
	{EZ_INVALID_VALUE, "Invalid value"},
	{EZ_INVALID_DAEMON, "Invalid zigbee daemon"},
	{EZ_NO_DAEMON, "No zigbee daemon"},
	{EZ_NO_MESSAGE, "No zigbee message"},
	{EZ_INVALID_ATTR, "Invalid attribute"},
	{EZ_NOT_FOUND, "Not found"},
	{EZ_ERR_SOCK, "Socket error"},
	{EZ_MSG_SEND_ERROR, "Send message error"},
	{EZ_NETWORK_EXIST, "Network has existed"}
};

static inline const char *zigbee_error_msg(int err)
{
	const zigbee_error_msg_string *msgs = error_msg_strings;
	int i, size;

	size = sizeof(error_msg_strings) / sizeof(error_msg_strings[0]);
	for (i = 0; i < size; i++) {
		if (msgs[i].err == err) {
			return (char *)msgs[i].msg;
		}
	}

	return "null";
}

#endif /* INCLUDE_ZIGBEE_ERROR_H_ */
