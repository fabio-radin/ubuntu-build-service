#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <string.h>
#include <assert.h>
#include "zigbee.h"

#define ENDPOINT_TEMPERATURE_SENSOR			2
#define ENDPOINT_OCCUPY_SENSOR				3

#define SET_FAKE_OCCUPANCY_TIME				(60 * 1000)
#define SET_FAKE_TEMPERATURE_TIME			2000
#define SET_RANDOM_BASE_DATA				25

static const char *occupy_occupied = "occupied";
static const char *occupy_unoccupied = "not occupied";

static GMainLoop *mainloop;

static const char *_get_occupy_status_description(zigbee_occupancy_status status)
{
	if (ZIGBEE_OCCUPIED == status)
		return occupy_occupied;
	else
		return occupy_unoccupied;
}

static gboolean _set_fake_occupy_data(gpointer data)
{
	zigbee_occupancy_status status;
	zigbee_occupancy_status occupy_status;
	unsigned int value_length = 0;
	char value[MAX_ATTRIBUTE_SIZE];
	zigbee_attribute_data_type value_type = ZIGBEE_UNKNOWN_ATTRIBUTE_TYPE;

	memset(value, 0, MAX_ATTRIBUTE_SIZE);

	srand((unsigned int)time(NULL));
	status = rand()%2;

	if (EZ_OK == zigbee_general_read_local_attribute(ZCL_OCCUPANCY_SENSING_CLUSTER_ID, ZCL_OCCUPANCY_ATTRIBUTE_ID,
													 value, &value_length, &value_type, ENDPOINT_OCCUPY_SENSOR))
		memcpy(&occupy_status, value, sizeof(short));
	else {
		printf("read local occupy status failed\n");
		return false;
	}

	if (status != occupy_status) {
		if (EZ_OK == zigbee_occupancy_set_occupancy_status(ENDPOINT_OCCUPY_SENSOR, status)) {
			printf("Occupy status is changed from %s to %s\n",
				   _get_occupy_status_description(occupy_status),
				   _get_occupy_status_description(status));
			occupy_status = status;
		} else {
			printf("set occupy status failed\n");
			return false;
		}
	}
	return true;
}

static gboolean _set_fake_temperature_data(gpointer data)
{
	int value = 0;
	int last_temperature; /* reduce the repeat temperature case */
	unsigned int value_length = 0;
	char temperature[MAX_ATTRIBUTE_SIZE];
	zigbee_attribute_data_type value_type = ZIGBEE_UNKNOWN_ATTRIBUTE_TYPE;

	memset(temperature, 0, MAX_ATTRIBUTE_SIZE);

	/* generate a random temperature between 25-30 */
	srand((unsigned int)time(NULL));
	value = rand()%6 + SET_RANDOM_BASE_DATA;

	if (EZ_OK == zigbee_general_read_local_attribute(ZCL_TEMP_MEASUREMENT_CLUSTER_ID, ZCL_TEMP_MEASURED_VALUE_ATTRIBUTE_ID,
													 temperature, &value_length, &value_type, ENDPOINT_TEMPERATURE_SENSOR))
		memcpy(&last_temperature, temperature, sizeof(short));
	else {
		printf("read local temperature failed\n");
		return false;
	}

	if (value != last_temperature) {
		if (EZ_OK == zigbee_temperature_set_measured_value(ENDPOINT_TEMPERATURE_SENSOR, value * 100)) {
			printf("Local temperature is changed to %d\n", value);
			last_temperature = value;
		} else {
			printf("set temperature failed\n");
			return false;
		}
	}
	return true;
}

static void _loop_quit(void)
{
	if (!mainloop)
		return;

	g_main_loop_quit(mainloop);
}

static void _on_callback(void *user_data, zigbee_response_type response_type, void *payload)
{
	zigbee_network_notification network_notification;
	int ret = EZ_OK;

	switch (response_type) {
	case ZIGBEE_RESPONSE_NETWORK_NOTIFICATION:
		network_notification = *((zigbee_network_notification *) payload);
		switch (network_notification) {
		case ZIGBEE_NETWORK_JOIN:
			printf("NETWORK_NOTIFICATION: JOIN\n");
			break;

		case ZIGBEE_NETWORK_LEAVE:
			printf("NETWORK_NOTIFICATION: LEAVE\n");
			break;

		case ZIGBEE_NETWORK_EXIST:
			printf("NETWORK_NOTIFICATION: Network exist, please leave current network and try again\n");
			_loop_quit();
			break;

		case ZIGBEE_NETWORK_FIND_FORM_SUCCESS:
			printf("NETWORK_NOTIFICATION: FIND FORM SUCCESS\n");
			break;

		case ZIGBEE_NETWORK_FIND_FORM_FAILED:
			printf("NETWORK_NOTIFICATION: FIND FORM FAILED\n");
			_loop_quit();
			break;

		case ZIGBEE_NETWORK_FIND_JOIN_SUCCESS:

			g_timeout_add(SET_FAKE_OCCUPANCY_TIME, _set_fake_occupy_data, NULL);	/* change the occupy status once by 1 minute */
			g_timeout_add(SET_FAKE_TEMPERATURE_TIME, _set_fake_temperature_data, NULL);	/* change the temperature once by 2 seconds */

			printf("NETWORK_NOTIFICATION: FIND JOIN SUCCESS\n");
			break;

		case ZIGBEE_NETWORK_FIND_JOIN_FAILED:
			printf("NETWORK_NOTIFICATION: FIND JOIN FAILED\n");
			_loop_quit();
			break;

		default:
			printf("NETWORK_NOTIFICATION: %d\n", network_notification);
			_loop_quit();
			break;
		}
		break;

	default:
		break;
	}
}

static int _network_start(zigbee_network_state *state)
{
	int ret = EZ_OK;

	ret = zigbee_network_start(state);
	if (EZ_OK != ret)
		printf("network_start error %d\n", ret);

	return ret;
}

static int _network_join(void)
{
	int ret = EZ_OK;

	ret = zigbee_network_join();
	if (EZ_OK != ret)
		printf("network join error %d\n", ret);

	return ret;
}

static void _loop_run(void)
{
	if (!mainloop)
		mainloop = g_main_loop_new(NULL, FALSE);

	g_main_loop_run(mainloop);
}

static int _create_SENSORS_device(void)
{
	int ret = EZ_OK;
	zigbee_local_endpoint_info endpoint_info;

	memset(&endpoint_info, 0, sizeof(zigbee_local_endpoint_info));

	endpoint_info.endpoints[endpoint_info.count].profile = ZIGBEE_PROFILE_HA;
	endpoint_info.endpoints[endpoint_info.count].endpoint_id = ENDPOINT_TEMPERATURE_SENSOR;
	endpoint_info.endpoints[endpoint_info.count].device_id = DEVICE_TEMPERATURE_SENSOR;
	endpoint_info.count++;

	endpoint_info.endpoints[endpoint_info.count].profile = ZIGBEE_PROFILE_HA;
	endpoint_info.endpoints[endpoint_info.count].endpoint_id = ENDPOINT_OCCUPY_SENSOR;
	endpoint_info.endpoints[endpoint_info.count].device_id = DEVICE_OCCUPANCY_SENSOR;
	endpoint_info.count++;

	ret = zigbee_set_local_endpoint(&endpoint_info);
	if (EZ_OK != ret)
		printf("Set local endpoint error %d\n", ret);

	return ret;
}

static int _reset(void)
{
	int ret = EZ_OK;

	printf("Start reset\n");
	ret = zigbee_reset_local();
	if (EZ_OK != ret)
		printf("Reset failed: %d\n", ret);

	return ret;
}

static void _show_usage(void)
{
	printf("===================================================================================\n");
	printf("usage:\n");
	printf("<application name> [arguments]\n");
	printf("[--reset]         , Reset device\n");
	printf("without argument  , Join a network\n");
	printf("===================================================================================\n");
}

int main(int argc, char *argv[])
{
	zigbee_network_state state = ZIGBEE_NO_NETWORK;
	int i = 0;
	int ret = EZ_OK;
	bool need_reset = false;

	if (argc > 1) {
		for (i = 1; i < argc; i++) {
			if (!strcmp(argv[i], "--reset"))
				need_reset = true;
			if (!strcmp(argv[i], "--help")) {
				_show_usage();
				return -1;
			}
		}
	}

	ret = _create_SENSORS_device();
	if (EZ_OK != ret)
		return -1;

	ret = zigbee_initialize(_on_callback, NULL);
	if (EZ_OK != ret)
		goto free_quit;

	ret = _network_start(&state);
	if (EZ_OK != ret)
		goto free_quit;

	if (true == need_reset) {
		ret = _reset();
		if (EZ_OK != ret)
			goto free_quit;
		state = ZIGBEE_NO_NETWORK;
	}

	if (ZIGBEE_NO_NETWORK == state) {
		ret = _network_join();
		if (EZ_OK != ret)
			goto free_quit;
	}

	_loop_run();

free_quit:
	zigbee_deinitialize();

	return 0;
}
