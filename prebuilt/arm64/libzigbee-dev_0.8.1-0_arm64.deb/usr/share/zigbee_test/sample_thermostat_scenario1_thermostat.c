#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <string.h>
#include <assert.h>
#include "zigbee.h"

#define ENDPOINT_HEATING_COOLING_UNIT		1
#define ENDPOINT_TEMPERATURE_SENSOR			2
#define ENDPOINT_OCCUPY_SENSOR				3
#define SERVICE_MONITOR_TIME				1000
#define SET_FAKE_OCCUPANCY_TIME				(60 * 1000)
#define SET_FAKE_TEMPERATURE_TIME			2000
#define SET_RANDOM_BASE_DATA				25

static const char *mode_off = "Off";
static const char *mode_heat = "Heat";
static const char *mode_cool = "Cool";
static const char *mode_unsupport = "Unsupport";
static const char *occupy_occupied = "occupied";
static const char *occupy_unoccupied = "not occupied";
static GMainLoop *mainloop;
static short g_heating_point;
static short g_cooling_point;
static zigbee_thermostat_system_mode g_requested_system_mode;

static void _loop_quit(void)
{
	if (!mainloop)
		return;

	g_main_loop_quit(mainloop);
}

static void _open_fan(bool open)
{
	int ret = EZ_OK;
	uint8_t mode = ZIGBEE_FAN_MODE_AUTO;	/* Auto mode */

	if (false == open)
		mode = ZIGBEE_FAN_MODE_OFF;

	ret = zigbee_general_write_local_attribute(ZCL_FAN_CONTROL_CLUSTER_ID,
											   ZCL_FAN_CONTROL_FAN_MODE_ATTRIBUTE_ID,
											   &mode, sizeof(uint8_t),
											   ZIGBEE_ENUM8_ATTRIBUTE_TYPE,
											   ENDPOINT_HEATING_COOLING_UNIT);
	if (EZ_OK != ret)
		printf("Set fan mode failed\n");
}

static void _set_thermostat_mode(zigbee_thermostat_system_mode mode)
{
	int ret = EZ_OK;

	ret = zigbee_thermostat_set_system_mode(ENDPOINT_HEATING_COOLING_UNIT, mode);

	if (EZ_OK != ret)
		printf("Set thermostat mode (%d) failed\n", mode);
}

static const char *_get_occupy_status_description(zigbee_occupancy_status status)
{
	if (ZIGBEE_OCCUPIED == status)
		return occupy_occupied;
	else
		return occupy_unoccupied;
}

static const char *_get_system_mode_description(zigbee_thermostat_system_mode mode)
{
	switch (mode) {
	case ZIGBEE_SYSTEM_MODE_OFF:
		return mode_off;
	case ZIGBEE_SYSTEM_MODE_COOL:
		return mode_cool;
	case ZIGBEE_SYSTEM_MODE_HEAT:
		return mode_heat;
	default:
		return mode_unsupport;
	}
}

static bool _service_monitor(void)
{
	int ret = EZ_ERROR;
	short temperature = 0;
	zigbee_occupancy_status occupy_status;
	unsigned int value_length = 0;
	char value[MAX_ATTRIBUTE_SIZE];
	zigbee_attribute_data_type value_type = ZIGBEE_UNKNOWN_ATTRIBUTE_TYPE;
	zigbee_thermostat_system_mode mode = 0;

	memset(value, 0, MAX_ATTRIBUTE_SIZE);
	ret = zigbee_general_read_local_attribute(ZCL_OCCUPANCY_SENSING_CLUSTER_ID, ZCL_OCCUPANCY_ATTRIBUTE_ID,
											  value, &value_length, &value_type, ENDPOINT_OCCUPY_SENSOR);
	if (EZ_OK == ret)
		memcpy(&occupy_status, value, sizeof(short));
	else {
		printf("get local occupy error %d\n", ret);
		return false;
	}

	if (EZ_OK != zigbee_thermostat_get_system_mode(ENDPOINT_HEATING_COOLING_UNIT, &mode)) {
		printf("get local system mode error\n");
		return false;
	}

	/* if room is empty, turn off thermostat and fan */
	if (ZIGBEE_UNOCCUPIED == occupy_status) {
		if (ZIGBEE_SYSTEM_MODE_OFF != mode) {
			_set_thermostat_mode(ZIGBEE_SYSTEM_MODE_OFF);
			_open_fan(false);
			printf("Room is empty, thermostat won't work\n");
		}
		return true;
	}

	memset(value, 0, MAX_ATTRIBUTE_SIZE);
	ret = zigbee_general_read_local_attribute(ZCL_TEMP_MEASUREMENT_CLUSTER_ID, ZCL_TEMP_MEASURED_VALUE_ATTRIBUTE_ID,
											  value, &value_length, &value_type, ENDPOINT_TEMPERATURE_SENSOR);
	if (EZ_OK == ret)
		memcpy(&temperature, value, sizeof(short));
	else {
		printf("get local temperature error %d\n", ret);
		return false;
	}

	if (ZIGBEE_SYSTEM_MODE_COOL == g_requested_system_mode) {
		if (temperature > g_cooling_point && ZIGBEE_SYSTEM_MODE_COOL != mode) {
			_set_thermostat_mode(ZIGBEE_SYSTEM_MODE_COOL);
			_open_fan(true);
			printf("Current temperature(%d) is higher than (%d), start cooling\n",
					temperature/100, g_cooling_point/100);
		}

		if (temperature <= g_cooling_point && ZIGBEE_SYSTEM_MODE_OFF != mode) {
			_set_thermostat_mode(ZIGBEE_SYSTEM_MODE_OFF);
			_open_fan(false);
			printf("Current temperature(%d) is lower or equal than (%d), stop cooling\n",
					temperature/100, g_cooling_point/100);
		}
	} else if (ZIGBEE_SYSTEM_MODE_HEAT == g_requested_system_mode) {
		if (temperature < g_heating_point && ZIGBEE_SYSTEM_MODE_HEAT != mode) {
			_set_thermostat_mode(ZIGBEE_SYSTEM_MODE_HEAT);
			_open_fan(true);
			printf("Current temperature(%d) is lower than (%d), start heating\n",
					temperature/100, g_heating_point/100);
		}

		if (temperature >= g_heating_point && ZIGBEE_SYSTEM_MODE_OFF != mode) {
			_set_thermostat_mode(ZIGBEE_SYSTEM_MODE_OFF);
			_open_fan(false);
			printf("Current temperature(%d) is higher or equal than (%d), stop heating\n",
					temperature/100, g_heating_point/100);
		}
	} else if (ZIGBEE_SYSTEM_MODE_OFF == g_requested_system_mode) {
		if (ZIGBEE_SYSTEM_MODE_OFF != mode)
			_set_thermostat_mode(ZIGBEE_SYSTEM_MODE_OFF);
		_open_fan(false);
	} else
		printf("unsupport system mode (%d)\n", mode);

	return true;
}

static gboolean _set_fake_occupy_data(gpointer data)
{
	zigbee_occupancy_status status;
	zigbee_occupancy_status last_occupy_status;
	unsigned int value_length = 0;
	char value[MAX_ATTRIBUTE_SIZE];
	zigbee_attribute_data_type value_type = ZIGBEE_UNKNOWN_ATTRIBUTE_TYPE;

	memset(value, 0, MAX_ATTRIBUTE_SIZE);

	srand((unsigned int)time(NULL));
	status = rand()%2;

	if (EZ_OK == zigbee_general_read_local_attribute(ZCL_OCCUPANCY_SENSING_CLUSTER_ID, ZCL_OCCUPANCY_ATTRIBUTE_ID,
													 value, &value_length, &value_type, ENDPOINT_OCCUPY_SENSOR))
		memcpy(&last_occupy_status, value, sizeof(short));
	else {
		printf("read local occupy status failed\n");
		return false;
	}

	if (status != last_occupy_status) {
		if (EZ_OK == zigbee_occupancy_set_occupancy_status(ENDPOINT_OCCUPY_SENSOR, status)) {
			printf("Occupy status is changed from %s to %s\n",
				   _get_occupy_status_description(last_occupy_status),
				   _get_occupy_status_description(status));
			last_occupy_status = status;
			if (!_service_monitor())
				_loop_quit();
		} else {
			printf("set occupy status failed\n");
			return false;
		}
	}
	return true;
}

static gboolean _set_fake_temperature_data(gpointer data)
{
	int value = 0;
	int last_temp = 0;
	unsigned int value_length = 0;
	char temperature[MAX_ATTRIBUTE_SIZE];
	zigbee_attribute_data_type value_type = ZIGBEE_UNKNOWN_ATTRIBUTE_TYPE;

	memset(temperature, 0, MAX_ATTRIBUTE_SIZE);

	/* generate a random temperature between 25-30 */
	srand((unsigned int)time(NULL));
	value = rand()%6 + SET_RANDOM_BASE_DATA;

	if (EZ_OK == zigbee_general_read_local_attribute(ZCL_TEMP_MEASUREMENT_CLUSTER_ID, ZCL_TEMP_MEASURED_VALUE_ATTRIBUTE_ID,
													 temperature, &value_length, &value_type, ENDPOINT_TEMPERATURE_SENSOR))
		memcpy(&last_temp, temperature, sizeof(short));
	else {
		printf("read local temperature failed\n");
		return false;
	}

	if (value != last_temp) {
		if (EZ_OK == zigbee_temperature_set_measured_value(ENDPOINT_TEMPERATURE_SENSOR, value * 100)) {
			printf("Local temperature is changed to %d\n", value);
			last_temp = value;
			if (!_service_monitor())
				_loop_quit();
		} else {
			printf("set temperature failed\n");
			return false;
		}
	}
	return true;
}

static void _loop_run(void)
{
	if (!mainloop)
		mainloop = g_main_loop_new(NULL, FALSE);

	g_main_loop_run(mainloop);
}

static int _network_start(zigbee_network_state *state)
{
	int ret = EZ_OK;

	ret = zigbee_network_start(state);
	if (EZ_OK != ret)
		printf("network_start error %d\n", ret);

	return ret;
}

static int _commissioning_initiator_start(void)
{
	int ret = EZ_OK;

	ret = zigbee_ezmode_commissioning(ENDPOINT_HEATING_COOLING_UNIT, true, true);

	if (EZ_OK == ret)
		printf("Commissioning initiator start...\n");
	else
		printf("Commissioning initiator start failed: %d\n", ret);

	return ret;
}

static void _on_commissioning_status(zigbee_commissioning_state commissioning_state)
{
	switch (commissioning_state) {
	case COMMISSIONING_ERROR:
		printf("Commissioning: error\n");
		_loop_quit();
		break;
	case COMMISSIONING_ERR_IN_PROGRESS:
		printf("Commissioning: error in progress, please wait\n");
		break;
	case COMMISSIONING_NETWORK_STEERING_FORM:
		printf("Commissioning: network steering form\n");
		break;
	case COMMISSIONING_NETWORK_STEERING_SUCCESS:
		printf("Commissioning: network steering success\n");
		break;
	case COMMISSIONING_NETWORK_STEERING_FAILED:
		printf("Commissioning: network steering failed\n");
		_loop_quit();
		break;
	case COMMISSIONING_WAIT_NETWORK_STEERING:
		printf("Commissioning: wait for network steering\n");
		break;
	case COMMISSIONING_INITIATOR_SUCCESS:
		printf("Commissioning: initiator success\n");

		g_timeout_add(SET_FAKE_OCCUPANCY_TIME, _set_fake_occupy_data, NULL);	/* change the occupy status once by 1 minute */
		g_timeout_add(SET_FAKE_TEMPERATURE_TIME, _set_fake_temperature_data, NULL);	/* change the temperature once by 2 seconds */
		break;
	case COMMISSIONING_INITIATOR_FAILED:
		printf("Commissioning: initiator failed\n");
		printf("Please run target first, application exit\n");
		_loop_quit();
		break;
	case COMMISSIONING_INITIATOR_STOP:
		printf("Commissioning: initiator stopped\n");
		_loop_quit();
		break;
	default:
		printf("Commissioning: Other status\n");
		_loop_quit();
		break;
	}
}

void _on_callback_attr_changed(zigbee_attribute_changed_response *info)
{
	int ret = EZ_OK;
	zigbee_thermostat_system_mode mode = 0;
	char value[MAX_ATTRIBUTE_SIZE];
	unsigned int value_length = 0;
	zigbee_attribute_data_type value_type = ZIGBEE_UNKNOWN_ATTRIBUTE_TYPE;

	memset(&value, 0, MAX_ATTRIBUTE_SIZE);

	if (ENDPOINT_HEATING_COOLING_UNIT != info->endpoint_id)
		return;

	if (ZIGBEE_ATTR_OCCUPIED_HEATING_SETPOINT == info->type) {
		ret = zigbee_general_read_local_attribute(ZCL_THERMOSTAT_CLUSTER_ID,
												  ZCL_OCCUPIED_HEATING_SETPOINT_ATTRIBUTE_ID,
												  value, &value_length, &value_type,
												  ENDPOINT_HEATING_COOLING_UNIT);
		if (EZ_OK == ret) {
			memcpy(&g_heating_point, value, sizeof(short));
			printf("Heating setpoint is changed to %d degree\n", g_heating_point/100);
			if (!_service_monitor())
				_loop_quit();
		} else {
			printf("Read heating setpoint failed\n");
			_loop_quit();
		}
	} else if (ZIGBEE_ATTR_OCCUPIED_COOLING_SETPOINT == info->type) {
		ret = zigbee_general_read_local_attribute(ZCL_THERMOSTAT_CLUSTER_ID,
												  ZCL_OCCUPIED_COOLING_SETPOINT_ATTRIBUTE_ID,
												  value, &value_length, &value_type,
												  ENDPOINT_HEATING_COOLING_UNIT);
		if (EZ_OK == ret) {
			memcpy(&g_cooling_point, value, sizeof(short));
			printf("Cooling setpoint is changed to %d degree\n", g_cooling_point/100);
			if (!_service_monitor())
				_loop_quit();
		} else {
			printf("Read cooling setpoint failed\n");
			_loop_quit();
		}
	} else if (ZIGBEE_ATTR_SYSTEM_MODE == info->type) {
		if (EZ_OK == zigbee_thermostat_get_system_mode(ENDPOINT_HEATING_COOLING_UNIT, &mode)) {
			if (g_requested_system_mode != mode) {
				printf("Mode is changed from %s to %s\n",
					   _get_system_mode_description(g_requested_system_mode),
					   _get_system_mode_description(mode));
				g_requested_system_mode = mode;
				if (!_service_monitor())
					_loop_quit();
			}
		} else {
			printf("Read system mode failed\n");
			_loop_quit();
		}
	}
}

static void _on_callback(void *user_data, zigbee_response_type response_type, void *payload)
{
	switch (response_type) {
	case ZIGBEE_RESPONSE_COMMISSIONING_STATUS:
		_on_commissioning_status(*(zigbee_commissioning_state *)payload);
		break;
	case ZIGBEE_RESPONSE_ATTRIBUTE_CHANGE:
		_on_callback_attr_changed((zigbee_attribute_changed_response *)payload);
		break;

	default:
		break;
	}
}

static int _create_HEATINGCOOLING_device(void)
{
	int ret = EZ_OK;
	zigbee_local_endpoint_info endpoint_info;

	memset(&endpoint_info, 0, sizeof(zigbee_local_endpoint_info));
	endpoint_info.endpoints[endpoint_info.count].profile = ZIGBEE_PROFILE_HA;
	endpoint_info.endpoints[endpoint_info.count].endpoint_id = ENDPOINT_HEATING_COOLING_UNIT;
	endpoint_info.endpoints[endpoint_info.count].device_id = DEVICE_HEATING_COOLING_UNIT;
	endpoint_info.count++;

	endpoint_info.endpoints[endpoint_info.count].profile = ZIGBEE_PROFILE_HA;
	endpoint_info.endpoints[endpoint_info.count].endpoint_id = ENDPOINT_TEMPERATURE_SENSOR;
	endpoint_info.endpoints[endpoint_info.count].device_id = DEVICE_TEMPERATURE_SENSOR;
	endpoint_info.count++;

	endpoint_info.endpoints[endpoint_info.count].profile = ZIGBEE_PROFILE_HA;
	endpoint_info.endpoints[endpoint_info.count].endpoint_id = ENDPOINT_OCCUPY_SENSOR;
	endpoint_info.endpoints[endpoint_info.count].device_id = DEVICE_OCCUPANCY_SENSOR;
	endpoint_info.count++;

	ret = zigbee_set_local_endpoint(&endpoint_info);
	if (EZ_OK != ret)
		printf("Set local endpoint error %d", ret);

	return ret;
}

static int _reset(void)
{
	int ret = EZ_OK;

	printf("Start reset\n");
	ret = zigbee_reset_local();
	if (EZ_OK != ret)
		printf("Reset failed: %d\n", ret);

	return ret;
}

static void _show_usage(void)
{
	printf("===================================================================================\n");
	printf("usage:\n");
	printf("<application name> [arguments]\n");
	printf("[--reset]         , Reset device\n");
	printf("without argument  , Run ezmode commissioning to establish a network\n");
	printf("===================================================================================\n");
}

int main(int argc, char *argv[])
{
	zigbee_network_state state = ZIGBEE_NO_NETWORK;
	int i = 0;
	int ret = EZ_OK;
	bool need_reset = false;

	if (argc > 1) {
		for (i = 1; i < argc; i++) {
			if (!strcmp(argv[i], "--reset"))
				need_reset = true;
			if (!strcmp(argv[i], "--help")) {
				_show_usage();
				return -1;
			}
		}
	}

	ret = _create_HEATINGCOOLING_device();
	if (EZ_OK != ret)
		return -1;

	ret = zigbee_initialize(_on_callback, NULL);
	if (EZ_OK != ret)
		goto free_quit;

	ret = _network_start(&state);
	if (EZ_OK != ret)
		goto free_quit;

	if (true == need_reset) {
		ret = _reset();
		if (EZ_OK != ret)
			goto free_quit;
		state = ZIGBEE_NO_NETWORK;
	}

	_set_thermostat_mode(ZIGBEE_SYSTEM_MODE_OFF);
	_open_fan(false);

	ret = _commissioning_initiator_start();
	if (EZ_OK != ret)
		goto free_quit;

	_loop_run();

free_quit:
	zigbee_deinitialize();

	return 0;
}
