#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <string.h>
#include <assert.h>
#include "zigbee.h"

#define ENDPOINT_HEATING_COOLING_UNIT		1

static const char *mode_off = "Off";
static const char *mode_auto = "Auto";
static const char *mode_unsupport = "Unsupport";
static GMainLoop *mainloop;

static void _loop_run(void)
{
	if (!mainloop)
		mainloop = g_main_loop_new(NULL, FALSE);

	g_main_loop_run(mainloop);
}

static const char *_get_fan_mode_description(zigbee_fan_mode mode)
{
	switch (mode) {
	case ZIGBEE_FAN_MODE_OFF:
		return mode_off;
	case ZIGBEE_FAN_MODE_AUTO:
		return mode_auto;

	default:
		return mode_unsupport;
	}
}

static void _open_fan(bool open)
{
	int ret = EZ_OK;
	uint8_t mode = ZIGBEE_FAN_MODE_AUTO;	/* Auto mode */

	if (false == open)
		mode = ZIGBEE_FAN_MODE_OFF;

	ret = zigbee_general_write_local_attribute(ZCL_FAN_CONTROL_CLUSTER_ID,
											   ZCL_FAN_CONTROL_FAN_MODE_ATTRIBUTE_ID,
											   &mode, sizeof(uint8_t),
											   ZIGBEE_ENUM8_ATTRIBUTE_TYPE,
											   ENDPOINT_HEATING_COOLING_UNIT);
	if (EZ_OK != ret)
		printf("Set fan mode failed\n");
}

void _on_callback_attr_changed(zigbee_attribute_changed_response *info)
{
	int ret = EZ_OK;
	char value[MAX_ATTRIBUTE_SIZE];
	unsigned int value_length = 0;
	zigbee_attribute_data_type value_type = ZIGBEE_UNKNOWN_ATTRIBUTE_TYPE;
	zigbee_fan_mode mode = 0;
	static zigbee_fan_mode previous_fan_mode;

	memset(value, 0, MAX_ATTRIBUTE_SIZE);

	if (ENDPOINT_HEATING_COOLING_UNIT != info->endpoint_id)
		return;

	if (ZIGBEE_ATTR_FAN_MODE == info->type) {
		ret = zigbee_general_read_local_attribute(ZCL_FAN_CONTROL_CLUSTER_ID,
												  ZCL_FAN_CONTROL_FAN_MODE_ATTRIBUTE_ID,
												  value, &value_length, &value_type,
												  ENDPOINT_HEATING_COOLING_UNIT);
		memcpy(&mode, value, sizeof(short));
		if (EZ_OK == ret) {
			if (previous_fan_mode != mode) {
				printf("Fan mode is changed from %s to %s\n", _get_fan_mode_description(previous_fan_mode),
						_get_fan_mode_description(mode));
				previous_fan_mode = mode;
			}
		} else
			printf("Read fan mode failed\n");
	}
}

static void _loop_quit(void)
{
	if (!mainloop)
		return;

	g_main_loop_quit(mainloop);
}

static void _on_callback(void *user_data, zigbee_response_type response_type, void *payload)
{
	zigbee_network_notification network_notification;
	int ret = EZ_OK;

	switch (response_type) {;
	case ZIGBEE_RESPONSE_ATTRIBUTE_CHANGE:
		_on_callback_attr_changed((zigbee_attribute_changed_response *)payload);
		break;
	case ZIGBEE_RESPONSE_NETWORK_NOTIFICATION:
		network_notification = *((zigbee_network_notification *) payload);
		switch (network_notification) {
		case ZIGBEE_NETWORK_JOIN:
			printf("NETWORK_NOTIFICATION: JOIN\n");
			break;

		case ZIGBEE_NETWORK_LEAVE:
			printf("NETWORK_NOTIFICATION: LEAVE\n");
			break;

		case ZIGBEE_NETWORK_EXIST:
			printf("NETWORK_NOTIFICATION: Network exist, please leave current network and try again\n");
			_loop_quit();
			break;

		case ZIGBEE_NETWORK_FIND_FORM_SUCCESS:
			printf("NETWORK_NOTIFICATION: FIND FORM SUCCESS\n");
			break;

		case ZIGBEE_NETWORK_FIND_FORM_FAILED:
			printf("NETWORK_NOTIFICATION: FIND FORM FAILED\n");
			_loop_quit();
			break;

		case ZIGBEE_NETWORK_FIND_JOIN_SUCCESS:
			printf("NETWORK_NOTIFICATION: FIND JOIN SUCCESS\n");
			break;

		case ZIGBEE_NETWORK_FIND_JOIN_FAILED:
			printf("NETWORK_NOTIFICATION: FIND JOIN FAILED\n");
			_loop_quit();
			break;

		default:
			printf("NETWORK_NOTIFICATION: %d\n", network_notification);
			_loop_quit();
			break;
		}
		break;

	default:
		break;
	}
}

static int _network_start(zigbee_network_state *state)
{
	int ret = EZ_OK;

	ret = zigbee_network_start(state);
	if (EZ_OK != ret)
		printf("network_start error %d\n", ret);

	return ret;
}

static int _network_join(void)
{
	int ret = EZ_OK;

	ret = zigbee_network_join();
	if (EZ_OK != ret)
		printf("network join error %d\n", ret);

	return ret;
}

static int _create_HEATINGCOOLING_device(void)
{
	int ret = EZ_OK;
	zigbee_local_endpoint_info endpoint_info;

	memset(&endpoint_info, 0, sizeof(zigbee_local_endpoint_info));
	endpoint_info.endpoints[endpoint_info.count].profile = ZIGBEE_PROFILE_HA;
	endpoint_info.endpoints[endpoint_info.count].endpoint_id = ENDPOINT_HEATING_COOLING_UNIT;
	endpoint_info.endpoints[endpoint_info.count].device_id = DEVICE_HEATING_COOLING_UNIT;
	endpoint_info.count++;

	ret = zigbee_set_local_endpoint(&endpoint_info);
	if (EZ_OK != ret)
		printf("Set local endpoint error %d", ret);

	return ret;
}

static int _reset(void)
{
	int ret = EZ_OK;

	printf("Start reset\n");
	ret = zigbee_reset_local();
	if (EZ_OK != ret)
		printf("Reset failed: %d\n", ret);

	return ret;
}

static void _show_usage(void)
{
	printf("===================================================================================\n");
	printf("usage:\n");
	printf("<application name> [arguments]\n");
	printf("[--reset]         , Reset device\n");
	printf("without argument  , Join a network\n");
	printf("===================================================================================\n");
}

int main(int argc, char *argv[])
{
	zigbee_network_state state = ZIGBEE_NO_NETWORK;
	int i = 0;
	int ret = EZ_OK;
	bool need_reset = false;

	if (argc > 1) {
		for (i = 1; i < argc; i++) {
			if (!strcmp(argv[i], "--reset"))
				need_reset = true;
			if (!strcmp(argv[i], "--help")) {
				_show_usage();
				return -1;
			}
		}
	}

	ret = _create_HEATINGCOOLING_device();
	if (EZ_OK != ret)
		return -1;

	ret = zigbee_initialize(_on_callback, NULL);
	if (EZ_OK != ret)
		goto free_quit;

	ret = _network_start(&state);
	if (EZ_OK != ret)
		goto free_quit;

	if (true == need_reset) {
		ret = _reset();
		if (EZ_OK != ret)
			goto free_quit;
		state = ZIGBEE_NO_NETWORK;
	}

	if (ZIGBEE_NO_NETWORK == state) {
		ret = _network_join();
		if (EZ_OK != ret)
			goto free_quit;
	}

	_open_fan(false);

	_loop_run();

free_quit:
	zigbee_deinitialize();

	return 0;
}
