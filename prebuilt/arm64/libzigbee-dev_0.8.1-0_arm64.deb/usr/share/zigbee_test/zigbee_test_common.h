#ifndef _ARTIK_ZIGBEE_TEST_COMMON_H_
#define _ARTIK_ZIGBEE_TEST_COMMON_H_

#include "zigbee.h"
#include "zigbee_error.h"
#include "zigbee_util.h"

#define CUSTOM_ENDPOINT_CONFIG_FILE		"/opt/zigbee/endpoint_config"
#define ENDPOINT_ID_MIN				1
#define ENDPOINT_ID_MAX				239
#define KEYBOARD_INPUT_SIZE			300
#define DEFAULT_TEST_CHANNEL		25
#define DEFAULT_TEST_TX_POWER		ZIGBEE_TX_POWER_2
#define DEFAULT_TEST_PANID			0x1234
#define CHANNEL_MIN					11
#define CHANNEL_MAX					26
#define TX_MIN						(-9)
#define TX_MAX						8
#define INVALID_TX					(-100)

enum timer_command {
	TIMER_IEEE_DESC_REQUEST
};

extern char* get_device_name(int device_id);
typedef void(*func)(char *input, int max_size);
typedef int(*timer_func)(enum timer_command cmd, int id, void *user_data);

struct st_timer {
	enum timer_command command;
	int id;
	timer_func func;
	void *user_data;
};

struct device_type {
	ZIGBEE_PROFILE profile;
	ZIGBEE_DEVICEID device_id;
	ZIGBEE_DEVICE_VERSION device_version;
	int default_endpoint_id;
	char *name;
};

struct test_device {
	ZIGBEE_PROFILE profile;
	ZIGBEE_DEVICEID device_id;
	ZIGBEE_DEVICE_VERSION device_version;
	int endpoint_id;

	zigbee_error(*ezmode_commissioning_initiator_start)(int local_endpoint);
	zigbee_error(*ezmode_commissioning_target_start)(int local_endpoint);
	zigbee_error(*identify_request)(const struct zigbee_sending_info *sending_info,
									int duration, int endpoint_id);
	zigbee_error(*identify_get_remaining_time)(const struct zigbee_sending_info *sending_info,
											   int *time, int endpoint_id);
	zigbee_error(*groups_get_local_name_support)(int endpoint_id);
	zigbee_error(*groups_set_local_name_support)(int endpoint_id, bool support);
	zigbee_error(*onoff_command)(const struct zigbee_sending_info *sending_info,
								 const zigbee_onoff_status target_status,
								 int endpoint_id);
	zigbee_error(*onoff_get_value)(int endpoint_id, zigbee_onoff_status *status);
	zigbee_error(*level_control_request)(const struct zigbee_sending_info *sending_info,
										 const zigbee_level_control_command *command,
										 int endpoint_id);
	zigbee_error(*level_control_get_value)(int endpoint_id, int *value);
	zigbee_error(*illum_set_measured_value_range)(int endpoint_id, int min, int max);
	zigbee_error(*illum_set_measured_value)(int endpoint_id, int value);
	zigbee_error(*illum_get_measured_value)(int endpoint_id, int *value);
	zigbee_error(*reset_to_factory_default)(const struct zigbee_sending_info *sending_info,
											int endpoint_id);
	zigbee_error(*request_reporting)(int cluster_id,
									 const struct zigbee_sending_info *sending_info,
									 zigbee_reporting_type report_type,
									 int min_interval, int max_interval,
									 int change_threshold, int endpoint_id);
	zigbee_error(*stop_reporting)(int cluster_id,
								  const struct zigbee_sending_info *sending_info,
								  zigbee_reporting_type report_type,
								  int endpoint_id);
	zigbee_error(*groups_command)(const struct zigbee_sending_info *sending_info,
								  zigbee_groups_info *groups_info,
								  int endpoint_id);
	zigbee_error(*occupancy_set_type)(int local_endpoint,
									  zigbee_occupancy_type type);
	zigbee_error(*occupancy_set_value)(int local_endpoint,
									   zigbee_occupancy_status status);
	zigbee_error(*temperature_set_measured_value)(int local_endpoint, int value);
	zigbee_error(*temperature_set_measured_value_range)(int local_endpoint,
														int min, int max);
	zigbee_error(*humidity_set_measured_value)(int local_endpoint, int value);
	zigbee_error(*humidity_set_measured_value_range)(int local_endpoint,
													 int min, int max);
	zigbee_error(*general_read_local_attribute)(ZIGBEE_CLUSTER_ID cluster,
												ZIGBEE_ATTRIBUTE_ID attribute,
												char value[MAX_ATTRIBUTE_SIZE],
												unsigned int *value_length,
												zigbee_attribute_data_type *value_type,
												int local_endpoint);
	zigbee_error(*general_write_local_attribute)(ZIGBEE_CLUSTER_ID cluster,
											 	 ZIGBEE_ATTRIBUTE_ID attribute,
											 	 void *value,
											 	 unsigned int value_length,
											 	 zigbee_attribute_data_type value_type,
											 	 int local_endpoint);
	zigbee_error(*general_read_remote_attribute)(const struct zigbee_sending_info *sending_info,
											 	 ZIGBEE_CLUSTER_ID cluster,
											 	 ZIGBEE_ATTRIBUTE_ID attribute,
											 	 char value[MAX_ATTRIBUTE_SIZE],
											 	 unsigned int *value_length,
											 	 zigbee_attribute_data_type *value_type,
											 	 int local_endpoint);
	zigbee_error(*general_write_remote_attribute)(const struct zigbee_sending_info *sending_info,
												  ZIGBEE_CLUSTER_ID cluster,
												  ZIGBEE_ATTRIBUTE_ID attribute,
												  void *value,
												  unsigned int value_length,
												  zigbee_attribute_data_type value_type,
												  int local_endpoint);
	zigbee_error(*general_request_reporting)(const struct zigbee_sending_info *sending_info,
										 	 ZIGBEE_CLUSTER_ID cluster_id,
										 	 ZIGBEE_ATTRIBUTE_ID attribute_id,
										 	 zigbee_attribute_data_type attribute_type,
										 	 int min_interval, int max_interval,
										 	 int change_threshold, int local_endpoint);
	zigbee_error(*general_stop_reporting)(const struct zigbee_sending_info *sending_info,
										  ZIGBEE_CLUSTER_ID cluster_id,
										  ZIGBEE_ATTRIBUTE_ID attribute_id,
										  zigbee_attribute_data_type attribute_data_type,
										  int local_endpoint);
	zigbee_error(*general_read_reporting_config)(const struct zigbee_sending_info *sending_info,
												 ZIGBEE_CLUSTER_ID cluster,
												 ZIGBEE_ATTRIBUTE_ID attribute,
												 zigbee_reporting_info *reporting_info,
												 int local_endpoint);
	zigbee_error(*general_discover_attribute)(const struct zigbee_sending_info *sending_info,
											  ZIGBEE_CLUSTER_ID cluster,
											  ZIGBEE_ATTRIBUTE_ID start_attribute,
											  uint8_t max_count,
											  struct zigbee_discovery_attributes *attr_list,
											  int local_endpoint);
};

int read_int(char *input, int max_size, int default_value);
bool read_q(char *input, int max_size);
bool read_e(char *input, int max_size);
bool read_lf(char *input, int max_size);
int read_input_int(int default_value);
void show(const char *format, ...);
void showln(const char *format, ...);
void show_hyphen();
void show_retry();
void show_range(int min, int max);
void show_select();
void show_network_status(int status);
void show_node_type(int type);
void show_device(zigbee_device *device);
void show_device_info(zigbee_device_info *device_info);
zigbee_error read_channel(char *input, int max_size, zigbee_channel *channel);
zigbee_error read_tx(char *input, int max_size, zigbee_tx_power *tx);
zigbee_error read_pan_id(char *input, int max_size, int *pan_id);
void show_request_channel();
void show_request_tx();
void show_request_pan_id();
void show_mac_capability(ZIGBEE_MAC_CAPABILITY mac_capability);
struct test_device *add_test_device(ZIGBEE_PROFILE profile, ZIGBEE_DEVICEID device_id,
									ZIGBEE_DEVICE_VERSION device_version, int endpoint_id);
void delete_test_device(int endpoint_id);
void release_all_test_devices();
int get_test_device_count();
bool check_test_device_endpoint_id(int endpoint_id);
void get_test_device_list(int *endpoint_list, int max_size, int *size);
struct test_device *get_test_device(int index);
struct test_device *get_test_device_by_endpoint_id(int endpoint_id);
int add_timer(timer_func func, enum timer_command cmd, int second,
			  void *user_data);
int add_periodic_timer(timer_func func, enum timer_command cmd, int msec,
			void *user_data);
void *remove_timer(int id);

#endif /* _ARTIK_ZIGBEE_TEST_COMMON_H_ */
