#ifndef	__ZIGBEE_DEF_H__
#define	__ZIGBEE_DEF_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stdbool.h>
#include <glib.h>
#include "zigbee_clusters.h"

/*! \file zigbee_def.h
 *
 *	\brief ZigBee definitions
 *
 *	Definitions and functions
 *
 */
#define REQUIRED_ZIGBEED_VERSION		"0.8.1"
#define ZIGBEED_VERSION_FILE			"/etc/zigbee/daemon_version"
#define ZIGBEED_PROCESS_NAME			"zigbeed"

/* why we not use profile id directly.
 * for most device type of ZLL, the profile id is 0x104, same to HA.
 * for more information, please check [UG1039-AppDevFundamentals-ZLL.pdf],
 * chapter [3.1 Clusters]. GP have same problem.
 */
typedef unsigned short ZIGBEE_PROFILE;
#define ZIGBEE_PROFILE_HA		0x0104
#define ZIGBEE_PROFILE_ZLL		0xC05E
#define ZIGBEE_PROFILE_GP		0xA1E0
/* Public profile - ranges from 0x0000 to 0x7fff
 * Manufacturer Specific Profile - ranges from 0xc000 to 0xffff
 */
#define ZIGBEE_PROFILE_INVALID	0x8000
#define MAX_ZIGBEE_PROFILE		0xFFFF

/**
 * Different profiles may have different minimum device versions,
 * HA, GP and ZLL minimum device versions are fixed here, for other
 * minimum device versions, please check the related specifications.
 **/
typedef unsigned char ZIGBEE_DEVICE_VERSION;
#define ZIGBEE_HA_MIN_DEVICE_VERSION	0x00
#define ZIGBEE_GP_MIN_DEVICE_VERSION	0x00
#define ZIGBEE_ZLL_MIN_DEVICE_VERSION	0x02

/*!
 * @brief	The max count of parameters for zcl raw command
 */
#define ZIGBEE_MAX_ZCL_PAYLOAD_PARAM    20

/*!
 * @brief	The max count of bypes for one parameter of zcl raw command
 *			Whole frame size can't be bigger than 82 bytes. There are 3 bytes used by
 *			frame control + sequence + command id
 */
#define ZIGBEE_MAX_ZCL_PAYLOAD_SIZE     (82 - 3)

#define ZIGBEE_DEFAULT_OTA_IMAGE_LOCATION		"/opt/zigbee/ota-images"

/**
 * @brief	Data type for payload of zcl raw command
 */
enum zigbee_raw_data_type {
	RAW_DATA_U8 = 0,	/* 1 byte */
	RAW_DATA_U16,		/* 2 bytes */
	RAW_DATA_U32,		/* 4 bytes */
	RAW_DATA_ARRAY_U8,	/* 1 byte array */
	RAW_DATA_ARRAY_U16,	/* 2 bytes array */
	RAW_DATA_ARRAY_U32,	/* 4 bytes array */
	RAW_DATA_STRING		/* string */
};

/**
 * @brief	One parameter for payload of zcl raw command
 *			If type is RAW_DATA_U16, need to cast data as a unsigned short *, then save data to it.
 *			RAW_DATA_U32 needs to cast as a 4 bytes pointer, such as int * in 32 bits system.
 *			length is only available when type is a array type, such as RAW_DATA_ARRAY_U8; it represents
 *			the count of array element.
 */
struct zigbee_raw_parameter_data {
	enum zigbee_raw_data_type type;		/* data type of parameter */
	uint8_t length;						/* available when type is a array type */
	char data[ZIGBEE_MAX_ZCL_PAYLOAD_SIZE];		/* content of parameter */
};

/**
 * @brief	payload of zcl raw command
 */
struct zigbee_raw_data_payload {
	int count;					/* parameters' count */
	struct zigbee_raw_parameter_data parameter[ZIGBEE_MAX_ZCL_PAYLOAD_PARAM];
};

/**
 * @brief	Thermostat device has two versions, for optional clusters,
 *			version 0 has several client clusters without any server clusters,
 *			version 1 has only relative humidity server cluster
 *			without any client clusters
 */
#define THERMOSTAT_CONTROLLER_DEVICE_VERSION			0
#define THERMOSTAT_HUMIDITY_SENSOR_DEVICE_VERSION		1

/* Standard ZigBee device identifier ranges from 0x0000 to 0xbfff */
typedef unsigned short ZIGBEE_DEVICEID;
/* HA Device*/
#define DEVICE_ON_OFF_SWITCH						0x0000
#define DEVICE_LEVEL_CONTROL_SWITCH					0x0001
#define DEVICE_ON_OFF_OUTPUT						0x0002
#define DEVICE_LEVEL_CONTROLLABLE_OUTPUT			0x0003
#define DEVICE_SCENE_SELECTOR						0x0004
#define DEVICE_CONFIGURATION_TOOL					0x0005
#define DEVICE_REMOTE_CONTROL						0x0006
#define DEVICE_COMBINED_INTERFACE					0x0007
#define DEVICE_RANGE_EXTENDER						0x0008
#define DEVICE_MAINS_POWER_OUTLET					0x0009
#define DEVICE_DOOR_LOCK							0x000a
#define DEVICE_DOOR_LOCK_CONTROLLER					0x000b
#define DEVICE_SIMPLE_SENSOR						0x000c
#define DEVICE_CONSUMPTION_AWARENESS_DEVICE			0x000d
#define DEVICE_HOME_GATEWAY							0x0050
#define DEVICE_SMART_PLUG							0x0051
#define DEVICE_WHITE_GOODS							0x0052
#define DEVICE_METER_INTERFACE						0x0053
#define DEVICE_ON_OFF_LIGHT							0x0100
#define DEVICE_DIMMABLE_LIGHT						0x0101
#define DEVICE_COLOR_DIMMABLE_LIGHT					0x0102
#define DEVICE_ON_OFF_LIGHT_SWITCH					0x0103
#define DEVICE_DIMMER_SWITCH						0x0104
#define DEVICE_COLOR_DIMMER_SWITCH					0x0105
#define DEVICE_LIGHT_SENSOR							0x0106
#define DEVICE_OCCUPANCY_SENSOR						0x0107
#define DEVICE_SHADE								0x0200
#define DEVICE_SHADE_CONTROLLER						0x0201
#define DEVICE_WINDOW_COVERING_DEVICE				0x0202
#define DEVICE_WINDOW_COVERING_CONTROLLER			0x0203
#define DEVICE_HEATING_COOLING_UNIT					0x0300
#define DEVICE_THERMOSTAT							0x0301
#define DEVICE_TEMPERATURE_SENSOR					0x0302
#define DEVICE_PUMP									0x0303
#define DEVICE_PUMP_CONTROLLER						0x0304
#define DEVICE_PRESSURE_SENSOR						0x0305
#define DEVICE_FLOW_SENSOR							0x0306
#define DEVICE_MINI_SPLIT_AC						0x0307
#define DEVICE_IAS_CONTROL_AND_INDICATING_EQUIPMENT	0x0400
#define DEVICE_IAS_ANCILLARY_CONTROL_EQUIPMENT		0x0401
#define DEVICE_IAS_ZONE								0x0402
#define DEVICE_IAS_WARNING_DEVICE					0x0403
/* ZLL device*/
#define DEVICE_ZLL_ON_OFF_LIGHT						0x0000
#define DEVICE_ZLL_ON_OFF_PLUG_IN_UNIT				0x0010
#define DEVICE_ZLL_DIMMABLE_LIGHT					0x0100
#define DEVICE_ZLL_DIMMABLE_PLUG_IN_UNIT			0x0110
#define DEVICE_ZLL_COLOR_LIGHT						0x0200
#define DEVICE_ZLL_EXTENDED_COLOR_LIGHT				0x0210
#define DEVICE_ZLL_COLOR_TEMPERATURE_LIGHT			0x0220
#define DEVICE_ZLL_COLOR_CONTROLLER					0x0800
#define DEVICE_ZLL_COLOR_SCENE_CONTROLLER			0x0810
#define DEVICE_ZLL_NON_COLOR_CONTROLLER				0x0820
#define DEVICE_ZLL_NON_COLOR_SCENE_CONTROLLER		0x0830
#define DEVICE_ZLL_CONTROL_BRIDGE					0x0840
#define DEVICE_ZLL_ON_OFF_SENSOR					0x0850
/* GP device*/
#define DEVICE_GP_PROXY								0x0060
#define DEVICE_GP_PROXY_BASIC						0x0061
#define DEVICE_GP_TARGET_PLUS						0x0062
#define DEVICE_GP_TARGET							0x0063
#define DEVICE_GP_COMMISSIONING_TOOL				0x0064
#define DEVICE_GP_COMBO								0x0065
#define DEVICE_GP_COMBO_BASIC						0x0066
/* Invalidate device*/
#define DEVICE_INVALIDATE							0xC000

/**
 * @brief	Type for referring to ZCL attribute id
 *			For the attribute ids, please check zigbee_attributes.h
 */
/* Standard ZigBee attribute identifier ranges from 0x0000 to 0x4fff.
 * Global attributes identifier ranges from 0xf000 to 0xfffe.
 * All other values are reserved.
 */
typedef	unsigned short		ZIGBEE_ATTRIBUTE_ID;
#define	MAX_ATTRIBUTE_ID	0xFFFE

/**
 * @brief	Type for referring to ZCL cluster id
 *			For the cluster ids, please check zigbee_clusters.h
 */
/* Standard ZigBee cluster identifier ranges from 0x0000 to 0x7fff
 * Manufacturer Specific cluster identifier ranges from 0xfc00 to 0xffff
 */
typedef	unsigned short				ZIGBEE_CLUSTER_ID;
#define	MAX_CLUSTER_ID				0xFFFE
#define	MAX_ZDO_CLUSTER_COUNT		0xFF

#define	MAX_NODE_ID			0xFFFF
/**
 * @brief	ZigBee network address (16-bit)
 */
typedef	unsigned short								ZIGBEE_NODE_ID;
#define	ZIGBEE_NODE_ID_BROADCAST					0xFFFC	/* All routers */
#define	ZIGBEE_NODE_ID_RX_ON_WHEN_IDLE_BROADCAST	0xFFFD	/* All non-sleepy devices */
#define	ZIGBEE_NODE_ID_SLEEPY_BROADCAST				0xFFFF	/* All devices, including sleepy end devices */
#define	MAX_NODE_ID									0xFFFF

/**
 * @brief	The 16-bit address of the group.
 *			It can be used for multicast.
 *
 *			The group identifiers need to be unique in the network and their range is (0x0001 - 0xfeff).
 *			Group identifier 0x0000 is used for the default group in the ZCL scene cluster.
 *			Group identifiers (0xff00 - 0xffff) shall be reserved.
 */
typedef	unsigned short		ZIGBEE_GROUP_ID;
#define	ZCL_SCENE_GROUP_ID	0x0000
#define	MAX_GROUP_ID		0xFEFF

/**
* @brief IAS Zone Status attribute
*
* The Zone Status attribute is a bit map, The meaning of each bit is summarized
* by the macro ZIGBEE_IAS_ZONE_STATUS_BIT_XXX.
*/
typedef uint16_t ZIGBEE_IAS_ZONE_STATUS;
/* 1 - opened or alarmed
 * 0 - closed or not alarmed
 */
#define ZIGBEE_IAS_ZONE_STATUS_BIT_ALARM1				(1 << 0)
/* 1 - opened or alarmed
 * 0 - closed or not alarmed
 */
#define ZIGBEE_IAS_ZONE_STATUS_BIT_ALARM2				(1 << 1)
/* 1 - Tampered
 * 0 - Not tampered
 */
#define ZIGBEE_IAS_ZONE_STATUS_BIT_TAMPER				(1 << 2)
/* 1 - Low battery
 * 0 - Battery OK
 */
#define ZIGBEE_IAS_ZONE_STATUS_BIT_BATTERY				(1 << 3)
/* 1 - Reports
 * 0 - Does not report
 */
#define ZIGBEE_IAS_ZONE_STATUS_BIT_SUPERVISION_REPORTS	(1 << 4)
/* 1 - Reports restore
 * 0 - Does not report restore
 */
#define ZIGBEE_IAS_ZONE_STATUS_BIT_RESTORE_REPORTS		(1 << 5)
/* 1 - Trouble/Failure
 * 0 - OK
 */
#define ZIGBEE_IAS_ZONE_STATUS_BIT_TROUBLE				(1 << 6)
/* 1 - AC/Mains fault
 * 0 - AC/Mains OK
 */
#define ZIGBEE_IAS_ZONE_STATUS_BIT_AC					(1 << 7)
/* 1 - Sensor is in test mode
 * 0 - Sensor is in operation mode
 */
#define ZIGBEE_IAS_ZONE_STATUS_BIT_TEST					(1 << 8)
/* 1 - Sensor detects a defective battery
 * 0 - Sensor battery is func-tioning normally
 */
#define ZIGBEE_IAS_ZONE_STATUS_BIT_BATTERY_DEFECT		(1 << 9)

#define	MAX_COMMAND_BUFFER_SIZE	5000
#define MAX_RESPONSE_SIZE		10000
#define MAX_RECEIVED_COMMAND_PLAYLOAD_LENGTH	1024
#define MAX_DEVICE_INFO_SIZE	20
#define MAX_ENDPOINT_SIZE		5
#define MAX_CLUSTER_SIZE		9
#define EUI64_SIZE				8
#define EXTEND_PAN_ID_SIZE		8
#define COORDINATOR_NODEID		0x0000
#define ZIGBEE_BROADCAST_ENDPOINT	0xFF
/* The maximum attribute count for attribute discover */
#define MAX_DISCOVER_ATTRITUTES		0xFF

#define MAX_ROUTING_TABLE_COUNT		0xFF
#define MAX_BINDING_TABLE_COUNT		0xFF

typedef unsigned char				ZIGBEE_ENDPOINT_ID;
#define MIN_ENDPOINT_ID				1
#define MAX_ENDPOINT_ID				0xFE
#define MAX_ACTIVE_ENDPOINT_COUNT	0xFF
#define MAX_DISCOVER_CYCLE_TIME		60	/* 60 minutes */

#define MAX_PERMITJOIN_DURATION		0xFF

#define ILLUMINANCE_MAX_VALUE					0xfffe
#define ILLUMINANCE_MIN_VALUE					1
#define ILLUMINANCE_VALUE_TOO_LOW_BE_MEASSURED	0
#define ILLUMINANCE_INVALIED_VALUE				0xffff
#define ILLUMINANCE_MAX_THRESHOLD				(ILLUMINANCE_MAX_VALUE - ILLUMINANCE_MIN_VALUE)
#define ILLUMINANCE_MAX_LUX						3576000.0	/* 3.576 x 10^6 */
#define ILLUMINANCE_MIN_LUX						1.0
#define ILLUMINANCE_LUX_TOO_LOW_BE_MEASSURED	0.0

#define TEMPERATURE_MAX_VALUE					0x7fff
#define TEMPERATURE_MIN_VALUE					(0x954d - 1 - 0xffff)
#define TEMPERATURE_INVALID_VALUE				0x8000
#define TEMPERATURE_MAX_THRESHOLD				(TEMPERATURE_MAX_VALUE - TEMPERATURE_MIN_VALUE)
/* Temperature = 100 x temperature in degrees Celsius */
#define TEMPERATURE_MAX_CELSIUS					(TEMPERATURE_MAX_VALUE / 100.0f)
#define TEMPERATURE_MIN_CELSIUS					(TEMPERATURE_MIN_VALUE / 100.0f)

#define HUMIDITY_MAX_VALUE						0x2710
#define HUMIDITY_MIN_VALUE						0x0
#define HUMIDITY_MAX_THRESHOLD					(HUMIDITY_MAX_VALUE - HUMIDITY_MIN_VALUE)

#define MAX_CHILDREN_NUMBER						255

/**
 * Error code
 */
#define EZ_OK					(0)
#define EZ_ERROR				(-1)
#define EZ_BAD_ARGS				(-2)
#define EZ_NOT_INITIALIZED		(-3)
#define EZ_NO_MEM				(-4)
#define EZ_NOT_SUPPORTED		(-5)
#define EZ_INVALID_VALUE		(-6)
#define EZ_INVALID_DAEMON		(-7)
#define EZ_NO_DAEMON			(-8)
#define EZ_NO_MESSAGE			(-9)
#define EZ_INVALID_ATTR			(-10)
#define EZ_NOT_FOUND			(-11)
#define EZ_ERR_SOCK				(-12)
#define EZ_MSG_SEND_ERROR		(-13)
#define EZ_NETWORK_EXIST		(-14)
#define EZ_NO_NETWORK			(-15)
#define EZ_IN_PROGRESS			(-16)
/* Deprecated, it will be deleted and replaced by EZ_NOT_FOUND */
#define EZ_NO_DEVICE			(-11)

#define MAX_NEIGHBOR_TABLE_SIZE 16
#define MAX_NEIGHBOR_TABLE_LIST_COUNT 2

/*!
 * \brief	The max attribute value size
 */
#define MAX_ATTRIBUTE_SIZE	33

/*!
 * \brief	Receiving command notification type from ZigBee Daemon
 *			This is one of response types
 */
typedef enum {
	ZIGBEE_CMD_SUCCESS = 0,
	ZIGBEE_CMD_ERR_PORT_PROBLEM = -3001,
	ZIGBEE_CMD_ERR_NO_SUCH_COMMAND = -3002,
	ZIGBEE_CMD_ERR_WRONG_NUMBER_OF_ARGUMENTS = -3003,
	ZIGBEE_CMD_ERR_ARGUMENT_OUT_OF_RANGE = -3004,
	ZIGBEE_CMD_ERR_ARGUMENT_SYNTAX_ERROR = -3005,
	ZIGBEE_CMD_ERR_STRING_TOO_LONG = -3006,
	ZIGBEE_CMD_ERR_INVALID_ARGUMENT_TYPE = -3007,
	ZIGBEE_CMD_ERR = -3008
} zigbee_notification;
/*!
 * \brief	Receiving network notification type from ZigBee Daemon
 *			This is one of response types
 */
typedef enum {
	/* It is notified in coordinator side when router joins current network */
	ZIGBEE_NETWORK_JOIN = 3100,
	/* It is notified in coordinator side when router leaves current network */
	ZIGBEE_NETWORK_LEAVE,
	ZIGBEE_NETWORK_FIND_FORM_SUCCESS,
	ZIGBEE_NETWORK_FIND_FORM_FAILED,
	ZIGBEE_NETWORK_FIND_JOIN_SUCCESS,
	ZIGBEE_NETWORK_FIND_JOIN_FAILED,
	/* If it is in a network currently and form/join is re-called, this type
	 * notification will be used*/
	ZIGBEE_NETWORK_EXIST,
	/* It is used when network_form_manually */
	ZIGBEE_NETWORK_FORM_SUCCESS,
	ZIGBEE_NETWORK_FORM_FAILED,
	/* It is used when network_join_manually */
	ZIGBEE_NETWORK_JOIN_SUCCESS,
	ZIGBEE_NETWORK_JOIN_FAILED
} zigbee_network_notification;
/*!
 * \brief	Receiving node type from ZigBee Daemon
 *			This is one of response types
 */
typedef enum {
	ZIGBEE_UNKNOWN_DEVICE = 3200,
	ZIGBEE_COORDINATOR = 3201,
	ZIGBEE_ROUTER = 3202,
	ZIGBEE_END_DEVICE = 3203,
	ZIGBEE_SLEEPY_END_DEVICE = 3204
} zigbee_node_type;
/*!
 * \brief	Receiving relation type from ZigBee Daemon
 *			This is one of response types
 */
typedef enum {
	PARENT = 0x0,
	CHILD,
	SIBLING
} zigbee_relation_type;
/*!
 * \brief	Receiving network state from ZigBee Daemon
 *			This is one of response types
 */
typedef enum {
	ZIGBEE_NO_NETWORK = 3210,
	ZIGBEE_JOINING_NETWORK,
	ZIGBEE_JOINED_NETWORK,
	ZIGBEE_JOINED_NETWORK_NO_PARENT,
	ZIGBEE_LEAVING_NETWORK
} zigbee_network_state;
/*!
 * \brief	Device discovery result
 */
typedef enum {
	ZIGBEE_DEVICE_DISCOVERY_NO_DEVICE = 3220,
	ZIGBEE_DEVICE_DISCOVERY_FOUND,
	ZIGBEE_DEVICE_DISCOVERY_DONE,
	ZIGBEE_DEVICE_DISCOVERY_START,
	ZIGBEE_DEVICE_DISCOVERY_ERROR,
	ZIGBEE_DEVICE_DISCOVERY_IN_PROGRESS,/* Cyclic discovery is in progress or last calling is not finished */
	ZIGBEE_DEVICE_DISCOVERY_CHANGED,	/* In cycle discovery, device is changed */
	ZIGBEE_DEVICE_DISCOVERY_LOST		/* In cycle discovery, device is lost */
} zigbee_device_discovery_status;
/*!
 * \brief	Network find status
 */
typedef enum {
	ZIGBEE_NETWORK_FOUND = 3230,
	ZIGBEE_NETWORK_FIND_FINISHED,
	ZIGBEE_NETWORK_FIND_ERR
} zigbee_network_find_status;

typedef enum {
	/* It is used for artik_zigbee_match_desc_response received */
	ZIGBEE_SERVICE_DISCOVERY_RECEIVED = 3240,
	ZIGBEE_SERVICE_DISCOVERY_DONE,
	ZIGBEE_SERVICE_DISCOVERY_ERROR,
	ZIGBEE_SERVICE_DISCOVERY_NO_RESPONSE
} zigbee_service_discovery_result;
/*!
 * \brief	Receiving response type from ZigBee Daemon
 */
typedef enum {
	/* Common response */
	ZIGBEE_RESPONSE_NOTIFICATION = 3300,
	ZIGBEE_RESPONSE_CLIENT_TO_SERVER_COMMAND_RECEIVED,
	ZIGBEE_RESPONSE_ATTRIBUTE_CHANGE,
	ZIGBEE_RESPONSE_REPORTING_CONFIGURE,
	ZIGBEE_RESPONSE_REPORT_ATTRIBUTE,
	ZIGBEE_RESPONSE_IDENTIFY_FEEDBACK_START,
	ZIGBEE_RESPONSE_IDENTIFY_FEEDBACK_STOP,
	/* Network response */
	ZIGBEE_RESPONSE_NETWORK_NOTIFICATION,
	ZIGBEE_RESPONSE_NETWORK_FIND,
	/* Device response */
	ZIGBEE_RESPONSE_DEVICE_DISCOVER,
	/* Cluster response */
	ZIGBEE_RESPONSE_BROADCAST_IDENTIFY_QUERY,
	ZIGBEE_RESPONSE_GROUPS_INFO,
	ZIGBEE_RESPONSE_COMMISSIONING_STATUS,
	ZIGBEE_RESPONSE_COMMISSIONING_TARGET_INFO,
	ZIGBEE_RESPONSE_COMMISSIONING_BOUND_INFO,
	ZIGBEE_RESPONSE_IEEE_ADDR_RESP,
	ZIGBEE_RESPONSE_SIMPLE_DESC_RESP,
	ZIGBEE_RESPONSE_MATCH_DESC_RESP,
	ZIGBEE_RESPONSE_BASIC_RESET_TO_FACTORY,	/* < Received basic reset to factory defaults requesting */
	ZIGBEE_RESPONSE_LEVEL_CONTROL,
	ZIGBEE_RESPONSE_GET_NETWORK_TOPOLOGY,
	/* Raw reporting */
	ZIGBEE_RESPONSE_GENERAL_REPORT_ATTRIBUTE,
	ZIGBEE_RESPONSE_END_DEVICE_BIND,
	ZIGBEE_RESPONSE_IAS_ZONE_STATUS_CHANGED,
	ZIGBEE_RESPONSE_SERVER_TO_CLIENT_COMMAND_RECEIVED,
	ZIGBEE_RESPONSE_PARENT_ANNOUNCE,
	ZIGBEE_RESPONSE_DEVICE_ANNOUNCE,
	ZIGBEE_RESPONSE_OTA_REQUEST_RECEIVED,

	/* Common response none */
	ZIGBEE_RESPONSE_NONE = 3399
} zigbee_response_type;
/*!
 * \brief	Attribute change type
 */
typedef enum {
	ZIGBEE_ATTR_ONOFF_STATUS,
	ZIGBEE_ATTR_LEVELCONTROL_LEVEL,
	ZIGBEE_ATTR_COLOR_HUE,
	ZIGBEE_ATTR_COLOR_SATURATION,
	ZIGBEE_ATTR_COLOR_CURRENT_X,
	ZIGBEE_ATTR_COLOR_CURRENT_Y,
	ZIGBEE_ATTR_COLOR_TEMP,
	ZIGBEE_ATTR_FAN_MODE,
	ZIGBEE_ATTR_FAN_MODE_SEQUENCE,
	ZIGBEE_ATTR_OCCUPIED_HEATING_SETPOINT,
	ZIGBEE_ATTR_OCCUPIED_COOLING_SETPOINT,
	ZIGBEE_ATTR_SYSTEM_MODE,
	ZIGBEE_ATTR_CONTROL_SEQUENCE,
	/**
	 * Illuminance Measured value, in the range 1 to 65534(0xfffe), which
	 * corresponding to illuminance of 1 lx to 3.576 x 10^6 lx.
	 *
	 * MeasuredValue represents the Illuminance in Lux (symbol lx) as follows:
	 * MeasuredValue = 10,000 x log10 Illuminance + 1
	 *
	 * e.g. the Illuminance measured value 10001 means 10 lx.
	 *
	 * Refer to 'zigbee_illum_measured_value_to_lux' and
	 * 'zigbee_illum_lux_to_measured_value'
	 **/
	ZIGBEE_ATTR_ILLUMINANCE,	/* cls:0x0400, attr:0x0000 */
	/**
	* The LocalTemperature(Measure Temperature), in the range 0x954d to 0x7fff.
	*
	* LocalTemperature = 100 x temperature in degrees Celsius.
	* Where -273.15 Celsius <= temperature <= 327.67 Celsius, corresponding to a
	* LocalTemperature in the range 0x954d to 0x7fff.
	*
	* e.g. the LocalTemperature value 110 means 1.1 Celsius
	*
	* Refer to 'zigbee_temperature_to_celsius' and 'zigbee_celsius_to_temperature'.
	**/
	ZIGBEE_ATTR_TEMPERATURE,	/* cls:0x0402, attr:0x0000 */
	ZIGBEE_ATTR_OCCUPANCY,		/* cls:0x0406, attr:0x0000 */
	ZIGBEE_ATTR_THERMOSTAT_TEMPERATURE,	/* cls:0x0201, attr:0x0000 */
	ZIGBEE_ATTR_HUMIDITY,		/* cls:0x0405, attr:0x0000 */
	ZIGBEE_ATTR_NONE
} zigbee_attribute_type;
/*!
 * \brief	Selectable tx power level
 */
typedef enum {
	ZIGBEE_TX_POWER_8 = 8,
	ZIGBEE_TX_POWER_7 = 7,
	ZIGBEE_TX_POWER_6 = 6,
	ZIGBEE_TX_POWER_5 = 5,
	ZIGBEE_TX_POWER_4 = 4,
	ZIGBEE_TX_POWER_3 = 3,
	ZIGBEE_TX_POWER_2 = 2,
	ZIGBEE_TX_POWER_1 = 1,
	ZIGBEE_TX_POWER_0 = 0,
	ZIGBEE_TX_POWER_MINUS1 = -1,
	ZIGBEE_TX_POWER_MINUS2 = -2,
	ZIGBEE_TX_POWER_MINUS3 = -3,
	ZIGBEE_TX_POWER_MINUS4 = -4,
	ZIGBEE_TX_POWER_MINUS5 = -5,
	ZIGBEE_TX_POWER_MINUS6 = -6,
	ZIGBEE_TX_POWER_MINUS7 = -7,
	ZIGBEE_TX_POWER_MINUS8 = -8,
	ZIGBEE_TX_POWER_MINUS9 = -9,
	ZIGBEE_TX_POWER_MINUS11 = -11,
	ZIGBEE_TX_POWER_MINUS12 = -12,
	ZIGBEE_TX_POWER_MINUS14 = -14,
	ZIGBEE_TX_POWER_MINUS17 = -17,
	ZIGBEE_TX_POWER_MINUS20 = -20,
	ZIGBEE_TX_POWER_MINUS26 = -26,
	ZIGBEE_TX_POWER_MINUS43 = -43
} zigbee_tx_power;
/*!
 * \brief	Selectable channel
 */
typedef enum {
	ZIGBEE_CHANNEL_11 = 11,
	ZIGBEE_CHANNEL_12 = 12,
	ZIGBEE_CHANNEL_13 = 13,
	ZIGBEE_CHANNEL_14 = 14,
	ZIGBEE_CHANNEL_15 = 15,
	ZIGBEE_CHANNEL_16 = 16,
	ZIGBEE_CHANNEL_17 = 17,
	ZIGBEE_CHANNEL_18 = 18,
	ZIGBEE_CHANNEL_19 = 19,
	ZIGBEE_CHANNEL_20 = 20,
	ZIGBEE_CHANNEL_21 = 21,
	ZIGBEE_CHANNEL_22 = 22,
	ZIGBEE_CHANNEL_23 = 23,
	ZIGBEE_CHANNEL_24 = 24,
	ZIGBEE_CHANNEL_25 = 25,
	ZIGBEE_CHANNEL_26 = 26
} zigbee_channel;

/*!
 * \brief	Request for device attribute information reporting
 */
typedef enum {
	ZIGBEE_REPORTING_INVALID_MIN_VALUE = -1,
	/*
	 * The change_threshold should be in the range 0 ~ 60082
	 * */
	ZIGBEE_REPORTING_THERMOSTAT_TEMPERATURE,
	/*
	 * ZIGBEE_REPORTING_OCCUPANCY_SENSING for change_threshold parameter has
	 * no meaning, set change_threshold value to 0
	 * */
	ZIGBEE_REPORTING_OCCUPANCY_SENSING,
	/*
	 * The change_threshold should be in the range 0 ~ 65533
	 * */
	ZIGBEE_REPORTING_MEASURED_ILLUMINANCE,
	/*
	 * The change_threshold should be in the range 0 ~ 60082
	 * */
	ZIGBEE_REPORTING_MEASURED_TEMPERATURE,
	/*
	 * The change_threshold should be in the range 0 ~ 10000
	 * */
	ZIGBEE_REPORTING_MEASURED_HUMIDITY,
	ZIGBEE_REPORTING_INVALID_MAX_VALUE
} zigbee_reporting_type;

/*!
 * \brief Local endpoint
 */
typedef struct {
	ZIGBEE_PROFILE profile;
	int endpoint_id;
	ZIGBEE_DEVICEID device_id;
	ZIGBEE_DEVICE_VERSION device_version;
	GList *server_cluster;
	GList *client_cluster;
} zigbee_local_endpoint;
/*!
 * \brief Local endpoint information
 */
typedef struct {
	int count;
	zigbee_local_endpoint endpoints[MAX_ENDPOINT_SIZE];
} zigbee_local_endpoint_info;
/*!
 * \brief	Structure for endpoint information
 */
typedef struct {
	int endpoint_id;
	int node_id;
	ZIGBEE_DEVICEID device_id;
	int server_cluster[MAX_CLUSTER_SIZE];
	int client_cluster[MAX_CLUSTER_SIZE];
} zigbee_endpoint;
/*!
 * \brief	Structure for endpoint list to find endpoints by cluster ID
 */
typedef struct {
	int num;
	zigbee_endpoint endpoint[MAX_ENDPOINT_SIZE * MAX_DEVICE_INFO_SIZE];
} zigbee_endpoint_list;
/*!
 * \brief	Structure for device information
 *			This is used when sending cluster commands to select device
 */
typedef struct {
	char eui64[EUI64_SIZE];
	int node_id;
	int endpoint_count;
	zigbee_endpoint endpoint[MAX_ENDPOINT_SIZE];
} zigbee_device;
/*!
 * \brief	List of device information
 */
typedef struct {
	int num;
	zigbee_device device[MAX_DEVICE_INFO_SIZE];
} zigbee_device_info;
/*!
 * \brief	Device discovery response
 */
typedef struct {
	zigbee_device_discovery_status status;
	zigbee_device device;
} zigbee_device_discovery;
/*!
 * \brief	The relationship between the neighbor and the current device
 */
enum zigbee_node_relation {
	ZIGBEE_NODE_RELATION_TYPE_PARENT			= 0x00,
	ZIGBEE_NODE_RELATION_TYPE_CHILD				= 0x01,
	ZIGBEE_NODE_RELATION_TYPE_SIBLING			= 0x02,
	ZIGBEE_NODE_RELATION_TYPE_NONE				= 0x03,
	ZIGBEE_NODE_RELATION_TYPE_PREVIOUS_CHILD	= 0x04
};
/*!
 * \brief	An indication of whether the neighbor device is accepting join requests
 */
enum zigbee_permit_joining {
	ZIGBEE_PERMIT_JOINING_NOT_ACCEPTING	= 0x00,
	ZIGBEE_PERMIT_JOINING_ACCEPTING		= 0x01,
	ZIGBEE_PERMIT_JOINING_UNKNOWN		= 0x02
};
/*!
 * \brief	Indicates if neighbor's receiver is enabled during idle portions of the CAP
 */
enum zigbee_neighbor_rx_on_when_idle {
	ZIGBEE_NEIGHBOR_RX_ON_WHEN_RECEIVER_OFF		= 0x00,
	ZIGBEE_NEIGHBOR_RX_ON_WHEN_RECEIVER_ON		= 0x01,
	ZIGBEE_NEIGHBOR_RX_ON_WHEN_UNKNOWN			= 0x02
};
/*!
 * \brief	Structure for remote node neighbor information
 *			This is used when return remote node information
 */
struct zigbee_neighbor {
	/* The relationship between the neighbor and the current device */
	enum zigbee_node_relation relation;
	char eui64[EUI64_SIZE];
	ZIGBEE_NODE_ID node_id;
	zigbee_node_type node_type;
	enum zigbee_permit_joining permit_joining;
	/* Indicates if neighbor's receiver is enabled during idle portions of the CAP */
	enum zigbee_neighbor_rx_on_when_idle rx_on_when_idle;
	/* The tree depth of the neighbor device */
	uint8_t depth;
	/* The 64-bit extended PAN identifier of the neighboring device */
	char extended_pan_id[EXTEND_PAN_ID_SIZE];
	/* The estimated link quality for RF transmissions from this device */
	uint8_t lqi;
};
/*!
 * \brief	Structure for lqi table information
 *			This is used when return lqi table information
 */
struct zigbee_lqi_table_entry {
	ZIGBEE_NODE_ID node_id;
	/* Number of Neighbor Table entries included within parameter neighbor */
	int neighbor_count;
	/* Total number of Neighbor Table entries within the Remote Device */
	int neighbor_table_entries;
	/* Starting index within the Neighbor Table to begin reporting for the parameter neighbor */
	int start_index;
	struct zigbee_neighbor neighbor[MAX_NEIGHBOR_TABLE_LIST_COUNT];
};
/*!
 * \brief	Get network topology result
 */
enum zigbee_network_topology_status {
	ZIGBEE_NETWORK_TOPOLOGY_IN_PROGRESS,
	ZIGBEE_NETWORK_TOPOLOGY_FOUND,
	ZIGBEE_NETWORK_TOPOLOGY_UNKNOWN_ERROR,
	ZIGBEE_NETWORK_TOPOLOGY_DONE
};
/*!
 * \brief	Get network topology response
 */
struct zigbee_network_topology {
	enum zigbee_network_topology_status status;
	struct zigbee_lqi_table_entry topology_info;
};
/*!
 * \brief	ZigBee command sending type
 */
enum zigbee_sending_type {
	ZIGBEE_SENDING_BY_ENDPOINT	= 1024,
	ZIGBEE_SENDING_BY_BINDING	= 1025,
	ZIGBEE_SENDING_BY_GROUP		= 1026
};
/*!
 * \brief	ZigBee command sending information
 *			The varable of 'data' is used according to the sending type
 *			ZIGBEE_SENDING_BY_ENDPOINT	:	dest_endpoint
 *			ZIGBEE_SENDING_BY_BINDING	:	'data' is not used here, the in parameter local endpoint
 *											in the API calling is used, which should be configured
 *											in binding table.
 *			ZIGBEE_SENDING_BY_GROUP		:	group_id
 */
struct zigbee_sending_info {
	enum zigbee_sending_type type;
	union {
		/* It is used for unicast, actually target 'node_id' and 'endpoint_id' are used */
		zigbee_endpoint dest_endpoint;
		/* It is used for multicast */
		int group_id;
	} data;
};
/*!
 * \brief	Structure for network information
 */
typedef struct {
	zigbee_channel channel;
	zigbee_tx_power tx_power;
	int pan_id;         /* < in the range 0-0xFFFF */
} zigbee_network_info;
/*!
 * \brief	Network find result
 */
typedef struct {
	zigbee_network_find_status find_status;
	zigbee_network_info network_info;
} zigbee_network_find_result;
/*!
 * \brief	Structure for current node information.
 *			The node_type, node_id and network_info are included if the network_state
 *			is ZIGBEE_JOINED_NETWORK or ZIGBEE_JOINED_NETWORK_NO_PARENT.
 */
typedef struct {
	zigbee_network_state network_state;
	char eui64[EUI64_SIZE];
	zigbee_node_type node_type;
	int node_id;
	zigbee_network_info network_info;
} zigbee_node_info;
/*!
 * \brief	Received command from remote device
 */
typedef struct {
	bool is_global_command;
	int dest_endpoint_id;
	int cluster_id;
	int command_id;
	char payload[MAX_RECEIVED_COMMAND_PLAYLOAD_LENGTH];
	int payload_length;	/* -1 if buffer size isn't enough */
	int source_node_id;
	int source_endpoint_id;
} zigbee_received_command;
/*!
 * \brief	Attribute changed response from zigbeed
 */
typedef struct {
	zigbee_attribute_type type;
	int endpoint_id;
} zigbee_attribute_changed_response;
/*!
 * \brief	Attribute struct which includes attribute id and attribute type
 */
struct zigbee_attribute {
	ZIGBEE_ATTRIBUTE_ID id;
	zigbee_attribute_data_type type;
};
/*!
 * \brief	Discovery attributes response from zigbeed
 */
struct zigbee_discovery_attributes {
	ZIGBEE_CLUSTER_ID cluster;
	/**
	 * - true	indicates that there are no more attributes to be discovered
	 * - false	indicates that there are more attributes to be discovered
	 **/
	bool discovery_complete;
	int attribute_count;
	struct zigbee_attribute attributes[MAX_DISCOVER_ATTRITUTES];
};

/*!
 * \brief	A structure used to store reporting configurations. If endpoint
 *			field is ::EMBER_AF_PLUGIN_REPORTING_UNUSED_ENDPOINT_ID, this
 *			configure is unused.
 */
typedef struct {
	bool used;
	int endpoint_id;
	int cluster_id;
	int attribute_id;
	bool is_server;

	struct {
		/** The minimum reporting interval, measured in seconds. */
		uint16_t min_interval;
		/** The maximum reporting interval, measured in seconds. */
		uint16_t max_interval;
		/** The minimum change to the attribute that will result in a report
		 *  being sent.
		 */
		uint32_t reportable_change;
	} reported;
} zigbee_reporting_info;

/*!
 * \brief	Structure for reporting from remote server, it is used for
 *			ZIGBEE_RESPONSE_GENERAL_REPORT_ATTRIBUTE. This is raw reporting
 *			data, user should parse the 'data' all by himself.
 *			The parsing should consider the 'cluster_id', 'attribute_id',
 *			'data_type' and 'data_length'
 */
struct zigbee_general_report_attribute_info {
	ZIGBEE_CLUSTER_ID cluster_id;
	ZIGBEE_ATTRIBUTE_ID attribute_id;
	zigbee_attribute_data_type data_type;
	char data[MAX_ATTRIBUTE_SIZE];
	unsigned int data_length;
};

/*!
 * \brief	Structure for report attribute from remote server
 *			It is used for response ZIGBEE_RESPONSE_REPORT_ATTRIBUTE.
 *
 *			User can get the 'data.value' or 'data.occupancy' directly.
 *				- data.value:	ZIGBEE_ATTR_ILLUMINANCE
 *								ZIGBEE_ATTR_TEMPERATURE
 *								ZIGBEE_ATTR_THERMOSTAT_TEMPERATURE
 *				- data.occypancy:	ZIGBEE_ATTR_OCCUPANCY
 */
typedef struct {
	zigbee_attribute_type attribute_type;
	union {
		/**
		 * Measured Value, it is used by
		 *	- Illuminance Measrued Value
		 *	- Temperature Measured Value
		 *	- Thermoastat Local Temperature
		 **/
		int value;
		zigbee_occupancy_status occupancy;
	} data;
} zigbee_report_attribute_info;

/*!
 * \brief	A structure for notifying identify feedback.
 */
typedef struct {
	int endpoint_id;
	int duration;	/* in seconds */
} zigbee_identify_feedback_info;

/*!
* \brief	Structure of target that ezmode commissioning find
*			Used in callback, to notify user
 */
typedef struct {
	int node_id;
	int endpoint_id;
} zigbee_commissioning_target_info;

/*!
* \brief	Structure of clusters that bound by ezmode commissioning
*			Used in callback, to notify user
*/
typedef struct {
	int node_id;
	int cluster_id;
	int endpoint_id;
} zigbee_commissioning_bound_info;

/*!
* \brief	Commissioning state
*			Used in callback, to notify user
*/
typedef enum {
	COMMISSIONING_ERROR = 0x00,				/* < Commissioning error */
	COMMISSIONING_ERR_IN_PROGRESS,			/* < Commissioning in progress error */
	COMMISSIONING_NETWORK_STEERING_FORM,	/* < Try to form a new network if network join failed */
	COMMISSIONING_NETWORK_STEERING_SUCCESS,	/* < Network steering successfully */
	COMMISSIONING_NETWORK_STEERING_FAILED,	/* < Network steering failed */
	COMMISSIONING_WAIT_NETWORK_STEERING,	/* < Network steering is in progress, wait */
	COMMISSIONING_TARGET_SUCCESS,			/* < Commissioning target successfully */
	COMMISSIONING_TARGET_STOP,				/* < Commissioning target stopped */
	COMMISSIONING_TARGET_FAILED,			/* < Commissioning target failed */
	COMMISSIONING_INITIATOR_SUCCESS,		/* < Commissioning initiator successfully */
	COMMISSIONING_INITIATOR_STOP,			/* < Commissioning initiator stopped */
	COMMISSIONING_INITIATOR_FAILED			/* < Commissioning initiator failed */
} zigbee_commissioning_state;

/*!
* \brief	Simple descriptor
*			Used in API
*/
typedef struct {
	ZIGBEE_PROFILE profile_id;
	ZIGBEE_NODE_ID node_id;
	ZIGBEE_DEVICEID device_id;
	int endpoint_id;
	int server_cluster_count;
	int server_cluster[MAX_ZDO_CLUSTER_COUNT];
	int client_cluster_count;
	int client_cluster[MAX_ZDO_CLUSTER_COUNT];
} zigbee_simple_descriptor;

/*!
 * \brief	Frequency band of the node descriptor
 *			The frequency band field of the node descriptor is five bits in length and specifies the frequency
 *			bands that are supported by the underlying IEEE 802.15.4 radio utilized by the node.
 *			For each frequency band supported by the underlying IEEE 802.15.4 radio, the corresponding bit of
 *			the frequency band field, as listed below, shall be set to 1. All other bits shall be set to 0.
 *
 *			[Bit Number]	[Supported Fre-quency Band]
 *			0				868 - 868.6 MHz
 *			1				Reserved
 *			2				902 - 928 MHz
 *			3				2400 - 2483.5 MHz
 *			4				Reserved
 */
typedef unsigned char ZIGBEE_FREQUENCE_BAND;

/*!
 * \brief	MAC Capability Flags of the node descriptor
 *			The MAC capability flags field is eight bits in length and specifies the node capabilities,
 *			as required by the IEEE 802.15.4-2003 MAC sub-layer.
 *
 *			[Bits: 0] Alternate PAN coordinator
 *			The alternate PAN coordinator sub-field is one bit in length and shall be set to 1 if this
 *			node is capable of becoming a PAN coordinator. Otherwise, the alternative PAN coordinator
 *			sub-field shall be set to 0.
 *
 *			[Bits: 1] Device type
 *			The device type sub-field is one bit in length and shall be set to 1 if this node is a full
 *			function device (FFD). Otherwise, the device type sub-field shall be set to 0, indicating
 *			a reduced function device (RFD).
 *
 *			[Bits: 2] Power source
 *			The power source sub-field is one bit in length and shall be set to 1 if the current power
 *			source is mains power. Otherwise, the power source sub-field shall be set to 0. This
 *			information is derived from the node current power source field of the node power descriptor.
 *
 *			[Bits: 3] Receiver on when idle
 *			The receiver on when idle sub-field is one bit in length and shall be set to 1 if the device
 *			does not disable its receiver to conserve power during idle periods. Otherwise, the receiver
 *			on when idle sub-field shall be set to 0
 *
 *			[Bits: 4-5] Reserved
 *
 *			[Bits: 6] Security capability
 *			The security capability sub-field is one bit in length and shall be set to 1 if the device is
 *			capable of sending and receiving frames secured using the security suite specified. Otherwise,
 *			the security capability sub-field shall be set to 0.
 *
 *			[Bits: 7] Allocate address
 *			The allocate address sub-field is one bit in length and shall be set to 0 or 1.
 */
typedef unsigned char ZIGBEE_MAC_CAPABILITY;

/*!
 * \brief	Descriptor Capability of the node descriptor
 *			The descriptor capability field of the node descriptor is eight bits in length, with bit
 *			settings signifying the descriptor capabilities of this node. It is used to facilitate
 *			discovery of particular features of the descriptor fields by other nodes on the system.
 *
 *			[Bits: 0] Extended Active Endpoint List Available
 *
 *			[Bits: 1] Extended Simple Descriptor List Available
 *
 *			[Bits: 2-7] Reserved
 */
typedef unsigned char ZIGBEE_DESCRIPTOR_CAPABILITY;

/*!
 * \brief	Server Mask field of the node descriptor
 *			The server mask field of the node descriptor is sixteen bits in length, with bit settings
 *			signifying the system server capabilities of this node. It is used to facilitate discovery
 *			of particular system servers by other nodes on the system.
 *
 *			[Bits: 0] Primary Trust Center
 *
 *			[Bits: 1] Backup Trust Center
 *
 *			[Bits: 2] Primary Binding Table Cache
 *
 *			[Bits: 3] Backup Binding Table Cache
 *
 *			[Bits: 4] Primary Discovery Cache
 *
 *			[Bits: 5] Backup Discovery Cache
 *
 *			[Bits: 6] Network Manager
 *
 *			[Bits: 7-8] Reserved
 *
 *			[Bits: 9-15] Stack Compliance Revision
 *			These bits indicate the revision of the ZigBee Pro Core specification that the running stack
 *			is implemnted to. Prior to revision 21 of the specification these bits were reserved and thus
 *			set to 0. A stack that is compliant to revision 21 would set these bits to 21 (0010101b).
 *			A stack shall indicate the revision of the specification it is compliant to by setting these bits.
 */
typedef unsigned short ZIGBEE_SERVER_MASK;

/*!
 * \brief	Node descriptor
 *			The node descriptor contains information about the capabilities of the ZigBee node and is mandatory
 *			for each node. There shall be only one node descriptor in a node.
 */
typedef struct {
	ZIGBEE_NODE_ID node_id;
	zigbee_node_type node_type;			/* < device type of the ZigBee node */
	bool complex_descriptor_available;	/* < whether a complex descriptor is available on this device */
	bool user_descriptor_available;		/* < whether a user descriptor is available on this device */
	uint16_t manufacturer_code;			/* < specifies a manufacturer code that is allocated by the ZigBee Alliance */
	ZIGBEE_FREQUENCE_BAND frequency_band;
	ZIGBEE_MAC_CAPABILITY mac_capability;
	ZIGBEE_DESCRIPTOR_CAPABILITY descriptor_capability;
	ZIGBEE_SERVER_MASK server_mask;
	/**
	 * The APS flags field of the node descriptor is three bits in length and specifies the application support
	 * sub-layer capabilities of the node. This field is currently not supported.
	 */
	uint8_t aps_flags;
	/**
	 * The maximum buffer size field with a valid range of 0x00-0x7f. This field specifies the maximum size,
	 * in octets of the network sub-layer data unit (NSDU) for this node. This is the maximum size of data or
	 * commands passed to or from the application by the application support sub-layer, before any
	 * fragmentation or re-assembly.
	 *
	 * This field can be used as a high-level indication for network management.
	 */
	uint8_t max_buffer_size;
	/**
	 * The maximum transfer size field of the node descriptor with a valid range of 0x0000-0x7fff. This field
	 * specifies the maximum size, in octets, of the application sub-layer data unit (ASDU) that can be
	 * transferred to this node in one single message transfer. This value can exceed the value of the node
	 * maximum buffer size field through the use of fragmentation.
	 */
	uint16_t max_incoming_transfer_size;
	/**
	 * The maximum transfer size field of the node descriptor with a valid range of 0x0000-0x7fff. This field
	 * specifies the maximum size, in octets, of the application sub-layer data unit (ASDU) that can be
	 * transferred from this node in one single message transfer. This value can exceed the value of the node
	 * maximum buffer size field through the use of fragmentation.
	 */
	uint16_t max_outgoing_transfer_size;
} zigbee_node_descriptor;

/*!
 * \brief	Power mode
 *			The current power mode field of the node power descriptor specifies the current sleep/power-saving
 *			mode of the node. The current power mode field shall be set to one of the non-reserved values listed.
 */
typedef enum {
	/**
	 * Receiver synchronized with the receiver on when idle subfield of the node descriptor.
	 */
	POWER_MODE_SYNCHRONIZED_WHEN_IDLE	=	0x00,
	/**
	 * Receiver comes on periodically as defined by the node power descriptor.
	 */
	POWER_MODE_COMES_ON_PERIODICALLY	=	0x01,
	/**
	 * Receiver comes on when stimulated, for example, by a user pressing a button.
	 */
	POWER_MODE_COMES_ON_WHEN_STIMULATED	=	0x02,
	POWER_MODE_RESERVED
} zigbee_power_mode;

/*!
 * \brief	Power source level
 *			The current power source level field of the node power descriptor specifies the level of charge
 *			of the power source. The current power source level field shall be set to one of the non-reserved
 *			values listed.
 */
typedef enum {
	POWER_SOURCE_LEVEL_CRITICAL	=	0x00,	/* < Charge Level Critical */
	POWER_SOURCE_LEVEL_33		=	0x04,	/* < Charge Level 33% */
	POWER_SOURCE_LEVEL_66		=	0x08,	/* < Charge Level 66% */
	POWER_SOURCE_LEVEL_100		=	0x0C,	/* < Charge Level 100% */
	POWER_SOURCE_LEVEL_RESERVED				/* < Charge Level Reserved */
} zigbee_power_source_level;

/*!
 * \brief	Power descriptor
 */
typedef struct {
	ZIGBEE_NODE_ID node_id;
	zigbee_power_mode current_power_mode;
	zigbee_power_source_level current_power_source_level;
	/**
	 * The available power sources field of the node power descriptor is four bits in length and specifies the
	 * power sources available on this node. For each power source supported on this node, the corresponding bit
	 * of the available power sources field, as listed below, shall be set to 1. All other bits shall be set to 0.
	 *
	 * [Available Power Sources Field Bit Number]	[Supported Power Source]
	 * 0											Constant (mains) power
	 * 1											Rechargeable battery
	 * 2											Disposable battery
	 * 3											Reserved
	 */
	uint8_t available_power_sources;
	/**
	 * The current power source field of the node power descriptor is four bits in length and specifies the current
	 * power source being utilized by the node. For the current power source selected, the corresponding bit of the
	 * current power source field refer to available power sources.
	 */
	uint8_t current_power_source;
} zigbee_power_descriptor;

/*!
* \brief	Simple descriptor response
*			Used in callback, to notify user
*/
typedef struct {
	zigbee_service_discovery_result result;
	int target_node_id;
	int target_endpoint;
	int server_cluster_count;
	int server_cluster[MAX_CLUSTER_SIZE];
	int client_cluster_count;
	int client_cluster[MAX_CLUSTER_SIZE];
} zigbee_simple_descriptor_response;

/*!
* \brief	Active endpoints
*/
typedef struct {
	ZIGBEE_NODE_ID node_id;
	uint8_t count;
	ZIGBEE_ENDPOINT_ID endpoint_ids[MAX_ACTIVE_ENDPOINT_COUNT];
} zigbee_active_endpoints;

/*!
* \brief	Broadcast identify query response
*			Used in callback, to notify user
*/
typedef struct {
	int node_id;
	int endpoint_id;
	int timeout;
} zigbee_broadcast_identify_query_response;
/*!
 * \brief	Structure for device announce
 */
typedef struct {
	ZIGBEE_NODE_ID node_id;
	char ieee_addr[EUI64_SIZE];
	ZIGBEE_MAC_CAPABILITY mac_capability;
} zigbee_device_annce_info;
/*!
 * \brief The child information.
 */
typedef struct {
	/* The IEEE address of the child bound to the parent */
	char ieee_address[EUI64_SIZE];
} zigbee_child_information;

/*!
 * \brief	parent announce response(Parent_annce_rsp)
 *			This response is for ZigBee routers (including the coordinator) on the network to construct
 *			all the end devices known to the local device, then notify other ZigBee routers.
 *			Used in callback, to notify user
 */
typedef struct {
	/* The received message is request or response */
	bool request;
	/* The received message response status */
	int status;
	ZIGBEE_NODE_ID node_id;
	/* The number of ChildInfo structures contained in the message */
	int children_number;
	/* The child information */
	zigbee_child_information child_info[MAX_CHILDREN_NUMBER];
} zigbee_parent_annce_info;

/*!
* \brief	Ieee addr response
*			Used in callback, to notify user
*/
typedef struct {
	zigbee_service_discovery_result result;
	int node_id;
	char eui64[EUI64_SIZE];
} zigbee_ieee_addr_response;

/*!
* \brief	Match descriptor response
*			Used in callback, to notify user
*/
typedef struct {
	zigbee_service_discovery_result result;
	int node_id;
	int endpoint_list[MAX_ENDPOINT_SIZE];
	int count;
} zigbee_match_desc_response;

/*!
* \brief	ZigBee Device Object (ZDO) response status.
*
*			Most responses to ZDO commands contain a status byte.
*			The meaning of this byte is defined by the ZigBee Device Profile.
*/
typedef enum {
	/* These values are taken from Table 48 of ZDP Errata 043238r003 and Table 2 */
	/* of NWK 02130r10. */
	ZIGBEE_ZDP_SUCCESS = 0x00,
	/* 0x01 to 0x7F are reserved */
	ZIGBEE_ZDP_INVALID_REQUEST_TYPE = 0x80,
	ZIGBEE_ZDP_DEVICE_NOT_FOUND = 0x81,
	ZIGBEE_ZDP_INVALID_ENDPOINT = 0x82,
	ZIGBEE_ZDP_NOT_ACTIVE = 0x83,
	ZIGBEE_ZDP_NOT_SUPPORTED = 0x84,
	ZIGBEE_ZDP_TIMEOUT = 0x85,
	ZIGBEE_ZDP_NO_MATCH = 0x86,
	/* 0x87 is reserved            = 0x87, */
	ZIGBEE_ZDP_NO_ENTRY = 0x88,
	ZIGBEE_ZDP_NO_DESCRIPTOR = 0x89,
	ZIGBEE_ZDP_INSUFFICIENT_SPACE = 0x8a,
	ZIGBEE_ZDP_NOT_PERMITTED = 0x8b,
	ZIGBEE_ZDP_TABLE_FULL = 0x8c,
	ZIGBEE_ZDP_NOT_AUTHORIZED = 0x8d,

	ZIGBEE_NWK_ALREADY_PRESENT = 0xC5,
	ZIGBEE_NWK_TABLE_FULL = 0xC7,
	ZIGBEE_NWK_UNKNOWN_DEVICE = 0xC8
} zigbee_zdo_response_status;

typedef enum {
	/* A binding that is currently not in use. */
	ZIGBEE_UNUSED_BINDING	 = 0,
	/* A unicast binding whose 64-bit identifier is the destination EUI64. */
	ZIGBEE_UNICAST_BINDING	 = 1,
	/* A unicast binding whose 64-bit identifier is the many-to-one
	 * destination EUI64.  Route discovery should be disabled when sending
	 * unicasts via many-to-one bindings.
	 */
	ZIGBEE_MANY_TO_ONE_BINDING	 = 2,
	/* A multicast binding whose 64-bit identifier is the group address. A
	 * multicast binding can be used to send messages to the group and to receive
	 * messages sent to the group.
	 */
	ZIGBEE_MULTICAST_BINDING	 = 3
} zigbee_binding_type;

/*!
* \brief Zigbee binding table entry
*/
typedef struct {
	/* The type of binding. */
	zigbee_binding_type type;
	/*The endpoint on the local node.*/
	int local;
	/* A cluster ID that matches one from the local endpoint's simple descriptor.
	 * This cluster ID is set by the provisioning application to indicate which
	 * part an endpoint's functionality is bound to this particular remote node
	 * and is used to distinguish between unicast and multicast bindings. Note
	 * that a binding can be used to to send messages with any cluster ID, not
	 * just that listed in the binding.
	 */
	int cluster_id;
	/* The endpoint on the remote node (specified by \c identifier).*/
	int remote;
	/* A 64-bit identifier.  This is either:
	 * - The destination EUI64, for unicasts
	 * - A 16-bit multicast group address, for multicasts
	 */
	char identifier[EUI64_SIZE];
	/* The index of the network the binding belongs to.*/
	int network_index;
} zigbee_binding_table_entry;

/*!
 * \brief Zigbee routing table entry
 */
struct zigbee_routing_table_entry {
	/* The 16-bit network ad-dress of this route */
	ZIGBEE_NODE_ID destination_address;

	/* This entry's status
	 * 0x0=ACTIVE.
	 * 0x1=DISCOVERY_UNDERWAY.
	 * 0x2=DISCOVERY_FAILED.
	 * 0x3=INACTIVE.
	 * 0x4=VALIDATION_UNDERWAY
	 * 0x5-0x7=RESERVED.
	 */
	uint8_t status:3;

	/* A flag indicating whether the device is a memory constrained concentrator */
	uint8_t memory_constrained:1;

	/* A flag indicating that the destination is a con-centrator that issued a many-to-one request */
	uint8_t many_to_one:1;

	/* A flag indicating that a route record command frame should be
	 * sent to the destination prior to the next data packet
	 */
	uint8_t route_record_required:1;
	uint8_t reserved:2;

	/* The 16-bit network ad-dress of the next hop on the way to the destination */
	ZIGBEE_NODE_ID next_hop_address;
};

/*!
 * \brief Zigbee routing table list, the response of routing table request
 */
struct zigbee_routing_table_list {
	/* Total number of Routing Table entries within the Remote Device */
	uint8_t total_num;

	/* Starting index within the Routing Table to begin reporting for the RoutingTable-List */
	uint8_t start_index;

	/* Number of Routing Table entries in-cluded within RoutingTableList */
	uint8_t count;
	struct zigbee_routing_table_entry entries[MAX_ROUTING_TABLE_COUNT];
};

struct zigbee_binding_table_entry {
	/* The source IEEE address for the binding entry */
	char src_addr[EUI64_SIZE];
	/* The source endpoint for the binding entry */
	ZIGBEE_ENDPOINT_ID src_endpoint;
	/* The identifier of the cluster on the source device that is bound to the destination device */
	ZIGBEE_CLUSTER_ID cluster_id;
	/* The addressing mode for the destination address */
	/* 0x00 = reserved
	 * 0x01 = 16-bit group address for DstAddr and DstEndpoint not present
	 * 0x02 = reserved
	 * 0x03 = 64-bit extended address for DstAddr and DstEndp present
	 * 0x04 - 0xff = reserved
	 */
	uint8_t dst_addr_mode;
	/* The destination address for the binding entry */
	uint8_t dst_addr[EUI64_SIZE];
	ZIGBEE_ENDPOINT_ID dst_endpoint;
};

struct zigbee_binding_table_list {
	/* Total number of Binding Table entries within the Remote Device */
	uint8_t binding_table_entries;
	/* Starting index within the Binding Table to begin reporting for the BindingTableList */
	uint8_t start_index;
	/* Number of Binding Table entries included within BindingTableList */
	uint8_t binding_table_list_count;
	/* A list of descriptors for the Remote Device's Binding Table */
	struct zigbee_binding_table_entry entries[MAX_BINDING_TABLE_COUNT];
};

/*!
* \brief	IAS Zone Type
*
* The Zone Type dictates the meaning of Alarm1 and Alarm2 bits of the ZoneStatus
* attribute, see ZIGBEE_IAS_ZONE_STATUS.
*/
enum zigbee_ias_zone_type {
	/* Alarm1 - System Alarm
	 * Alarm2 - N/A
	 */
	ZIGBEE_IAS_ZONE_TYPE_STANDARD_CIE				= 0x0000,
	/* Alarm1 - Intrusion indication
	 * Alarm2 - Presence indication
	 */
	ZIGBEE_IAS_ZONE_TYPE_MOTION_SENSOR				= 0x000D,
	/* Alarm1 - 1st portal Open-Close
	 * Alarm2 - 2nd portal Open-Close
	 */
	ZIGBEE_IAS_ZONE_TYPE_CONTACT_SWITCH				= 0x0015,
	/* Alarm1 - Fire indication
	 * Alarm2 - N/A
	 */
	ZIGBEE_IAS_ZONE_TYPE_FIRE_SENSOR				= 0x0028,
	/* Alarm1 - Water overflow indication
	 * Alarm2 - N/A
	 */
	ZIGBEE_IAS_ZONE_TYPE_WATER_SENSOR				= 0x002A,
	/* Alarm1 - Carbon Monoxide(CO) indication
	 * Alarm2 - Cooking indication
	 */
	ZIGBEE_IAS_ZONE_TYPE_GAS_SENSOR					= 0x002B,
	/* Alarm1 - Fall/Concussion
	 * Alarm2 - Emergency button
	 */
	ZIGBEE_IAS_ZONE_TYPE_PERSONAL_EMERGENCY_DEVICE	= 0x002C,
	/* Alarm1 - Movement indication
	 * Alarm2 - Vibration
	 */
	ZIGBEE_IAS_ZONE_TYPE_VIBRATION_MOVEMENT_SENSOR	= 0x002D,
	/* Alarm1 - Panic
	 * Alarm2 - Emergency
	 */
	ZIGBEE_IAS_ZONE_TYPE_REMOTE_CONTROL				= 0x010F,
	/* Alarm1 - Panic
	 * Alarm2 - Emergency
	 */
	ZIGBEE_IAS_ZONE_TYPE_KEY_FOB					= 0x0115,
	/* Alarm1 - Panic
	 * Alarm2 - Emergency
	 */
	ZIGBEE_IAS_ZONE_TYPE_KEYPAD						= 0x021D,
	/* EN 50131 European Standards Series for Intruder Alarm Systems.
	 *
	 * Alarm1 - N/A
	 * Alarm2 - N/A
	 */
	ZIGBEE_IAS_ZONE_TYPE_STANDARD_WARNING_DEVICE	= 0x0225,
	/* Alarm1 - Glass breakage detected
	 * Alarm2 - N/A
	 */
	ZIGBEE_IAS_ZONE_TYPE_GLASS_BREAK_SENSOR			= 0x0226,
	/* A ZigBee repeater for security devices that needs to be supervised by
	 * the alarm panel/ IAS CIE to ensure a reliable security sensor network.
	 *
	 * Alarm1 - N/A
	 * Alarm2 - N/A
	 */
	ZIGBEE_IAS_ZONE_TYPE_SECURITY_REPEATER			= 0x0229,
	ZIGBEE_IAS_ZONE_TYPE_INVALID_ZONE_TYPE			= 0xFFFF
};

/*!
* \brief IAS Zone Status Change Notification
*
* It is sent in IAS Zone server cluster side and received in IAS Zone client
* cluster side when a change takes place in one or more bits of the Zone
* Status attribute.
*/
struct zigbee_ias_zone_status_changed_notification {
	/* The source node which reports this change */
	int node_id;
	/* It is the current value of the ZoneStatus attribute */
	ZIGBEE_IAS_ZONE_STATUS zone_status;
	/* It is reserved for additional status information and shall be set to zero */
	uint8_t extended_status;
	/* Zone ID is the index of the Zone in the CIE's zone table */
	uint8_t zone_id;
	/* The Delay is defined as the amount of time, in quarter-seconds, from
	 * the moment when a change takes place in one or more bits of the Zone
	 * Status attribute and the successful transmission of the Zone Status
	 * Change Notification. */
	uint16_t delay;
};

/**
 * @deprecated	This type is deprecated and will be removed, it is
 *				replaced by endpoint id(int type).
 *
 * @brief	endpoint instance
 */
typedef void *zigbee_endpoint_handle;

/**
 * @deprecated	This struct is deprecated and will be removed, it is
 *				replaced by zigbee_local_endpoint.
 *
 * @brief	Used to store endpoint info, get this info by
 *			get_device_info_by_handle()
 * @see		get_device_info_by_handle
 */
struct inner_endpoint_info {
	int endpoint_id;
	ZIGBEE_PROFILE profile;
	ZIGBEE_DEVICEID device_id;
	unsigned char version;
};

#ifdef __cplusplus
}
#endif
#endif				/* __ZIGBEE_DEF_H__ */
