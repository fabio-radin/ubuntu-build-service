/*
 * Copyright (c) 2016 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the License);
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __ZIGBEE_H
#define __ZIGBEE_H

/**
 * @defgroup	zigbee ZigBee
 * @brief		Artik ZigBee API
 *
 * This module includes ZigBee API.
 * @{
 */

#include <glib.h>
#include <zigbee_def.h>
#include <zigbee_clusters.h>
#include <zigbee_attributes.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief		logging backend system
 */
enum zigbee_log_system {
	ZIGBEE_LOG_SYSTEM_STDERR,	/**< Standard error */
	ZIGBEE_LOG_SYSTEM_SYSLOG,	/**< syslog */
	ZIGBEE_LOG_SYSTEM_NONE,		/**< no log */
	ZIGBEE_LOG_SYSTEM_CUSTOM	/**< use custom log handler */
};

/**
 * @brief		Callback function type
 */
typedef void(*zigbee_client_callback)(void *user_data,
									  zigbee_response_type response_type,
									  void *payload);

/**
 * @brief		Add local endpoint to GList
 *
 * @param [in]	endpoint_info	The local endpoints to be added
 * @param [in]	endpoint_list		The GList to add to
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_add_local_endpoint(zigbee_local_endpoint *endpoint, GList **endpoint_list);

/**
 * @brief		Set local endpoints, they are saved locally and used to create
 *				device when initialize() is called.
 *				In GList is structure zigbee_local_endpoint.
 *
 * @param [in]	endpoint_info	The local endpoints to be saved
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_set_local_endpoints(GList *endpoint_info);

/**
 * @brief		Get local endpoints which are saved locally.
 *				In GList is structure zigbee_local_endpoint.
 *
 * @param [out]	endpoint_info	The local endpoints to be returned
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_get_local_endpoints(const GList **endpoint_info);

/**
 * @brief		Free GList endpoint list
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_free_local_endpoint(GList *endpoint_list);

/**
 * @brief		Initialize zigbee module
 * @param [in]	callback	User callback function for receiving,
 *							such a command results, it can be NULL.
 * @param [in]	user_data	Send user data, it can be NULL.
 * @return		 Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_initialize(zigbee_client_callback app_callback, void *user_data);

/**
 * @brief		Deinitialize, release the data allocated in artik-sdk
 */
void zigbee_deinitialize(void);

/**
 * @brief		Construct a raw zigbee command frame and send out, only for specific cluster
 *				command, not for global command. Every field should be filled according to
 *				ZCL specification including cluster id, command id and its payload.
 *
 * @param [in]	sending_info		Command sending information, including sending type,
 *									source or destination information, etc.
 * @param [in]	manufacturer_code	16 bits manufacturer code, it is not used if it is set to 0x0000.
 * @param [in]	client_to_server	Indicate the direction of this command.
 * @param [in]	cluster_id			The cluster id.
 *									0x0000 - 0x7fff: Standard ZigBee cluster identifier.
 *									0xfc00 - 0xffff: Manufacturer Specific cluster identifier.
 * @param [in]	command_id			The command id.
 *									0x00 - 0x7f: Standard ZigBee command or Manufacture Specific command.
 * @param [in]	payload				The payload.
 * @param [in]	local_endpoint		Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_zcl_raw_command(const struct zigbee_sending_info *sending_info,
						   uint16_t manufacturer_code, bool client_to_server,
						   uint16_t cluster_id, uint8_t command_id,
						   const struct zigbee_raw_data_payload *payload,
						   int local_endpoint);

/**
 * @brief		Form a new network as a coordinator.
 *
 * This begins a search for an unused Channel and Pan Id.
 * Then this will automatically form a network on the first unused Channel
 * and Pan Id it finds.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 * Callback function is called for notifying the result.
 * -Response type : ZIGBEE_RESPONSE_NETWORK_NOTIFICATION
 * -Response payload : pointer of zigbee_network_notification
 *						ZIGBEE_NETWORK_FIND_FORM_SUCCESS (succeeded)
 *						ZIGBEE_NETWORK_FIND_FORM_FAILED (failed)
 */
int zigbee_network_form(void);

/**
 * @brief		Form a new network as a coordinator
 *
 * @param [in]	network_info	Network information for forming network
 *								including channel, tx power, pan ID
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_network_form_manually(const zigbee_network_info *network_info);

/**
 * @brief		Permit joining to the formed network from other nodes
 *
 * @param [in]	duration	Second value to permit joining, 0xff is unlimited
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_network_permitjoin(int duration_sec);

/**
 * @brief		Leave from the joined network
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_network_leave(void);

/**
 * @brief		Join to the existing network by other coordinator automatically.

 * Begins a search for a joinable network.
 * Will automatically join to the first found network.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 * Callback function is called for notifying the result.
 * -Response type : ZIGBEE_RESPONSE_NETWORK_NOTIFICATION
 * -Response payload : pointer of zigbee_network_notification
 *						ZIGBEE_NETWORK_FIND_JOIN_SUCCESS (succeeded)
 *						ZIGBEE_NETWORK_FIND_JOIN_FAILED (failed)
 */
int zigbee_network_join(void);

/**
 * @brief		Stop the network scanning.
 *				When 'network form', 'network join' and 'network find' are
 *				called, network scanning is conducted in zigbeed side, this
 *				api is provided to stop network scanning.
 *
 * @return		Result of operation, EZ_OK when succeeded, otherwise failed.
 */
int zigbee_network_stop_scan(void);

/**
 * @brief		Join to the formed network by other coordinator
 *
 * @param [in]	network_info	Network information for forming network
 *								including channel, tx power, pan ID
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_network_join_manually(const zigbee_network_info *network_info);

/**
 * @brief		Scan existing networks
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 * Callback function is called for notifying the result.
 * -Response type : ZIGBEE_RESPONSE_NETWORK_FIND
 * -Response payload : pointer of struct zigbee_network_find_result
 */
int zigbee_network_find(void);

/**
 * @brief		Get current node information.
 *
 * @param[out]	node_info	The node information to be returned.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_get_node_info(zigbee_node_info *node_info);

/**
 * @brief		Get endpoint information by endpoint_id
 *
 * @param [out]	endpoint		The endpoint information to be returned.
 * @param [in]	endpoint_id		the endpoint id to be checked
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_get_local_endpoint_by_endpointid(zigbee_local_endpoint *endpoint,
											int endpoint_id);

/**
 * @brief		Check if local endpoint contains the server/client cluster
 *
 * @param [in]	endpoint_id	The local endpoint id to be checked
 * @param [in]	cluster_id	The cluster id defined in zigbee_def.h
 * @param [in]	is_server	Server cluster or client cluster,
 *							true for server, false for client.
 *
 * @return		Result of operation, EZ_OK on contains, error code otherwise.
 */
int zigbee_local_endpoint_contains_cluster(int endpoint_id,
										   int cluster_id,
										   bool is_server);

/**
 * @brief		Request device/service discovery
 *				Device/service discovery is a cyclic call, for the cyclic
 *				duration setting, please check api 'set_discover_cycle_time'.
 *				If current api 'device_discover' is called, the discovery is
 *				triggered immediately.
 *
 * @return		Result of operation, EZ_OK when succeeded
 *
 * The result will be delivered through callback function.
 * Callback function is called for notifying the result.
 * -Response type : ZIGBEE_RESPONSE_DEVICE_DISCOVER
 * -Response payload : pointer of zigbee_device_discovery.
 *					zigbee_device_discovery_status will be sent in
 *					different phases.
 *					Initialization phase:
 *						ZIGBEE_DEVICE_DISCOVERY_START,
 *						ZIGBEE_DEVICE_DISCOVERY_IN_PROGRESS.
 *					Discovery phase:
 *						ZIGBEE_DEVICE_DISCOVERY_FOUND,
 *						ZIGBEE_DEVICE_DISCOVERY_ERROR.
 *					Complete phase:
 *						ZIGBEE_DEVICE_DISCOVERY_DONE,
 *						ZIGBEE_DEVICE_DISCOVERY_NO_DEVICE.
 */
int zigbee_device_discover(void);

/**
 * @brief		Get device info from zigbee daemon
 *
 * @param[out]	device_info	the memory pointer for return device info list.
 * @return		Result of operation, EZ_OK when succeeded, EZ_NOT_FOUND
 *
 *				when no discovered device info returned, otherwise failed.
 */
int zigbee_get_discovered_device_list(zigbee_device_info *device_info);

/**
 * @brief		Find endpoint list to filtered by cluster ID and SERVER/CLIENT
 *
 * @param [out]	endpoints	Endpoint list that are matched by other parameters
 * @param [in]	cluster_id	Cluster ID that is defined in artik-cluster-id.h
 * @param [in]	is_server	1 for SERVER, 0 for CLIENT
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_device_find_by_cluster(zigbee_endpoint_list *endpoints,
								  int cluster_id, int is_server);

/**
 * @brief		Set the cyclic duaration of device discovery cycle
 *
 * @param[in]	cycle_duration	The cyclic duaration, in minutes, in the range 0~60,
 *								positive value. The default cyclic duration is 1 minute.
 *								If the value is equal to 0 , the loop timer is stopped.
 *
 * @return		Result of operation, EZ_OK when succeeded
 */
int zigbee_set_discover_cycle_time(unsigned int cycle_duration);

/* ezmode commissioning */
/**
 * @brief		Do ezmode commissioning procedure.
 *				Firstly do network steering.
 *				Secondly do find and bind target start, see zigbee_find_bind_target_start.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 * [Commissioning result in target side]
 *	-Response type : ZIGBEE_RESPONSE_COMMISSIONING_STATUS
 *	-Response payload : pointer of zigbee_commissioning_state
 */
int zigbee_ezmode_commissioning_target_start(int local_endpoint);

/* ezmode commissioning */
/**
 * @brief		Do ezmode commissioning procedure.
 *				Firstly do network steering.
 *				Secondly do find and bind initiator start, see zigbee_find_bind_initiator_start.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 * [Commissioning result in initiator side]
 *	-Response type : ZIGBEE_RESPONSE_COMMISSIONING_STATUS
 *	-Response payload : pointer of zigbee_commissioning_state
 *
 *	[Target information in initiator side]
 *	-Response type : ZIGBEE_RESPONSE_COMMISSIONING_TARGET_INFO
 *	-Response payload : pointer of zigbee_commissioning_target_info
 *
 *	[Bind information in initiator side]
 *	-Response type : ZIGBEE_RESPONSE_COMMISSIONING_TARGET_INFO
 *	-Response payload : pointer of zigbee_commissioning_target_info
 */
int zigbee_ezmode_commissioning_initiator_start(int local_endpoint);

/**
 * @brief		Check if the device supports commissioning or not
 *
 * @param[in] device_id	The device id to be checked
 * @param[in] initiator	Check to support initiator or target.
 *						true for checking initiator supported,
 *						false for checking target supported.
 *
 * @return		Result of operation, EZ_OK for supported, EZ_NOT_SUPPORTED for
 *				not supported, error code otherwise.
 */
int zigbee_check_commissioning_support(const ZIGBEE_DEVICEID device_id,
									   bool initiator);

/* network steering */
/**
 * @brief		Do network steering
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 * Callback function is called for notifying the result.
 * -Response type : ZIGBEE_RESPONSE_COMMISSIONING_STATUS
 * -Response payload : pointer of zigbee_commissioning_state including
 *						COMMISSIONING_ERROR
 *						COMMISSIONING_ERR_IN_PROGRESS
 *						COMMISSIONING_NETWORK_STEERING_FORM
 *						COMMISSIONING_NETWORK_STEERING_SUCCESS
 *						COMMISSIONING_NETWORK_STEERING_FAILED
 *						COMMISSIONING_WAIT_NETWORK_STEERING
 */
int zigbee_network_steering(void);

/* finding and binding */
/**
 * @brief		Do finding and binding target process, which enable the target
 *				side can be bound to by the initiator side during the minimum
 *				identify time(3 minutes).
 *
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 *	[Commissioning result in target side]
 *	-Response type : ZIGBEE_RESPONSE_COMMISSIONING_STATUS
 *	-Response payload : pointer of zigbee_commissioning_state
 */
int zigbee_find_bind_target_start(int local_endpoint);

/* finding and binding */
/**
 * @brief		Do finding and binding initiator procedure, bind to the target
 *				side which is in the same network.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 *	[Commissioning result in initiator side]
 *	-Response type : ZIGBEE_RESPONSE_COMMISSIONING_STATUS
 *	-Response payload : pointer of zigbee_commissioning_state
 *
 *	[Target information in initiator side]
 *	-Response type : ZIGBEE_RESPONSE_COMMISSIONING_TARGET_INFO
 *	-Response payload : pointer of zigbee_commissioning_target_info
 *
 *	[Bind information in initiator side]
 *	-Response type : ZIGBEE_RESPONSE_COMMISSIONING_TARGET_INFO
 *	-Response payload : pointer of zigbee_commissioning_target_info
 */
int zigbee_find_bind_initiator_start(int local_endpoint);

/* broadcast permit joiin */
/**
 * @brief		Do broadcast permit join.
 *
 * @param [in]	duration		duration of join time. The range is 0 ~ 255.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_broadcast_permitjoin(int duration);

/* broadcast identify query request */
/**
 * @brief		Broadcast identify query request cmd of cluster "Identify"
 *
 * @param [in]	local_endpoint		Endpoint id that start broadcasting
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 * Callback function is called for notifying the result.
 * -Response type : ZIGBEE_RESPONSE_BROADCAST_IDENTIFY_QUERY
 * -Response payload : pointer of zigbee_broadcast_identify_query_response
 */
int zigbee_broadcast_identify_query(int local_endpoint);


/* factory reset */
/**
 * @brief		Factory reset operation, that clear bindings and groups.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_factory_reset(void);

/* local attribute reset */
/**
 * @brief		Reset local attribute to default.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_reset_local_attr(int local_endpoint);

/**
 * @brief		Reset local device attribute, binding list and initialize network.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_reset_local(void);

/* get max binding table size */
/**
 * @brief	Get binding table size
 *
 * @param [out]	size	The binding table size to be returned
 * @return				Result of operation, EZ_OK on success,
 *						error code otherwise.
 */
int zigbee_get_binding_table_size(int *size);

/* get binding entry */
/**
 * @brief		Get binding entry content
 *
 * @param [in]	index		Index of binding entry
 * @param [out]	value		pointer that store the entry content
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_get_binding_entry(int index, zigbee_binding_table_entry *value);

/* set binding entry */
/**
 * @brief		Set binding entry to binding table
 *
 * @param [in]	index	Index of binding entry
 * @param [in]	value	pointer of binding entry
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_set_binding_entry(int index, zigbee_binding_table_entry *value);

/* delete entry */
/**
 * @brief		Delete an entry from the binding table
 *
 * @param [in]	index	Index of binding entry
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_delete_binding_entry(int index);

/* clear binding table */
/**
 * @brief		Clear the binding table
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_clear_binding_table(void);

/* ZigBee network address request */
/**
 * @brief		Send node id request.
 *
 * @param [in]	ieee_addr	Ieee address to be resolved.
 * @param [out]	node_id		Node id to be returned.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_zdo_nodeid_request(char ieee_addr[EUI64_SIZE], ZIGBEE_NODE_ID *node_id);

/* Ieee address request */
/**
 * @brief		Send ieee address request.
 *				This command supports unicast only.
 *
 * @param [in]	node_id		Node id that the request is sent to.
 * @param [out]	ieee_addr	The 8 bytes ieee address to be returned.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_zdo_ieee_addr_request(ZIGBEE_NODE_ID node_id, char ieee_addr[EUI64_SIZE]);

/* ZDO leave request */
/**
 * @brief		Send zdo leave request(ZDO Mgmt_Leave_Req).
 *				This command supports unicast only.
 *
 * @param [in]	node_id				The node which will receive the request.
 * @param [in]	ieee_addr			The 64-bit IEEE address of the entity to be re-moved from the
 *									network or NULL if the device removes itself from the network.
 * @param [in]	remove_children		Remove children.
 * @param [in]	rejoin_after_leave	Rejoin after leave.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_zdo_leave_request(ZIGBEE_NODE_ID node_id,
							 char ieee_addr[EUI64_SIZE],
							 bool remove_children,
							 bool rejoin_after_leave);

/* Node descriptor request */
/**
 * @brief		Send node descriptor request.
 *				This command supports unicast only.
 *
 * @param [in]	node_id			Node id that the request is sent to.
 * @param [out]	node_descriptor	The node descriptor to be returned.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_zdo_node_descriptor_request(ZIGBEE_NODE_ID node_id, zigbee_node_descriptor *node_descriptor);

/* Power descriptor request */
/**
 * @brief		Send power descriptor request.
 *				This command supports unicast only.
 *				It is sent from a local device wishing to inquire as to the power descriptor of a remote device.
 *
 * @param [in]	node_id				Node id that the request is sent to.
 * @param [out]	power_descriptor	The power descriptor to be returned.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_zdo_power_descriptor_request(ZIGBEE_NODE_ID node_id, zigbee_power_descriptor *power_descriptor);

/* active endpoints request */
/**
 * @brief		Send active endpoints request.
 *				This command supports unicast only.
 *
 * @param [in]	node_id				Node id that the request is sent to.
 * @param [out]	active_endpoints	The active endpoints to be returned.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_zdo_active_endpoints_request(ZIGBEE_NODE_ID node_id, zigbee_active_endpoints *active_endpoints);

/* simple description request */
/**
 * @brief		Send simple descriptor request.
 *				This command supports unicast only.
 *
 * @param [in]	node_id				Node id that the request is sent to.
 * @param [in]	endpoint_id			Target endpoint id to be resolved.
 * @param [out]	simple_descriptor	The simple descriptor to be returned.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_zdo_simple_descriptor_request(ZIGBEE_NODE_ID node_id, ZIGBEE_ENDPOINT_ID endpoint_id,
										 zigbee_simple_descriptor *simple_descriptor);

/* match descriptor request */
/**
 * @brief		Send match descriptor request.
 *				This command supports broadcast and unicast.
 *
 *				Find remote devices supporting a specific simple descriptor match criterion,
 *				in the remote device side, for each Simple Descriptor that matches with at least one cluster,
 *				add its endpoint to the response (zigbee_match_desc_response).
 *
 * @param [in]	node_id			Node id that the request is sent to.
 * @param [in]	profile_id		Profile id which is checked.
 * @param [in]	server_clusters	Server clusters which are checked.
 * @param [in]	server_count	The count of server clusters.
 * @param [in]	client_clusters	Client clusters which are checked.
 * @param [in]	client_count	The count of client clusters.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 * Callback function is called for notifying the result.
 * -Response type : ZIGBEE_RESPONSE_MATCH_DESC_RESP
 * -Response payload : pointer of zigbee_match_desc_response
 *
 * User can check the response result according to the parameter 'result', and the result sequences
 * are different between broadcast API and unicast API.
 * -Broadcast : multiple ZIGBEE_SERVICE_DISCOVERY_RECEIVED and one ZIGBEE_SERVICE_DISCOVERY_DONE type
 *				responses will be notified in sequence.
 * -Unicast : single ZIGBEE_SERVICE_DISCOVERY_RECEIVED and one ZIGBEE_SERVICE_DISCOVERY_DONE type
 *				responses will be notified in sequence.
 */
int zigbee_zdo_match_descriptor_request(ZIGBEE_NODE_ID node_id, ZIGBEE_PROFILE profile_id,
										ZIGBEE_CLUSTER_ID server_clusters[MAX_ZDO_CLUSTER_COUNT], int server_count,
										ZIGBEE_CLUSTER_ID client_clusters[MAX_ZDO_CLUSTER_COUNT], int client_count);

/* end device bind request */
/**
 * @brief		Send end device bind request to do binding between two devices.
 *				The requests are sent to Coordinator, and handled in Coordinator side. If a match of
 *				Profile ID and at least one server or client cluster ID is detected, the ZigBee
 *				Coordinator will send bind request command for each matched Cluster ID value.
 *
 *				When binding success, binding table is updated, user can call function
 *				'get_binding_entry' for checking.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 * Callback function is called for notifying the result.
 * -Response type : ZIGBEE_RESPONSE_END_DEVICE_BIND
 * -Response payload : pointer of zigbee_end_device_bind_response
 */
int zigbee_zdo_end_device_bind_request(ZIGBEE_ENDPOINT_ID local_endpoint);

/* LQI table request */
/**
 * @brief		Send lqi table request.
 *				This command supports unicast only.
 *
 * @param [in]	node_id			The node whose LQI table is desired.
 * @param [in]	starting_index	The index of the first neighbor to include in the response.
 * @param [out]	lqi_entry		The neighbor information to be returned. The max number of
 *								entries is 3.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_zdo_lqi_table_request(ZIGBEE_NODE_ID node_id,
								 uint8_t starting_index,
								 struct zigbee_lqi_table_entry *lqi_entry);

/**
 * @brief		Request the source node to bind to the destination node on the specified cluster.
 *
 * @param [in]	src_node		The node id of the source node.
 * @param [in]	src_endpoint	The endpoint id of the source node.
 * @param [in]	cluster			The cluster id to bind to.
 * @param [in]	dest_node		The node id of the destination address to bind to.
 * @param [in]	dest_endpoint	The endpoint id of the destination to bind to.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_zdo_bind_unicast_request(ZIGBEE_NODE_ID src_node, ZIGBEE_ENDPOINT_ID src_endpoint,
									ZIGBEE_CLUSTER_ID cluster, ZIGBEE_NODE_ID dest_node,
									ZIGBEE_ENDPOINT_ID dest_endpoint);

/**
 * @brief		Request the source node to bind to the destination group on the specified cluster.
 *
 * @param [in]	src_node		The node id of the source node.
 * @param [in]	src_endpoint	The endpoint id of the source node.
 * @param [in]	cluster			The cluster id to bind to.
 * @param [in]	dest_group		The 16-bit group address for destination address to bind to.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_zdo_bind_group_request(ZIGBEE_NODE_ID src_node, ZIGBEE_ENDPOINT_ID src_endpoint,
								  ZIGBEE_CLUSTER_ID cluster, ZIGBEE_GROUP_ID dest_group);

/**
 * @brief		Send binding table request.
 *				This command supports unicast only.
 *
 * @param [in]	node_id			Node id that the request is sent to.
 * @param [in]	index			The start index of binding table.
 * @param [out]	binding_entry	The binding table to be returned.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_zdo_binding_table_request(ZIGBEE_NODE_ID node_id, uint8_t index,
									 struct zigbee_binding_table_list *binding_entry);

/**
 * @brief		Send routing table request.
 *				This command supports unicast only.
 *
 * @param [in]	node_id			Node id that the request is sent to.
 * @param [in]	index			The start index of routing table.
 * @param [out]	routing_entry	The routing table to be returned.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_zdo_routing_table_request(ZIGBEE_NODE_ID node_id, uint8_t index,
									 struct zigbee_routing_table_list *routing_entry);

/* cluster client */
/**
 * @brief		Notice server to report the attribute value.
 *
 * @param [in]	cluster_id			Remote device atturbite cluster id.
 * @param [in]	sending_info		Command sending information, including sending type,
 *									source or destination information, etc.
 * @param [in]	report_type			The reporting type to be requested.
 * @param [in]	min_interval		The reporting minimum interval. Greater than or equal to 0.
 * @param [in]	max_interval		The reporting maximum interval. Less than or equal to 0xFFFF.
 *									If set 0xFFFF, reporting stopped.
 * @param [in]	change_threshold	Minimum changed value to trigger reporting.
 * @param [in]	local_endpoint		Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_request_reporting(int cluster_id,
							 const struct zigbee_sending_info *sending_info,
							 zigbee_reporting_type report_type,
							 int min_interval, int max_interval,
							 int change_threshold, int local_endpoint);

/* cluster client */
/**
 * @brief		Notice server to stop report the attribute value.
 *
 * @param [in]	cluster_id		Remote device atturbite cluster id.
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [in]	report_type		The reporting type to be requested.
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_stop_reporting(int cluster_id,
						  const struct zigbee_sending_info *sending_info,
						  zigbee_reporting_type report_type,
						  int local_endpoint);

/**
 * @brief		Check the if the device supports the specified reporting type
 *
 * @param[in]	device_id		The device id to be checked.
 * @param[in]	report_type		The reporting type to be checked.
 *
 * @return		Result of operation, EZ_OK when support, otherwise not support.
 */
int zigbee_check_reporting(ZIGBEE_DEVICEID device_id,
						   zigbee_reporting_type report_type);

/**
 * @brief		Read the local endpoint's attribute value
 *
 * @param[in]	cluster			The cluster id to be checked
 * @param[in]	attribute		The server attribute id to be checked
 * @param[out]	value			The attribute value to be returned, the string type data
 *								is ended with '\0'.
 *								For the attribute value size, MAX_ATTRIBUTE_SIZE can be
 *								used for safe.
 * @param[out]	value_length	The attribute value length to be returned, it can be NULL.
 * @param[out]	value_type		The attribute value type to be returned, it can be NULL.
 * @param[in]	local_endpoint	Local endpoint id
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_general_read_local_attribute(ZIGBEE_CLUSTER_ID cluster,
										ZIGBEE_ATTRIBUTE_ID attribute,
										char *value,
										unsigned int *value_length,
										zigbee_attribute_data_type *value_type,
										int local_endpoint);

/**
 * @brief		Write the local endpoint's attribute value
 *
 * @param[in]	cluster			The cluster id to be checked
 * @param[in]	attribute		The server attribute id to be checked
 * @param[in]	value			The attribute value to be written
 * @param[in]	value_length	The attribute value length to be written
 * @param[in]	value_type		The attribute value type to be written
 * @param[in]	local_endpoint	Local endpoint id
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_general_write_local_attribute(ZIGBEE_CLUSTER_ID cluster,
										ZIGBEE_ATTRIBUTE_ID attribute,
										void *value,
										unsigned int value_length,
										zigbee_attribute_data_type value_type,
										int local_endpoint);

/**
 * @brief		Read the remote endpoint's attribute value
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param[in]	cluster			The cluster id to be checked
 * @param[in]	attribute		The server attribute id to be checked
 * @param[out]	value			The attribute value to be returned, the string type data
 *								is ended with '\0'.
 *								For the attribute value size, MAX_ATTRIBUTE_SIZE can be
 *								used for safe.
 * @param[out]	value_length	The attribute value length to be returned, it can be NULL.
 * @param[out]	value_type		The attribute value type to be returned, it can be NULL.
 * @param[in]	local_endpoint	Local endpoint id
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_general_read_remote_attribute(const struct zigbee_sending_info *sending_info,
										 ZIGBEE_CLUSTER_ID cluster,
										 ZIGBEE_ATTRIBUTE_ID attribute,
										 char *value,
										 unsigned int *value_length,
										 zigbee_attribute_data_type *value_type,
										 int local_endpoint);

/**
 * @brief		Write the remote endpoint's attribute value
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param[in]	cluster			The cluster id to be checked
 * @param[in]	attribute		The server attribute id to be checked
 * @param[in]	value			The attribute value to be written
 * @param[in]	value_length	The attribute value length to be written
 * @param[in]	value_type		The attribute value type to be written
 * @param[in]	local_endpoint	Local endpoint id
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_general_write_remote_attribute(const struct zigbee_sending_info *sending_info,
										  ZIGBEE_CLUSTER_ID cluster,
										  ZIGBEE_ATTRIBUTE_ID attribute,
										  void *value,
										  unsigned int value_length,
										  zigbee_attribute_data_type value_type,
										  int local_endpoint);

/**
 * @brief		Discover the identifiers and types of the attributes on a remote
 *				device which are supported within the cluster.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param[in]	cluster			The cluster id to be checked
 * @param[in]	start_attribute	The start attribute identifier, which specifies
 *								the value of the identifier at which to begin
 *								the attribute discovery.
 * @param[in]	max_count		The max count of discovered attributes.
 * @param[out]	attr_list		The discovery attributse result to be returned
 * @param[in]	local_endpoint	Local endpoint id
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_general_discover_attribute(const struct zigbee_sending_info *sending_info,
									  ZIGBEE_CLUSTER_ID cluster,
									  ZIGBEE_ATTRIBUTE_ID start_attribute,
									  uint8_t max_count,
									  struct zigbee_discovery_attributes *attr_list,
									  int local_endpoint);

/* cluster client */
/**
 * @brief		Notice server to report the attribute value.
 *				This is an advanced API for users who should know the cluster id,
 *				attribute id and attribute data type and range of change threshold of
 *				the target endpoint.
 *
 * Parsed reporting or raw reporting be delivered through callback function.
 *	[Parsed reporting]
 *	This type reporting has been parsed, user can get value directory.
 *	- Response type : ZIGBEE_RESPONSE_REPORT_ATTRIBUTE
 *	- Response payload : pointer of zigbee_report_attribute_info
 *
 *	[Raw reporting]
 *	This is raw reporting data, user should parse the data all by himself.
 *	- Response type : ZIGBEE_RESPONSE_GENERAL_REPORT_ATTRIBUTE
 *	- Response payload : pointer of zigbee_general_report_attribute_info
 *
 * @param [in]	sending_info		Command sending information, including sending type,
 *									source or destination information, etc.
 * @param [in]	cluster_id			Remote device atturbite cluster id.
 * @param [in]	attribute_id		The reporting type to be requested.
 * @param [in]	attribute_data_type	The data type of attribute.
 * @param [in]	min_interval		The reporting minimum interval.
 * @param [in]	max_interval		The reporting maximum interval.
 *									If set 0xFFFF, reporting stopped.
 * @param [in]	change_threshold	Minimum changed value to trigger reporting.
 * @param [in]	local_endpoint		Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * << Some available cases in ZCL spec >>
 * << For more cases, please refer to ZCL spec >>
 *	[Illuminance Measurement cluster]
 *	- cluster_id:			0x0400
 *	- attribute_id:			0x0000	[measured value]
 *	- attribute_data_type:	ZIGBEE_INT16U_ATTRIBUTE_TYPE
 *	- attribute_id:			0x0003	[tolerance]
 *	- attribute_data_type:	ZIGBEE_INT16U_ATTRIBUTE_TYPE
 *
 *	[Occupancy Sensing cluster]
 *	- cluster_id:			0x0406
 *	- attribute_id:			0x0000	[occupancy]
 *	- attribute_data_type:	ZIGBEE_BITMAP8_ATTRIBUTE_TYPE
 *
 *	[Temperature Measurement cluster]
 *	- cluster_id:			0x0402
 *	- attribute_id:			0x0000	[measured value]
 *	- attribute_data_type:	ZIGBEE_INT16S_ATTRIBUTE_TYPE
 *	- attribute_id:			0x0003	[tolerance]
 *	- attribute_data_type:	ZIGBEE_INT16S_ATTRIBUTE_TYPE
 *
 *	[Thermostat cluster]
 *	- cluster_id:			0x0201
 *	- attribute_id:			0x0000	[local temperature]
 *	- attribute_data_type:	ZIGBEE_INT16S_ATTRIBUTE_TYPE
 *	- attribute_id:			0x0007	[pi cooling demand]
 *	- attribute_data_type:	ZIGBEE_INT8U_ATTRIBUTE_TYPE
 *	- attribute_id:			0x0008	[pi heating demand]
 *	- attribute_data_type:	ZIGBEE_INT8U_ATTRIBUTE_TYPE
 */
int zigbee_general_request_reporting(const struct zigbee_sending_info *sending_info,
									 ZIGBEE_CLUSTER_ID cluster_id,
									 ZIGBEE_ATTRIBUTE_ID attribute_id,
									 zigbee_attribute_data_type attribute_data_type,
									 int min_interval, int max_interval,
									 int change_threshold, int local_endpoint);

/**
 * @brief		Notice server to stop report the attribute value.
 *
 * @param [in]	sending_info		Command sending information, including sending type,
 *									source or destination information, etc.
 * @param [in]	cluster_id			Remote device atturbite cluster id.
 *									(For example: Illuminance Measurement 0x0400)
 * @param [in]	attribute_id		The reporting type to be requested.
 *									(For example: measured value 0x0000)
 * @param [in]	attribute_data_type	The data type of attribute.
 *									(For example: data type of cluster(0x0400)
 *									attribute(0x0000) is ZIGBEE_INT16U_ATTRIBUTE_TYPE)
 * @param [in]	local_endpoint		Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_general_stop_reporting(const struct zigbee_sending_info *sending_info,
								  ZIGBEE_CLUSTER_ID cluster_id,
								  ZIGBEE_ATTRIBUTE_ID attribute_id,
								  zigbee_attribute_data_type attribute_data_type,
								  int local_endpoint);

/**
 * @brief		Read the configuration details of the reporting mechanism
 *				for the attribute of a cluster.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param[in]	cluster			The cluster id to read configuration details.
 * @param[in]	attribute		The server attribute identifier to be read configuration details.
 * @param[out]	reporting_info	The read attribute value to be returned.
 * @param[in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_general_read_reporting_config(const struct zigbee_sending_info *sending_info,
										 ZIGBEE_CLUSTER_ID cluster,
										 ZIGBEE_ATTRIBUTE_ID attribute,
										 zigbee_reporting_info *reporting_info,
										 int local_endpoint);

/* Basic(0x0000) cluster client API */
/**
 * @brief		Resets all attribute values to factory default.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_basic_reset_to_factory_defaults(const struct zigbee_sending_info *sending_info,
										   int local_endpoint);

/* Identify(0x0003) cluster client API */
/**
 * @brief		Send command "Identify", to request identify.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [in]	duration		Identify duration in seconds. in the range 0~0xffff
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_identify_command(const struct zigbee_sending_info *sending_info,
							int duration, int local_endpoint);

/* Identify(0x0003) cluster client API */
/**
 * @brief		Send command "Identify Query", to get remote identify time.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [out]	time			Remaining seconds of identifying.
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_identify_get_remaining_time(const struct zigbee_sending_info *sending_info,
									   int *time, int local_endpoint);

/* Groups(0x0004) cluster client API */
/**
 * @brief		Commands are defined here for discovering the group membership of a
 *				device, adding a group, removing a group and removing all groups.
 *
 *				Any endpoint on any device MAY be assigned to one or more groups,
 *				each labeled with a 16-bit identifier (0x0001 - 0xfff7), which acts
 *				for all intents and purposes like a network address.
 *				Once a group is established, frames will be delivered to every endpoint
 *				assigned to the group address.
 *
 * @param [in]		sending_info	Command sending information, including sending type,
 *									source or destination information, etc.
 * @param [in/out]	groups_info		Group command to be sent or got.
 *									Refer to struct zigbee_groups_info.
 * @param [in]		local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_groups_command(const struct zigbee_sending_info *sending_info,
						  zigbee_groups_info *groups_info,
						  int local_endpoint);

/* Groups(0x0004) cluster server API */
/**
 * @brief		Get attribute of "name support" of cluster "Groups".
 *
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		EZ_OK, group names is supported.
 *				E_NOT_SUPPORTED, group names isn't supported.
 *				otherwise is others error code.
 */
int zigbee_groups_get_local_name_support(int local_endpoint);

/* Groups(0x0004) cluster server API */
/**
 * @brief		Set local attribute of "name support" of cluster "Groups".
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	support			Set name support attribute.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_groups_set_local_name_support(int local_endpoint, bool support);

/* On/off(0x0006) cluster client API */
/**
 * @brief		Send command to control remote on/off.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [in]	target_status	On/off command, please refer to
 *								"enum zigbee_onoff_status".
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_onoff_command(const struct zigbee_sending_info *sending_info,
						 const zigbee_onoff_status target_status,
						 int local_endpoint);

/* On/off(0x0006) cluster server API */
/**
 * @brief		Get attribute of "on/off" of cluster "On/off".
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [out]	status			On/off status(refer to enum zigbee_onoff_status).
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_onoff_get_value(int local_endpoint, zigbee_onoff_status *status);

/* Level Control(0x0008) cluster client API */
/**
 * @brief		Send commands about level control, to control remote level.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [in]	command			Level control command, please refer
 *								to "struct zigbee_level_control_command".
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_levelcontrol_command(const struct zigbee_sending_info *sending_info,
								const zigbee_level_control_command *command,
								int local_endpoint);

/* Level Control(0x0008) cluster server API */
/**
 * @brief		Get attribute of "current level" of cluster "Levle Control".
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [out]	value			Current level of this device. The meaning of
 *								'level' is device dependent.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_levelcontrol_get_value(int local_endpoint, int *value);

/* Illuminance Measurement(0x0400) cluster server API */
/**
 * @brief		Set the range of illuminance in measured value(1 to 65534(0xFFFE))
 *				Max value shall be greater than min value.
 *				MeasuredValue represents the Illuminance in Lux (symbol lx)
 *				as follows:
 *				MeasuredValue = 10,000 x log10 Illuminance + 1
 *
 *				Refer to 'zigbee_illum_measured_value_to_lux' and
 *				'zigbee_illum_lux_to_measured_value'
 *
 * @param [in]	local_endpoint		Local endpoint id.
 * @param [in]	min_measured_value	Min measured value. The range is 0x0001 ~ 0xfffd.
 * @param [in]	max_measured_value	Max measured value. The range is 0x0002 ~ 0xfffe.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_illum_set_measured_value_range(int local_endpoint,
										  int min_measured_value,
										  int max_measured_value);

/* Illuminance Measurement(0x0400) cluster server API */
/**
 * @brief		Set the measured illuminance value.
 *				pre-requisite: before calling this API, zigbee_illum_set_measured_value_range must be called
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	measured_value	Measured value, in the range 1 to 65534(0xfffe),
 *								which corresponding to illuminance of 1 lx to
 *								3.576 x 10^6 lx.
 *
 *								MeasuredValue represents the Illuminance in
 *								Lux (symbol lx) as follows:
 *								MeasuredValue = 10,000 x log10 Illuminance + 1
 *
 *								e.g. To set the sensor to 10 lx, use calculated value 10001.
 *
 *								Refer to 'zigbee_illum_measured_value_to_lux' and
 *								'zigbee_illum_lux_to_measured_value'
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_illum_set_measured_value(int local_endpoint, int measured_value);

/* Illuminance Measurement(0x0400) cluster server API */
/**
 * @brief		Get the Illuminance value
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [out]	measured_value	Measured value, in the range 1 to 65534(0xfffe).
 *
 *								MeasuredValue represents the Illuminance in
 *								Lux (symbol lx) as follows:
 *								MeasuredValue = 10,000 x log10 Illuminance + 1
 *
 *								e.g. The measured value 10001 means 10 lx.
 *
 *								Refer to 'zigbee_illum_measured_value_to_lux' and
 *								'zigbee_illum_lux_to_measured_value'
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_illum_get_measured_value(int local_endpoint, int *measured_value);

/* Occupancy Sensing(0x0406) cluster server API */
/**
 * @brief		Set attribute "occupancy" of cluster "Occupancy Sensing".
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	status			attribute value of "occupancy".
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_occupancy_set_occupancy_status(int local_endpoint,
										  zigbee_occupancy_status status);

/* Occupancy Sensing(0x0406) cluster server API */
/**
 * @brief		Set attribute "occupancy sensor type" of cluster
 *				"Occupancy Sensing".
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	type			occupancy sensor type.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_occupancy_set_occypancy_type(int local_endpoint,
										zigbee_occupancy_type type);

/* Temperature Measurement(0x0402) cluster server API */
/**
 * @brief		Set local attribute "measured value" of cluster "Temperature Measurement".
 *				pre-requisite: before calling this API, zigbee_temperature_set_measured_value_range must be called
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	value			The MeasuredValue which represents the temperature
 *								in degrees Celsius as follows:
 *								MeasuredValue = 100 x temperature in degrees Celsius.
 *								Where -273.15 Celsius <= temperature <= 327.67 Celsius,
 *								corresponding to a MeasuredValue in the range 0x954d to 0x7fff.
 *
 *								Refer to 'zigbee_temperature_to_celsius' and
 *								'zigbee_celsius_to_temperature'.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_temperature_set_measured_value(int local_endpoint, int value);

/* Temperature Measurement(0x0402) cluster server API */
/**
 * @brief		Set local attribute "min measured value" and
 *				"max measured value" of cluster "Temperature Measurement".
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	min				Min MeasuredValue to be set. The range is 0x954d to 0x7ffe.
 * @param [in]	max				Max MeasuredValue to be set. The range is 0x954e to 0x7fff.
 *
 *								The MeasuredValue(Min and Max) which represents the
 *								temperature in degrees Celsius as follows:
 *								MeasuredValue = 100 x temperature in degrees Celsius.
 *								Where -273.15 Celsius <= temperature <= 327.67 Celsius,
 *								corresponding to a MeasuredValue in the range 0x954d to 0x7fff.
 *
 *								Refer to 'zigbee_temperature_to_celsius' and
 *								'zigbee_celsius_to_temperature'.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
*/
int zigbee_temperature_set_measured_value_range(int local_endpoint,
												int min, int max);

/* Relative Humidity Measurement(0x0405) cluster server API */
/**
 * @brief		Set local attribute "measured value" of cluster "Relative Humidity Measurement"
 *				pre-requisite: before calling this API, zigbee_humidity_set_measured_value_range must be called
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	value			MeasuredValue represents the relative humidity in % as follows:
 *								MeasuredValue = 100 x Relative humidity
 *								Where 0% <= Relative humidity <= 100%,
 *								corresponding to a MeasuredValue in the range 0 to 0x2710.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */

int zigbee_humidity_set_measured_value(int local_endpoint, int value);

/* Relative Humidity Measurement(0x0405) cluster server API */
/**
 * @brief		Get local attribute "measured value" of cluster "Relative Humidity Measurement"
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [out]	value			MeasuredValue represents the relative humidity in % as follows:
 *								MeasuredValue = 100 x Relative humidity
 *								Where 0% <= Relative humidity <= 100%,
 *								corresponding to a MeasuredValue in the range 0 to 0x2710
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_humidity_get_measured_value(int local_endpoint, int *value);

/* Relative Humidity Measurement(0x0405) cluster server API */
/**
 * @brief		Set local attribute "min measured value" and
 *				"max measured value" of cluster "Relative Humidity Measurement".
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	min				Min MeasuredValue to be set. The range is 0x0000 - 0x270f
 * @param [in]	max				Max MeasuredValue to be set. The range is 0x0001 - 0x2710
 *
 *								MeasuredValue (min and max) represents the
 *								relative humidity in % as follows:
 *								MeasuredValue = 100 x Relative humidity
 *								Where 0% <= Relative humidity <= 100%,
 *								corresponding to a MeasuredValue in the range 0 to 0x2710.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
*/
int zigbee_humidity_set_measured_value_range(int local_endpoint, int min, int max);

/* Relative Humidity Measurement(0x0405) cluster server API */
/**
 * @brief		Get local attribute "min measured value" and
 *				"max measured value" of cluster "Relative Humidity Measurement".
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [out]	min				Min MeasuredValue to get. The range is 0x0000 - 0x270f
 * @param [out]	max				Max MeasuredValue to get. The range is 0x0001 - 0x2710
 *
 *								MeasuredValue (min and max) represents the
 *								relative humidity in % as follows:
 *								MeasuredValue = 100 x Relative humidity
 *								Where 0% <= Relative humidity <= 100%,
 *								corresponding to a MeasuredValue in the range 0 to 0x2710.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_humidity_get_measured_value_range(int local_endpoint, int *min, int *max);

/* Fan Control(0x0202) cluster server API */
/**
 * @brief		Get "fan mode" attribute of cluster "Fan Control".
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [out]	mode			Local fan mode pointer(refer to enum fan_mode).
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_fan_get_mode(int local_endpoint, zigbee_fan_mode *mode);

/* Fan Control(0x0202) cluster server API */
/**
 * @brief		Get "fan mode sequence" attribute of cluster "Fan Control".
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [out]	seq				Local fan mode sequence pointer.
 *								(refer to enum fan_mode_sequence).
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_fan_get_mode_sequence(int local_endpoint,
								 zigbee_fan_mode_sequence *seq);

/* Thermostat(0x0201) cluster server API */
/**
 * @brief		Set "local temperature" attribute of cluster
 *				"Thermostat" locally.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	temperature		The LocalTemperature, in the range 0x954d to 0x7fff.
 *								LocalTemperature = 100 x temperature in degrees Celsius.
 *								Where -273.15 Celsius <= temperature <= 327.67 Celsius,
 *								corresponding to a LocalTemperature in the range 0x954d to 0x7fff.
 *
 *								Refer to 'zigbee_temperature_to_celsius' and
 *								'zigbee_celsius_to_temperature'.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_set_local_temperature(int local_endpoint,
											int temperature);

/* Thermostat(0x0201) cluster server API */
/**
 * @brief		Get "local temperature" attribute of cluster
 *				"Thermostat" locally.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [out]	temperature		The LocalTemperature, in the range 0x954d to 0x7fff.
 *								LocalTemperature = 100 x temperature in degrees Celsius.
 *								Where -273.15 Celsius <= temperature <= 327.67 Celsius,
 *								corresponding to a LocalTemperature in the range 0x954d to 0x7fff.
 *
 *								Refer to 'zigbee_temperature_to_celsius' and
 *								'zigbee_celsius_to_temperature'.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
*/
int zigbee_thermostat_get_local_temperature(int local_endpoint,
											int *temperature);

/* Thermostat(0x0201) cluster server API */
/**
 * @brief		Set "occupied cooling setpoint" attribute(temperature) of
 *				cluster "Thermostat" locally.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	temperature		The LocalTemperature, in the range 0x954d to 0x7fff.
 *								LocalTemperature = 100 x temperature in degrees Celsius.
 *								Where -273.15 Celsius <= temperature <= 327.67 Celsius,
 *								corresponding to a LocalTemperature in the range 0x954d to 0x7fff.
 *
 *								Refer to 'zigbee_temperature_to_celsius' and
 *								'zigbee_celsius_to_temperature'.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_set_occupied_cooling_setpoint(int local_endpoint,
													int temperature);

/* Thermostat(0x0201) cluster server API */
/**
 * @brief		Get "occupied cooling setpoint" attribute(temperature) of
 *				cluster "Thermostat" locally.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [out]	temperature		The LocalTemperature, in the range 0x954d to 0x7fff.
 *								LocalTemperature = 100 x temperature in degrees Celsius.
 *								Where -273.15 Celsius <= temperature <= 327.67 Celsius,
 *								corresponding to a LocalTemperature in the range 0x954d to 0x7fff.
 *
 *								Refer to 'zigbee_temperature_to_celsius' and
 *								'zigbee_celsius_to_temperature'.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_get_occupied_cooling_setpoint(int local_endpoint,
													int *temperature);

/* Thermostat(0x0201) cluster server API */
/**
 * @brief		Set "occupied heating setpoint" attribute(temperature) of
 *				cluster "Thermostat" locally.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	temperature		The LocalTemperature, in the range 0x954d to 0x7fff.
 *								LocalTemperature = 100 x temperature in degrees Celsius.
 *								Where -273.15 Celsius <= temperature <= 327.67 Celsius,
 *								corresponding to a LocalTemperature in the range 0x954d to 0x7fff.
 *
 *								Refer to 'zigbee_temperature_to_celsius' and
 *								'zigbee_celsius_to_temperature'.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_set_occupied_heating_setpoint(int local_endpoint,
													int temperature);

/* Thermostat(0x0201) cluster server API */
/**
 * @brief		Get "occupied heating setpoint" attribute(temperature) of
 *				cluster "Thermostat" locally.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [out]	temperature		The LocalTemperature, in the range 0x954d to 0x7fff.
 *								LocalTemperature = 100 x temperature in degrees Celsius.
 *								Where -273.15 Celsius <= temperature <= 327.67 Celsius,
 *								corresponding to a LocalTemperature in the range 0x954d to 0x7fff.
 *
 *								Refer to 'zigbee_temperature_to_celsius' and
 *								'zigbee_celsius_to_temperature'.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_get_occupied_heating_setpoint(int local_endpoint,
													int *temperature);

/* Thermostat(0x0201) cluster server API */
/**
 * @brief		Set "system mode" attribute of cluster "Thermostat" locally.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	mode			The system mode to be set.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_set_system_mode(int local_endpoint,
									  zigbee_thermostat_system_mode mode);

/* Thermostat(0x0201) cluster server API */
/**
 * @brief		Get "system mode" attribute of cluster "Thermostat" locally.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [out]	mode			The system mode pointer.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_get_system_mode(int local_endpoint,
									  zigbee_thermostat_system_mode *mode);

/* Thermostat(0x0201) cluster server API */
/**
 * @brief		Set "control sequence of operation" attribute of
 *				cluster "Thermostat" locally.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	seq				The control sequence to be set.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_set_control_sequence(int local_endpoint,
										   zigbee_thermostat_control_sequence seq);

/* Thermostat(0x0201) cluster server API */
/**
 * @brief		Get "control sequence of operation" attribute of cluster
 *				"Thermostat" locally.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [out]	seq				The control sequence pointer.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_get_control_sequence(int local_endpoint,
										   zigbee_thermostat_control_sequence *seq);

/* Thermostat(0x0201) cluster client API */
/**
 * @brief		Send setpoint raise/lower control commands to remote server.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [in]	mode			The thermostat setpoint mode.
 * @param [in]	temperature		The amount of LocalTemperature is to be a
 *								increased/decreased by, in steps of 1 degree.
 *								Positive value for increase, negative
 *								one for decrease. The range is -127 ~ 127.
 *
 *								LocalTemperature = 10 x temperature in degrees Celsius.
 *
 *								Refer to 'zigbee_temperature_to_celsius' and
 *								'zigbee_celsius_to_temperature'.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_request_setpoint_raise_lower(const struct zigbee_sending_info *sending_info,
												   zigbee_thermostat_setpoint_mode mode,
												   int temperature,
												   int local_endpoint);

/* OTA Upgrade(0x00119) cluster util API */
/**
 * @brief		Set OTA image base directory.
 * 				Default location is defined in ZIGBEE_DEFAULT_OTA_IMAGE_LOCATION.
 * 				This just sets base directory, to reload OTA image in set base directory
 * 				please refer zigbee_ota_reload_images().
 *
 * @param[in]	dir		Absolute path of OTA image base directory. "/" is prohibited.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_ota_set_image_directory(const char *dir);

/**
 * @brief		Reload OTA images into internal storage, then return image information.
 * 				OTA image files should be located in base location to get information
 * 				To change base location, please use zigbee_ota_set_image_directory().
 *
 * @param[out]	info	List of ota image information (please refer zigbee_ota_image_info)
 * 						List length is less than 128.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_ota_reload_images(GList **info);

/**
 * @brief		Free OTA image list generated by zigbee_ota_reload_images().
 * 				This API function is a helper function to free OTA image list fully.
 * 				After using OTA image list, list should be freed either by calling this function
 * 				or by users to avoid memory leak.
 *
 * @param[in]	info	List of ota image information returned by zigbee_ota_reload_images()
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_ota_free_image_list(GList *info);

/**
 * @brief		Set logging backend system
 *
 * @param[in]	system Log system
 *
 * @return		0 on success, -1 otherwise
 */
int zigbee_log_set_system(enum zigbee_log_system system);


/*********************************DEPRECATED*******************************************************/
/**
 * @deprecated	This API is deprecated and will be removed, it is
 *				replaced by 'zigbee_get_node_info'.
 *
 * @brief		Request my current network status
 *
 * @param [out]	state	ZIGBEE_JOINED_NETWORK when succeeded
 *						ZIGBEE_NO_NETWORK if the node is not part of a network
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_network_request_my_network_status(zigbee_network_state *state);

/**
 * @deprecated	This API is deprecated and will be removed, it is
 *				replaced by 'zigbee_get_node_info'.
 *
 * @brief		Request my current device type
 *
 * @param [out]	type	current device type
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_device_request_my_node_type(zigbee_node_type *type);

/**
 * @deprecated	This API is deprecated and will be removed, it is
 *				replaced by 'zigbee_get_node_info'.
 *
 * @brief		Request my current device node id
 *
 * @param [out]	node_id	Current device node id to be returned
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_device_request_my_node_id(int *node_id);

/**
 * @deprecated	This api will be removed.
 *				When called zigbee_initialize, this API is called automatically
 *
 * @brief		Resume network operation after a reboot
 * This should be called on startup whether or not
 * the node was previously part of a network.
 *
 * @param [out] state		ZIGBEE_JOINED_NETWORK when succeeded
 *							ZIGBEE_NO_NETWORK if the node is not part of a
 *							network
 *							It can be NULL
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_network_start(zigbee_network_state *state);

/**
 * @deprecated	This api will be removed.
 *
 * @brief		Get device handle list
 *
 * @return		Return the local device handle list.
 */
GList *zigbee_get_handle_list(void);

/**
 * @deprecated	This API is deprecated and will be removed, it is
 *				replaced by 'zigbee_get_local_endpoint_by_endpointid'.
 *
 * @brief		Get endpoint id by handle
 * @param [in]	handle		the handle id
 * @return		endpoint info pointer, NULL if failed.
 */
struct inner_endpoint_info *get_device_info_by_handle(zigbee_endpoint_handle handle);

/**
 * @deprecated	It is deprecated and will be removed, it is replaced
 *				by 'zigbee_local_endpoint_contains_cluster'.
 *
 * @brief		Check if the endpoint contains the server/client cluster
 *
 * @param [in]	endpoint	The endpoint to be checked
 * @param [in]	cluster_id	The cluster id defined in zigbee_def.h
 * @param [in]	is_server	Server cluster or client cluster,
 *							true for server, false for client.
 *
 * @return		Result of operation, EZ_OK on contains, error code otherwise.
 */
int zigbee_check_local_endpoint_contains_cluster(zigbee_local_endpoint *endpoint,
												 int cluster_id,
												 bool is_server);

/**
 * @deprecated	It is deprecated and will be removed, it is replaced
 *				by 'zigbee_check_local_endpoint_contains_cluster'.
 *
 * @brief		Check if the cluster match the endpoint or not
 * @param [in]	info		info of a endpoint
 * @param [in]	cluster_id	the cluster id defined in zigbee_def.h
 * @param [in]	is_server	server: 1
 *							client: 0
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_check_cluster(struct inner_endpoint_info *info, int cluster_id,
						 int is_server);

/**
 * @deprecated	It is deprecated and will be removed, it is replaced
 *				by 'zigbee_basic_reset_to_factory_defaults'.
 *
 * @brief		Resets all attribute values to factory default.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_reset_to_factory_default(const struct zigbee_sending_info *sending_info,
									int local_endpoint);

/**
 * @deprecated	It is deprecated and will be removed, it is replaced
 *				by 'zigbee_identify_command'.
 *
 * @brief		Send command "Identify", to request identify.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [in]	duration		Identify duration in seconds. in the range 0~0xffff
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_identify_request(const struct zigbee_sending_info *sending_info,
							int duration, int local_endpoint);

/**
 * @deprecated	It is deprecated and will be removed, it is replaced
 *				by 'zigbee_levelcontrol_command'.
 *
 * @brief		Send commands about level control, to control remote level.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [in]	command			Level control command, please refer
 *								to "struct zigbee_level_control_command".
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_level_control_request(const struct zigbee_sending_info *sending_info,
								 const zigbee_level_control_command *command,
								 int local_endpoint);

/**
 * @deprecated	It is deprecated and will be removed, it is replaced
 *				by 'zigbee_levelcontrol_get_value'.
 *
 * @brief		Get attribute of "current level" of cluster "Levle Control".
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [out]	value			Current level of this device. The meaning of
 *								'level' is device dependent.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_level_control_get_value(int local_endpoint, int *value);

/**
 * @deprecated	It is deprecated and will be removed, it is replaced
 *				by 'zigbee_colorcontrol_command'.
 *
 * @brief		Send commands about level control, to control remote level.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [in]	command			Color control command, please refer to
 *								"struct zigbee_color_control_command".
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_color_control_request(const struct zigbee_sending_info *sending_info,
								 const zigbee_color_control_command *command,
								 int local_endpoint);

/**
 * @deprecated	It is deprecated and will be removed, it is replaced
 *				by 'zigbee_colorcontrol_get_value'.
 *
 * @brief		Get attributes of cluster "Color Control".
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [out]	value			Attributes values of cluster "Color Control",
 *								refer to "struct zigbee_color_control_value".
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_color_control_get_value(int local_endpoint,
								   zigbee_color_control_value *value);

/**
 * @deprecated	It is deprecated and will be removed, it is replaced
 *				by 'zigbee_occupancy_set_occupancy_status'.
 *
 * @brief		Set attribute "occupancy" of cluster "Occupancy Sensing".
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	status			attribute value of "occupancy".
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_occupancy_set_value(int local_endpoint,
							   zigbee_occupancy_status status);

/**
 * @deprecated	It is deprecated and will be removed, it is replaced
 *				by 'zigbee_occupancy_set_occypancy_type'.
 *
 * @brief		Set attribute "occupancy sensor type" of cluster
 *				"Occupancy Sensing".
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	type			occupancy sensor type.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_occupancy_set_type(int local_endpoint,
							  zigbee_occupancy_type type);

/**
 * @deprecated	It is deprecated and will be removed, it is replaced
 *				by 'zigbee_get_binding_entry'.
 *
 * @brief				Get binding entry content
 *
 * @param [in]	index	Index of binding entry
 * @param [out]	value	pointer that store the entry content
 *
 * @return				Result of operation, EZ_OK on success,
 *						error code otherwise.
 */
int zigbee_get_binding(int index, zigbee_binding_table_entry *value);

/**
 * @deprecated	It is deprecated and will be removed, it is replaced
 *				by 'zigbee_set_binding_entry'.
 *
 * @brief				Set binding entry to binding table
 *
 * @param [in]	index	Index of binding entry
 * @param [in]	value	pointer of binding entry
 *
 * @return				Result of operation, EZ_OK on success,
 *						error code otherwise.
 */
int zigbee_set_binding(int index, zigbee_binding_table_entry *value);

/**
 * @deprecated	It is deprecated and will be removed, it is replaced
 *				by 'zigbee_delete_binding_entry'.
 *
 * @brief				Delete an entry from the binding table
 *
 * @param [in]	index	Index of binding entry
 *
 * @return				Result of operation, EZ_OK on success,
 *						error code otherwise.
 */
int zigbee_delete_binding(int index);

/**
 * @deprecated	It is deprecated and will be removed, it is replaced
 *				by 'zigbee_clear_binding_table'.
 *
 * @brief		Clear the binding table
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_clear_binding(void);

/* finding and binding */
/**
 * @deprecated	It is deprecated and will be removed, it is replaced
 *				by zigbee_find_bind_target_start
 *				and zigbee_find_bind_initiator_start
 *
 * @brief		Do finding and binding procedure.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	initiator		True is initiator, false is target.
 * @param [in]	start			True is to start.
 *								False is to stop, and it is deprecated.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 *	[Commissioning result in both target and initiator sides]
 *	-Response type : ZIGBEE_RESPONSE_COMMISSIONING_STATUS
 *	-Response payload : pointer of zigbee_commissioning_state
 *
 *	[Target information in initiator side]
 *	-Response type : ZIGBEE_RESPONSE_COMMISSIONING_TARGET_INFO
 *	-Response payload : pointer of zigbee_commissioning_target_info
 *
 *	[Bind information in initiator side]
 *	-Response type : ZIGBEE_RESPONSE_COMMISSIONING_TARGET_INFO
 *	-Response payload : pointer of zigbee_commissioning_target_info
 */
int zigbee_find_bind(int local_endpoint, bool initiator, bool start);

/* ezmode commissioning */
/**
 * @deprecated	It is deprecated and will be removed, it is replaced
 *				by zigbee_ezmode_commissioning_target_start
 *				and zigbee_ezmode_commissioning_initiator_start
 *
 * @brief		Do ezmode commissioning procedure.
 *				Firstly do network steering.
 *				Secondly do find and bind, see zigbee_find_bind.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	initiator		True is initiator, false is target.
 * @param [in]	start			True is to start.
 *								False is to stop, and it is deprecated.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 *	[Commissioning result in both target and initiator sides]
 *	-Response type : ZIGBEE_RESPONSE_COMMISSIONING_STATUS
 *	-Response payload : pointer of zigbee_commissioning_state
 *
 *	[Target information in initiator side]
 *	-Response type : ZIGBEE_RESPONSE_COMMISSIONING_TARGET_INFO
 *	-Response payload : pointer of zigbee_commissioning_target_info
 *
 *	[Bind information in initiator side]
 *	-Response type : ZIGBEE_RESPONSE_COMMISSIONING_TARGET_INFO
 *	-Response payload : pointer of zigbee_commissioning_target_info
 */
int zigbee_ezmode_commissioning(int endpoint_id, bool initiator, bool start);

/* Ieee address request */
/**
 * @deprecated	It is deprecated and will be removed, it is replaced
 *				by 'zigbee_zdo_ieee_addr_request'
 *
 * @brief		Send ieee address request
 *
 * @param [in]	node_id		Node id that need to resolve.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 * Callback function is called for notifying the result.
 * -Response type : ZIGBEE_RESPONSE_IEEE_ADDR_RESP
 * -Response payload : pointer of zigbee_ieee_addr_response
 */
int zigbee_ieee_addr_request(int node_id);

/* simple description request */
/**
 * @deprecated	It is deprecated and will be removed, it is replaced
 *				by 'zigbee_zdo_simple_descriptor_request'
 *
 * @brief		Send simple description request
 *
 * @param [in]	node_id			Node id that the request send to
 * @param [in]	dest_endpoint	Target endpoint id
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 * Callback function is called for notifying the result.
 * -Response type : ZIGBEE_RESPONSE_SIMPLE_DESC_RESP
 * -Response payload : pointer of zigbee_simple_descriptor_response
 */
int zigbee_simple_descriptor_request(int node_id, int dest_endpoint);

/* broadcast match description request */
/**
 * @deprecated	It is deprecated and will be removed, it is replaced
 *				by 'zigbee_zdo_match_descriptor_request'
 *
 * @brief				Broadcast match description request to do device
 *						discovery
 *
 * @param [in]	profile_id	ZIGBEE_PROFILE_HA, ZIGBEE_PROFILE_ZLL and ZIGBEE_PROFILE_GP
 * @param [in]	cluster_id	Cluster id
 * @param [in]	server_cluster	true is cluster server, false is cluster client
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 * Callback function is called for notifying the result.
 * -Response type : ZIGBEE_RESPONSE_MATCH_DESC_RESP
 * -Response payload : pointer of zigbee_match_desc_response
 */
int zigbee_broadcast_match_descriptor_request(ZIGBEE_PROFILE profile_id,
											  int cluster_id,
											  bool server_cluster);

/**
 * @deprecated	It is deprecated and will be removed. If you want to set
 *				occupancy status to local endpoint, using
 *				'zigbee_general_write_local_attribute'.
 *
 * @brief		Get "occupancy" attribute of cluster "Thermostat" locally.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [in]	status			The occupancy status to be set.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_set_occupancy_status(int local_endpoint,
										   zigbee_occupancy_status status);

/**
 * @deprecated	It is deprecated and will be removed. If you want to get
 *				occupancy status from local endpoint, using
 *				'zigbee_general_read_local_attribute'.
 *
 * @brief		Get "occupancy" attribute of cluster "Thermostat" locally.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 * @param [out]	status			The occupancy status pointer.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_get_occupancy_status(int local_endpoint,
										   zigbee_occupancy_status *status);

/* end device bind request */
/**
 * @deprecated	It is deprecated and will be removed, it is replaced
 *				by 'zigbee_zdo_end_device_bind_request'
 *
 * @brief		Send end device bind request to do binding between two devices.
 *				Note that, this function should be called in both target side
 *				and initiator side.
 *				When binding success, binding table is updated in initiator
 *				side, user can call function 'get_binding_entry' for checking.
 *
 * @param [in]	local_endpoint	Local endpoint id
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 *
 * The result will be delivered through callback function.
 * Callback function is called for notifying the result.
 * -Response type : ZIGBEE_RESPONSE_END_DEVICE_BIND
 * -Response payload : pointer of zigbee_end_device_bind_response
 */
int zigbee_end_device_bind_request(int local_endpoint);

/**
 * @deprecated	It is deprecated and will be removed, it is replaced
 *				by 'zigbee_zdo_bind_unicast_request'
 *
 * @brief		Request the src node to bind to the target node on the specified cluster.
 *
 * @param [in]	src_node		The node id of the src node.
 * @param [in]	src_endpoint	The endpoint id of the src node.
 * @param [in]	cluster			The cluster id to bind.
 * @param [in]	target_node		The node id of the target to bind.
 * @param [in]	target_endpoint	The endpoint id of the target to bind.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_zdo_bind_request(int src_node, int src_endpoint,
							ZIGBEE_CLUSTER_ID cluster,
							int target_node, int target_endpoint);

/**
 * @deprecated	This API is deprecated and will be removed
 *
 * @brief		Send Command Line Interface(CLI) command
 *				This is normally used for certification testing
 *
 * @param [in]	command		String of CLI command
 */
void zigbee_raw_request(const char *command);

/* Fan Control(0x0202) cluster client API */
/**
 * @deprecated	This API is deprecated and will be removed, it is
 *				replaced by 'zigbee_general_write_remote_attribute'.
 *
 * @brief		Write fun mode to remote server.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [in]	mode			The new mode set to server.
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_fan_write_mode(const struct zigbee_sending_info *sending_info,
						  zigbee_fan_mode mode, int local_endpoint);

/* Fan Control(0x0202) cluster client API */
/**
 * @deprecated	This API is deprecated and will be removed, it is
 *				replaced by 'zigbee_general_write_remote_attribute'.
 *
 * @brief		Write fun mode sequence to remote server.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [in]	seq				The new seq set to server.
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_fan_write_mode_sequence(const struct zigbee_sending_info *sending_info,
								   zigbee_fan_mode_sequence seq,
								   int local_endpoint);

/* Fan Control(0x0202) cluster client API */
/**
 * @deprecated	This API is deprecated and will be removed, it is
 *				replaced by 'zigbee_general_read_remote_attribute'.
 *
 * @brief		Read fun mode from remote server.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [out]	fanmode			Fan Mode attribute value pointer.
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_fan_read_mode(const struct zigbee_sending_info *sending_info,
						 zigbee_fan_mode *fanmode, int local_endpoint);

/* Fan Control(0x0202) cluster client API */
/**
 * @deprecated	This API is deprecated and will be removed, it is
 *				replaced by 'zigbee_general_read_remote_attribute'.
 *
 * @brief		Read fun mode sequence from remote server.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [out]	fanmode_sequence	Fan Mode Sequence attribute value pointer.
 * @param [in]	local_endpoint		Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_fan_read_mode_sequence(const struct zigbee_sending_info *sending_info,
								  zigbee_fan_mode_sequence *fanmode_sequence,
								  int local_endpoint);

/* Thermostat(0x0201) cluster client API */
/**
 * @deprecated	This API is deprecated and will be removed, it is
 *				replaced by 'zigbee_general_read_remote_attribute'.
 *
 * @brief		Read "occupied cooling setpoint" attribute (temperature)
 *				from remote server.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [out]	temperature		The LocalTemperature, in the range 0x954d to 0x7fff.
 *								LocalTemperature = 100 x temperature in degrees Celsius.
 *								Where -273.15 Celsius <= temperature <= 327.67 Celsius,
 *								corresponding to a LocalTemperature in the range 0x954d to 0x7fff.
 *
 *								Refer to 'zigbee_temperature_to_celsius' and
 *								'zigbee_celsius_to_temperature'.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */

int zigbee_thermostat_read_occupied_cooling_setpoint(const struct zigbee_sending_info *sending_info,
													 int *temperature,
													 int local_endpoint);

/* Thermostat(0x0201) cluster client API */
/**
 * @deprecated	This API is deprecated and will be removed, it is
 *				replaced by 'zigbee_general_read_remote_attribute'.
 *
 * @brief		Read "heating setpoint" attribute (temperature) from
 *				remote server.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [out]	temperature		The LocalTemperature, in the range 0x954d to 0x7fff.
 *								LocalTemperature = 100 x temperature in degrees Celsius.
 *								Where -273.15 Celsius <= temperature <= 327.67 Celsius,
 *								corresponding to a LocalTemperature in the range 0x954d to 0x7fff.
 *
 *								Refer to 'zigbee_temperature_to_celsius' and
 *								'zigbee_celsius_to_temperature'.
 *
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_read_occupied_heating_setpoint(const struct zigbee_sending_info *sending_info,
													 int *temperature,
													 int local_endpoint);

/* Thermostat(0x0201) cluster client API */
/**
 * @deprecated	This API is deprecated and will be removed, it is
 *				replaced by 'zigbee_general_read_remote_attribute'.
 *
 * @brief		Read "system mode" attribute from remote thermostat server.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [out]	mode			The system mode pointer.
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_read_system_mode(const struct zigbee_sending_info *sending_info,
									   zigbee_thermostat_system_mode *mode,
									   int local_endpoint);

/* Thermostat(0x0201) cluster client API */
/**
 * @deprecated	This API is deprecated and will be removed, it is
 *				replaced by 'zigbee_general_write_remote_attribute'.
 *
 * @brief		Write "system mode" attribute to remote thermostat server.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [in]	mode			The system mode set to remote server.
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_write_system_mode(const struct zigbee_sending_info *sending_info,
										zigbee_thermostat_system_mode mode,
										int local_endpoint);

/* Thermostat(0x0201) cluster client API */
/**
 * @deprecated	This API is deprecated and will be removed, it is
 *				replaced by 'zigbee_general_read_remote_attribute'.
 *
 * @brief		Read "control sequence of operation" attribute from remote
 *				thermostat server.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [out]	mode			The system mode pointer.
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_read_control_sequence(const struct zigbee_sending_info *sending_info,
											zigbee_thermostat_control_sequence *seq,
											int local_endpoint);

/* Thermostat(0x0201) cluster client API */
/**
 * @deprecated	This API is deprecated and will be removed, it is
 *				replaced by 'zigbee_general_write_remote_attribute'.
 *
 * @brief		Write "control sequence of operation" attribute to remote
 *				thermostat server.
 *
 * @param [in]	sending_info	Command sending information, including sending type,
 *								source or destination information, etc.
 * @param [in]	mode			The system mode set to remote server.
 * @param [in]	local_endpoint	Local endpoint id.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_thermostat_write_control_sequence(const struct zigbee_sending_info *sending_info,
											 zigbee_thermostat_control_sequence seq,
											 int local_endpoint);

/**
 * @deprecated	It is deprecated and will be removed, it is replaced
 *				by 'zigbee_set_local_endpoints'
 *
 * @brief		Set local endpoints, they are saved locally and used to create
 *				device when initialize() is called.
 *
 * @param [in]	endpoint_info	The local endpoints to be saved
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_set_local_endpoint(zigbee_local_endpoint_info *endpoint_info);

/**
 * @deprecated	It is deprecated and will be removed, it is replaced
 *				by 'zigbee_get_local_endpoints'
 *
 * @brief		Get local endpoints which are saved locally when last function
 *				set_local_endpoint() is called.
 *
 * @param [out]	endpoint_info	The local endpoints to be returned
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_get_local_endpoint(zigbee_local_endpoint_info *endpoint_info);

/**
 * @}
 */

#ifdef __cplusplus
}
#endif
#endif	/*__ZIGBEE_H*/

