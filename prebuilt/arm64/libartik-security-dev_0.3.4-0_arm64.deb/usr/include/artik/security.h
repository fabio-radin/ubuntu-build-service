/*
 * Copyright (c) 2016 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the License);
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __ARTIK_SECURITY__H
#define __ARTIK_SECURITY__H

/**
 * @defgroup security Security
 * @brief Security API
 *
 * This module includes Secure Environment Execution functions.
 **/

#include <artik/security/see_common.h>
#include <artik/security/see_key_manager.h>
#include <artik/security/see_authentication.h>
#include <artik/security/see_secure_storage.h>
#include <artik/security/see_post_provision.h>
#include <artik/security/see_enc_decryption.h>

#endif
