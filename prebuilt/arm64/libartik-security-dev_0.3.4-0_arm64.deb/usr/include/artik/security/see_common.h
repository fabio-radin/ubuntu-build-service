/*
 * Copyright (c) 2016 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the License);
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __ARTIK_SEE_COMMON__H
#define __ARTIK_SEE_COMMON__H

/**
 * @file see_common.h
 * @brief common file to use security api
 */

/**
 * @ingroup security
 * @defgroup see_common See_Common
 * @brief common file to use security api
 *
 * @{
 */

#include <stdio.h>
#ifdef __cplusplus
extern "C" {
#endif

extern int see_debug;
#define err(fmt, args...) do { if (see_debug > 0) printf("<E> : " fmt "\n", ##args); } while(0)
#define info(fmt, args...) do { if (see_debug > 1) printf("<I> : " fmt "\n", ##args); } while(0)
#define dbg(fmt, args...) do { if (see_debug > 2) printf("<D> : " fmt "\n", ##args); } while(0)

/**
 * @brief Common Data for input and output at SEE
 */
typedef struct {
	void *data; /**< data pointer*/
	unsigned int length; /**< data length */
} see_data;

/**
 * @brief File Information in secure storage
 */
typedef struct {
	char name[20]; /**< file name */
	unsigned int attr; /**< data type */
} see_storage_file;

/**
 * @brief File List of secure storage
 */
typedef see_storage_file *see_storage_list;

/**
 * @brief Cryptography algorithm
 */
typedef enum {
	AES_ALGORITHM = 0x0000,
	AES_128 = AES_ALGORITHM, /**< 128 bits aes algorithm */
	AES_192, /**< 192 bits aes algorithm */
	AES_256, /**< 256 bits aes algorithm */
	RSA_ALGORITHM = 0x1000,
	RSA_1024 = RSA_ALGORITHM, /**< 1024 bits rsa algorithm */
	RSA_2048, /**< 2048 bits rsa algorithm */
	RSA_3072, /**< 3072 bits rsa algorithm */
	ECC_ALGORITHM = 0x2000,
	ECC_BRAINPOOL_P256R1 = ECC_ALGORITHM, /**< ecc brainpool curve for p256r1 */
	ECC_BRAINPOOL_P384R1, /**< ecc brainpool curve for p384r1 */
	ECC_BRAINPOOL_P512R1, /**< ecc brainpool curve for p512r1 */
	ECC_SEC_P256R1, /**< nist curve for p256r1 */
	ECC_SEC_P384R1, /**< nist curve for p384r1 */
	ECC_SEC_P521R1, /**< nist curve for p521r1 */
	HASH_ALGORITHM = 0x3000,
	HASH_MD5 = HASH_ALGORITHM, /**< md5 hash algorithm */
	HASH_SHA1, /**< sha1 hash algorithm */
	HASH_SHA224, /**< sha224 hash algorithm */
	HASH_SHA256, /**< sha256 hash algorithm */
	HASH_SHA384, /**< sha384 hash algorithm */
	HASH_SHA512, /**< sha512 hash algorithm */
	HMAC_ALGORITHM = 0x4000,
	HMAC_MD5 = HMAC_ALGORITHM, /**< hmac with md5 */
	HMAC_SHA1, /**< hmac with sha1 */
	HMAC_SHA224, /**< hmac with sha224 */
	HMAC_SHA256, /**< hmac with sha256 */
	HMAC_SHA384, /**< hmac with sha384 */
	HMAC_SHA512 /**< hmac with sha512 */
} see_algorithm;

/**
 * @brief aes mode
 */
typedef enum {
	AES_ECB_NOPAD = 0, /**< aes128 ecb nopad mode */
	AES_ECB_ISO9797_M1 = 1, /**< aes128 ecb iso9797 m1 mode */
	AES_ECB_ISO9797_M2 = 2, /**< aes128 ecb iso9797 m2 mode */
	AES_ECB_PKCS5 = 3, /**< aes128 ecb pkcs5 mode */
	AES_ECB_PKCS7 = 4, /**< aes128 ecb pkcs7 mode */
	AES_CBC_NOPAD = 5, /**< aes128 cbc nopad mode */
	AES_CBC_ISO9797_M1 = 6, /**< aes128 cbc iso9797 m1 mode */
	AES_CBC_ISO9797_M2 = 7, /**< aes128 cbc iso9797 m2 mode */
	AES_CBC_PKCS5 = 8, /**< aes128 cbc pkcs5 mode */
	AES_CBC_PKCS7 = 9, /**< aes128 cbc pkcs7 mode */
	AES_CTR = 10 /**< aes128 ctr nopad mode */
} see_aes_mode;

/**
 * @brief rsa mode
 */
typedef enum {
	RSAES_PKCS1_V1_5 = 0, /**< rsaes pkcs1 v1_5 for enc/dec */
	RSAES_PKCS1_OAEP_MGF1_SHA1 = 1, /**< rsaes pkcs1 oaep mgf1 sha1 for enc/dec */
	RSAES_PKCS1_OAEP_MGF1_SHA224 = 2, /**< rsaes pkcs1 oaep mgf1 sha224 for enc/dec */
	RSAES_PKCS1_OAEP_MGF1_SHA256 = 3, /**< rsaes pkcs1 oaep mgf1 sha256 for enc/dec */
	RSAES_PKCS1_OAEP_MGF1_SHA384 = 4, /**< rsaes pkcs1 oaep mgf1 sha384 for enc/dec */
	RSAES_PKCS1_OAEP_MGF1_SHA512 = 5, /**< rsaes pkcs1 oaep mgf1 sha512 for enc/dec */
	RSASSA_PKCS1_V1_5_MD5 = 6, /**< rsaes pkcs1 v1_5 md5 for sign/verify */
	RSASSA_PKCS1_V1_5_SHA1 = 7, /**< rsaes pkcs1 v1_5 sha1 for sign/verify */
	RSASSA_PKCS1_V1_5_SHA224 = 8, /**< rsaes pkcs1 v1_5 sha224 for sign/verify */
	RSASSA_PKCS1_V1_5_SHA256 = 9, /**< rsaes pkcs1 v1_5 sha256 for sign/verify */
	RSASSA_PKCS1_V1_5_SHA384 = 10, /**< rsaes pkcs1 v1_5 sha384 for sign/verify */
	RSASSA_PKCS1_V1_5_SHA512 = 11, /**< rsaes pkcs1 v1_5 sha512 for sign/verify */
	RSASSA_PKCS1_PSS_MGF1_SHA1 = 12, /**< rsaes pkcs1 pss mgf1 sha1 for sign/verify */
	RSASSA_PKCS1_PSS_MGF1_SHA224 = 13, /**< rsaes pkcs1 pss mgf1 sha224 for sign/verify */
	RSASSA_PKCS1_PSS_MGF1_SHA256 = 14, /**< rsaes pkcs1 pss mgf1 sha256 for sign/verify */
	RSASSA_PKCS1_PSS_MGF1_SHA384 = 15, /**< rsaes pkcs1 pss mgf1 sha384 for sign/verify */
	RSASSA_PKCS1_PSS_MGF1_SHA512 = 16, /**< rsaes pkcs1 pss mgf1 sha512 for sign/verify, not support rsa1024 */
} see_rsa_mode;

/**
 * @brief ecdsa curve
 */
typedef enum {
	ECDSA_BRAINPOOL_P256R1 = 0, /**< brainpool curve for P256 */
	ECDSA_BRAINPOOL_P384R1 = 1, /**< brainpool curve for P384r1 */
	ECDSA_BRAINPOOL_P512R1 = 2, /**< brainpool curve for P512r1 */
	ECDSA_SEC_P256R1 = 3, /**< nist curve for P256r1 */
	ECDSA_SEC_P384R1 = 4, /**< nist curve for P384r1 */
	ECDSA_SEC_P521R1 = 5, /**< nist curve for P521r1 */
} see_ecdsa_curve;

/**
 * @brief csr
 */
typedef struct {
	unsigned char issuer_country[128]; /**< issuer country */
	unsigned char issuer_organization[128]; /**< issuer organization */
	unsigned char issuer_cn[128]; /**< issuer cn */
	unsigned char issuer_keyname[20]; /**< issuer key name in secure storage */
	unsigned int issuer_algorithm; /**< algorithm of issuer key, refer to see_algorithm */
	unsigned char subject_country[128]; /**< subject country */
	unsigned char subject_organization[128]; /**< subject organization */
	unsigned char subject_cn[128]; /**< subject cn */
	unsigned char subject_keyname[20]; /**< subject key name in secure storage */
	unsigned int subject_algorithm; /**< algorithm of subject key, refer to see_algorithm */
	unsigned int serial; /**< certificate serial */
	unsigned int cert_years; /**< certificate expiration date */
} see_csr;

/**
 * @brief Initialize see
 *
 * - Initialize 'see' for using the API and determine supported API functionality.
 * - Find secure devices such as Secure Element and Secure OS and initialize the devices.
 * - With Secure OS, a user must enter ID nad PASSWORD for using the APIs.
 * - If the user wants to access the same Secure Storage next time, the same ID and PWD must be used.
 * - Without a Secure OS, a user can enter NULL for ID and PWD.
 *
 * @param[in] id  : User id for APIs
 * @param[in] pwd : User password for APIs
 * @returns 0 if succeeded. Returns other value if failed.
 * @see see_deinit()
 */
int see_init(const char *id, const char *pwd);

/**
 * @brief Deinitialize see
 *
 * - Finalize see.
 *
 * @returns 0 if succeeded. Returns other value if failed.
 * @see see_init
 */
int see_deinit(void);
#ifdef __cpluscplus
}
#endif
/**
 * @}
 */
#endif
