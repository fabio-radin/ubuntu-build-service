/*
 * Copyright (c) 2016 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the License);
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __ARTIK_SEE_KEY_MANAGER__H
#define __ARTIK_SEE_KEY_MANAGER__H

#include <artik/security/see_common.h>

/**
 * @file see_key_manager.h
 * @brief key manager api
 *
 * @example see-keymanager-test.c
 */

/**
 * @ingroup Security
 * @defgroup see_key_manager See_Key_Manager
 * @brief Key Management API
 *
 * This API provides an interface for Key Management
 * @{
 */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Generates symmetric and asymmetric keys.
 *
 * - Generate symmetric and asymmetric keys.
 * - A generated key is stored in secure storage.
 * - A key in secure storage cannot be overwritten.
 * - If a user wants to generate a key in special storage,
 *   the user should prefix a location with index.
 * <PRE>
 * 	1. SE Storage       : SE/
 * 	2. TEMP Storage     : TMP/
 * 	 - TEMP Storage save a data on volatile memory,
 * 	   so the data is discarded when finalizing API.
 * </PRE>
 * - Limitations
 * <PRE>
 * 	1. TEE Storage
 *		1) Algorithm : AES_128,
 *		               AES_192,
 *		               AES_256,
 *		               RSA_1024,
 *		               RSA_2048,
 *		               ECC_BRAINPOOL_P256R1,
 *		               ECC_BRAINPOOL_P384R1,
 *		               ECC_BRAINPOOL_P512R1,
 *		               ECC_SEC_P256R1,
 *		               ECC_SEC_P384R1,
 *		               ECC_SEC_P521R1,
 *		               HMAC_MD5,
 *		               HMAC_SHA1,
 *		               HMAC_SHA224,
 *		               HMAC_SHA256,
 *		               HMAC_SHA384,
 *		               HMAC_SHA512
 *		2) Capacity  : Irrespective of data type, 1024 files in TEE Storage
 *		3) Key name  : 20 characters max length
 *	2. SE Storage
 *		1) Algorithm : AES_128,
 *		               AES_256
 *		2) Capacity  : SE/0 ~ 14 for AES_256,
 *		               SE/15 ~ 30 for AES_128
 *		3) Key name  : 5 characters max length include “SE/” prefix (“SE/”)
 *	3. TEMP Storage
 *	    1) Algorithm : AES_128,
 *		               AES_192,
 *		               AES_256,
 *		               RSA_1024,
 *		               RSA_2048,
 *		               ECC_BRAINPOOL_P256R1,
 *		               ECC_BRAINPOOL_P384R1,
 *		               ECC_BRAINPOOL_P512R1,
 *		               ECC_SEC_P256R1,
 *		               ECC_SEC_P384R1,
 *		               ECC_SEC_P521R1,
 *		               HMAC_MD5,
 *		               HMAC_SHA1,
 *		               HMAC_SHA224,
 *		               HMAC_SHA256,
 *		               HMAC_SHA384,
 *		               HMAC_SHA512
 *		2) Capacity  : TMP/0 ~ 3 for Irrespective of data type
 *		3) Key name  : 6 characters max length include “TMP/” prefix (“TMP/”)
 * </PRE>
 *
 * @param[in] algo     : Key algorithm.
 * @param[in] key_name : Key name in secure storage.
 * @param[in] pub_key  : If key pair is asymmetric, public key will be returned when a user enter key argument.
 * @returns 0 if succeeded. Returns other value if failed.
 * @see enum see_algorithm
 * @see struct see_data
 */
int see_generate_key(see_algorithm algo, const char *key_name, see_data *pub_key);

/**
 * @brief Set external key.
 *
 * - Store external keys which the user generated in secure storage.
 * - A key in secure storage cannot be overwritten.
 * - If a user wants to store a key in special storage,
 *   the user should prefix a location with index.
 * <PRE>
 * 	1. SE Storage       : SE/
 * 	2. TEMP Storage     : TMP/
 * 	 - TEMP Storage save a data on volatile memory,
 * 	   so the data is discarded when finalizing API.
 * </PRE>
 * - Limitations
 * <PRE>
 * 	1. TEE Storage
 * 		1) Algorithm : AES_128,
 * 		               AES_192,
 * 		               AES_256,
 * 		               RSA_1024,
 *		               RSA_2048,
 *		               ECC_BRAINPOOL_P256R1,
 *		               ECC_BRAINPOOL_P384R1,
 *		               ECC_BRAINPOOL_P512R1,
 *		               ECC_SEC_P256R1,
 *		               ECC_SEC_P384R1,
 *		               ECC_SEC_P512R1,
 *		               HMAC_MD5,
 *		               HMAC_SHA1,
 *		               HMAC_SHA224,
 *		               HMAC_SHA256,
 *		               HMAC_SHA384,
 *		               HMAC_SHA512
 * 		2) Capacity  : Irrespective of data type, 1024 files in TEE Storage
 * 		3) Key name  : 20 characters max length
 * 	2. SE Storage
 * 		1) Algorithm : AES_128,
 * 		               AES_256
 * 		2) Capacity  : SE/0 ~ 14 for AES_256,
 * 		               SE/15 ~ 30 for AES_128
 * 		3) Key name  : 5 characters max length include “SE/” prefix (“SE/”)
 * 	3. TEMP Storage
 * 		1) Algorithm : AES_128,
 * 		               AES_192,
 * 		               AES_256,
 * 		               RSA_1024,
 *		               RSA_2048,
 *		               ECC_BRAINPOOL_P256R1,
 *		               ECC_BRAINPOOL_P384R1,
 *		               ECC_BRAINPOOL_P512R1,
 *		               ECC_SEC_P256R1,
 *		               ECC_SEC_P384R1,
 *		               ECC_SEC_P512R1,
 *		               HMAC_MD5,
 *		               HMAC_SHA1,
 *		               HMAC_SHA224,
 *		               HMAC_SHA256,
 *		               HMAC_SHA384,
 *		               HMAC_SHA512
 * 		2) Capacity  : TMP/0 ~ 3 for Irrespective of data type
 * 		3) Key name  : 6 characters max length include “TMP/” prefix (“TMP/”)
 * </PRE>
 *
 * @param[in] algo     : Key algorithm.
 * @param[in] key_name : Key name in secure storage.
 * @param[in] key      : External key data will be stored in secure storage.
 * @returns 0 if succeeded. Returns other value if failed.
 * @see enum see_algorithm
 * @see struct see_data
 */
int see_set_key(see_algorithm algo, const char *key_name, see_data key);

/**
 * @brief Get public key of asymmetric key from secure storage.
 *
 * - Get a public key from secure storage.
 * - In case of a symmetric key, it cannot get a public key.
 * - If a user wants to get a public key from special storage,
 *   the user should prefix a location with index.
 * <PRE>
 * 	1. TEMP Storage     : TMP/
 * 	 - TEMP Storage save a data on volatile memory,
 * 	   so the data is discarded when finalizing API.
 * 	2. ARTIK Credential : ARTIK/
 * 	3. Post Provision   : POSTP/
 * </PRE>
 * - Limitations
 * <PRE>
 * 	1. TEE Storage
 * 		1) Algorithm : RSA_1024,
 * 		               RSA_2048,
 * 		               ECC_BRAINPOOL_P256R1,
 * 		               ECC_BRAINPOOL_P384R1,
 * 		               ECC_BRAINPOOL_P512R1,
 * 		               ECC_SEC_P256R1,
 * 		               ECC_SEC_P384R1,
 * 		               ECC_SEC_P521R1
 * 		2) Key name  : 20 characters max length
 * 	2. TEMP Storage
 * 		1) Algorithm : RSA_1024,
 * 		               RSA_2048,
 * 		               ECC_BRAINPOOL_P256R1,
 * 		               ECC_BRAINPOOL_P384R1,
 * 		               ECC_BRAINPOOL_P512R1,
 * 		               ECC_SEC_P256R1,
 * 		               ECC_SEC_P384R1,
 * 		               ECC_SEC_P521R1
 * 		2) Key name  : 6 characters max length include “TMP/” prefix (“TMP/”)
 * 	3. ARTIK Credential
 * 		1) Algorithm : ECC_BRAINPOOL_P256R1
 * 		2) Key name  : 7 characters max length include “ARTIK/” prefix (“ARTIK/”)
 * 	4. Post Provision
 * 		1) Algorithm : RSA_2048,
 * 		               ECC_BRAINPOOL_P256R1,
 * 		               ECC_SEC_P256R1
 * 		2) Key name  : 7 characters max length include “POSTP/” prefix (“POSTP/”)
 * </PRE>
 *
 * @param[in] algo     : Key algorithm.
 * @param[in] key_name : Key name in secure storage
 * @param[in] pub_key  : If key pair is asymmetric, public key will be returned.
 * @returns 0 if succeeded. Returns other value if failed.
 * @see enum see_algorithm
 * @see struct see_data
 */
int see_get_pubkey(see_algorithm algo, const char *key_name, see_data *pub_key);

/**
 * @brief Remove key from secure storage
 *
 * - Remove a key from secure storage.
 * - If a user wants to remove a key in special storage,
 *   the user should prefix a location with index.
 * <PRE>
 * 	1. SE Storage       : SE/
 * 	2. TEMP Storage     : TMP/
 * 	 - TEMP Storage save a data on volatile memory,
 * 	   so the data is discarded when finalizing API.
 * </PRE>
 * - Limitations
 * <PRE>
 * 	1. TEE Storage
 * 		1) Algorithm : AES_128,
 * 		               AES_192,
 * 		               AES_256,
 * 		               RSA_1024,
 * 		               RSA_2048,
 * 		               ECC_BRAINPOOL_P256R1,
 * 		               ECC_BRAINPOOL_P384R1,
 * 		               ECC_BRAINPOOL_P521R1,
 * 		               ECC_SEC_P256R1,
 * 		               ECC_SEC_P384R1,
 * 		               ECC_SEC_P521R1,
 * 		               HMAC_MD5,
 * 		               HMAC_SHA1,
 * 		               HMAC_SHA224,
 * 		               HMAC_SHA256,
 * 		               HMAC_SHA384,
 * 		               HMAC_SHA512
 * 		2) Key name  : 20 characters max length
 * 	2. SE Storage
 * 		1) Algorithm : AES_128,
 * 		               AES_256
 * 		2) Key name  : 5 characters max length include “SE/” prefix (“SE/”)
 * 	3. TEMP Storage
 * 		1) Algorithm : AES_128,
 * 		               AES_192,
 * 		               AES_256,
 * 		               RSA_1024,
 * 		               RSA_2048,
 * 		               ECC_BRAINPOOL_P256R1,
 * 		               ECC_BRAINPOOL_P384R1,
 * 		               ECC_BRAINPOOL_P521R1,
 * 		               ECC_SEC_P256R1,
 * 		               ECC_SEC_P384R1,
 * 		               ECC_SEC_P521R1,
 * 		               HMAC_MD5,
 * 		               HMAC_SHA1,
 * 		               HMAC_SHA224,
 * 		               HMAC_SHA256,
 * 		               HMAC_SHA384,
 * 		               HMAC_SHA512
 * 		2) Key name  : 6 characters max length include “TMP/” prefix (“TMP/”)
 * </PRE>
 *
 * @param[in] algo     : Key algorithm.
 * @param[in] key_name : Key name in secure storage.
 * @returns 0 if succeeded. Returns other value if failed.
 * @see enum see_algorithm
 */
int see_remove_key(see_algorithm algo, const char *key_name);

#ifdef __cpluscplus
}
#endif
/**
 * @}
 */
#endif
