/*
 * Copyright (c) 2016 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the License);
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *		http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __ZIGBEE_UTIL_H
#define __ZIGBEE_UTIL_H

/**
 * @file	zigbee_util.h
 * @brief	Artik ZigBee util functions
 *
 * This module includes ZigBee util functions.
 * @{
 */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief		Get the Illuminance Lux value according to MeasuredValue
 *
 * @param [in]	measured_value	Measured value, in the range 1 to 65534(0xfffe).
 * @param [out]	lux				The Lux value to be returned.
 *
 *								MeasuredValue represents the Illuminance in
 *								Lux (symbol lx) as follows:
 *								MeasuredValue = 10,000 x log10 Illuminance + 1
 *
 *								e.g. The measured value 10001 means 10 lx.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_illum_measured_value_to_lux(int measured_value, double *lux);

/**
 * @brief		Get the Illuminance MeasuredValue according to Lux value
 *
 * @param [in]	lux				The Lux value, in the range 1 lx to 3.576 x 10^6 lx.
 * @param [out]	measured_value	Measured value to be returned.
 *
 *								MeasuredValue represents the Illuminance in
 *								Lux (symbol lx) as follows:
 *								MeasuredValue = 10,000 x log10 Illuminance + 1
 *
 *								e.g. The measured value 10001 means 10 lx.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_illum_lux_to_measured_value(double lux, int *measured_value);

/**
 * @brief		Get the temperature in degrees Celsius according to the Local Temperature,
 *				Temperature Measured Value or setpoint.
 *
 * @param [in]	temperature	The Local Temperature, Temperature Measured Value or setpoint.
 * @param [out]	celsius		The temperature in degrees Celsius to be returned.
 *
 *							The LocalTemperature, in the range 0x954d to 0x7fff.
 *							LocalTemperature = 100 x temperature in degrees Celsius.
 *							Where -273.15 Celsius <= temperature <= 327.67 Celsius,
 *							corresponding to a LocalTemperature in the range 0x954d to 0x7fff.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_temperature_to_celsius(int temperature, float *celsius);

/**
 * @brief		Get the Local Temperature, Temperature Measured Value or setpoint according
 *				to the temperature in degrees Celsius.
 *
 * @param [in]	celsius		The temperature in degrees Celsius.
 * @param [out]	temperature	The Local Temperature, Temperature Measured Value or setpoint
 *							to be returned.
 *
 *							The LocalTemperature, in the range 0x954d to 0x7fff.
 *							LocalTemperature = 100 x temperature in degrees Celsius.
 *							Where -273.15 Celsius <= temperature <= 327.67 Celsius,
 *							corresponding to a LocalTemperature in the range 0x954d to 0x7fff.
 *
 * @return		Result of operation, EZ_OK on success, error code otherwise.
 */
int zigbee_celsius_to_temperature(float celsius, int *temperature);

/**
 * @}
 */

#ifdef __cplusplus
}
#endif
#endif	/*__ZIGBEE_UTIL_H*/

