#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <string.h>
#include <assert.h>

#include "zigbee_test_common.h"

#define EASY_PJOIN_DURATION			0x3C
#define EASY_IDENTIFY_DURATION		10	/* seconds */
#define ILLUMINANCE_MIN				100
#define ILLUMINANCE_MAX				10000
#define ILLUMINANCE_STEP			50
#define TEMPERATURE_MIN				(-273.15f)	/* celsius */
#define TEMPERATURE_MAX				(327.67f)
#define TEMPERATURE_STEP			(10.0f)
#define REPORTING_MAX_COUNT			3
#define CS_TARGET_TIMEOUT_SEC		60	/* steering will cost much time */
#define CS_INITIATOR_RETRY_COUNT	5
#define NWK_FIND_MAX_SIZE			8
#define TRY_AGAIN					100
#define NO_PROMPT					101
#define DISCOVER_ATTRIBUTE_COUNT	10
#define TEST_GROUP_ID				0x7A

enum operation_nwk_test {
	OPT_NWK_FOMR = 1,
	OPT_NWK_FORM_ADV,
	OPT_NWK_JOIN,
	OPT_NWK_JOIN_ADV,
	OPT_NWK_FIND_AND_JOIN,
	OPT_NWK_STOP_SCAN,
	OPT_NWK_LEAVE,
	OPT_NWK_PERMIT_JOIN,
	OPT_NWK_DISCOVER_DEVICE,
	OPT_NWK_GET_DISCOVERED_DEVICE,
	OPT_NWK_COMMISSION_OPERATION,
	OPT_NWK_START_TEST
};

enum operation_main_test {
	OPT_MAIN_SETUP_NETWORK = 0,
	OPT_MAIN_GET_NODE_INFO,
	OPT_MAIN_AUTO_TEST,
	OPT_MAIN_IDENDITY,
	OPT_MAIN_ON_OFF,
	OPT_MAIN_LEVEL_CONTROL,
	OPT_MAIN_ILLUM_MEASUREMENT,
	OPT_MAIN_OCCUPANCY_SENSOR,
	OPT_MAIN_TEMPERATURE_SENSOR,
	OPT_MAIN_HUMIDITY,
	OPT_MAIN_BIND_TEST,
	OPT_MAIN_REMOTE_CONTROL,
	OPT_MAIN_THERMOSTAT,
	OPT_MAIN_REPORTING_TEST,
	OPT_MAIN_GROUPS,
	OPT_MAIN_GENERAL_TEST,
	OPT_MAIN_ZDO_TEST,
	OPT_MAIN_ZCL_RAW_COMMAND_TEST
};

enum operation_thermostat_test {
	OPT_THERMOSTAT_CLIENT = 1,
	OPT_THERMOSTAT_SERVER_SET,
	OPT_THERMOSTAT_SERVER_GET
};

enum commissioning_operation {
	COMMISSION_OPT_TARGET_START = 1,
	COMMISSION_OPT_INITIATOR_START,
	COMMISSION_OPT_FACTORY_RESET,
	COMMISSION_OPT_NETWORK_STEERING,
	COMMISSION_OPT_BROADCAST_PERMITJOIN,
	COMMISSION_OPT_FIND_BIND_TARGET_START,
	COMMISSION_OPT_FIND_BIND_INITIATOR_START,
	/*
	 * 1 BROADCAST_IDENTIFY_QUERY
	 * 2 IEEE_ADDR_REQUEST
	 * 3 SIMPLE_DESCRIPTOR_REQUEST
	 * */
	COMMISSION_OPT_QUERY_DEVICE,
	COMMISSION_OPT_BROADCAST_MATCH_DESC_REQUEST,
	COMMISSION_OPT_NONE
};

enum operation_zdo_test {
	OPT_ZDO_NODE_ID_REQUEST = 1,
	OPT_ZDO_IEEE_REQUEST,
	OPT_ZDO_NODE_DESCRIPTOR_REQUEST,
	OPT_ZDO_POWER_DESCRIPTOR_REQUEST,
	OPT_ZDO_ACTIVE_ENDPOINTS_REQUEST,
	OPT_ZDO_SIMPLE_DESCRIPTOR_REQUEST,
	OPT_ZDO_MATCH_DESCRIPTOR_BROADCAST_REQUEST,
	OPT_ZDO_ROUTING_TABLE_REQUEST,
	OPT_ZDO_LQI_TABLE_REQUEST,
	OPT_ZDO_LEAVE_REQUEST
};

enum bind_api {
	OPT_BIND_GET = 1,
	OPT_BIND_SET,
	OPT_BIND_DELETE,
	OPT_BIND_CLEAR,
	OPT_BIND_END_DEVICE_REQUEST,
	OPT_BIND_UNICAST_REQUEST,
	OPT_BIND_GROUP_REQUEST,
	OPT_BINDING_TABLE_REQUEST
};

enum operation_reporting_test {
	OPT_REPORTING_MAIN_TESTING = 0,
	OPT_REPORTING_OCCUPANCY_REPORTING,
	OPT_REPORTING_MEASURED_TEMPERATURE_REPORTING,
	OPT_REPORTING_MEASURED_ILLUMINANCE_REPORTING,
	OPT_REPORTING_MEASURED_HUMIDITY_REPORTING
};

enum operation_general_test {
	OPT_GENERAL_MAIN_TESTING = 0,
	OPT_GENERAL_READ_LOCAL_ATTRIBUTE,
	OPT_GENERAL_WRITE_LOCAL_ATTRIBUTE,
	OPT_GENERAL_READ_REMOTE_ATTRIBUTE,
	OPT_GENERAL_WRITE_REMOTE_ATTRIBUTE,
	OPT_GENERAL_REQUEST_REPORTING,
	OPT_GENERAL_STOP_REPORTING,
	OPT_GENERAL_READ_REPORTING_CONFIG,
	OPT_GENERAL_DISCOVERY_ATTRIBUTE
};

enum zcl_raw_command_argument_step {
	RAW_COMMAND_DEST_NODE = 0,
	RAW_COMMAND_DEST_EP,
	RAW_COMMAND_LOCAL_EP,
	RAW_COMMAND_MANUFACTURE_CODE,
	RAW_COMMAND_DIRECTION,
	RAW_COMMAND_CLUSTER_ID,
	RAW_COMMAND_COMMAND_ID,
	RAW_COMMAND_PAYLOAD
};

enum zcl_raw_command_argument_type {
	ARGUMENT_DATA_TYPE = 0,
	ARGUMENT_DATA_COUNT,
	ARGUMENT_DATA_CONTENT
};

enum operation_zcl_raw_command_test {
	OPT_ZCL_RAW_MAIN_TESTING = 0,
	OPT_ZCL_RAW_SEND_COMMAND
};

struct ieee_desc_request {
	bool ieee_request;
	int node_id;
	int target_endpoint;
	struct ieee_desc_request *next;
};

static struct device_type device_types[] = {
	{ ZIGBEE_PROFILE_HA, DEVICE_ON_OFF_SWITCH, 0,
	  1, "On/Off Switch" },
	{ ZIGBEE_PROFILE_HA, DEVICE_LEVEL_CONTROL_SWITCH, 0,
	  2, "Level Control Switch" },
	{ ZIGBEE_PROFILE_HA, DEVICE_ON_OFF_LIGHT, 0,
	  19, "On/Off Light" },
	{ ZIGBEE_PROFILE_HA, DEVICE_DIMMABLE_LIGHT, 0,
	  20, "Dimmable Light" },
	{ ZIGBEE_PROFILE_HA, DEVICE_LIGHT_SENSOR, 0,
	  25, "Light Sensor" },
	{ ZIGBEE_PROFILE_HA, DEVICE_OCCUPANCY_SENSOR, 0,
	  26, "Occupancy Sensor" },
	{ ZIGBEE_PROFILE_HA, DEVICE_TEMPERATURE_SENSOR, 0,
	  33, "Temperature Sensor" },
	{ ZIGBEE_PROFILE_HA, DEVICE_REMOTE_CONTROL, 0,
	  7, "Remote Control" },
	{ ZIGBEE_PROFILE_HA, DEVICE_IAS_CONTROL_AND_INDICATING_EQUIPMENT, 0,
	  38, "IAS Control and Indication Equipment" },
	{ ZIGBEE_PROFILE_HA, DEVICE_THERMOSTAT, THERMOSTAT_CONTROLLER_DEVICE_VERSION,
	  32, "Thermostat (Controller)" },
	{ ZIGBEE_PROFILE_HA, DEVICE_THERMOSTAT, THERMOSTAT_HUMIDITY_SENSOR_DEVICE_VERSION,
	  42, "Thermostat (Humidity sensor)" },

	{ -1, -1, -1, -1, NULL}
};

static const char * const zdo_routing_entry_status[] = {
	"ACTIVE",
	"DISCOVERY_UNDERWAY",
	"DISCOVERY_FAILED",
	"INACTIVE",
	"VALIDATION_UNDERWAY",
	"RESERVED",
	"RESERVED",
	"RESERVED"
};

struct {
	int count;
	struct test_device device[MAX_ENDPOINT_SIZE];
} local_commission_devices;

enum set_zcl_parameter_step {
	STEP_SET_PARAM_TYPE = 1,
	STEP_SET_U8,
	STEP_SET_U16,
	STEP_SET_U32,
	STEP_SET_ARRAY8_SIZE,
	STEP_SET_ARRAY8_VALUE,
	STEP_SET_ARRAY16_SIZE,
	STEP_SET_ARRAY16_VALUE,
	STEP_SET_ARRAY32_SIZE,
	STEP_SET_ARRAY32_VALUE,
	STEP_SET_STRING
};

struct {
	int dest_node_id;
	int dest_endpoint;
	int local_endpoint;
	uint16_t manufacturer_code;
	bool client_to_server;
	ZIGBEE_CLUSTER_ID cluster_id;
	uint8_t command_id;
	struct zigbee_raw_data_payload payload;
} zcl_raw_data;

static func current_func;
static int illuminance_value = ILLUMINANCE_MIN;
static int illuminance_min = ILLUMINANCE_MIN;
static int illuminance_max = ILLUMINANCE_MAX;

static int reporting_measured_illum_count = 0;
static int reporting_occupancy_count = 0;
static int identify_endpoint_id = -1;
static int ieee_descriptor_requesting = false;
static int ieee_descriptor_periodic_id = -1;
struct ieee_desc_request *ieee_desc_request_head = NULL;
struct ieee_desc_request *ieee_desc_request_tail = NULL;
static bool got_eui = false;
static char eui64[EUI64_SIZE];
static int set_binding_index;
static int delete_binding_index;
static int reporting_measured_temp_count = 0;
static int reporting_measured_humidity_count = 0;
zigbee_network_find_result nwk_found_list[NWK_FIND_MAX_SIZE];
static int nwk_find_size = 0;
static int end_device_bind_index = 0;
static zigbee_thermostat_control_sequence thermostat_control_sequence = ZIGBEE_CONTROL_SEQUENCE_RESERVED;
static zigbee_occupancy_status thermostat_occupancy_status = ZIGBEE_UNOCCUPIED;
static zigbee_thermostat_system_mode thermostat_system_mode = ZIGBEE_SYSTEM_MODE_RESERVED;
static int thermostat_temperature = 100;

const char *zc_type = "COORDINATOR";
const char *zr_type = "ROUTER";
const char *zed_type = "END DEVICE";
const char *parent = "PARENT";
const char *child = "CHILD";
const char *sibling = "SIBLING";
const char *zigbee_raw_command_prefix = "zigbee_raw_command_cli";

static GMainLoop *mainloop = NULL;

static void _func_main(char *input, int max_size);
static void _func_network(char *input, int max_size);
static void _func_network_find_join(char *input, int max_size);
static void _func_commission_target_start(char *input, int max_size);
static void _func_commission_initiator_start(char *input, int max_size);
static void _func_commisioning_operation(char *input, int max_size);
static void _func_zcl_raw_command(char *input, int max_size);
static int _on_timer_callback(enum timer_command cmd, int id, void *user_data);
static void _on_callback(void *user_data,
						 zigbee_response_type response_type,
						 void *payload);
static void _func_bind_api(char *input, int max_size);

static int _get_device_type_count()
{
	int count = 0;

	for (count = 0;; count++) {
		if (device_types[count].name == NULL)
			break;
	}

	return count;
}

static struct device_type *_get_device_type(int index)
{
	if (index >= _get_device_type_count())
		return NULL;

	return &device_types[index];
}

char* get_device_name(int device_id)
{
	int i = 0;

	while (device_types[i].name != NULL) {
		if (device_types[i].device_id == device_id)
			return device_types[i].name;
		i++;
	}

	return NULL;
}

static zigbee_error _identify_test()
{
	zigbee_endpoint_list endpoint_list;
	struct zigbee_sending_info sending_info;
	zigbee_local_endpoint info;
	zigbee_endpoint *endpoint;
	struct test_device *test_device;
	int i, j, count;
	int remained_time, duration;
	zigbee_error ret = EZ_OK;
	bool is_supported;

	is_supported = false;
	count = get_test_device_count();
	for (i = 0; i < count; i++) {
		test_device = get_test_device(i);
		if (test_device->identify_request != NULL &&
			test_device->identify_get_remaining_time != NULL) {
			is_supported = true;
			break;
		}
	}

	if (is_supported == false)
		return EZ_NOT_SUPPORTED;

	ret = zigbee_device_find_by_cluster(&endpoint_list, ZCL_IDENTIFY_CLUSTER_ID, 1);
	if (EZ_OK != ret) {
		showln("Identify: Find endpoint by cluster failed: %s", zigbee_error_msg(ret));
		return ret;
	}

	ret = zigbee_get_local_endpoint_by_endpointid(&info, test_device->endpoint_id);
	if (EZ_OK != ret) {
		showln("wrong endpoint_id %d\n", test_device->endpoint_id);
		return EZ_ERROR;
	}

	if (zigbee_local_endpoint_contains_cluster(info.endpoint_id, ZCL_IDENTIFY_CLUSTER_ID, false) != EZ_OK) {
		showln("not supported operation\n");
		return EZ_ERROR;
	}

	for (; i < count; i++) {
		test_device = get_test_device(i);

		if (test_device->identify_request == NULL ||
			test_device->identify_get_remaining_time == NULL) {
			continue;
		}

		showln("Identify: testing started by ep(%d)", test_device->endpoint_id);

		for (j = 0; j < endpoint_list.num; j++) {
			endpoint = &endpoint_list.endpoint[j];
			sending_info.type = ZIGBEE_SENDING_BY_ENDPOINT;
			memcpy(&sending_info.data.dest_endpoint, endpoint, sizeof(zigbee_endpoint));

			ret = test_device->identify_request(&sending_info,
												EASY_IDENTIFY_DURATION + i,
												info.endpoint_id);
			if (ret == EZ_OK)
				showln("Identify: send request to node(0x%04X)",
					   endpoint->node_id);
			else {
				showln("Identify: send request failed: %s", zigbee_error_msg(ret));
				return ret;
			}
		}

		sleep((int)((EASY_IDENTIFY_DURATION + i) / 2));

		for (duration = 0; duration < (EASY_IDENTIFY_DURATION + i) / 2;
			 duration++) {
			for (j = 0; j < endpoint_list.num; j++) {
				endpoint = &endpoint_list.endpoint[j];
				sending_info.type = ZIGBEE_SENDING_BY_ENDPOINT;
				memcpy(&sending_info.data.dest_endpoint, endpoint, sizeof(zigbee_endpoint));

				ret = test_device->identify_get_remaining_time(&sending_info,
															   &remained_time,
															   info.endpoint_id);

				if (ret != EZ_OK) {
					fprintf(stderr, "Identify: get remaining time failed: %s\n",
							zigbee_error_msg(ret));
					return ret;
				}

				showln("Identify: remained time: %d", remained_time);

				if (remained_time == 0)
					break;
			}

			sleep(1);
		}

		showln("Identify: testing succeeded by ep(%d)",
			   test_device->endpoint_id);
	}

	return EZ_OK;
}

static zigbee_error _groups_test(void)
{
	zigbee_endpoint_list endpoint_list;
	struct zigbee_sending_info sending_info;
	zigbee_local_endpoint info;
	zigbee_endpoint *endpoint = NULL;
	struct test_device *test_device = NULL;
	zigbee_error ret = EZ_OK;
	int i, j, k, count;
	bool is_supported = false;
	zigbee_groups_info groups_info;

	count = get_test_device_count();
	for (i = 0; i < count; i++) {
		test_device = get_test_device(i);
		if (test_device->groups_command != NULL) {
			is_supported = true;
			break;
		}
	}

	if (is_supported == false)
		return EZ_NOT_SUPPORTED;

	ret = zigbee_device_find_by_cluster(&endpoint_list, ZCL_GROUPS_CLUSTER_ID, 1);
	if (EZ_OK != ret) {
		showln("Groups: Find endpoint by cluster failed: %s", zigbee_error_msg(ret));
		return ret;
	}

	for (; i < count; i++) {
		test_device = get_test_device(i);
		if (test_device->groups_command == NULL)
			continue;

		ret = zigbee_get_local_endpoint_by_endpointid(&info, test_device->endpoint_id);
		if (EZ_OK != ret)
			continue;

		if (zigbee_local_endpoint_contains_cluster(info.endpoint_id, ZCL_GROUPS_CLUSTER_ID,
				false) != EZ_OK)
			continue;

		showln("Groups: testing started by ep(%d)", test_device->endpoint_id);

		for (j = 0; j < endpoint_list.num; j++) {
			endpoint = &endpoint_list.endpoint[j];
			sending_info.type = ZIGBEE_SENDING_BY_ENDPOINT;
			memcpy(&sending_info.data.dest_endpoint, endpoint, sizeof(zigbee_endpoint));

			groups_info.group_cmd = ZIGBEE_GROUPS_REMOVE_ALL;
			ret = test_device->groups_command(&sending_info, &groups_info, info.endpoint_id);
			if (ret == EZ_OK)
				showln("Groups: send Remove All Groups to device(0x%04X)",
					   endpoint->node_id);
			else {
				showln("Groups: send Remove All Groups failed: %s", zigbee_error_msg(ret));
				return ret;
			}

			sleep(1);

			groups_info.group_cmd = ZIGBEE_GROUPS_ADD;
			groups_info.group_id[0] = TEST_GROUP_ID;
			strcpy((char *)groups_info.group_name, "zigbee");
			ret = test_device->groups_command(&sending_info, &groups_info, info.endpoint_id);
			if (ret == EZ_OK)
				showln("Groups: send Add Group to group id: %d, groups name: %s to device(0x%04X)",
					   groups_info.group_id[0], groups_info.group_name, endpoint->node_id);
			else {
				showln("Groups: send Add Group failed: %s", zigbee_error_msg(ret));
				return ret;
			}

			sleep(1);

			groups_info.group_cmd = ZIGBEE_GROUPS_VIEW;
			groups_info.group_id[0] = TEST_GROUP_ID;

			ret = test_device->groups_command(&sending_info, &groups_info, info.endpoint_id);
			if (ret == EZ_OK) {
				show("Groups: send View Group to device(0x%04X) group id: %d", endpoint->node_id,
						groups_info.group_id[0]);
				if (strlen((char *)groups_info.group_name) > 0)
					showln(" group name: %s", groups_info.group_name);
				else
					showln("");
			} else {
				showln("Groups: send View Group failed: %s", zigbee_error_msg(ret));
				return ret;
			}

			sleep(1);

			ret = test_device->identify_request(&sending_info,
								EASY_IDENTIFY_DURATION + i, info.endpoint_id);
			if (ret == EZ_OK)
				showln("Identify: send request to node(0x%04X)",
					   endpoint->node_id);
			else {
				showln("Identify: send request failed: %s", zigbee_error_msg(ret));
				return ret;
			}

			sleep(1);

			groups_info.group_cmd = ZIGBEE_GROUPS_ADD_IF_IDENTIFYING;
			groups_info.group_id[0] = TEST_GROUP_ID + 1;
			strcpy((char *)groups_info.group_name, "artik");
			ret = test_device->groups_command(&sending_info, &groups_info, info.endpoint_id);
			if (ret == EZ_OK)
				showln("Groups: send Add Group if identifying to group id: %d, groups name: %s to device(0x%04X)",
					   groups_info.group_id[0], groups_info.group_name, endpoint->node_id);
			else {
				showln("Groups: send Add Group if identifying failed: %s", zigbee_error_msg(ret));
				return ret;
			}

			sleep(1);

			groups_info.group_cmd = ZIGBEE_GROUPS_VIEW;
			groups_info.group_id[0] = TEST_GROUP_ID + 1;

			ret = test_device->groups_command(&sending_info, &groups_info, info.endpoint_id);
			if (ret == EZ_OK) {
				show("Groups: send View Group to device(0x%04X) group id: %d", endpoint->node_id,
						groups_info.group_id[0]);
				if (strlen((char *)groups_info.group_name) > 0)
					showln(" group name: %s", groups_info.group_name);
				else
					showln("");
			} else {
				showln("Groups: send View Group failed: %s", zigbee_error_msg(ret));
				return ret;
			}

			sleep(1);

			groups_info.group_cmd = ZIGBEE_GROUPS_GET_MEMBERSHIP;
			groups_info.group_id[0] = TEST_GROUP_ID;
			groups_info.group_count = 1;

			ret = test_device->groups_command(&sending_info, &groups_info, info.endpoint_id);

			if (ret == EZ_OK) {
				showln("Groups: send Get group membership to device(0x%04X), get %d groups",
						   endpoint->node_id, groups_info.group_count);
				for (k = 0; k < groups_info.group_count; k++)
					showln("Group membership: group id[%d]", groups_info.group_id[k]);
				showln("The remaining capacity of group table is %d", groups_info.capacity);
			} else {
				showln("Groups: send Get group membership failed: %s", zigbee_error_msg(ret));
				return ret;
			}

			sleep(1);

			groups_info.group_cmd = ZIGBEE_GROUPS_GET_MEMBERSHIP;
			groups_info.group_id[0] = TEST_GROUP_ID + 1;
			groups_info.group_count = 1;

			ret = test_device->groups_command(&sending_info, &groups_info, info.endpoint_id);

			if (ret == EZ_OK) {
				showln("Groups: send Get group membership to device(0x%04X), get %d groups",
						   endpoint->node_id, groups_info.group_count);
				for (k = 0; k < groups_info.group_count; k++)
					showln("Group membership: group id[%d]", groups_info.group_id[k]);
				showln("The remaining capacity of group table is %d", groups_info.capacity);
			} else {
				showln("Groups: send Get group membership failed: %s", zigbee_error_msg(ret));
				return ret;
			}

			groups_info.group_cmd = ZIGBEE_GROUPS_GET_MEMBERSHIP;
			groups_info.group_id[0] = TEST_GROUP_ID;
			groups_info.group_id[1] = TEST_GROUP_ID + 1;
			groups_info.group_count = 2;

			ret = test_device->groups_command(&sending_info, &groups_info, info.endpoint_id);

			if (ret == EZ_OK) {
				showln("Groups: send Get group membership to device(0x%04X), get %d groups",
						   endpoint->node_id, groups_info.group_count);
				for (k = 0; k < groups_info.group_count; k++)
					showln("Group membership: group id[%d]", groups_info.group_id[k]);
				showln("The remaining capacity of group table is %d", groups_info.capacity);
			} else {
				showln("Groups: send Get group membership failed: %s", zigbee_error_msg(ret));
				return ret;
			}

			sleep(1);

			groups_info.group_cmd = ZIGBEE_GROUPS_REMOVE;
			groups_info.group_id[0] = TEST_GROUP_ID + 1;
			ret = test_device->groups_command(&sending_info, &groups_info, info.endpoint_id);
			if (ret == EZ_OK)
				showln("Groups: send Remove Group group id: %d to device(0x%04X)",
					   groups_info.group_id[0], endpoint->node_id);
			else {
				showln("Groups: send Remove Group failed: %s", zigbee_error_msg(ret));
				return ret;
			}

			sleep(1);

			groups_info.group_cmd = ZIGBEE_GROUPS_GET_MEMBERSHIP;
			groups_info.group_count = 0;

			ret = test_device->groups_command(&sending_info, &groups_info, info.endpoint_id);

			if (ret == EZ_OK) {
				showln("Groups: send Get group membership to device(0x%04X), get %d groups",
						   endpoint->node_id, groups_info.group_count);
				for (k = 0; k < groups_info.group_count; k++)
					showln("Group membership: group id[%d]", groups_info.group_id[k]);
				showln("The remaining capacity of group table is %d", groups_info.capacity);
			} else {
				showln("Groups: send Get group membership failed: %s", zigbee_error_msg(ret));
				return ret;
			}

			sleep(1);

			groups_info.group_cmd = ZIGBEE_GROUPS_REMOVE_ALL;
			ret = test_device->groups_command(&sending_info, &groups_info, info.endpoint_id);
			if (ret == EZ_OK)
				showln("Groups: send Remove All Groups to device(0x%04X)",
					   endpoint->node_id);
			else {
				showln("Groups: send Remove All Groups failed: %s", zigbee_error_msg(ret));
				return ret;
			}
		}
	}

	return ret;
}

static zigbee_error _onoff_test()
{
	zigbee_endpoint_list endpoint_list;
	struct zigbee_sending_info sending_info;
	zigbee_local_endpoint info;
	zigbee_endpoint *endpoint;
	struct test_device *test_device;
	zigbee_error ret = EZ_OK;
	int i, j, count;
	bool is_supported;

	is_supported = false;
	count = get_test_device_count();
	for (i = 0; i < count; i++) {
		test_device = get_test_device(i);
		if (test_device->onoff_command != NULL) {
			is_supported = true;
			break;
		}
	}

	if (is_supported == false)
		return EZ_NOT_SUPPORTED;

	ret = zigbee_device_find_by_cluster(&endpoint_list, ZCL_ON_OFF_CLUSTER_ID, 1);
	if (EZ_OK != ret) {
		showln("On/Off: Find endpoint by cluster failed: %s", zigbee_error_msg(ret));
		return ret;
	}

	for (; i < count; i++) {
		test_device = get_test_device(i);
		if (test_device->onoff_command == NULL)
			continue;

		ret = zigbee_get_local_endpoint_by_endpointid(&info, test_device->endpoint_id);
		if (EZ_OK != ret) {
			continue;
		}

		if (zigbee_local_endpoint_contains_cluster(info.endpoint_id, ZCL_ON_OFF_CLUSTER_ID,
				false) != EZ_OK) {
			continue;
		}
		showln("On/off: testing started by ep(%d)", test_device->endpoint_id);

		for (j = 0; j < endpoint_list.num; j++) {
			endpoint = &endpoint_list.endpoint[j];
			sending_info.type = ZIGBEE_SENDING_BY_ENDPOINT;
			memcpy(&sending_info.data.dest_endpoint, endpoint, sizeof(zigbee_endpoint));

			ret = test_device->onoff_command(&sending_info, ZIGBEE_ONOFF_TOGGLE,
											 info.endpoint_id);
			if (ret == EZ_OK)
				showln("On/off: send TOGGLE to ep(%d)",
					   endpoint->endpoint_id);
			else {
				showln("On/off: send TOGGLE failed: %s", zigbee_error_msg(ret));
				return ret;
			}

			sleep(1);

			ret = test_device->onoff_command(&sending_info, ZIGBEE_ONOFF_ON,
											 info.endpoint_id);
			if (ret == EZ_OK)
				showln("On/off: send ON to ep(%d)", endpoint->endpoint_id);
			else {
				showln("On/off: send ON failed: %s", zigbee_error_msg(ret));
				return ret;
			}

			sleep(1);

			ret = test_device->onoff_command(&sending_info, ZIGBEE_ONOFF_OFF,
											 info.endpoint_id);
			if (ret == EZ_OK)
				showln("On/off: send OFF to ep(%d)",
					   endpoint->endpoint_id);
			else {
				showln("On/off: send OFF failed: %s", zigbee_error_msg(ret));
				return ret;
			}

			sleep(1);
		}

		showln("On/off: testing succeeded by ep(%d)", test_device->endpoint_id);
	}

	return EZ_OK;
}

static bool _local_endpoint_contains_cluster(zigbee_local_endpoint endpoint,
											 ZIGBEE_CLUSTER_ID cluster,
											 bool is_server)
{
	int i = 0;

	if (is_server) {
		for (i = 0; i < MAX_CLUSTER_SIZE && endpoint.server_cluster[i] >= 0; i++)
			if (endpoint.server_cluster[i] == cluster)
				return true;
	} else {
		for (i = 0; i < MAX_CLUSTER_SIZE && endpoint.client_cluster[i] >= 0; i++)
			if (endpoint.client_cluster[i] == cluster)
				return true;
	}
	return false;
}

static zigbee_error _levelcontrol_test(bool with_onoff)
{
	zigbee_endpoint_list endpoint_list;
	struct zigbee_sending_info sending_info;
	zigbee_local_endpoint info;
	zigbee_endpoint *endpoint;
	zigbee_level_control_command cmd;
	struct test_device *test_device;
	zigbee_error ret = EZ_OK;
	int i, j, count;
	bool is_supported;
	int testing_transition_time = 10;	/* 1 sec */

	is_supported = false;
	count = get_test_device_count();
	for (i = 0; i < count; i++) {
		test_device = get_test_device(i);
		if (test_device->level_control_request != NULL) {
			is_supported = true;
			break;
		}
	}

	if (is_supported == false)
		return EZ_NOT_SUPPORTED;

	ret = zigbee_device_find_by_cluster(&endpoint_list, ZCL_LEVEL_CONTROL_CLUSTER_ID, 1);
	if (EZ_OK != ret) {
		showln("Level Control: Find endpoint by cluster failed: %s", zigbee_error_msg(ret));
		return ret;
	}

	for (; i < count; i++) {
		test_device = get_test_device(i);
		if (test_device->level_control_request == NULL)
			continue;

		ret = zigbee_get_local_endpoint_by_endpointid(&info, test_device->endpoint_id);
		if (EZ_OK != ret) {
			continue;
		}

		if (zigbee_local_endpoint_contains_cluster(info.endpoint_id, ZCL_LEVEL_CONTROL_CLUSTER_ID,
				false) != EZ_OK) {
			continue;
		}
		showln("Level control: testing started by ep(%d)",
			   test_device->endpoint_id);

		for (j = 0; j < endpoint_list.num; j++) {
			endpoint = &endpoint_list.endpoint[j];
			sending_info.type = ZIGBEE_SENDING_BY_ENDPOINT;
			memcpy(&sending_info.data.dest_endpoint, endpoint, sizeof(zigbee_endpoint));

			cmd.control_type = with_onoff ? ZIGBEE_MOVE_TO_LEVEL_ONOFF :
							   ZIGBEE_MOVE_TO_LEVEL;
			cmd.parameters.move_to_level.level = 10;
			cmd.parameters.move_to_level.transition_time = testing_transition_time;
			ret = test_device->level_control_request(&sending_info, &cmd, info.endpoint_id);
			if (ret == EZ_OK)
				showln("Level control: send MOVE TO %d with transition time: %d %s to ep(%d)",
					   cmd.parameters.move_to_level.level,
					   cmd.parameters.move_to_level.transition_time,
					   with_onoff ? "with ONOFF" : "without ONOFF",
					   endpoint->endpoint_id);
			else {
				showln("Level control: send MOVE TO %d %s failed: %s",
					   cmd.parameters.move_to_level.level,
					   with_onoff ? "with ONOFF" : "without ONOFF",
					   zigbee_error_msg(ret));
				return ret;
			}

			sleep(2);

			cmd.control_type = with_onoff ? ZIGBEE_MOVE_ONOFF : ZIGBEE_MOVE;
			cmd.parameters.move.control_mode = ZIGBEE_LEVEL_CONTROL_UP;
			cmd.parameters.move.rate = 5;
			ret = test_device->level_control_request(&sending_info, &cmd, info.endpoint_id);
			if (ret == EZ_OK)
				showln("Level control: send MOVE UP with rate: %d %s for ep(%d)",
					   cmd.parameters.move.rate,
					   with_onoff ? "with ONOFF" : "without ONOFF",
					   endpoint->endpoint_id);
			else {
				showln("Level control: send MOVE UP %s failed: %s",
					   with_onoff ? "with ONOFF" : "without ONOFF",
					   zigbee_error_msg(ret));
				return ret;
			}

			sleep(5);

			cmd.control_type = with_onoff ? ZIGBEE_STOP_ONOFF : ZIGBEE_STOP;
			ret = test_device->level_control_request(&sending_info, &cmd, info.endpoint_id);
			if (ret == EZ_OK)
				showln("Level control: send STOP %s for ep(%d)",
					   with_onoff ? "with ONOFF" : "without ONOFF",
					   endpoint->endpoint_id);
			else {
				showln("Level control: send STOP %s failed: %s",
					   with_onoff ? "with ONOFF" : "without ONOFF",
					   zigbee_error_msg(ret));
				return ret;
			}

			sleep(2);

			cmd.control_type = with_onoff ? ZIGBEE_STEP_ONOFF : ZIGBEE_STEP;
			cmd.parameters.step.control_mode = ZIGBEE_LEVEL_CONTROL_DOWN;
			cmd.parameters.step.step_size = 10;
			cmd.parameters.step.transition_time = testing_transition_time;
			ret = test_device->level_control_request(&sending_info, &cmd, info.endpoint_id);
			if (ret == EZ_OK)
				showln("Level control: send STEP DOWN with step size: %d transition time: %d %s for ep(%d)",
					   cmd.parameters.step.step_size, cmd.parameters.step.transition_time,
					   with_onoff ? "with ONOFF" : "without ONOFF",
					   endpoint->endpoint_id);
			else {
				showln("Level control: send STEP DOWN %s failed: %s",
					   with_onoff ? "with ONOFF" : "without ONOFF",
					   zigbee_error_msg(ret));
				return ret;
			}

			sleep(5);

			cmd.control_type = with_onoff ? ZIGBEE_STOP_ONOFF : ZIGBEE_STOP;
			ret = test_device->level_control_request(&sending_info, &cmd, info.endpoint_id);
			if (ret == EZ_OK)
				showln("Level control: send STOP %s for ep(%d)",
					   with_onoff ? "with ONOFF" : "without ONOFF",
					   endpoint->endpoint_id);
			else {
				showln("Level control: send STOP %s failed: %s",
					   with_onoff ? "with ONOFF" : "without ONOFF",
					   zigbee_error_msg(ret));
				return ret;
			}

			sleep(2);
		}

		showln("Level control: testing succeeded by ep(%d)",
			   test_device->endpoint_id);
	}

	return EZ_OK;
}

static zigbee_error _illuminance_test()
{
	zigbee_local_endpoint info;
	struct test_device *test_device;
	zigbee_error ret = EZ_OK;
	int i, count;
	bool is_supported;
	int ill_value;
	double illum_lux = ILLUMINANCE_MIN_LUX;

	is_supported = false;
	count = get_test_device_count();
	for (i = 0; i < count; i++) {
		test_device = get_test_device(i);
		if (test_device->illum_set_measured_value != NULL &&
			test_device->illum_set_measured_value_range != NULL) {
			is_supported = true;
			break;
		}
	}

	if (is_supported == false)
		return EZ_NOT_SUPPORTED;

	for (; i < count; i++) {
		test_device = get_test_device(i);
		if (test_device->illum_set_measured_value == NULL)
			continue;

		ret = zigbee_get_local_endpoint_by_endpointid(&info, test_device->endpoint_id);
		if (EZ_OK != ret) {
			continue;
		}

		if (zigbee_local_endpoint_contains_cluster(info.endpoint_id, ZCL_ILLUM_MEASUREMENT_CLUSTER_ID,
				true) !=
		EZ_OK) {
			continue;
		}
		showln("Illuminance: testing started by ep(%d)",
			   test_device->endpoint_id);

		illuminance_min += ILLUMINANCE_STEP;
		illuminance_max -= ILLUMINANCE_STEP;
		illuminance_value += (ILLUMINANCE_STEP * 2);

		if (illuminance_min >= illuminance_max) {
			illuminance_min = ILLUMINANCE_MIN;
			illuminance_max = ILLUMINANCE_MAX;
		}

		if (illuminance_value < illuminance_min ||
			illuminance_value > illuminance_max)
			illuminance_value = illuminance_min;

		ret = test_device->illum_set_measured_value_range(info.endpoint_id,
														  illuminance_min,
														  illuminance_max);
		if (ret == EZ_OK)
			showln("Set illuminance measured value range to %d - %d", illuminance_min,
					illuminance_max);
		else {
			showln("Set illuminance measured value range to %d - %d failed: %s", illuminance_min,
					illuminance_max, zigbee_error_msg(ret));
			return ret;
		}

		sleep(1);
		ret = test_device->illum_get_measured_value(info.endpoint_id,
													&ill_value);

		if (ret == EZ_OK) {
			ret = zigbee_illum_measured_value_to_lux(ill_value, &illum_lux);
			if (EZ_OK == ret)
				showln("Get illuminance measured value %d lux %f lx", ill_value, illum_lux);
			else {
				showln("Get illuminance measured value %d get lux error: %s", ill_value,
						zigbee_error_msg(ret));
				return ret;
			}
		} else {
			showln("Get illuminance failed: %s", zigbee_error_msg(ret));
			return ret;
		}

		sleep(1);
		ret = test_device->illum_set_measured_value(info.endpoint_id,
													illuminance_value);
		if (ret == EZ_OK) {
			ret = zigbee_illum_measured_value_to_lux(illuminance_value, &illum_lux);
			if (EZ_OK == ret)
				showln("Set illuminance measured value %d lux %f lx", illuminance_value, illum_lux);
			else {
				showln("Set illuminance measured value %d get lux error: %s", illuminance_value,
						zigbee_error_msg(ret));
				return ret;
			}
		} else {
			showln("Set illuminance failed: %s", zigbee_error_msg(ret));
			return ret;
		}

		sleep(1);
		ret = test_device->illum_get_measured_value(info.endpoint_id,
													&ill_value);
		if (ret == EZ_OK) {
			ret = zigbee_illum_measured_value_to_lux(ill_value, &illum_lux);
			if (EZ_OK == ret)
				showln("Get illuminance measured value %d lux %f lx", ill_value, illum_lux);
			else {
				showln("Get illuminance measured value %d get lux error: %s", ill_value,
						zigbee_error_msg(ret));
				return ret;
			}
		} else {
			showln("Get illuminance failed: %s", zigbee_error_msg(ret));
			return ret;
		}
		showln("Illuminance: testing succeeded by ep(%d)",
			   test_device->endpoint_id);
	}

	return EZ_OK;
}

static zigbee_error _occypancy_sensor_test()
{
	struct test_device *test_device = NULL;
	zigbee_local_endpoint info;
	zigbee_error ret = EZ_OK;
	int i = 0, count = 0;
	bool is_supported = false;

	count = get_test_device_count();
	for (i = 0; i < count; i++) {
		test_device = get_test_device(i);
		if (NULL != test_device->occupancy_set_value && NULL != test_device->occupancy_set_type) {
			is_supported = true;
			break;
		}
	}

	if (false == is_supported)
		return EZ_NOT_SUPPORTED;

	for (; i < count; i++) {
		test_device = get_test_device(i);
		if (NULL == test_device->occupancy_set_value || NULL == test_device->occupancy_set_type)
			continue;

		ret = zigbee_get_local_endpoint_by_endpointid(&info, test_device->endpoint_id);
		if (EZ_OK != ret) {
			showln("wrong endpoint_id %d\n", test_device->endpoint_id);
			continue;
		}

		if (zigbee_local_endpoint_contains_cluster(info.endpoint_id, ZCL_OCCUPANCY_SENSING_CLUSTER_ID,
				true) != EZ_OK)
			continue;

		showln("Occupancy Sensor: testing started by ep(%d)", test_device->endpoint_id);

		ret = test_device->occupancy_set_type(test_device->endpoint_id,
				ZIGBEE_OCCUPANCY_ULTRASONIC);
		if (EZ_OK == ret)
			showln("Set occypancy type to ULTRASONIC");
		else {
			showln("Set occypancy type to ULTRASONIC failed: %s", zigbee_error_msg(ret));

			return ret;
		}

		sleep(2);
		ret = test_device->occupancy_set_value(test_device->endpoint_id, ZIGBEE_OCCUPIED);
		if (EZ_OK == ret)
			showln("Set occypancy value to OCCUPIED");
		else {
			showln("Set occypancy value to OCCUPIED failed: %s", zigbee_error_msg(ret));
			return ret;
		}

		sleep(2);
		ret = test_device->occupancy_set_type(test_device->endpoint_id, ZIGBEE_OCCUPANCY_PIR);
		if (EZ_OK == ret)
			showln("Set occypancy type to PIR");
		else {
			showln("Set occypancy type to PIR failed: %s", zigbee_error_msg(ret));
			return ret;
		}

		sleep(2);
		ret = test_device->occupancy_set_value(test_device->endpoint_id, ZIGBEE_UNOCCUPIED);
		if (EZ_OK == ret)
			showln("Set occypancy value to UNOCCUPIED");
		else {
			showln("Set occypancy value to UNOCCUPIED failed: %s", zigbee_error_msg(ret));
			return ret;
		}

		showln("Occupancy Sensor: testing succeeded by ep(%d)", test_device->endpoint_id);
	}

	return EZ_OK;
}

static zigbee_error _temperature_sensor_test(void)
{
	zigbee_local_endpoint info;
	struct test_device *test_device = NULL;
	zigbee_error ret = EZ_OK;
	int i = 0, count = 0;
	bool is_supported = false;
	int min = 0x01, max = 0x7fff;
	int temp_value = 0;

	count = get_test_device_count();
	for (i = 0; i < count; i++) {
		test_device = get_test_device(i);
		if (NULL != test_device->temperature_set_measured_value
				&& NULL != test_device->temperature_set_measured_value_range) {
			is_supported = true;
			break;
		}
	}

	if (false == is_supported)
		return EZ_NOT_SUPPORTED;

	for (; i < count; i++) {
		test_device = get_test_device(i);
		if (NULL == test_device->temperature_set_measured_value
				|| NULL == test_device->temperature_set_measured_value_range)
			continue;

		ret = zigbee_get_local_endpoint_by_endpointid(&info, test_device->endpoint_id);
		if (EZ_OK != ret) {
			showln("Wrong endpoint id %d", test_device->endpoint_id);
			continue;
		}

		if (EZ_OK != zigbee_local_endpoint_contains_cluster(info.endpoint_id,
						ZCL_TEMP_MEASUREMENT_CLUSTER_ID, true))
			continue;

		showln("Temperature Sensor: testing started by ep(%d)", test_device->endpoint_id);

		ret = test_device->temperature_set_measured_value_range(test_device->endpoint_id, min, max);
		if (EZ_OK == ret)
			showln("Set measured value range min(%d) max(%d) success", min, max);
		else {
			showln("Set measured value range min(%d) max(%d) failed(%s)", min, max,
					zigbee_error_msg(ret));
			return ret;
		}
		sleep(1);

		temp_value = 10;
		ret = test_device->temperature_set_measured_value(test_device->endpoint_id, temp_value);
		if (EZ_OK == ret)
			showln("Set Temperature measured value(%d) success", temp_value);
		else {
			showln("Set Temperature measured value(%d) failed(%s)", temp_value,
					zigbee_error_msg(ret));
			return ret;
		}
		sleep(1);

		temp_value = 100;
		ret = test_device->temperature_set_measured_value(test_device->endpoint_id, temp_value);
		if (EZ_OK == ret)
			showln("Set Temperature measured value(%d) success", temp_value);
		else {
			showln("Set Temperature measured value(%d) failed(%s)", temp_value,
					zigbee_error_msg(ret));
			return ret;
		}

		showln("Temperature Sensor: testing succeeded by ep(%d)", test_device->endpoint_id);
	}

	return EZ_OK;
}

static zigbee_error _humidity_test(void)
{
	zigbee_local_endpoint info;
	struct test_device *test_device = NULL;
	zigbee_error ret = EZ_OK;
	int i = 0, count = 0;
	bool is_supported = false;
	int min = HUMIDITY_MIN_VALUE, max = HUMIDITY_MAX_VALUE;
	int temp_value = 0;

	count = get_test_device_count();
	for (i = 0; i < count; i++) {
		test_device = get_test_device(i);
		if (NULL != test_device->humidity_set_measured_value &&
			NULL != test_device->humidity_set_measured_value_range) {
			is_supported = true;
			break;
		}
	}

	if (false == is_supported)
		return EZ_NOT_SUPPORTED;

	for (; i < count; i++) {
		test_device = get_test_device(i);
		if (NULL == test_device->humidity_set_measured_value ||
			NULL == test_device->humidity_set_measured_value_range)
			continue;

		ret = zigbee_get_local_endpoint_by_endpointid(&info, test_device->endpoint_id);
		if (EZ_OK != ret) {
			showln("Wrong endpoint id %d", test_device->endpoint_id);
			continue;
		}

		if (EZ_OK != zigbee_local_endpoint_contains_cluster(info.endpoint_id,
						ZCL_RELATIVE_HUMIDITY_MEASUREMENT_CLUSTER_ID, true)) {
			continue;
		}

		showln("Humidity: testing started by ep(%d)", test_device->endpoint_id);

		ret = test_device->humidity_set_measured_value_range(test_device->endpoint_id, min, max);
		if (EZ_OK == ret)
			showln("Set measured value range min(%d) max(%d) success", min, max);
		else {
			showln("Set measured value range min(%d) max(%d) failed(%s)", min, max,
					zigbee_error_msg(ret));
			return ret;
		}
		sleep(1);

		temp_value = 10;
		ret = test_device->humidity_set_measured_value(test_device->endpoint_id, temp_value);
		if (EZ_OK == ret)
			showln("Set humidity measured value(%d) success", temp_value);
		else {
			showln("Set humidity measured value(%d) failed(%s)", temp_value,
					zigbee_error_msg(ret));
			return ret;
		}
		sleep(1);

		temp_value = 100;
		ret = test_device->humidity_set_measured_value(test_device->endpoint_id, temp_value);
		if (EZ_OK == ret)
			showln("Set humidity measured value(%d) success", temp_value);
		else {
			showln("Set humidity measured value(%d) failed(%s)", temp_value,
					zigbee_error_msg(ret));
			return ret;
		}

		showln("Humidity: testing succeeded by ep(%d)", test_device->endpoint_id);
	}

	return EZ_OK;
}

static zigbee_error _update_onoff_test(zigbee_occupancy_status occupancy)
{
	struct test_device *test_device = NULL;
	zigbee_local_endpoint info;
	zigbee_error ret = EZ_OK;
	int i = 0, count = 0;
	bool is_supported = false;
	zigbee_onoff_status onoff_status = ZIGBEE_ONOFF_OFF;
	/* For general commands, user should know the attribute information, and
	 * on/off attribute is a bool type, true indicates ON, false indicates OFF
	 **/
	bool general_onoff_value = false;

	count = get_test_device_count();
	for (i = 0; i < count; i++) {
		test_device = get_test_device(i);
		if (NULL != test_device->onoff_get_value) {
			is_supported = true;
			break;
		}
	}

	if (false == is_supported)
		return EZ_NOT_SUPPORTED;

	for (; i < count; i++) {
		test_device = get_test_device(i);
		if (NULL == test_device->onoff_get_value)
			continue;

		ret = zigbee_get_local_endpoint_by_endpointid(&info, test_device->endpoint_id);
		if (EZ_OK != ret) {
			showln("wrong endpoint_id %d\n", test_device->endpoint_id);
			continue;
		}

		if (zigbee_local_endpoint_contains_cluster(info.endpoint_id, ZCL_ON_OFF_CLUSTER_ID,
			true) != EZ_OK)
			continue;

		ret = test_device->onoff_get_value(test_device->endpoint_id, &onoff_status);
		if (EZ_OK == ret) {
			if (ZIGBEE_OCCUPIED == occupancy && ZIGBEE_ONOFF_OFF == onoff_status) {
				general_onoff_value = true;

				ret = test_device->general_write_local_attribute(ZCL_ON_OFF_CLUSTER_ID,
						ZCL_ON_OFF_ATTRIBUTE_ID, &general_onoff_value, ZIGBEE_BOOLEAN_ATTRIBUTE_SIZE,
						ZIGBEE_BOOLEAN_ATTRIBUTE_TYPE, test_device->endpoint_id);
				if (EZ_OK == ret)
					showln("Change the on/off status from OFF to ON when occupied for endpoint %d",
							test_device->endpoint_id);
				else {
					showln("General write on/off attribute to %d for endpoint %d failed: %s",
							general_onoff_value, test_device->endpoint_id, zigbee_error_msg(ret));
					return ret;
				}
			} else if (ZIGBEE_UNOCCUPIED == occupancy && ZIGBEE_ONOFF_ON == onoff_status) {
				general_onoff_value = false;

				ret = test_device->general_write_local_attribute(ZCL_ON_OFF_CLUSTER_ID,
						ZCL_ON_OFF_ATTRIBUTE_ID, &general_onoff_value, ZIGBEE_BOOLEAN_ATTRIBUTE_SIZE,
						ZIGBEE_BOOLEAN_ATTRIBUTE_TYPE, test_device->endpoint_id);
				if (EZ_OK == ret)
					showln("Change the on/off status from ON to OFF when unoccupied for endpoint %d",
							test_device->endpoint_id);
				else {
					showln("General write on/off attribute to %d for endpoint %d failed: %s",
							general_onoff_value, test_device->endpoint_id, zigbee_error_msg(ret));
					return ret;
				}
			}
		} else {
			showln("Get onoff value failed: %s", zigbee_error_msg(ret));
			return ret;
		}
	}

	return EZ_OK;
}

static zigbee_error _general_read_local_attribute_test()
{
	char value[MAX_ATTRIBUTE_SIZE];
	ZIGBEE_ATTRIBUTE_ID attribute = ZCL_ON_OFF_ATTRIBUTE_ID;
	ZIGBEE_CLUSTER_ID cluster = ZCL_ILLUM_MEASUREMENT_CLUSTER_ID;
	zigbee_attribute_data_type value_type = ZIGBEE_UNKNOWN_ATTRIBUTE_TYPE;
	zigbee_attribute_data_type expect_value_type = ZIGBEE_UNKNOWN_ATTRIBUTE_TYPE;
	zigbee_local_endpoint info;
	struct test_device *test_device = NULL;
	zigbee_error ret = EZ_OK;
	int i = 0;
	int count = 0;
	int uint16_value = 0;
	int uint8_value = 0;
	unsigned int read_length = 0;
	unsigned int expect_read_length = 0;
	bool is_supported = false;

	memset(&value, 0, MAX_ATTRIBUTE_SIZE);

	count = get_test_device_count();
	for (i = 0; i < count; i++) {
		test_device = get_test_device(i);
		if (NULL != test_device->general_read_local_attribute) {
			is_supported = true;
			break;
		}
	}

	if (false == is_supported)
		return EZ_NOT_SUPPORTED;

	for (; i < count; i++) {
		test_device = get_test_device(i);
		if (NULL == test_device->general_read_local_attribute)
			continue;

		ret = zigbee_get_local_endpoint_by_endpointid(&info, test_device->endpoint_id);
		if (EZ_OK != ret) {
			showln("wrong endpoint_id %d\n", test_device->endpoint_id);
			continue;
		}

		if (zigbee_local_endpoint_contains_cluster(info.endpoint_id, ZCL_ILLUM_MEASUREMENT_CLUSTER_ID,
			true) == EZ_OK) {
			cluster = ZCL_ILLUM_MEASUREMENT_CLUSTER_ID;
			attribute = ZCL_ILLUM_MEASURED_VALUE_ATTRIBUTE_ID;
			expect_value_type = ZIGBEE_INT16U_ATTRIBUTE_TYPE;
			expect_read_length = ZIGBEE_INT16U_ATTRIBUTE_SIZE;
		} else if (zigbee_local_endpoint_contains_cluster(info.endpoint_id, ZCL_LEVEL_CONTROL_CLUSTER_ID,
			true) == EZ_OK) {
			cluster = ZCL_LEVEL_CONTROL_CLUSTER_ID;
			attribute = ZCL_ON_LEVEL_ATTRIBUTE_ID;
			expect_value_type = ZIGBEE_INT8U_ATTRIBUTE_TYPE;
			expect_read_length = ZIGBEE_INT8U_ATTRIBUTE_SIZE;
		} else if (zigbee_local_endpoint_contains_cluster(info.endpoint_id, ZCL_ON_OFF_CLUSTER_ID,
			true) == EZ_OK) {
			cluster = ZCL_ON_OFF_CLUSTER_ID;
			attribute = ZCL_ON_OFF_ATTRIBUTE_ID;
			expect_value_type = ZIGBEE_BOOLEAN_ATTRIBUTE_TYPE;
			expect_read_length = ZIGBEE_BOOLEAN_ATTRIBUTE_SIZE;
		} else {
			showln("ep(%d) doesn't with a suitable cluster", info.endpoint_id);
			continue;
		}

		ret = test_device->general_read_local_attribute(cluster,
														attribute, value, &read_length,
														&value_type,
														test_device->endpoint_id);

		if (EZ_OK == ret) {
			if (read_length != expect_read_length || expect_value_type != value_type) {
				showln("attribute(0x%04X), value length(%d), expect length(%d), value type(%d), expect type(%d)",
						attribute, read_length, expect_read_length, value_type, expect_value_type);
				return EZ_ERROR;
			}

			if (ZIGBEE_INT16U_ATTRIBUTE_TYPE == value_type) {
				memcpy(&uint16_value, value, read_length);
				showln("General read local attribute 0x%04X, value %d, value length %d, value type %d",
						attribute, uint16_value, read_length, value_type);
			} else {
				memcpy(&uint8_value, value, read_length);
				showln("General read local attribute 0x%04X, value %d, value length %d, value type %d",
						attribute, uint8_value, read_length, value_type);
			}
		} else {
			showln("General read local attribute 0x%04X value failed %d\n", attribute, ret);
			return ret;
		}

		showln("General read local attribute: testing succeeded by ep(%d)",
			   test_device->endpoint_id);
	}

	return EZ_OK;
}

static zigbee_error _general_write_local_attribute_test()
{
	ZIGBEE_ATTRIBUTE_ID attribute = ZCL_ON_OFF_ATTRIBUTE_ID;
	ZIGBEE_CLUSTER_ID cluster = ZCL_ILLUM_MEASUREMENT_CLUSTER_ID;
	zigbee_attribute_data_type value_type = ZIGBEE_UNKNOWN_ATTRIBUTE_TYPE;
	zigbee_local_endpoint info;
	struct test_device *test_device = NULL;
	zigbee_error ret = EZ_OK;
	int i = 0;
	int count = 0;
	unsigned char uint8_value = 0;
	unsigned short uint16_value = 0;
	unsigned int value_length = 0;
	bool is_supported = false;

	count = get_test_device_count();
	for (i = 0; i < count; i++) {
		test_device = get_test_device(i);
		if (NULL != test_device->general_write_local_attribute) {
			is_supported = true;
			break;
		}
	}

	if (false == is_supported)
		return EZ_NOT_SUPPORTED;

	for (; i < count; i++) {
		test_device = get_test_device(i);
		if (NULL == test_device->general_write_local_attribute)
			continue;

		ret = zigbee_get_local_endpoint_by_endpointid(&info, test_device->endpoint_id);
		if (EZ_OK != ret) {
			showln("wrong endpoint_id %d\n", test_device->endpoint_id);
			continue;
		}

		if (zigbee_local_endpoint_contains_cluster(info.endpoint_id, ZCL_ILLUM_MEASUREMENT_CLUSTER_ID,
			true) == EZ_OK) {
			cluster = ZCL_ILLUM_MEASUREMENT_CLUSTER_ID;
			attribute = ZCL_ILLUM_MEASURED_VALUE_ATTRIBUTE_ID;
			value_type = ZIGBEE_INT16U_ATTRIBUTE_TYPE;
			value_length = ZIGBEE_INT16U_ATTRIBUTE_SIZE;
			uint16_value = 0x0016;
			ret = test_device->general_write_local_attribute(cluster, attribute,
															 &uint16_value,
															 value_length, value_type,
															 test_device->endpoint_id);
		} else if (zigbee_local_endpoint_contains_cluster(info.endpoint_id, ZCL_LEVEL_CONTROL_CLUSTER_ID,
			true) == EZ_OK) {
			cluster = ZCL_LEVEL_CONTROL_CLUSTER_ID;
			attribute = ZCL_ON_LEVEL_ATTRIBUTE_ID;
			value_type = ZIGBEE_INT8U_ATTRIBUTE_TYPE;
			value_length = ZIGBEE_INT8U_ATTRIBUTE_SIZE;
			uint8_value = 0x16;
			ret = test_device->general_write_local_attribute(cluster, attribute,
															 &uint8_value,
															 value_length, value_type,
															 test_device->endpoint_id);
		} else if (zigbee_local_endpoint_contains_cluster(info.endpoint_id, ZCL_ON_OFF_CLUSTER_ID,
			true) == EZ_OK) {
			cluster = ZCL_ON_OFF_CLUSTER_ID;
			attribute = ZCL_ON_OFF_ATTRIBUTE_ID;
			value_type = ZIGBEE_INT8U_ATTRIBUTE_TYPE;
			value_length = ZIGBEE_INT8U_ATTRIBUTE_SIZE;
			uint8_value = 0x01;
			ret = test_device->general_write_local_attribute(cluster, attribute,
															 &uint8_value,
															 value_length, value_type,
															 test_device->endpoint_id);
		} else {
			showln("ep(%d) doesn't with a suitable cluster", info.endpoint_id);
			continue;
		}

		if (EZ_OK == ret) {
			if (ZIGBEE_INT16U_ATTRIBUTE_TYPE == value_type)
				showln("General write local attribute 0x%04X for cluster 0x%04X, value %d, value length %d, value type %d",
						attribute, cluster, uint16_value, value_length, value_type);
			else
				showln("General write local attribute 0x%04X for cluster 0x%04X, value %d, value length %d, value type %d",
						attribute, cluster, uint8_value, value_length, value_type);
		} else {
			showln("General write local attribute 0x%04X value for cluster 0x%04X failed %d\n",
					attribute, cluster, ret);
			return ret;
		}

		showln("General write local attribute: testing succeeded by ep(%d)",
			   test_device->endpoint_id);
	}

	return EZ_OK;
}

static zigbee_error _general_read_remote_attribute_by_cluster(struct test_device *test_device,
															  ZIGBEE_CLUSTER_ID cluster)
{
	char value[MAX_ATTRIBUTE_SIZE];
	struct zigbee_sending_info sending_info;
	zigbee_endpoint_list endpoint_list;
	ZIGBEE_ATTRIBUTE_ID attribute = ZCL_ON_OFF_ATTRIBUTE_ID;
	zigbee_attribute_data_type value_type = ZIGBEE_UNKNOWN_ATTRIBUTE_TYPE;
	zigbee_attribute_data_type expect_value_type = ZIGBEE_UNKNOWN_ATTRIBUTE_TYPE;
	zigbee_error ret = EZ_OK;
	int uint16_value = 0;
	int uint8_value = 0;
	unsigned int read_length = 0;
	unsigned int expect_read_length = 0;

	if (NULL == test_device)
		return EZ_ERROR;

	zigbee_device_find_by_cluster(&endpoint_list, cluster, 1);

	if (endpoint_list.num <= 0) {
		showln("There is no endpoint to send read remote attribute command by cluster(0x%04X)", cluster);
		return EZ_NOT_SUPPORTED;
	}

	if (ZCL_ILLUM_MEASUREMENT_CLUSTER_ID == cluster) {
		attribute = ZCL_ILLUM_MEASURED_VALUE_ATTRIBUTE_ID;
		expect_value_type = ZIGBEE_INT16U_ATTRIBUTE_TYPE;
		expect_read_length = ZIGBEE_INT16U_ATTRIBUTE_SIZE;
	} else if (ZCL_LEVEL_CONTROL_CLUSTER_ID == cluster) {
		attribute = ZCL_ON_LEVEL_ATTRIBUTE_ID;
		expect_value_type = ZIGBEE_INT8U_ATTRIBUTE_TYPE;
		expect_read_length = ZIGBEE_INT8U_ATTRIBUTE_SIZE;
	} else if (ZCL_ON_OFF_CLUSTER_ID == cluster) {
		attribute = ZCL_ON_OFF_ATTRIBUTE_ID;
		expect_value_type = ZIGBEE_BOOLEAN_ATTRIBUTE_TYPE;
		expect_read_length = ZIGBEE_BOOLEAN_ATTRIBUTE_SIZE;
	} else if (ZCL_IDENTIFY_CLUSTER_ID == cluster) {
		attribute = ZCL_IDENTIFY_TIME_ATTRIBUTE_ID;
		expect_value_type = ZIGBEE_INT16U_ATTRIBUTE_TYPE;
		expect_read_length = ZIGBEE_INT16U_ATTRIBUTE_SIZE;
	} else {
		showln("unsupport cluster(0x%04X)", cluster);
		return EZ_NOT_SUPPORTED;
	}

	sending_info.type = ZIGBEE_SENDING_BY_ENDPOINT;

	memcpy(&sending_info.data.dest_endpoint, &endpoint_list.endpoint[0], sizeof(zigbee_endpoint));
	memset(&value, 0, MAX_ATTRIBUTE_SIZE);
	ret = test_device->general_read_remote_attribute(&sending_info,
													 cluster, attribute,
													 value, &read_length, &value_type,
													 test_device->endpoint_id);

	if (EZ_OK != ret) {
		showln("General read remote attribute(0x%04X) for cluster(0x%04X) from node id(0x%04X) endpoint id(%d) failed %d\n",
			   attribute, cluster,
			   endpoint_list.endpoint[0].node_id,
			   endpoint_list.endpoint[0].endpoint_id, ret);
		return ret;
	} else {
		if (expect_read_length != read_length || expect_value_type != value_type) {
			showln("attribute(0x%04X) from cluster(0x%04X), value length(%d), expect length(%d), value type(%d), expect type(%d)",
				   attribute, cluster, read_length, expect_read_length,
				   value_type, expect_value_type);
			return EZ_ERROR;
		} else {
			if (ZIGBEE_INT16U_ATTRIBUTE_TYPE == value_type) {
				memcpy(&uint16_value, value, read_length);
				showln("General read remote attribute(0x%04X) for cluster(0x%04X) value(%d) value length(%d) value type(%d) from node id(0x%04X) endpoint id(%d)",
					   attribute, cluster,
					   uint16_value, read_length, value_type,
					   endpoint_list.endpoint[0].node_id,
					   endpoint_list.endpoint[0].endpoint_id);
			} else {
				memcpy(&uint8_value, value, read_length);
				showln("General read remote attribute(0x%04X) for cluster(0x%04X) value(%d) value length(%d) value type(%d) from node id(0x%04X) endpoint id(%d)",
					   attribute, cluster,
					   uint8_value, read_length, value_type,
					   endpoint_list.endpoint[0].node_id,
					   endpoint_list.endpoint[0].endpoint_id);
			}
		}
	}
	return EZ_OK;
}

static zigbee_error _general_read_remote_attribute_test()
{
	zigbee_local_endpoint info;
	struct test_device *test_device = NULL;
	zigbee_error ret = EZ_OK;
	int i = 0;
	int count = 0;
	bool is_supported = false;

	count = get_test_device_count();
	for (i = 0; i < count; i++) {
		test_device = get_test_device(i);
		if (NULL != test_device->general_read_remote_attribute) {
			is_supported = true;
			break;
		}
	}

	if (false == is_supported)
		return EZ_NOT_SUPPORTED;

	for (; i < count; i++) {
		test_device = get_test_device(i);
		if (NULL == test_device->general_read_remote_attribute)
			continue;

		ret = zigbee_get_local_endpoint_by_endpointid(&info, test_device->endpoint_id);
		if (EZ_OK != ret) {
			showln("wrong endpoint_id %d\n", test_device->endpoint_id);
			continue;
		}

		ret = _general_read_remote_attribute_by_cluster(test_device,
				ZCL_ILLUM_MEASUREMENT_CLUSTER_ID);
		if (EZ_ERROR == ret)
			return ret;

		ret = _general_read_remote_attribute_by_cluster(test_device,
				ZCL_LEVEL_CONTROL_CLUSTER_ID);
		if (EZ_ERROR == ret)
			return ret;

		ret = _general_read_remote_attribute_by_cluster(test_device,
				ZCL_ON_OFF_CLUSTER_ID);
		if (EZ_ERROR == ret)
			return ret;

		ret = _general_read_remote_attribute_by_cluster(test_device,
				ZCL_IDENTIFY_CLUSTER_ID);
		if (EZ_ERROR == ret)
			return ret;

		showln("General read remote attribute: testing succeeded by ep(%d)",
				test_device->endpoint_id);
	}

	return EZ_OK;
}

static zigbee_error _general_write_remote_attribute_by_cluster(struct test_device *test_device,
															   ZIGBEE_CLUSTER_ID cluster)
{
	struct zigbee_sending_info sending_info;
	zigbee_endpoint_list endpoint_list;
	zigbee_attribute_data_type value_type = ZIGBEE_INT16U_ATTRIBUTE_TYPE;
	ZIGBEE_ATTRIBUTE_ID attribute = ZCL_ON_LEVEL_ATTRIBUTE_ID;
	zigbee_error ret = EZ_OK;
	unsigned short uint16_value = 0x0016;
	unsigned short uint8_value = 0x16;

	if (NULL == test_device)
		return EZ_ERROR;

	if (ZCL_LEVEL_CONTROL_CLUSTER_ID == cluster) {
		attribute = ZCL_ON_LEVEL_ATTRIBUTE_ID;
		value_type = ZIGBEE_INT8U_ATTRIBUTE_TYPE;
	} else if (ZCL_IDENTIFY_CLUSTER_ID == cluster) {
		attribute = ZCL_IDENTIFY_TIME_ATTRIBUTE_ID;
		value_type = ZIGBEE_INT16U_ATTRIBUTE_TYPE;
	} else {
		showln("unsupport cluster(0x%04X)", cluster);
		return EZ_NOT_SUPPORTED;
	}

	zigbee_device_find_by_cluster(&endpoint_list, cluster, 1);

	if (endpoint_list.num <= 0) {
		showln("There is no endpoint to send write remote attribute command by cluster(0x%04X)",
			   cluster);
		return EZ_NOT_SUPPORTED;
	}

	sending_info.type = ZIGBEE_SENDING_BY_ENDPOINT;

	memcpy(&sending_info.data.dest_endpoint, &endpoint_list.endpoint[0], sizeof(zigbee_endpoint));

	if (ZIGBEE_INT16U_ATTRIBUTE_TYPE == value_type) {
		ret = test_device->general_write_remote_attribute(&sending_info,
														  cluster, attribute,
														  &uint16_value, sizeof(uint16_value),
														  value_type, test_device->endpoint_id);
		if (EZ_OK != ret) {
			showln("General write remote attribute(0x%04X) for cluster(0x%04X) to node id(0x%04X) endpoint id(%d) failed %d\n",
				   attribute, cluster,
				   endpoint_list.endpoint[0].node_id,
				   endpoint_list.endpoint[0].endpoint_id, ret);
			return ret;
		} else {
			showln("General write remote attribute(0x%04X) for cluster(0x%04X) value(%d) value length(%d) value type(%d) to node id(0x%04X) endpoint id(%d)",
				   attribute, cluster,
				   uint16_value, sizeof(uint16_value), value_type,
				   endpoint_list.endpoint[0].node_id,
				   endpoint_list.endpoint[0].endpoint_id);
		}
	} else {
		ret = test_device->general_write_remote_attribute(&sending_info,
														  cluster, attribute,
														  &uint8_value, sizeof(uint8_value),
														  value_type, test_device->endpoint_id);
		if (EZ_OK != ret) {
			showln("General write remote attribute(0x%04X) for cluster(0x%04X) to node id(0x%04X) endpoint id(%d) failed %d\n",
				   attribute, cluster,
				   endpoint_list.endpoint[0].node_id,
				   endpoint_list.endpoint[0].endpoint_id, ret);
			return ret;
		} else {
			showln("General write remote attribute(0x%04X) for cluster(0x%04X) value(%d) value length(%d) value type(%d) to node id(0x%04X) endpoint id(%d)",
				   attribute, cluster,
				   uint8_value, sizeof(uint8_value), value_type,
				   endpoint_list.endpoint[0].node_id,
				   endpoint_list.endpoint[0].endpoint_id);
		}
	}
	return EZ_OK;
}

static zigbee_error _general_write_remote_attribute_test()
{
	zigbee_local_endpoint info;
	struct test_device *test_device = NULL;
	zigbee_error ret = EZ_OK;
	int i = 0;
	int count = 0;
	bool is_supported = false;

	count = get_test_device_count();
	for (i = 0; i < count; i++) {
		test_device = get_test_device(i);
		if (NULL != test_device->general_write_remote_attribute) {
			is_supported = true;
			break;
		}
	}

	if (false == is_supported)
		return EZ_NOT_SUPPORTED;

	for (; i < count; i++) {
		test_device = get_test_device(i);
		if (NULL == test_device->general_write_remote_attribute)
			continue;

		ret = zigbee_get_local_endpoint_by_endpointid(&info, test_device->endpoint_id);
		if (EZ_OK != ret) {
			showln("wrong endpoint_id %d\n", test_device->endpoint_id);
			continue;
		}

		ret = _general_write_remote_attribute_by_cluster(test_device,
			ZCL_ILLUM_MEASUREMENT_CLUSTER_ID);
		if (EZ_ERROR == ret)
			return ret;

		ret = _general_write_remote_attribute_by_cluster(test_device, ZCL_IDENTIFY_CLUSTER_ID);
		if (EZ_ERROR == ret)
			return ret;

		showln("General write remote attribute: testing succeeded by ep(%d)",
				test_device->endpoint_id);
	}

	return EZ_OK;
}

static zigbee_error _general_request_reporting_test()
{
	struct zigbee_sending_info sending_info;
	zigbee_local_endpoint info;
	zigbee_endpoint_list endpoint_list;
	ZIGBEE_ATTRIBUTE_ID attribute = ZCL_ON_OFF_ATTRIBUTE_ID;
	ZIGBEE_CLUSTER_ID cluster = 0xFFFF;
	zigbee_attribute_data_type attribute_type = ZIGBEE_INT16U_ATTRIBUTE_TYPE;
	struct test_device *test_device = NULL;
	zigbee_error ret = EZ_OK;
	int i = 0;
	int count = 0;
	int min_interval = 1;
	int max_interval = 10;
	int threshold = 2;
	bool is_supported = false;

	count = get_test_device_count();
	for (i = 0; i < count; i++) {
		test_device = get_test_device(i);
		if (NULL != test_device->general_request_reporting) {
			is_supported = true;
			break;
		}
	}

	if (false == is_supported)
		return EZ_NOT_SUPPORTED;

	for (; i < count; i++) {
		test_device = get_test_device(i);
		if (NULL == test_device->general_request_reporting)
			continue;

		ret = zigbee_get_local_endpoint_by_endpointid(&info, test_device->endpoint_id);
		if (EZ_OK != ret) {
			showln("wrong endpoint_id %d\n", test_device->endpoint_id);
			continue;
		}

		if (DEVICE_ON_OFF_SWITCH == info.device_id) {
			zigbee_device_find_by_cluster(&endpoint_list, ZCL_ON_OFF_CLUSTER_ID, 1);

			if (endpoint_list.num > 0) {
				cluster = ZCL_ON_OFF_CLUSTER_ID;
				attribute = ZCL_ON_OFF_ATTRIBUTE_ID;
				attribute_type = ZIGBEE_BOOLEAN_ATTRIBUTE_TYPE;
			}
		} else if (DEVICE_LEVEL_CONTROL_SWITCH == info.device_id) {
			zigbee_device_find_by_cluster(&endpoint_list, ZCL_LEVEL_CONTROL_CLUSTER_ID, 1);

			if (endpoint_list.num > 0) {
				cluster = ZCL_LEVEL_CONTROL_CLUSTER_ID;
				attribute = ZCL_ON_LEVEL_ATTRIBUTE_ID;
				attribute_type = ZIGBEE_INT8U_ATTRIBUTE_TYPE;
			}
		} else if (DEVICE_REMOTE_CONTROL == info.device_id) {
			zigbee_device_find_by_cluster(&endpoint_list, ZCL_ILLUM_MEASUREMENT_CLUSTER_ID, 1);

			if (endpoint_list.num > 0) {
				cluster = ZCL_ILLUM_MEASUREMENT_CLUSTER_ID;
				attribute = ZCL_ILLUM_MEASURED_VALUE_ATTRIBUTE_ID;
				attribute_type = ZIGBEE_INT16U_ATTRIBUTE_TYPE;
			}
		} else {
			showln("ep(%d) isn't a suitable device for request reporting", info.endpoint_id);
			continue;
		}

		if (0xFFFF == cluster) {
			showln("There isn't a suitable remote device for ep(%d) for request reporting", info.endpoint_id);
			continue;
		}

		sending_info.type = ZIGBEE_SENDING_BY_ENDPOINT;
		memcpy(&sending_info.data.dest_endpoint, &endpoint_list.endpoint[0], sizeof(zigbee_endpoint));
		ret = test_device->general_request_reporting(&sending_info, cluster, attribute,
													 attribute_type, min_interval,
													 max_interval, threshold, info.endpoint_id);

		if (EZ_OK == ret)
			showln("Reporting: request reporting for attribute 0x%04X from ep(%d) to node id(0x%04X) endpoint id(%d)success",
				   attribute, info.endpoint_id,
				   endpoint_list.endpoint[0].node_id,
				   endpoint_list.endpoint[0].endpoint_id);
		else
			showln("Reporting: request reporting for attribute 0x%04X failed %d", attribute, ret);
	}

	return EZ_OK;
}

static zigbee_error _general_stop_reporting_test()
{
	struct zigbee_sending_info sending_info;
	zigbee_local_endpoint info;
	zigbee_endpoint_list endpoint_list;
	ZIGBEE_ATTRIBUTE_ID attribute = ZCL_ON_OFF_ATTRIBUTE_ID;
	ZIGBEE_CLUSTER_ID cluster = 0xFFFF;
	zigbee_attribute_data_type attribute_type = ZIGBEE_INT16U_ATTRIBUTE_TYPE;
	struct test_device *test_device = NULL;
	zigbee_error ret = EZ_OK;
	int i = 0;
	int count = 0;
	bool is_supported = false;

	count = get_test_device_count();
	for (i = 0; i < count; i++) {
		test_device = get_test_device(i);
		if (NULL != test_device->general_stop_reporting) {
			is_supported = true;
			break;
		}
	}

	if (false == is_supported)
		return EZ_NOT_SUPPORTED;

	for (; i < count; i++) {
		test_device = get_test_device(i);
		if (NULL == test_device->general_stop_reporting)
			continue;

		ret = zigbee_get_local_endpoint_by_endpointid(&info, test_device->endpoint_id);
		if (EZ_OK != ret) {
			showln("wrong endpoint_id %d\n", test_device->endpoint_id);
			continue;
		}

		if (DEVICE_ON_OFF_SWITCH == info.device_id) {
			zigbee_device_find_by_cluster(&endpoint_list, ZCL_ON_OFF_CLUSTER_ID, 1);

			if (endpoint_list.num > 0) {
				cluster = ZCL_ON_OFF_CLUSTER_ID;
				attribute = ZCL_ON_OFF_ATTRIBUTE_ID;
				attribute_type = ZIGBEE_BOOLEAN_ATTRIBUTE_TYPE;
			}
		} else if (DEVICE_LEVEL_CONTROL_SWITCH == info.device_id) {
			zigbee_device_find_by_cluster(&endpoint_list, ZCL_LEVEL_CONTROL_CLUSTER_ID, 1);

			if (endpoint_list.num > 0) {
				cluster = ZCL_LEVEL_CONTROL_CLUSTER_ID;
				attribute = ZCL_CURRENT_LEVEL_ATTRIBUTE_ID;
				attribute_type = ZIGBEE_INT8U_ATTRIBUTE_TYPE;
			}
		} else if (DEVICE_REMOTE_CONTROL == info.device_id) {
			zigbee_device_find_by_cluster(&endpoint_list, ZCL_ILLUM_MEASUREMENT_CLUSTER_ID, 1);

			if (endpoint_list.num > 0) {
				cluster = ZCL_ILLUM_MEASUREMENT_CLUSTER_ID;
				attribute = ZCL_ILLUM_MEASURED_VALUE_ATTRIBUTE_ID;
				attribute_type = ZIGBEE_INT16U_ATTRIBUTE_TYPE;
			}
		} else {
			showln("ep(%d) isn't a suitable device to stop reporting", info.endpoint_id);
			continue;
		}

		if (0xFFFF == cluster) {
			showln("There isn't a suitable remote device for ep(%d) to stop reporting", info.endpoint_id);
			continue;
		}

		sending_info.type = ZIGBEE_SENDING_BY_ENDPOINT;
		memcpy(&sending_info.data.dest_endpoint, &endpoint_list.endpoint[0], sizeof(zigbee_endpoint));
		ret = test_device->general_stop_reporting(&sending_info, cluster, attribute,
												  attribute_type, info.endpoint_id);

		if (EZ_OK == ret)
			showln("Stop reporting: for attribute 0x%04X from ep(%d) to node id(0x%04X) endpoint id(%d)success",
				   attribute, info.endpoint_id,
				   endpoint_list.endpoint[0].node_id,
				   endpoint_list.endpoint[0].endpoint_id);
		else
			showln("Stop reporting: for attribute 0x%04X failed %d", attribute, ret);
	}

	return EZ_OK;
}

static zigbee_error _general_read_reporting_config_test()
{
	zigbee_reporting_info reporting_info;
	struct zigbee_sending_info sending_info;
	zigbee_local_endpoint info;
	zigbee_endpoint_list endpoint_list;
	ZIGBEE_ATTRIBUTE_ID attribute = ZCL_ON_OFF_ATTRIBUTE_ID;
	ZIGBEE_CLUSTER_ID cluster = 0xFFFF;
	struct test_device *test_device = NULL;
	zigbee_error ret = EZ_OK;
	int i = 0;
	int count = 0;
	bool is_supported = false;

	count = get_test_device_count();
	for (i = 0; i < count; i++) {
		test_device = get_test_device(i);
		if (NULL != test_device->general_read_reporting_config) {
			is_supported = true;
			break;
		}
	}

	if (false == is_supported)
		return EZ_NOT_SUPPORTED;

	for (; i < count; i++) {
		test_device = get_test_device(i);
		if (NULL == test_device->general_read_reporting_config)
			continue;

		ret = zigbee_get_local_endpoint_by_endpointid(&info, test_device->endpoint_id);
		if (EZ_OK != ret) {
			showln("wrong endpoint_id %d\n", test_device->endpoint_id);
			continue;
		}

		if (DEVICE_ON_OFF_SWITCH == info.device_id) {
			zigbee_device_find_by_cluster(&endpoint_list, ZCL_ON_OFF_CLUSTER_ID, 1);

			if (endpoint_list.num > 0) {
				cluster = ZCL_ON_OFF_CLUSTER_ID;
				attribute = ZCL_ON_OFF_ATTRIBUTE_ID;
			}
		} else if (DEVICE_LEVEL_CONTROL_SWITCH == info.device_id) {
			zigbee_device_find_by_cluster(&endpoint_list, ZCL_LEVEL_CONTROL_CLUSTER_ID, 1);

			if (endpoint_list.num > 0) {
				cluster = ZCL_LEVEL_CONTROL_CLUSTER_ID;
				attribute = ZCL_CURRENT_LEVEL_ATTRIBUTE_ID;
			}
		} else if (DEVICE_REMOTE_CONTROL == info.device_id) {
			zigbee_device_find_by_cluster(&endpoint_list, ZCL_ILLUM_MEASUREMENT_CLUSTER_ID, 1);

			if (endpoint_list.num > 0) {
				cluster = ZCL_ILLUM_MEASUREMENT_CLUSTER_ID;
				attribute = ZCL_ILLUM_MEASURED_VALUE_ATTRIBUTE_ID;
			}
		} else {
			showln("ep(%d) isn't a suitable device to read reporting config", info.endpoint_id);
			continue;
		}

		if (0xFFFF == cluster) {
			showln("There isn't a suitable remote device for ep(%d) to read reporting config", info.endpoint_id);
			continue;
		}

		sending_info.type = ZIGBEE_SENDING_BY_ENDPOINT;
		memcpy(&sending_info.data.dest_endpoint, &endpoint_list.endpoint[0], sizeof(zigbee_endpoint));
		ret = test_device->general_read_reporting_config(&sending_info, cluster, attribute,
														 &reporting_info, info.endpoint_id);

		if (EZ_OK == ret)
			showln("Read reporting config: cluster(0x%04X) attr(0x%04X) min_interval(%d) "
				   "max_interval(%d) reportable_change(%d) from node id(0x%04X) endpoint id(%d)",
					reporting_info.cluster_id,
					reporting_info.attribute_id,
					reporting_info.reported.min_interval,
					reporting_info.reported.max_interval,
					reporting_info.reported.reportable_change,
					endpoint_list.endpoint[0].node_id,
					endpoint_list.endpoint[0].endpoint_id);
		else if (EZ_NOT_FOUND == ret)
			showln("There is no reporting configuration for cluster(0x%04X) attr(0x%04X) "
				   "in node id(0x%04X) endpoint id(%d)",
					ZCL_ILLUM_MEASUREMENT_CLUSTER_ID, attribute,
					endpoint_list.endpoint[0].node_id,
					endpoint_list.endpoint[0].endpoint_id);
		else
			showln("read reporting failed(%d)", ret);
	}

	return EZ_OK;
}

static zigbee_error _general_discovery_attribute_by_cluster(struct test_device *test_device,
															ZIGBEE_CLUSTER_ID cluster)
{
	struct zigbee_discovery_attributes attr_list;
	struct zigbee_sending_info sending_info;
	zigbee_endpoint_list endpoint_list;
	ZIGBEE_ATTRIBUTE_ID attribute_start = 0x0000;
	zigbee_error ret = EZ_OK;
	int i = 0;

	if (NULL == test_device)
		return EZ_ERROR;

	zigbee_device_find_by_cluster(&endpoint_list, cluster, 1);

	if (endpoint_list.num <= 0) {
		showln("There is no endpoint to send discovery attribute command by cluster(0x%04X)",
			   cluster);
		return EZ_NOT_SUPPORTED;
	}

	sending_info.type = ZIGBEE_SENDING_BY_ENDPOINT;

	memcpy(&sending_info.data.dest_endpoint, &endpoint_list.endpoint[0], sizeof(zigbee_endpoint));

	ret = test_device->general_discover_attribute(&sending_info, cluster,
												  attribute_start, DISCOVER_ATTRIBUTE_COUNT,
												  &attr_list, test_device->endpoint_id);

	if (EZ_OK == ret) {
		showln("General discover attribute by cluster(0x%04X) to node id(0x%04X) "
			   "endpoint id(%d) count(%d) discovery complete(%d)",
				cluster,
				endpoint_list.endpoint[0].node_id,
				endpoint_list.endpoint[0].endpoint_id,
				attr_list.attribute_count, attr_list.discovery_complete);

		for (i = 0; i < attr_list.attribute_count; i++)
			showln("index %d attribute 0x%04X attribute type 0x%02X", i,
					attr_list.attributes[i].id, attr_list.attributes[i].type);
	} else
		showln("General discover attribute by cluster(0x%04X) to "
			   "node id(0x%04X) endpoint id(%d) failed(%d)", cluster,
				endpoint_list.endpoint[0].node_id,
				endpoint_list.endpoint[0].endpoint_id, ret);

	return ret;
}

static zigbee_error _general_discovery_attribute_test()
{
	struct test_device *test_device = NULL;
	zigbee_local_endpoint info;
	zigbee_error ret = EZ_OK;
	int i = 0, j = 0;
	int count = 0;
	int unsupport_count = 0;
	bool is_supported = false;
	ZIGBEE_CLUSTER_ID cluster[] = {
		ZCL_ILLUM_MEASUREMENT_CLUSTER_ID,
		ZCL_LEVEL_CONTROL_CLUSTER_ID,
		ZCL_LEVEL_CONTROL_CLUSTER_ID,
		ZCL_ON_OFF_CLUSTER_ID
	};

	count = get_test_device_count();
	for (i = 0; i < count; i++) {
		test_device = get_test_device(i);
		if (NULL != test_device->general_discover_attribute) {
			is_supported = true;
			break;
		}
	}

	if (false == is_supported)
		return EZ_NOT_SUPPORTED;

	for (; i < count; i++) {
		test_device = get_test_device(i);
		if (NULL == test_device->general_discover_attribute)
			continue;

		ret = zigbee_get_local_endpoint_by_endpointid(&info, test_device->endpoint_id);
		if (EZ_OK != ret) {
			showln("wrong endpoint_id %d\n", test_device->endpoint_id);
			continue;
		}

		for (j = 0; j < sizeof(cluster) / sizeof(ZIGBEE_CLUSTER_ID); j++) {
			ret = _general_discovery_attribute_by_cluster(test_device, cluster[j]);

			if (EZ_ERROR == ret)
				return ret;
			else if (EZ_NOT_SUPPORTED == ret)
				unsupport_count++;
		}
	}

	if (sizeof(cluster)/sizeof(ZIGBEE_CLUSTER_ID) == unsupport_count) {
		showln("General discovery attribute: testing failed by ep(%d) "
			   "for total are unsupported",
			   test_device->endpoint_id);
		return EZ_ERROR;
	} else {
		showln("General discovery attribute: testing succeeded by ep(%d)",
			   test_device->endpoint_id);
		return EZ_OK;
	}
}

static zigbee_error _do_basic_remote_control()
{
	zigbee_endpoint_list endpoint_list;
	struct zigbee_sending_info sending_info;
	zigbee_endpoint *endpoint = NULL;
	struct test_device *test_device = NULL;
	zigbee_error ret = EZ_ERROR;
	int i, j, count = 0;
	bool is_supported = false;

	count = get_test_device_count();
	for (i = 0; i < count; i++) {
		test_device = get_test_device(i);
		if (test_device->reset_to_factory_default != NULL) {
			is_supported = true;
			break;
		}
	}

	if (is_supported == false)
		return EZ_NOT_SUPPORTED;

	ret = zigbee_device_find_by_cluster(&endpoint_list, ZCL_BASIC_CLUSTER_ID, 1);
	if (EZ_OK != ret) {
		showln("Basic: Find endpoint by cluster failed: %s", zigbee_error_msg(ret));
		return ret;
	}

	for (; i < count; i++) {
		test_device = get_test_device(i);

		if (test_device->reset_to_factory_default == NULL)
			continue;

		showln("Remote control basic: testing started by ep(%d)",
				test_device->endpoint_id);

		for (j = 0; j < endpoint_list.num; j++) {
			endpoint = &endpoint_list.endpoint[j];
			sending_info.type = ZIGBEE_SENDING_BY_ENDPOINT;
			memcpy(&sending_info.data.dest_endpoint, endpoint, sizeof(zigbee_endpoint));

			ret = test_device->reset_to_factory_default(&sending_info,
														test_device->endpoint_id);
			if (ret != EZ_OK) {
				showln("Failed to reset to factory default for result: %d",
					   ret);
				return ret;
			}
			else
				showln("Success to reset to factory default to node 0x%04X",
					   endpoint->node_id);
			sleep(2);
		}

		showln("Remote control: testing succeeded by ep(%d)",
			   test_device->endpoint_id);
	}

	return EZ_OK;
}

static zigbee_error _zdo_bind_unicast_request(ZIGBEE_ENDPOINT_ID local_endpoint, ZIGBEE_NODE_ID local_node,
											  ZIGBEE_CLUSTER_ID cluster, bool is_bind)
{
	zigbee_endpoint_list src_endpoint_list;
	zigbee_endpoint *src_endpoint = NULL;
	zigbee_error ret = EZ_ERROR;
	int i = 0;

	ret = zigbee_device_find_by_cluster(&src_endpoint_list, cluster, 1);
	if (EZ_OK != ret) {
		showln("Device find by server cluster 0x%04X error: %s", cluster, zigbee_error_msg(ret));
		return ret;
	}

	if (src_endpoint_list.num <= 0) {
		showln("There is no remote src endpoint for server cluster 0x%04X", cluster);
		return EZ_NOT_SUPPORTED;
	}

	showln("ZDO %s unicast request: testing started by ep(%d)", is_bind ? "bind" : "unbind", local_endpoint);
	for (i = 0; i < src_endpoint_list.num; i++) {
		src_endpoint = &src_endpoint_list.endpoint[i];

		if (is_bind)
			ret = zigbee_zdo_bind_unicast_request(src_endpoint->node_id, src_endpoint->endpoint_id, cluster,
					local_node, local_endpoint);
		else
			ret = EZ_NOT_SUPPORTED;	/* < unbind API and testing are planned to be provided */

		show("ZDO %s unicast src node 0x%04X endpoint %d cluster 0x%04X dest node 0x%04X endpoint %d ",
				is_bind ? "bind" : "unbind", src_endpoint->node_id, src_endpoint->endpoint_id, cluster,
				local_node, local_endpoint);
		if (EZ_OK == ret)
			showln("success");
		else {
			showln("error: %s", zigbee_error_msg(ret));
			return ret;
		}

		sleep(1);
	}
	showln("ZDO %s unicast request: testing end by ep(%d)", is_bind ? "bind" : "unbind", local_endpoint);

	return EZ_OK;
}

static zigbee_error _zdo_end_device_bind_test(void)
{
	zigbee_local_endpoint_info endpoint_info;

	zigbee_local_endpoint *endpoint = NULL;
	zigbee_error ret = EZ_ERROR;

	ret = zigbee_get_local_endpoint(&endpoint_info);
	if (EZ_OK != ret) {
		showln("Get local endpoint error %s", zigbee_error_msg(ret));
		return ret;
	}

	if (endpoint_info.count <= 0) {
		showln("Get none local endpoint error");
		return EZ_NOT_FOUND;
	}

	if (end_device_bind_index >= endpoint_info.count)
		end_device_bind_index = 0;

	endpoint = &endpoint_info.endpoints[end_device_bind_index];
	ret = zigbee_zdo_end_device_bind_request((ZIGBEE_ENDPOINT_ID)endpoint->endpoint_id);
	if (EZ_OK == ret)
		showln("End device bind request by endpoint %d ...", endpoint->endpoint_id);
	else
		showln("End device bind request by endpoint %d failed %s", endpoint->endpoint_id,
				zigbee_error_msg(ret));
	end_device_bind_index++;

	return ret;
}

static zigbee_error _zdo_bind_unicast(bool is_bind)
{
	zigbee_node_info node_info;
	zigbee_local_endpoint_info endpoint_info;
	zigbee_local_endpoint local_ep;
	int i = 0;
	zigbee_error ret = EZ_ERROR;
	zigbee_error ret_illum = EZ_ERROR;
	zigbee_error ret_occupancy = EZ_ERROR;
	zigbee_error ret_temp = EZ_ERROR;

	ret = zigbee_get_node_info(&node_info);
	if (EZ_OK != ret) {
		showln("Get node info error: %s", zigbee_error_msg(ret));
		return ret;
	}

	ret = zigbee_get_local_endpoint(&endpoint_info);
	if (EZ_OK != ret) {
		showln("Get local endpoint error: %s", zigbee_error_msg(ret));
		return ret;
	}

	for (i = 0; i < endpoint_info.count; i++) {
		local_ep = endpoint_info.endpoints[i];

		if (EZ_OK == zigbee_check_local_endpoint_contains_cluster(&local_ep, ZCL_ILLUM_MEASUREMENT_CLUSTER_ID, false))
			ret_illum = _zdo_bind_unicast_request(local_ep.endpoint_id, node_info.node_id,
					ZCL_ILLUM_MEASUREMENT_CLUSTER_ID, is_bind);
		else
			showln("Local endpoint does not contain Illuminace client cluster");

		if (EZ_OK == zigbee_check_local_endpoint_contains_cluster(&local_ep, ZCL_OCCUPANCY_SENSING_CLUSTER_ID, false))
			ret_occupancy = _zdo_bind_unicast_request(local_ep.endpoint_id, node_info.node_id,
					ZCL_OCCUPANCY_SENSING_CLUSTER_ID, is_bind);
		else
			showln("Local endpoint does not contain Occupancy client cluster");

		if (EZ_OK == zigbee_check_local_endpoint_contains_cluster(&local_ep, ZCL_TEMP_MEASUREMENT_CLUSTER_ID, false))
			ret_temp = _zdo_bind_unicast_request(local_ep.endpoint_id, node_info.node_id,
					ZCL_TEMP_MEASUREMENT_CLUSTER_ID, is_bind);
		else
			showln("Local endpoint does not contain Temperatuer client cluster");
	}

	if (EZ_OK != ret_illum && EZ_OK != ret_occupancy && EZ_OK != ret_temp)
		return EZ_ERROR;
	else
		return EZ_OK;
}

static zigbee_error _zdo_bind_group_request(ZIGBEE_CLUSTER_ID cluster, bool is_bind)
{
	zigbee_endpoint_list src_endpoint_list;
	zigbee_endpoint *endpoint = NULL;
	zigbee_error ret = EZ_ERROR;
	int i = 0;

	ret = zigbee_device_find_by_cluster(&src_endpoint_list, cluster, 0);
	if (EZ_OK != ret) {
		showln("Device find by client cluster 0x%04X error: %s", cluster, zigbee_error_msg(ret));
		return ret;
	}

	if (src_endpoint_list.num <= 0) {
		showln("There is no remote src endpoint for client cluster 0x%04X", cluster);
		return EZ_NOT_SUPPORTED;
	}

	showln("ZDO %s group request: testing started for cluster 0x%04X", is_bind ? "bind" : "unbind",
			cluster);
	for (i = 0; i < src_endpoint_list.num; i++) {
		endpoint = &src_endpoint_list.endpoint[i];

		if (is_bind)
			ret = zigbee_zdo_bind_group_request(endpoint->node_id, endpoint->endpoint_id, cluster,
					TEST_GROUP_ID);
		else
			ret = EZ_NOT_SUPPORTED;	/* < unbind API and testing are planned to be provided */

		show("ZDO %s group src node 0x%04X endpoint %d cluster 0x%04X dest group 0x%04X ",
				is_bind ? "bind" : "unbind", endpoint->node_id, endpoint->endpoint_id, cluster,
				TEST_GROUP_ID);
		if (EZ_OK == ret)
			showln("success");
		else {
			showln("error: %s", zigbee_error_msg(ret));
			return ret;
		}

		sleep(1);
	}
	showln("ZDO %s group request: testing end for cluster 0x%04X", is_bind ? "bind" : "unbind", cluster);

	return EZ_OK;
}

static zigbee_error _zdo_bind_group(bool is_bind)
{
	zigbee_error ret_on_off = EZ_ERROR;
	zigbee_error ret_level_ctl = EZ_ERROR;

	ret_on_off = _zdo_bind_group_request(ZCL_ON_OFF_CLUSTER_ID, is_bind);
	ret_level_ctl = _zdo_bind_group_request(ZCL_LEVEL_CONTROL_CLUSTER_ID, is_bind);

	if (EZ_OK != ret_on_off && EZ_OK != ret_level_ctl)
		return EZ_ERROR;
	else
		return EZ_OK;
}

static zigbee_error _zdo_binding_table_request(void)
{
	zigbee_device_info device_info;
	struct zigbee_binding_table_list list;
	zigbee_error ret = EZ_ERROR;
	int i = 0;
	int j = 0;
	int k = 0;
	uint16_t dest_addr = 0;

	ret = zigbee_get_discovered_device_list(&device_info);
	if (EZ_OK != ret) {
		showln("Get discovered device failed: %s", zigbee_error_msg(ret));
		return ret;
	}

	if (device_info.num <= 0) {
		showln("Please discover device firstly");
		return EZ_NOT_FOUND;
	}

	for (i = 0; i < device_info.num; i++) {
		ret = zigbee_zdo_binding_table_request(device_info.device[i].node_id, 0, &list);
		if (EZ_OK != ret)
			showln("Request binding table for node 0x%04X failed: %s", device_info.device[i].node_id,
					zigbee_error_msg(ret));
		else {
			showln("Request binding table for node 0x%04X success", device_info.device[i].node_id);
			showln("Binding table binding table entries total num = %d, start index = %d, binding table list count = %d",
					list.binding_table_entries, list.start_index, list.binding_table_list_count);
			for (j = 0; j < list.binding_table_list_count; j++) {
				show("Index %d source IEEE address ");
				for (k = 0; k < EUI64_SIZE; k++)
					show("%02X", list.entries[j].src_addr[k]);

				show(", source endpoint %d, cluster id 0x%04X, addressing mode 0x%02X",
					 list.entries[j].src_endpoint,
					 list.entries[j].cluster_id,
					 list.entries[j].dst_addr_mode);

				if (0x01 == list.entries[j].dst_addr_mode) {
					memcpy(&dest_addr, list.entries[j].dst_addr, 2);
					show(", destination address 0x04X", dest_addr);
				} else if (0x03 == list.entries[j].dst_addr_mode) {
					show(", destination address ");
					for (k = 0; k < EUI64_SIZE; k++)
						show("%02X", list.entries[j].dst_addr[k]);
					show(", destination endpoint %d", list.entries[j].dst_endpoint);
				}
				showln("");
			}
		}
	}

	showln("Done");
	return EZ_OK;
}

static zigbee_error _zdo_node_id_request(void)
{
	zigbee_device_info device_info;
	zigbee_error ret = EZ_ERROR;
	int i = 0, j = 0;
	ZIGBEE_NODE_ID node_id = -1;

	ret = zigbee_get_discovered_device_list(&device_info);
	if (EZ_OK != ret) {
		showln("Get discovered device failed: %s", zigbee_error_msg(ret));
		return ret;
	}

	if (device_info.num <= 0) {
		showln("Please discover device firstly");
		return EZ_NOT_FOUND;
	}

	for (i = 0; i < device_info.num; i++) {
		if (NULL == device_info.device[i].eui64) {
			showln("NULL ieee address error for node 0x%04X", device_info.device[i].node_id);
			continue;
		}

		ret = zigbee_zdo_nodeid_request(device_info.device[i].eui64, &node_id);
		show("Request ");
		for (j = 0; j < EUI64_SIZE; j++)
			show("%02X", device_info.device[i].eui64[j]);
		show(" for node id ");

		if (ret == EZ_OK)
			showln("success 0x%04X", node_id);
		else
			showln("failed: %s", zigbee_error_msg(ret));
	}

	showln("Done");
	return ret;
}

static zigbee_error _zdo_simple_descriptor_request(void)
{
	zigbee_device_info device_info;
	zigbee_device device;
	zigbee_endpoint endpoint;
	zigbee_simple_descriptor descriptor;
	zigbee_error ret = EZ_ERROR;
	int i = 0, j = 0, k = 0;

	ret = zigbee_get_discovered_device_list(&device_info);
	if (EZ_OK != ret) {
		showln("Get discovered device failed: %s", zigbee_error_msg(ret));
		return ret;
	}

	if (device_info.num <= 0) {
		showln("Please discover device firstly");
		return EZ_NOT_FOUND;
	}

	for (i = 0; i < device_info.num; i++) {
		device = device_info.device[i];
		for (j = 0; j < device.endpoint_count; j++) {
			endpoint = device.endpoint[j];
			ret = zigbee_zdo_simple_descriptor_request(endpoint.node_id, endpoint.endpoint_id, &descriptor);

			if (EZ_OK != ret)
				showln("Request simple descriptor for node 0x%04X endpoint %d failed: %s", endpoint.node_id,
						endpoint.endpoint_id, zigbee_error_msg(ret));
			else {
				showln("Request simple descriptor for node 0x%04X endpoint %d success", endpoint.node_id,
						endpoint.endpoint_id);
				showln("Descriptor information: profile 0x%04X node 0x%04X device 0x%04X endpoint %d",
						descriptor.profile_id, descriptor.node_id, descriptor.device_id,
						descriptor.endpoint_id);
				for (k = 0; k < descriptor.server_cluster_count && k < MAX_ZDO_CLUSTER_COUNT; k++)
					showln("Cluster id 0x%04X, SERVER", descriptor.server_cluster[k]);
				for (k = 0; k < descriptor.client_cluster_count && k < MAX_ZDO_CLUSTER_COUNT; k++)
					showln("Cluster id 0x%04X, CLIENT", descriptor.client_cluster[k]);
			}
		}
	}

	showln("Done");
	return EZ_OK;
}

static zigbee_error _zdo_ieee_request(void)
{
	zigbee_device_info device_info;
	char ieee_addr[EUI64_SIZE];
	zigbee_error ret = EZ_ERROR;
	int i = 0, j = 0;

	ret = zigbee_get_discovered_device_list(&device_info);
	if (EZ_OK != ret) {
		showln("Get discovered device failed: %s", zigbee_error_msg(ret));
		return ret;
	}

	if (device_info.num <= 0) {
		showln("Please discover device firstly");
		return EZ_NOT_FOUND;
	}

	for (i = 0; i < device_info.num; i++) {
		ret = zigbee_zdo_ieee_addr_request(device_info.device[i].node_id, ieee_addr);
		if (ret == EZ_OK) {
			show("Ieee request 0x%04X ieee ", device_info.device[i].node_id);
			for (j = 0; j < EUI64_SIZE; j++)
				show("%02X", ieee_addr[j]);
			showln("");
		} else
			showln("Ieee request 0x%04X failed: %s", device_info.device[i].node_id, zigbee_error_msg(ret));
	}

	showln("Done");
	return ret;
}

static void _show_frequency_band(ZIGBEE_FREQUENCE_BAND frequency_band)
{
	/**
	 * The frequency band field of the node descriptor is five bits in length and specifies the frequency
	 * bands that are supported by the underlying IEEE 802.15.4 radio utilized by the node.
	 * For each frequency band supported by the underlying IEEE 802.15.4 radio, the corresponding bit of
	 * the frequency band field, as listed below, shall be set to 1. All other bits shall be set to 0.
	 *
	 * [Bit Number]	[Supported Fre-quency Band]
	 * 0			868 - 868.6 MHz
	 * 1			Reserved
	 * 2			902 - 928 MHz
	 * 3			2400 - 2483.5 MHz
	 * 4			Reserved
	 */
	show("Frequency Band [");
	if (frequency_band & 1)
		show("868 - 868.6 MHz, ");
	if (frequency_band & (1 << 2))
		show("902 - 928 MHz, ");
	if (frequency_band & (1 << 3))
		show("2400 - 2483.5 MHz, ");
	showln("]");
}

static void _show_node_type(zigbee_node_type node_type)
{
	switch (node_type) {
	case ZIGBEE_COORDINATOR:
		showln("Node type: Coordinator");
		break;

	case ZIGBEE_ROUTER:
		showln("Node type: Router");
		break;

	case ZIGBEE_END_DEVICE:
		showln("Node type: End device");
		break;

	case ZIGBEE_SLEEPY_END_DEVICE:
		showln("Node type: Sleepy end device");
		break;

	default:
		showln("Node type: Unknown");
		break;
	}
}

static zigbee_error _zdo_node_descriptor_request(void)
{
	zigbee_device_info device_info;
	zigbee_node_descriptor node_descriptor;
	zigbee_error ret = EZ_ERROR;
	int i = 0;

	ret = zigbee_get_discovered_device_list(&device_info);
	if (EZ_OK != ret) {
		showln("Get discovered device failed: %s", zigbee_error_msg(ret));
		return ret;
	}

	if (device_info.num <= 0) {
		showln("Please discover device firstly");
		return EZ_NOT_FOUND;
	}

	for (i = 0; i < device_info.num; i++) {
		ret = zigbee_zdo_node_descriptor_request(device_info.device[i].node_id, &node_descriptor);
		if (ret == EZ_OK) {
			showln("Node descriptor request 0x%04X success", device_info.device[i].node_id);
			showln("Node id 0x%04X APS flags 0x%02X complex descriptor available %d user descriptor available %d",
					node_descriptor.node_id, node_descriptor.aps_flags,
					node_descriptor.complex_descriptor_available, node_descriptor.user_descriptor_available);
			_show_node_type(node_descriptor.node_type);
			_show_frequency_band(node_descriptor.frequency_band);
			showln("Manufacturer code 0x%04X", node_descriptor.manufacturer_code);
			showln("Max buffer size %d max incoming size %d max outgoing size %d",
					node_descriptor.max_buffer_size, node_descriptor.max_incoming_transfer_size,
					node_descriptor.max_outgoing_transfer_size);
			showln("Descriptor capability 0x%02X Mac capability 0x%02X Server mask 0x%04X",
					node_descriptor.descriptor_capability, node_descriptor.mac_capability,
					node_descriptor.server_mask);
		} else
			showln("Node descriptor request 0x%04X failed: %s", device_info.device[i].node_id,
					zigbee_error_msg(ret));
	}

	showln("Done");
	return ret;
}

static zigbee_error _zdo_lqi_table_request(void)
{
	struct zigbee_lqi_table_entry lqi_entry;
	zigbee_device_info device_info;
	zigbee_error ret = EZ_ERROR;
	int i = 0;
	int j = 0;
	uint8_t starting_index = 0;
	char *device_type = NULL;
	char *device_relation = NULL;

	ret = zigbee_get_discovered_device_list(&device_info);
	if (EZ_OK != ret) {
		showln("Get discovered device failed: %s", zigbee_error_msg(ret));
		return ret;
	}

	if (device_info.num <= 0) {
		showln("Please discover device firstly");
		return EZ_NOT_FOUND;
	}

	for (j = 0; j < device_info.num; j++) {
		ret = zigbee_zdo_lqi_table_request(device_info.device[j].node_id, starting_index, &lqi_entry);
		if (EZ_OK == ret) {
			show("LQI table request for node id 0x%04X\n", device_info.device[j].node_id);
			for (i = 0; i < lqi_entry.neighbor_count; i++) {

				switch (lqi_entry.neighbor[i].relation) {
				case PARENT:
					device_relation = (char *)parent;
					break;
				case CHILD:
					device_relation = (char *)child;
					break;
				case SIBLING:
					device_relation = (char *)sibling;
					break;
				default:
					break;
				}

				switch (lqi_entry.neighbor[i].node_type) {
				case ZIGBEE_COORDINATOR:
					device_type = (char *)zc_type;
					break;
				case ZIGBEE_ROUTER:
					device_type = (char *)zr_type;
					break;
				case ZIGBEE_END_DEVICE:
					device_type = (char *)zed_type;
					break;
				default:
					break;
				}

				showln("index %d neighbor node: 0x%04x relation: %s node type: %s rx mode: 0x%02X permit joining: 0x%X tree depth: 0x%02X LQI: 0x%02X",
						i, lqi_entry.neighbor[i].node_id, device_relation, device_type, lqi_entry.neighbor[i].rx_on_when_idle,
						lqi_entry.neighbor[i].permit_joining, lqi_entry.neighbor[i].depth, lqi_entry.neighbor[i].lqi);
			}
		} else
			showln("LQI table request 0x%04X failed: %s", device_info.device[i].node_id, zigbee_error_msg(ret));
	}

	showln("Done");
	return ret;
}

static zigbee_error _zdo_leave_request(void)
{
	struct zigbee_lqi_table_entry lqi_entry;
	zigbee_device_info device_info;
	zigbee_error ret = EZ_ERROR;
	int i = 0;
	int j = 0;

	ret = zigbee_get_discovered_device_list(&device_info);
	if (EZ_OK != ret) {
		showln("Get discovered device failed: %s", zigbee_error_msg(ret));
		return ret;
	}

	if (device_info.num <= 0) {
		showln("Please discover device firstly");
		return EZ_NOT_FOUND;
	}

	for (i = 0; i < device_info.num; i++) {
		/* zdo leave node's child */
		zigbee_zdo_lqi_table_request(device_info.device[i].node_id, 0, &lqi_entry);
		if (EZ_OK == ret) {
			for (j = 0; j < lqi_entry.neighbor_count; j++) {
				if (ZIGBEE_END_DEVICE == lqi_entry.neighbor[j].node_type) {
					ret = zigbee_zdo_leave_request(device_info.device[i].node_id,
												   lqi_entry.neighbor[j].eui64,
												   true,
												   false);
					if (ret == EZ_OK)
						showln("zdo leave child success 0x%04X", lqi_entry.neighbor[j].node_id);
					else
						showln("zdo leave failed: %s", zigbee_error_msg(ret));
				}
			}
		}

		/* zdo leave node when the eui64 equals to the node's */
		ret = zigbee_zdo_leave_request(device_info.device[i].node_id,
									   device_info.device[i].eui64,
									   false,
									   false);
		if (ret == EZ_OK)
			showln("zdo leave success 0x%04X", device_info.device[i].node_id);
		else
			showln("zdo leave failed: %s", zigbee_error_msg(ret));
	}

	showln("Done");
	return ret;
}

static void _show_power_mode(zigbee_power_mode current_power_mode)
{
	switch (current_power_mode) {
	case POWER_MODE_SYNCHRONIZED_WHEN_IDLE:
		showln("Current power mode: synchronized with the receiver on when idle subfield of the node descriptor");
		break;

	case POWER_MODE_COMES_ON_PERIODICALLY:
		showln("Current power mode: comes on periodically as defined by the node power descriptor");
		break;

	case POWER_MODE_COMES_ON_WHEN_STIMULATED:
		showln("Current power mode: comes on when stimulated, for example, by a user pressing a button");
		break;

	default:
		showln("Current power mode: Unknown 0x%02X", current_power_mode);
		break;
	}
}

static void _show_power_source_level(zigbee_power_source_level current_power_source_level)
{
	switch (current_power_source_level) {
	case POWER_SOURCE_LEVEL_CRITICAL:
		showln("Current power source level: critical");
		break;

	case POWER_SOURCE_LEVEL_33:
		showln("Current power source level: 33%");
		break;

	case POWER_SOURCE_LEVEL_66:
		showln("Current power source level: 66%");
		break;

	case POWER_SOURCE_LEVEL_100:
		showln("Current power source level: 100%");
		break;

	default:
		showln("Current power source level: Unknown 0x%02X", current_power_source_level);
		break;
	}
}

static void _show_power_source(uint8_t power_source)
{
	/**
	 * [Available Power Sources Field Bit Number]	[Supported Power Source]
	 * 0											Constant (mains) power
	 * 1											Rechargeable battery
	 * 2											Disposable battery
	 * 3											Reserved
	 */
	show("[");

	if ((power_source & 1) != 0)
		show("Constant (mains) power, ");

	if ((power_source & (1 << 1)) != 0)
		show("Rechargeable battery, ");

	if ((power_source & (1 << 2)) != 0)
		show("Disposable battery, ");

	show("]");
}

static zigbee_error _zdo_power_descriptor_request(void)
{
	zigbee_device_info device_info;
	zigbee_power_descriptor power_descriptor;
	zigbee_error ret = EZ_ERROR;
	int i = 0;

	ret = zigbee_get_discovered_device_list(&device_info);
	if (EZ_OK != ret) {
		showln("Get discovered device failed: %s", zigbee_error_msg(ret));
		return ret;
	}

	if (device_info.num <= 0) {
		showln("Please discover device firstly");
		return EZ_NOT_FOUND;
	}

	for (i = 0; i < device_info.num; i++) {
		ret = zigbee_zdo_power_descriptor_request(device_info.device[i].node_id, &power_descriptor);
		if (ret == EZ_OK) {
			showln("Power descriptor request 0x%04X success", device_info.device[i].node_id);
			show("Node id 0x%04X available power sources ", power_descriptor.node_id);
			_show_power_source(power_descriptor.available_power_sources);
			show(" current power source ");
			_show_power_source(power_descriptor.current_power_source);
			showln("");
			_show_power_mode(power_descriptor.current_power_mode);
			_show_power_source_level(power_descriptor.current_power_source_level);
		} else
			showln("Power descriptor request 0x%04X failed: %s", device_info.device[i].node_id,
					zigbee_error_msg(ret));
	}

	showln("Done");
	return ret;
}

static zigbee_error _zdo_active_endpoints_request(void)
{
	zigbee_device_info device_info;
	zigbee_active_endpoints active_endpoints;
	zigbee_error ret = EZ_ERROR;
	int i = 0, j = 0;

	ret = zigbee_get_discovered_device_list(&device_info);
	if (EZ_OK != ret) {
		showln("Get discovered device failed: %s", zigbee_error_msg(ret));
		return ret;
	}

	if (device_info.num <= 0) {
		showln("Please discover device firstly");
		return EZ_NOT_FOUND;
	}

	for (i = 0; i < device_info.num; i++) {
		ret = zigbee_zdo_active_endpoints_request(device_info.device[i].node_id, &active_endpoints);
		if (EZ_OK != ret)
			showln("Request active endpoints for node 0x%04X failed: %s", device_info.device[i].node_id,
					zigbee_error_msg(ret));
		else {
			showln("Request active endpoints for node 0x%04X success", device_info.device[i].node_id);
			show("Active endpoints information: node 0x%04X endpoint count %d [", active_endpoints.node_id,
					active_endpoints.count);
			for (j = 0; j < active_endpoints.count && j < MAX_ACTIVE_ENDPOINT_COUNT; j++)
				show("%d ", active_endpoints.endpoint_ids[j]);
			showln("]");
		}
	}

	showln("Done");
	return EZ_OK;
}

static zigbee_error _zdo_match_descriptor_request(ZIGBEE_NODE_ID node_id)
{
	ZIGBEE_CLUSTER_ID server_clusters[MAX_ZDO_CLUSTER_COUNT];
	ZIGBEE_CLUSTER_ID client_clusters[MAX_ZDO_CLUSTER_COUNT];
	int server_count = 0;
	int client_count = 0;
	zigbee_error ret = EZ_ERROR;

	server_clusters[server_count] = ZCL_ON_OFF_CLUSTER_ID;
	server_count++;

	client_clusters[client_count] = ZCL_ON_OFF_CLUSTER_ID;
	client_count++;

	/* This is requesting for endpoints which contain On/off server or client cluster */
	ret = zigbee_zdo_match_descriptor_request(node_id, ZIGBEE_PROFILE_HA, server_clusters, server_count,
			client_clusters, client_count);
	if (EZ_OK == ret)
		showln("Match descriptor request (On/off server or client cluster) for node 0x%04X success", node_id);
	else
		showln("Match descriptor request (On/off server or client cluster) for node 0x%04X failed: %s",
				node_id, zigbee_error_msg(ret));

	return ret;
}

static zigbee_error _zdo_match_descriptor_broadcast_request(void)
{
	return _zdo_match_descriptor_request(ZIGBEE_NODE_ID_RX_ON_WHEN_IDLE_BROADCAST);
}

static zigbee_error _zdo_routing_table_request(void)
{
	zigbee_device_info device_info;
	struct zigbee_routing_table_list list;
	zigbee_error ret = EZ_ERROR;
	int i = 0;
	int j = 0;

	ret = zigbee_get_discovered_device_list(&device_info);
	if (EZ_OK != ret) {
		showln("Get discovered device failed: %s", zigbee_error_msg(ret));
		return ret;
	}

	if (device_info.num <= 0) {
		showln("Please discover device firstly");
		return EZ_NOT_FOUND;
	}

	for (i = 0; i < device_info.num; i++) {
		ret = zigbee_zdo_routing_table_request(device_info.device[i].node_id, 0, &list);
		if (EZ_OK != ret)
			showln("Request routing table for node 0x%04X failed: %s", device_info.device[i].node_id,
					zigbee_error_msg(ret));
		else {
			showln("Request routing table for node 0x%04X success", device_info.device[i].node_id);
			showln("Routing table total_num=%d, start_index=%d, count=%d", list.total_num, list.start_index,
					list.count);
			for (j = 0; j < list.count; j++)
				showln("dest_address=0x%04X, next_hop_address=0x%04X, many_to_one=%d,"
						"memory_constrained=%d, route_record_required=%d, status=%s",
						list.entries[j].destination_address, list.entries[j].next_hop_address,
						list.entries[j].many_to_one, list.entries[j].memory_constrained,
						list.entries[j].route_record_required,
						zdo_routing_entry_status[list.entries[j].status]);
		}
	}

	showln("Done");
	return EZ_OK;
}

static zigbee_error _stop_reporting(zigbee_reporting_type reporting_type)
{
	zigbee_endpoint_list endpoint_list;
	struct zigbee_sending_info sending_info;
	zigbee_local_endpoint info;
	zigbee_endpoint *endpoint = NULL;
	struct test_device *test_device = NULL;
	zigbee_error ret = EZ_ERROR;
	int i, j, count = 0;
	bool is_supported = false;
    int cluster_id = 0;

	count = get_test_device_count();
	for (i = 0; i < count; i++) {
		test_device = get_test_device(i);
		if (test_device->stop_reporting != NULL) {
			is_supported = true;
			break;
		}
	}

	if (is_supported == false)
		return EZ_NOT_SUPPORTED;

	switch (reporting_type) {
	case ZIGBEE_REPORTING_MEASURED_TEMPERATURE:
		ret = zigbee_device_find_by_cluster(&endpoint_list, ZCL_TEMP_MEASUREMENT_CLUSTER_ID, 1);
		cluster_id = ZCL_TEMP_MEASUREMENT_CLUSTER_ID;
		break;

	case ZIGBEE_REPORTING_MEASURED_ILLUMINANCE:
		ret = zigbee_device_find_by_cluster(&endpoint_list, ZCL_ILLUM_MEASUREMENT_CLUSTER_ID, 1);
		cluster_id = ZCL_ILLUM_MEASUREMENT_CLUSTER_ID;
		break;

	case ZIGBEE_REPORTING_OCCUPANCY_SENSING:
		ret = zigbee_device_find_by_cluster(&endpoint_list, ZCL_OCCUPANCY_SENSING_CLUSTER_ID, 1);
		cluster_id = ZCL_OCCUPANCY_SENSING_CLUSTER_ID;
		break;

	case ZIGBEE_REPORTING_THERMOSTAT_TEMPERATURE:
		ret = zigbee_device_find_by_cluster(&endpoint_list, ZCL_THERMOSTAT_CLUSTER_ID, 1);
		cluster_id = ZCL_THERMOSTAT_CLUSTER_ID;
		break;

	case ZIGBEE_REPORTING_MEASURED_HUMIDITY:
		ret = zigbee_device_find_by_cluster(&endpoint_list, ZCL_RELATIVE_HUMIDITY_MEASUREMENT_CLUSTER_ID, 1);
		cluster_id = ZCL_RELATIVE_HUMIDITY_MEASUREMENT_CLUSTER_ID;
		break;

	default:
		break;
	}

	if (EZ_OK != ret) {
		showln("Stop Reporting: Find endpoint by cluster failed: %s", zigbee_error_msg(ret));
		return ret;
	}

	for (; i < count; i++) {
		test_device = get_test_device(i);

		if (test_device->stop_reporting == NULL)
			continue;

		ret = zigbee_get_local_endpoint_by_endpointid(&info, test_device->endpoint_id);
		if (EZ_OK != ret)
			continue;

		if (zigbee_check_reporting(info.device_id, reporting_type) != EZ_OK)
			continue;

		if (zigbee_local_endpoint_contains_cluster(info.endpoint_id, cluster_id, false) != EZ_OK)
			continue;

		showln("Stop reporting: testing starting by ep(%d)",
			   test_device->endpoint_id);

		for (j = 0; j < endpoint_list.num; j++) {
			endpoint = &endpoint_list.endpoint[j];
			sending_info.type = ZIGBEE_SENDING_BY_ENDPOINT;
			memcpy(&sending_info.data.dest_endpoint, endpoint, sizeof(zigbee_endpoint));

			ret = test_device->stop_reporting(cluster_id, &sending_info,
											  reporting_type, info.endpoint_id);
			if (ret != ZIGBEE_CMD_SUCCESS)
				showln("Failed to stop reporting %d for result: %d",
					   reporting_type, ret);
			else
				showln("Success to stop reporting %d to node 0x%04x",
					   reporting_type, endpoint->node_id);
		}

		showln("Stop reporting: testing ending by ep(%d)",
			   test_device->endpoint_id);
	}

	return ret;
}

static zigbee_error _measured_illuminance_reporting_test()
{
	zigbee_endpoint_list endpoint_list;
	struct zigbee_sending_info sending_info;
	zigbee_local_endpoint info;
	zigbee_endpoint *endpoint = NULL;
	struct test_device *test_device = NULL;
	zigbee_error ret = EZ_ERROR;
	int i, j, count = 0;
	bool is_supported = false;

	int min_interval = 1;
	int max_interval = 10;
	int illuminance = 10;

	count = get_test_device_count();
	for (i = 0; i < count; i++) {
		test_device = get_test_device(i);
		if (test_device->request_reporting != NULL) {
			is_supported = true;
			break;
		}
	}

	if (is_supported == false)
		return EZ_NOT_SUPPORTED;

	ret = zigbee_device_find_by_cluster(&endpoint_list, ZCL_ILLUM_MEASUREMENT_CLUSTER_ID, 1);
	if (EZ_OK != ret) {
		showln("Illuminance: Find endpoint by cluster failed: %s", zigbee_error_msg(ret));
		return ret;
	}

	for (; i < count; i++) {
		test_device = get_test_device(i);

		if (test_device->request_reporting == NULL)
			continue;

		ret = zigbee_get_local_endpoint_by_endpointid(&info, test_device->endpoint_id);
		if (EZ_OK != ret)
			continue;

		if (zigbee_check_reporting(info.device_id, ZIGBEE_REPORTING_MEASURED_ILLUMINANCE) != EZ_OK)
			continue;

		if (zigbee_local_endpoint_contains_cluster(info.endpoint_id, ZCL_ILLUM_MEASUREMENT_CLUSTER_ID,
				false) != EZ_OK)
			continue;

		showln("Request measured illuminance reporting: testing started by ep(%d)", test_device->endpoint_id);

		for (j = 0; j < endpoint_list.num; j++) {
			endpoint = &endpoint_list.endpoint[j];
			sending_info.type = ZIGBEE_SENDING_BY_ENDPOINT;
			memcpy(&sending_info.data.dest_endpoint, endpoint, sizeof(zigbee_endpoint));

			ret = test_device->request_reporting(ZCL_ILLUM_MEASUREMENT_CLUSTER_ID, &sending_info, ZIGBEE_REPORTING_MEASURED_ILLUMINANCE,
												 min_interval, max_interval, illuminance, info.endpoint_id);
			if (ret != ZIGBEE_CMD_SUCCESS)
				showln("Failed to request measured illuminance reporting for result: %d", ret);
			else
				showln("Success to request measured illuminance reporting to node 0x%04x", endpoint->node_id);
		}

		showln("Request measured illuminance reporting: testing succeeded by ep(%d)", test_device->endpoint_id);
	}

	return ret;
}

static zigbee_error _occypancy_reporting_test()
{
	zigbee_endpoint_list endpoint_list;
	struct zigbee_sending_info sending_info;
	zigbee_local_endpoint info;
	zigbee_endpoint *endpoint = NULL;
	struct test_device *test_device = NULL;
	zigbee_error ret = EZ_ERROR;
	int i = 0, j = 0, count = 0;
	bool is_supported = false;

	int min_interval = 4;
	int max_interval = 10;

	count = get_test_device_count();
	for (i = 0; i < count; i++) {
		test_device = get_test_device(i);
		if (NULL != test_device->request_reporting) {
			is_supported = true;
			break;
		}
	}

	if (false == is_supported)
		return EZ_NOT_SUPPORTED;

	zigbee_device_find_by_cluster(&endpoint_list, ZCL_OCCUPANCY_SENSING_CLUSTER_ID, 1);
	if (endpoint_list.num <= 0) {
		showln("There is no endpoint to request occypancy reporting");
		return EZ_ERROR;
	}

	for (; i < count; i++) {
		test_device = get_test_device(i);

		if (NULL == test_device->request_reporting)
			continue;

		ret = zigbee_get_local_endpoint_by_endpointid(&info, test_device->endpoint_id);
		if (EZ_OK != ret) {
			showln("wrong endpoint_id %d\n", test_device->endpoint_id);
			continue;
		}

		if (EZ_OK != zigbee_check_reporting(info.device_id, ZIGBEE_REPORTING_OCCUPANCY_SENSING))
			continue;

		if (zigbee_local_endpoint_contains_cluster(info.endpoint_id, ZCL_OCCUPANCY_SENSING_CLUSTER_ID,
			false) != EZ_OK)
			continue;

		showln("Request Occupancy reporting: testing started by ep(%d)", test_device->endpoint_id);

		for (j = 0; j < endpoint_list.num; j++) {
			endpoint = &endpoint_list.endpoint[j];
			sending_info.type = ZIGBEE_SENDING_BY_ENDPOINT;
			memcpy(&sending_info.data.dest_endpoint, endpoint, sizeof(zigbee_endpoint));

			/* The change_threshold has no meaning for Occupancy Reporting */
			ret = test_device->request_reporting(ZCL_OCCUPANCY_SENSING_CLUSTER_ID, &sending_info,
					ZIGBEE_REPORTING_OCCUPANCY_SENSING, min_interval, max_interval, 0,
					info.endpoint_id);
			if (EZ_OK != ret) {
				showln("Failed to request Occupancy reporting to node 0x%04X for result: %d",
						endpoint->node_id, ret);
				break;
			} else
				showln("Success to request Occupancy reporting to node 0x%04X", endpoint->node_id);
		}

		showln("Request Occupancy reporting: testing end by ep(%d)", test_device->endpoint_id);
	}

	return ret;
}

static zigbee_error _measured_temperature_reporting_test(void)
{
	zigbee_endpoint_list endpoint_list;
	struct zigbee_sending_info sending_info;
	zigbee_local_endpoint info_point;
	zigbee_endpoint *endpoint = NULL;
	struct test_device *test_device = NULL;
	zigbee_error ret = EZ_ERROR;
	int i = 0, j = 0, count = 0;
	bool is_supported = false;

	int min_interval = 1;
	int max_interval = 10;
	int temperature = 10;

	count = get_test_device_count();
	for (i = 0; i < count; i++) {
		test_device = get_test_device(i);
		if (NULL != test_device->request_reporting) {
			is_supported = true;
			break;
		}
	}

	if (false == is_supported)
		return EZ_NOT_SUPPORTED;

	zigbee_device_find_by_cluster(&endpoint_list, ZCL_TEMP_MEASUREMENT_CLUSTER_ID, 1);
	if (endpoint_list.num <= 0) {
		showln("There is no endpoint to request measured temperature reporting");
		return EZ_ERROR;
	}

	for (; i < count; i++) {
		test_device = get_test_device(i);

		if (NULL == test_device->request_reporting)
			continue;

		ret = zigbee_get_local_endpoint_by_endpointid(&info_point, test_device->endpoint_id);
		if (EZ_OK != ret) {
			showln("wrong device->endpoint_id %d\n", test_device->endpoint_id);
			return EZ_NOT_FOUND;
		}

		if (EZ_OK != zigbee_check_reporting(info_point.device_id, ZIGBEE_REPORTING_MEASURED_TEMPERATURE))
			continue;

		if (EZ_OK != zigbee_local_endpoint_contains_cluster(info_point.endpoint_id,
						ZCL_TEMP_MEASUREMENT_CLUSTER_ID, false))
			continue;

		showln("Request measured temperature reporting: testing started by ep(%d)",
				test_device->endpoint_id);

		for (j = 0; j < endpoint_list.num; j++) {
			endpoint = &endpoint_list.endpoint[j];
			sending_info.type = ZIGBEE_SENDING_BY_ENDPOINT;
			memcpy(&sending_info.data.dest_endpoint, endpoint, sizeof(zigbee_endpoint));

			ret = test_device->request_reporting(ZCL_TEMP_MEASUREMENT_CLUSTER_ID, &sending_info,
					ZIGBEE_REPORTING_MEASURED_TEMPERATURE, min_interval, max_interval, temperature,
					info_point.endpoint_id);
			if (EZ_OK != ret) {
				showln("Failed to request measured temperature reporting for result: %d", ret);
				return ret;
			} else
				showln("Success to request measured temperature reporting to node 0x%04x",
						endpoint->node_id);
		}

		showln("Request measured temperature reporting: testing succeeded by ep(%d)",
				test_device->endpoint_id);
	}

	return EZ_OK;
}

static zigbee_error _measured_humidity_reporting_test(void)
{
	zigbee_endpoint_list endpoint_list;
	struct zigbee_sending_info sending_info;
	zigbee_local_endpoint info_point;
	zigbee_endpoint *endpoint = NULL;
	struct test_device *test_device = NULL;
	zigbee_error ret = EZ_ERROR;
	int i = 0, j = 0, count = 0;
	bool is_supported = false;

	int min_interval = 1;
	int max_interval = 10;
	int humidity = 10;

	count = get_test_device_count();
	for (i = 0; i < count; i++) {
		test_device = get_test_device(i);
		if (NULL != test_device->request_reporting) {
			is_supported = true;
			break;
		}
	}

	if (false == is_supported)
		return EZ_NOT_SUPPORTED;

	zigbee_device_find_by_cluster(&endpoint_list, ZCL_RELATIVE_HUMIDITY_MEASUREMENT_CLUSTER_ID, 1);
	if (endpoint_list.num <= 0) {
		showln("There is no endpoint to request measured humidity reporting");
		return EZ_ERROR;
	}

	for (; i < count; i++) {
		test_device = get_test_device(i);

		if (NULL == test_device->request_reporting)
			continue;

		ret = zigbee_get_local_endpoint_by_endpointid(&info_point, test_device->endpoint_id);
		if (EZ_OK != ret) {
			showln("wrong device->endpoint_id %d\n", test_device->endpoint_id);
			continue;
		}

		if (EZ_OK != zigbee_check_reporting(info_point.device_id, ZIGBEE_REPORTING_MEASURED_HUMIDITY))
			continue;

		if (EZ_OK != zigbee_local_endpoint_contains_cluster(info_point.endpoint_id,
						ZCL_RELATIVE_HUMIDITY_MEASUREMENT_CLUSTER_ID, false))
			continue;

		showln("Request measured humidity reporting: testing started by ep(%d)",
				test_device->endpoint_id);

		for (j = 0; j < endpoint_list.num; j++) {
			endpoint = &endpoint_list.endpoint[j];
			sending_info.type = ZIGBEE_SENDING_BY_ENDPOINT;
			memcpy(&sending_info.data.dest_endpoint, endpoint, sizeof(zigbee_endpoint));

			ret = test_device->request_reporting(ZCL_RELATIVE_HUMIDITY_MEASUREMENT_CLUSTER_ID, &sending_info,
					ZIGBEE_REPORTING_MEASURED_HUMIDITY, min_interval, max_interval, humidity,
					info_point.endpoint_id);
			if (EZ_OK != ret) {
				showln("Failed to request measured humidity reporting for result: %d", ret);
				return ret;
			} else
				showln("Success to request measured humidity reporting to node 0x%04x",
						endpoint->node_id);
		}

		showln("Request measured humidity reporting: testing succeeded by ep(%d)",
				test_device->endpoint_id);
	}

	return EZ_OK;
}

static zigbee_error _remote_control_test()
{
	struct test_device *test_device = NULL;
	int i, count = 0;
	bool is_supported = false;

	count = get_test_device_count();
	for (i = 0; i < count; i++) {
		test_device = get_test_device(i);
		if (test_device->reset_to_factory_default != NULL
				&& test_device->request_reporting != NULL) {
			is_supported = true;
			break;
		}
	}

	if (is_supported == false)
		return EZ_NOT_SUPPORTED;

	_do_basic_remote_control();
	showln("Remote control: testing succeeded");
	return EZ_OK;
}

static void _print_param_data(struct zigbee_raw_parameter_data data)
{
	uint8_t val_uint8 = 0;
	uint16_t val_uint16 = 0;
	uint32_t val_uint32 = 0;
	int i = 0;

	switch (data.type) {
	case RAW_DATA_U8:
		memcpy(&val_uint8, data.data, sizeof(val_uint8));
		show("RAW_DATA_U8: 0x%02X", val_uint8);
		break;

	case RAW_DATA_U16:
		memcpy(&val_uint16, data.data, sizeof(val_uint16));
		show("RAW_DATA_U16: 0x%04X", val_uint16);
		break;

	case RAW_DATA_U32:
		memcpy(&val_uint32, data.data, sizeof(val_uint32));
		show("RAW_DATA_U32: 0x%08X", val_uint32);
		break;

	case RAW_DATA_ARRAY_U8:
		show("RAW_DATA_ARRAY_U8:");
		for (i = 0; i < data.length; i++) {
			memcpy(&val_uint8, data.data + i * sizeof(val_uint8), sizeof(val_uint8));
			show(" %02X", val_uint8);
		}
		break;

	case RAW_DATA_ARRAY_U16:
		show("RAW_DATA_ARRAY_U16:");
		for (i = 0; i < data.length; i++) {
			memcpy(&val_uint16, data.data + i * sizeof(val_uint16), sizeof(val_uint16));
			show(" %04X", val_uint16);
		}
		break;

	case RAW_DATA_ARRAY_U32:
		show("RAW_DATA_ARRAY_U32:");
		for (i = 0; i < data.length; i++) {
			memcpy(&val_uint32, data.data + i * sizeof(val_uint32), sizeof(val_uint32));
			show(" %02X", val_uint32);
		}
		break;

	case RAW_DATA_STRING:
		show("RAW_DATA_STRING: %s", data.data);
		break;

	default:
		show("UNKNOWN");
		break;
	}
}

static void _print_payload_usage(void)
{
	showln("If there isn't any payload, user doesn't need input any texts, otherwise please follow below rules");
	showln("payload: this command's payload. There are 7 kinds of types:");
	showln("%d: RAW_DATA_U8", RAW_DATA_U8);
	showln("%d: RAW_DATA_U16", RAW_DATA_U16);
	showln("%d: RAW_DATA_U32", RAW_DATA_U32);
	showln("%d: RAW_DATA_ARRAY_U8", RAW_DATA_ARRAY_U8);
	showln("%d: RAW_DATA_ARRAY_U16", RAW_DATA_ARRAY_U16);
	showln("%d: RAW_DATA_ARRAY_U32", RAW_DATA_ARRAY_U32);
	showln("%d: RAW_DATA_STRING", RAW_DATA_STRING);
	showln("If it is not an array, it should be typed type + data. such as RAW_DATA_U8, it should be typed like: %d 12", RAW_DATA_U8);
	showln("If it is an array, it should be typed type + count + datas. such as RAW_DATA_ARRAY_U8, it should be typed like:%d 4 1 2 3 4", RAW_DATA_ARRAY_U8);
	showln("If it is a string, it should be typed like: %d zigbee_group", RAW_DATA_STRING);
	showln("For multiple parameters, just append the later one to the former one with a space character."
		   "It should be typed like:type1 + data1 + type2 + data2 + type3 + count3 + data3");
	showln("For example: first parameter is RAW_DATA_U8, value is 1, second parameter is RAW_DATA_ARRAY_U8,"
		   "count is 4, value is 1,2,3,4 respectively, it should be typed like:"
		   "%d 1 %d 4 1 2 3 4", RAW_DATA_U8, RAW_DATA_ARRAY_U8);
}

static void _print_zigbee_raw_command_usage(void)
{
	showln("zigbee raw command usage:");
	showln("%s <dest node id> <dest endpoint id> <local endpoint id> <manufacturer code> <direction> <cluster id> <command id> <payload>", zigbee_raw_command_prefix);
	showln("dest node id: destination node id, 2 bytes, it must be hex, such as 0x0045");
	showln("dest endpoint id: destination endpoint id, 1 byte, it must be decimalism, such as 19");
	showln("local endpoint id: local endpoint id, 1 byte, it must be decimalism, such as 1");
	showln("manufacturer code: manufacturer code, 2 bytes, it must be hex, such as 0x0001. Please note that 0x0000 means a zcl command without manufacturer code");
	showln("direction: 0 represents server to client, otherwise, client to server");
	showln("cluster id: cluster id, 2 bytes, it must be hex, such as 0x0006");
	showln("command id: command id, 1 byte, it must be hex, such as 0x00");
	_print_payload_usage();
	showln("\nFor example, send a identify command, it should be typed:");
	showln("%s 0x0012 2 1 0x0000 1 0x0003 0x00 1 0x0080", zigbee_raw_command_prefix);
}

static zigbee_error _zcl_raw_command_parse_argument(char *input)
{
	const char delims[] = " ";
	char *result = NULL;
	enum zcl_raw_command_argument_step step = RAW_COMMAND_DEST_NODE;
	enum zcl_raw_command_argument_type argument_type = ARGUMENT_DATA_TYPE;
	int payload_count = 0;
	int argument = 0;
	int data_size = 0;
	int array_total_count = 0;
	int array_count = 0;

	if (NULL == input) {
		showln("Parse argument, input is NULL");
		return EZ_BAD_ARGS;
	}

	*(input + strlen(input) - 1) = 0;	/* remove the last character \n from keyboard input */

	result = strtok(input, delims);

	if (0 != strcmp(result, zigbee_raw_command_prefix)) {
		showln("Command should start with %s", zigbee_raw_command_prefix);
		return EZ_ERROR;
	}

	while (result != NULL) {
		result = strtok(NULL, delims);

		if (NULL == result)
			break;

		argument = read_int(result, strlen(result), -1);

		if (RAW_COMMAND_DEST_NODE == step)
			zcl_raw_data.dest_node_id = argument;
		else if (RAW_COMMAND_DEST_EP == step)
			zcl_raw_data.dest_endpoint = argument;
		else if (RAW_COMMAND_LOCAL_EP == step)
			zcl_raw_data.local_endpoint = argument;
		else if (RAW_COMMAND_MANUFACTURE_CODE == step)
			zcl_raw_data.manufacturer_code = argument;
		else if (RAW_COMMAND_DIRECTION == step) {
			if (0 == argument)
				zcl_raw_data.client_to_server = false;
			else
				zcl_raw_data.client_to_server = true;
		} else if (RAW_COMMAND_CLUSTER_ID == step)
			zcl_raw_data.cluster_id = argument;
		else if (RAW_COMMAND_COMMAND_ID == step)
			zcl_raw_data.command_id = argument;
		else if (RAW_COMMAND_PAYLOAD <= step) {
			if (ARGUMENT_DATA_TYPE == argument_type) {
				if (argument < RAW_DATA_U8 || argument > RAW_DATA_STRING) {
					showln("Data type is error %d", argument);
					return EZ_ERROR;
				}

				if (RAW_DATA_U8 == argument) {
					data_size = 1;
					array_total_count = 0;
					argument_type = ARGUMENT_DATA_CONTENT;
				} else if (RAW_DATA_U16 == argument) {
					data_size = 2;
					array_total_count = 0;
					argument_type = ARGUMENT_DATA_CONTENT;
				} else if (RAW_DATA_U32 == argument) {
					data_size = 4;
					array_total_count = 0;
					argument_type = ARGUMENT_DATA_CONTENT;
				} else if (RAW_DATA_ARRAY_U8 == argument) {
					data_size = 1;
					argument_type = ARGUMENT_DATA_COUNT;
				} else if (RAW_DATA_ARRAY_U16 == argument) {
					data_size = 2;
					argument_type = ARGUMENT_DATA_COUNT;
				} else if (RAW_DATA_ARRAY_U32 == argument) {
					data_size = 4;
					argument_type = ARGUMENT_DATA_COUNT;
				} else if (RAW_DATA_STRING == argument) {
					argument_type = ARGUMENT_DATA_CONTENT;
					array_total_count = 0;
				}

				zcl_raw_data.payload.parameter[payload_count].type = argument;
			} else if (ARGUMENT_DATA_COUNT == argument_type) {
				array_total_count = argument;
				array_count = 0;
				argument_type = ARGUMENT_DATA_CONTENT;
			} else if (ARGUMENT_DATA_CONTENT == argument_type) {
				if (0 == array_total_count) {
					if (RAW_DATA_STRING == zcl_raw_data.payload.parameter[payload_count].type)
						strcpy(zcl_raw_data.payload.parameter[payload_count].data, result);
					else
						memcpy(zcl_raw_data.payload.parameter[payload_count].data, &argument,
							   data_size);

					payload_count++;
					argument_type = ARGUMENT_DATA_TYPE;
				} else {
					memcpy(zcl_raw_data.payload.parameter[payload_count].data + data_size * array_count,
						   &argument, data_size);
					array_count++;

					if (array_count == array_total_count) {
						argument_type = ARGUMENT_DATA_TYPE;
						zcl_raw_data.payload.parameter[payload_count].length = array_total_count;
						payload_count++;
					}
				}
			}
		}

		step++;
	}

	zcl_raw_data.payload.count = payload_count;

	if (RAW_COMMAND_PAYLOAD <= step)
		return EZ_OK;
	else
		return EZ_ERROR;

}

static zigbee_error _zcl_raw_command_test(void)
{
	struct zigbee_sending_info sending_info;
	zigbee_error ret = EZ_OK;
	int i = 0;

	if (zcl_raw_data.local_endpoint <= 0 || zcl_raw_data.dest_endpoint <= 0) {
		showln("Please set zcl sending information");
		return EZ_ERROR;
	}

	showln("Send zcl raw command: dest node id 0x%04X dest endpoint %d local endpoint %d",
			zcl_raw_data.dest_node_id, zcl_raw_data.dest_endpoint, zcl_raw_data.local_endpoint);
	showln("Command information: manufacturer code 0x%04X client-to-server %d cluster 0x%04X command 0x%02X",
			zcl_raw_data.manufacturer_code, zcl_raw_data.client_to_server, zcl_raw_data.cluster_id,
			zcl_raw_data.command_id);
	show("Command payload[");
	for (i = 0; i < zcl_raw_data.payload.count; i++) {
		show("{");
		_print_param_data(zcl_raw_data.payload.parameter[i]);
		show("}, ");
	}
	showln("]");

	sending_info.type = ZIGBEE_SENDING_BY_ENDPOINT;
	sending_info.data.dest_endpoint.node_id = zcl_raw_data.dest_node_id;
	sending_info.data.dest_endpoint.endpoint_id = zcl_raw_data.dest_endpoint;
	ret = zigbee_zcl_raw_command(&sending_info, zcl_raw_data.manufacturer_code,
			zcl_raw_data.client_to_server, zcl_raw_data.cluster_id, zcl_raw_data.command_id,
			&zcl_raw_data.payload, zcl_raw_data.local_endpoint);

	return ret;
}

static void _func_entry(func func)
{
	current_func = func;
	current_func(NULL, 0);
}

static void _thermostat_read_ocupied_setpoint_request(struct zigbee_sending_info sending_info, int local_ep)
{
	int temperature = 0;
	float temperature_celsius = 0;
	zigbee_error ret = EZ_ERROR;

	ret = zigbee_thermostat_read_occupied_cooling_setpoint(&sending_info, &temperature, local_ep);
	if (EZ_OK == ret) {
		ret = zigbee_temperature_to_celsius(temperature, &temperature_celsius);
		if (EZ_OK == ret)
			showln("Read occupied cooling setpoint %d Celsius %.2f", temperature, temperature_celsius);
		else
			showln("Read occupied cooling setpoint %d get Celsius error: %s", temperature,
					zigbee_error_msg(ret));
	} else
		showln("Read occupied cooling setpoint error: %s", zigbee_error_msg(ret));

	ret = zigbee_thermostat_read_occupied_heating_setpoint(&sending_info, &temperature, local_ep);
	if (EZ_OK == ret) {
		ret = zigbee_temperature_to_celsius(temperature, &temperature_celsius);
		if (EZ_OK == ret)
			showln("Read occupied heating setpoint %d Celsius %.2f", temperature, temperature_celsius);
		else
			showln("Read occupied heating setpoint %d get Celsius error: %s", temperature,
					zigbee_error_msg(ret));
	} else
		showln("Read occupied heating setpoint error: %s", zigbee_error_msg(ret));
}

static void _thermostat_setpoint_raise_lower_request(struct zigbee_sending_info sending_info,
													 int local_ep, int temperature)
{
	zigbee_error ret = EZ_ERROR;

	ret = zigbee_thermostat_request_setpoint_raise_lower(&sending_info, ZIGBEE_SETPOINT_MODE_BOTH,
			temperature, local_ep);
	if (EZ_OK == ret)
		showln("Request setpoint raise lower %d success", temperature);
	else
		showln("Request setpoint raise lower %d error: %s", temperature, zigbee_error_msg(ret));
}

static void _thermostat_client_setpoint_request(struct zigbee_sending_info sending_info, int local_ep)
{
	_thermostat_read_ocupied_setpoint_request(sending_info, local_ep);

	_thermostat_setpoint_raise_lower_request(sending_info, local_ep, 6);
	_thermostat_read_ocupied_setpoint_request(sending_info, local_ep);

	_thermostat_setpoint_raise_lower_request(sending_info, local_ep, -8);
	_thermostat_read_ocupied_setpoint_request(sending_info, local_ep);
}

static void _thermostat_client_mode_sequence_request(struct zigbee_sending_info sending_info, int local_ep)
{
	zigbee_thermostat_control_sequence seq = ZIGBEE_CONTROL_SEQUENCE_RESERVED;
	zigbee_thermostat_system_mode mode = ZIGBEE_SYSTEM_MODE_RESERVED;
	zigbee_error ret = EZ_ERROR;

	ret = zigbee_thermostat_read_system_mode(&sending_info, &mode, local_ep);
	if (EZ_OK == ret)
		showln("Read system mode %d", mode);
	else
		showln("Read system mode error: %s", zigbee_error_msg(ret));

	mode = ZIGBEE_SYSTEM_MODE_AUTO;
	ret = zigbee_thermostat_write_system_mode(&sending_info, mode, local_ep);
	if (EZ_OK == ret)
		showln("Write system mode %d success", mode);
	else
		showln("Write system mode %d error: %s", mode, zigbee_error_msg(ret));

	ret = zigbee_thermostat_read_system_mode(&sending_info, &mode, local_ep);
	if (EZ_OK == ret)
		showln("Read system mode %d", mode);
	else
		showln("Read system mode error: %s", zigbee_error_msg(ret));

	ret = zigbee_thermostat_read_control_sequence(&sending_info, &seq, local_ep);
	if (EZ_OK == ret)
		showln("Read control sequence %d", seq);
	else
		showln("Read control sequence error: %s", zigbee_error_msg(ret));

	seq = ZIGBEE_CONTROL_SEQUENCE_COOLING_HEATING;
	ret = zigbee_thermostat_write_control_sequence(&sending_info, seq, local_ep);
	if (EZ_OK == ret)
		showln("Write control sequence %d success", seq);
	else
		showln("Write control sequence %d error: %s", seq, zigbee_error_msg(ret));

	ret = zigbee_thermostat_read_control_sequence(&sending_info, &seq, local_ep);
	if (EZ_OK == ret)
		showln("Read control sequence %d", seq);
	else
		showln("Read control sequence error: %s", zigbee_error_msg(ret));
}

static void _thermostat_client_request(int local_ep)
{
	struct zigbee_sending_info sending_info;
	zigbee_endpoint_list remote_eps;
	zigbee_endpoint *remote_ep = NULL;
	zigbee_error ret = EZ_ERROR;
	int i = 0;

	ret = zigbee_device_find_by_cluster(&remote_eps, ZCL_THERMOSTAT_CLUSTER_ID, 1);
	if (EZ_OK != ret) {
		showln("Find remote device by server cluster 0x%04X error: %s", ZCL_THERMOSTAT_CLUSTER_ID,
				zigbee_error_msg(ret));
		return;
	}

	if (remote_eps.num <= 0) {
		showln("There is no remote endpoint for server cluster 0x%04X", ZCL_THERMOSTAT_CLUSTER_ID);
		return;
	}

	for (i = 0; i < remote_eps.num; i++) {
		remote_ep = &remote_eps.endpoint[i];
		sending_info.type = ZIGBEE_SENDING_BY_ENDPOINT;
		memcpy(&sending_info.data.dest_endpoint, remote_ep, sizeof(zigbee_endpoint));

		showln("Requesting for remote node 0x%04X endpint %d start", remote_ep->node_id,
				remote_ep->endpoint_id);

		_thermostat_client_mode_sequence_request(sending_info, local_ep);
		_thermostat_client_setpoint_request(sending_info, local_ep);

		showln("Requesting for remote node 0x%04X endpint %d end", remote_ep->node_id,
				remote_ep->endpoint_id);
	}
}

static void _thermostat_client_test(void)
{
	zigbee_local_endpoint_info endpoint_info;
	zigbee_local_endpoint local_ep;
	zigbee_error ret = EZ_ERROR;
	int i = 0;

	ret = zigbee_get_local_endpoint(&endpoint_info);
	if (EZ_OK != ret) {
		showln("Get local endpoint error: %s", zigbee_error_msg(ret));
		return;
	}

	for (i = 0; i < endpoint_info.count; i++) {
		local_ep = endpoint_info.endpoints[i];

		if (_local_endpoint_contains_cluster(local_ep, ZCL_THERMOSTAT_CLUSTER_ID, false)) {
			showln("Thermostat client request by local endpoint %d", local_ep.endpoint_id);
			_thermostat_client_request(local_ep.endpoint_id);
		} else
			showln("Local endpoint %d does not contain Thermostat client cluster", local_ep.endpoint_id);
	}

	showln("Done");
}

static void _thermostat_server_getting(int local_ep)
{
	zigbee_thermostat_control_sequence seq = ZIGBEE_CONTROL_SEQUENCE_RESERVED;
	zigbee_occupancy_status status = ZIGBEE_UNOCCUPIED;
	zigbee_thermostat_system_mode mode = ZIGBEE_SYSTEM_MODE_RESERVED;
	int temperature = 0;
	float temperature_celsius = 0;
	zigbee_error ret = EZ_ERROR;

	ret = zigbee_thermostat_get_system_mode(local_ep, &mode);
	if (EZ_OK == ret)
		showln("Get system mode %d", mode);
	else
		showln("Get system mode error: %s", zigbee_error_msg(ret));

	ret = zigbee_thermostat_get_control_sequence(local_ep, &seq);
	if (EZ_OK == ret)
		showln("Get control sequence %d", seq);
	else
		showln("Get control sequence error: %s", zigbee_error_msg(ret));

	ret = zigbee_thermostat_get_occupancy_status(local_ep, &status);
	if (EZ_OK == ret)
		showln("Get occupancy status %d", status);
	else
		showln("Get occupancy status error: %s", zigbee_error_msg(ret));

	ret = zigbee_thermostat_get_local_temperature(local_ep, &temperature);
	if (EZ_OK == ret) {
		ret = zigbee_temperature_to_celsius(temperature, &temperature_celsius);
		if (EZ_OK == ret)
			showln("Get temperature %d Celsius %.2f", temperature, temperature_celsius);
		else
			showln("Get temperature %d get Celsius error: %s", temperature, zigbee_error_msg(ret));
	} else
		showln("Get temperature error: %s", zigbee_error_msg(ret));

	ret = zigbee_thermostat_get_occupied_cooling_setpoint(local_ep, &temperature);
	if (EZ_OK == ret) {
		ret = zigbee_temperature_to_celsius(temperature, &temperature_celsius);
		if (EZ_OK == ret)
			showln("Get occupied cooling setpoint %d Celsius %.2f", temperature, temperature_celsius);
		else
			showln("Get occupied cooling setpoint %d get Celsius error: %s", temperature,
					zigbee_error_msg(ret));
	} else
		showln("Get occupied cooling setpoint error: %s", zigbee_error_msg(ret));

	ret = zigbee_thermostat_get_occupied_heating_setpoint(local_ep, &temperature);
	if (EZ_OK == ret) {
		ret = zigbee_temperature_to_celsius(temperature, &temperature_celsius);
		if (EZ_OK == ret)
			showln("Get occupied heating setpoint %d Celsius %.2f", temperature, temperature_celsius);
		else
			showln("Get occupied heating setpoint %d get Celsius error: %s", temperature,
					zigbee_error_msg(ret));
	} else
		showln("Get occupied heating setpoint error: %s", zigbee_error_msg(ret));
}

static void _thermostat_server_getting_test(void)
{
	zigbee_local_endpoint_info endpoint_info;
	zigbee_local_endpoint local_ep;
	zigbee_error ret = EZ_ERROR;
	int i = 0;

	ret = zigbee_get_local_endpoint(&endpoint_info);
	if (EZ_OK != ret) {
		showln("Get local endpoint error: %s", zigbee_error_msg(ret));
		return;
	}

	for (i = 0; i < endpoint_info.count; i++) {
		local_ep = endpoint_info.endpoints[i];

		if (_local_endpoint_contains_cluster(local_ep, ZCL_THERMOSTAT_CLUSTER_ID, true)) {
			showln("Thermostat server getting by local endpoint %d", local_ep.endpoint_id);
			_thermostat_server_getting(local_ep.endpoint_id);
		} else
			showln("Local endpoint %d does not contain Thermostat server cluster", local_ep.endpoint_id);
	}

	showln("Done");
}

static void _thermostat_server_setting(int local_ep)
{
	zigbee_error ret = EZ_ERROR;

	ret = zigbee_thermostat_set_system_mode(local_ep, thermostat_system_mode);
	if (EZ_OK == ret)
		showln("Set system mode %d success", thermostat_system_mode);
	else
		showln("Set system mode %d error: %s", thermostat_system_mode, zigbee_error_msg(ret));

	ret = zigbee_thermostat_set_control_sequence(local_ep, thermostat_control_sequence);
	if (EZ_OK == ret)
		showln("Set control sequence %d success", thermostat_control_sequence);
	else
		showln("Set control sequence %d error: %s", thermostat_control_sequence, zigbee_error_msg(ret));

	ret = zigbee_thermostat_set_occupancy_status(local_ep, thermostat_occupancy_status);
	if (EZ_OK == ret)
		showln("Set occupancy status %d success", thermostat_occupancy_status);
	else
		showln("Set occupancy status %d error: %s", thermostat_occupancy_status, zigbee_error_msg(ret));

	ret = zigbee_thermostat_set_local_temperature(local_ep, thermostat_temperature);
	if (EZ_OK == ret)
		showln("Set local temperature %d success", thermostat_temperature);
	else
		showln("Set local temperature %d error: %s", thermostat_temperature, zigbee_error_msg(ret));

	ret = zigbee_thermostat_set_occupied_cooling_setpoint(local_ep, thermostat_temperature + 10);
	if (EZ_OK == ret)
		showln("Set occupied cooling setpoint %d success", thermostat_temperature + 10);
	else
		showln("Set occupied cooling setpoint %d error: %s", thermostat_temperature + 10,
				zigbee_error_msg(ret));

	ret = zigbee_thermostat_set_occupied_heating_setpoint(local_ep, thermostat_temperature - 10);
	if (EZ_OK == ret)
		showln("Set occupied heating setpoint %d success", thermostat_temperature - 10);
	else
		showln("Set occupied heating setpoint %d error: %s", thermostat_temperature - 10,
				zigbee_error_msg(ret));
}

static void _thermostat_server_setting_test(void)
{
	zigbee_local_endpoint_info endpoint_info;
	zigbee_local_endpoint local_ep;
	zigbee_error ret = EZ_ERROR;
	int i = 0;

	ret = zigbee_get_local_endpoint(&endpoint_info);
	if (EZ_OK != ret) {
		showln("Get local endpoint error: %s", zigbee_error_msg(ret));
		return;
	}

	if (ZIGBEE_SYSTEM_MODE_RESERVED <= thermostat_system_mode)
		thermostat_system_mode = ZIGBEE_SYSTEM_MODE_OFF;

	if (ZIGBEE_CONTROL_SEQUENCE_RESERVED <= thermostat_control_sequence)
		thermostat_control_sequence = ZIGBEE_CONTROL_SEQUENCE_COOLING_ONLY;

	if (ZIGBEE_UNOCCUPIED < thermostat_occupancy_status)
		thermostat_occupancy_status = ZIGBEE_OCCUPIED;

	if (TEMPERATURE_MAX_VALUE < thermostat_temperature)
		thermostat_temperature = TEMPERATURE_MIN_VALUE;

	for (i = 0; i < endpoint_info.count; i++) {
		local_ep = endpoint_info.endpoints[i];

		if (_local_endpoint_contains_cluster(local_ep, ZCL_THERMOSTAT_CLUSTER_ID, true)) {
			showln("Thermostat server setting by local endpoint %d", local_ep.endpoint_id);
			_thermostat_server_setting(local_ep.endpoint_id);
		} else
			showln("Local endpoint %d does not contain Thermostat server cluster", local_ep.endpoint_id);
	}

	thermostat_system_mode++;
	thermostat_control_sequence++;
	thermostat_occupancy_status++;
	thermostat_temperature++;
	showln("Done");
}

static void _func_thermostat_show(void)
{
	showln("%d: Thermostat client test", OPT_THERMOSTAT_CLIENT);
	showln("%d: Thermostat server setting test", OPT_THERMOSTAT_SERVER_SET);
	showln("%d: Thermostat server getting test", OPT_THERMOSTAT_SERVER_GET);
	showln("0: Main test");
	showln("e: Exit (Quit with calling clean and reset device)");
	showln("q: Quit (Quit without calling clean and reset device)");
}

static void _thermostat_test(enum operation_thermostat_test opt_thermostat)
{
	switch (opt_thermostat) {
	case OPT_THERMOSTAT_CLIENT:
		_thermostat_client_test();
		break;

	case OPT_THERMOSTAT_SERVER_SET:
		_thermostat_server_setting_test();
		break;

	case OPT_THERMOSTAT_SERVER_GET:
		_thermostat_server_getting_test();
		break;

	default:
		showln("Unknown operation %d in thermostat test", opt_thermostat);
	}
}

static void _func_thermostat(char *input, int max_size)
{
	static int step;
	int n = 0;
	zigbee_error ret = EZ_OK;

	if (input == NULL)
		step = 0;

	switch (step) {
	case 0:
		show_hyphen();
		_func_thermostat_show();
		show_select();
		step = 1;
		break;

	case 1:
		if (read_q(input, max_size) == true) {
			g_main_loop_quit(mainloop);
			return;
		}

		if (read_e(input, max_size) == true) {
			ret = zigbee_reset_local();
			if (ret != EZ_OK)
				fprintf(stderr, "clean and reset device failed:%s", zigbee_error_msg(ret));
			else
				showln("clean and reset device success");
			g_main_loop_quit(mainloop);
			return;
		}

		if (read_lf(input, max_size) == true) {
			show_hyphen();
			_func_thermostat_show();
			show_select();
			break;
		}

		n = read_int(input, max_size, -1);

		switch (n) {
		case 0:
			_func_entry(_func_main);
			break;

		default:
			_thermostat_test((enum operation_thermostat_test)n);
			break;
		}
		break;

	default:
		fprintf(stderr, "Unknown step %d", step);
		break;
	}
}

static void _func_general_api_show()
{
	showln("%d: General read local attribute", OPT_GENERAL_READ_LOCAL_ATTRIBUTE);
	showln("%d: General write local attribute", OPT_GENERAL_WRITE_LOCAL_ATTRIBUTE);
	showln("%d: General read remote attribute", OPT_GENERAL_READ_REMOTE_ATTRIBUTE);
	showln("%d: General write remote attribute", OPT_GENERAL_WRITE_REMOTE_ATTRIBUTE);
	showln("%d: General request reporting", OPT_GENERAL_REQUEST_REPORTING);
	showln("%d: General stop reporting", OPT_GENERAL_STOP_REPORTING);
	showln("%d: General read reporting config", OPT_GENERAL_READ_REPORTING_CONFIG);
	showln("%d: General discovery attribute", OPT_GENERAL_DISCOVERY_ATTRIBUTE);
	showln("%d: Main testing", OPT_GENERAL_MAIN_TESTING);
	showln("e: Exit (Quit with calling clean and reset device)");
	showln("q: Quit (Quit without calling clean and reset device)");
}

static void _func_zcl_raw_command_show(void)
{
	_print_zigbee_raw_command_usage();
	show_hyphen();
	showln("%d: Main testing", OPT_GENERAL_MAIN_TESTING);
	showln("e: Exit (Quit with calling clean and reset device)");
	showln("q: Quit (Quit without calling clean and reset device)");
}

static void _zcl_get_cli_arguments(char *input, int max_size)
{
	zigbee_error ret = EZ_OK;

	if (EZ_OK == _zcl_raw_command_parse_argument(input)) {
		ret = _zcl_raw_command_test();
		if (EZ_OK == ret)
			showln("Done");
		else
			showln("Test failed: %s", zigbee_error_msg(ret));
	} else
		showln("Raw command arguments are error");
}

static void _func_zcl_raw_command(char *input, int max_size)
{
	static int step;
	int n = 0;
	zigbee_error ret = EZ_OK;

	if (NULL == input)
		step = 0;

	switch (step) {
	case 0:
		show_hyphen();
		_func_zcl_raw_command_show();
		show_select();
		step = 1;
		break;

	case 1:
		if (read_q(input, max_size)) {
			g_main_loop_quit(mainloop);
			return;
		}

		if (read_e(input, max_size)) {
			ret = zigbee_reset_local();
			if (EZ_OK != ret)
				fprintf(stderr, "clean and reset device failed:%s\n", zigbee_error_msg(ret));
			else
				showln("clean and reset device success");
			g_main_loop_quit(mainloop);
			return;
		}

		if (read_lf(input, max_size)) {
			show_hyphen();
			_func_zcl_raw_command_show();
			show_select();
			break;
		}

		n = input[0] - '0';

		switch (n) {
		case OPT_ZCL_RAW_MAIN_TESTING:
			_func_entry(_func_main);
			break;

		default:
			_zcl_get_cli_arguments(input, max_size);
			break;
		}
	}
}

static void _func_general_api(char *input, int max_size)
{
	static int step = 0;
	int n = 0;
	zigbee_error ret = EZ_OK;

	if (input == NULL)
		step = 0;

	switch (step) {
	case 0:
		show_hyphen();
		_func_general_api_show();
		show_select();
		step = 1;
		break;

	case 1:
		if (read_q(input, max_size) == true) {
			g_main_loop_quit(mainloop);
			return;
		}

		if (read_e(input, max_size) == true) {
			ret = zigbee_reset_local();
			if (ret != EZ_OK)
				fprintf(stderr, "clean and reset device failed:%s\n", zigbee_error_msg(ret));
			else
				showln("clean and reset device success");
			g_main_loop_quit(mainloop);
			return;
		}

		if (read_lf(input, max_size) == true) {
			show_hyphen();
			_func_general_api_show();
			show_select();
			break;
		}

		n = read_int(input, max_size, -1);

		switch (n) {
		case OPT_GENERAL_READ_LOCAL_ATTRIBUTE:	/* General read local attribute */
			ret = _general_read_local_attribute_test();
			if (ret == EZ_OK)
				showln("Done");
			else if (ret == EZ_NOT_SUPPORTED)
				showln("No device to process this test");
			else
				showln("Test failed: %s", zigbee_error_msg(ret));
			break;

		case OPT_GENERAL_WRITE_LOCAL_ATTRIBUTE:	/* General write local attribute */
			ret = _general_write_local_attribute_test();
			if (EZ_OK == ret)
				showln("Done");
			else if (EZ_NOT_SUPPORTED == ret)
				showln("No device to process this test");
			else
				showln("Test failed: %s", zigbee_error_msg(ret));
			break;

		case OPT_GENERAL_READ_REMOTE_ATTRIBUTE:	/* General read remote attribute */
			ret = _general_read_remote_attribute_test();
			if (EZ_OK == ret)
				showln("Done");
			else if (EZ_NOT_SUPPORTED == ret)
				showln("No device to process this test");
			else
				showln("Test failed: %s", zigbee_error_msg(ret));
			break;

		case OPT_GENERAL_WRITE_REMOTE_ATTRIBUTE:	/* General write remote attribute */
			ret = _general_write_remote_attribute_test();
			if (EZ_OK == ret)
				showln("Done");
			else if (EZ_NOT_SUPPORTED == ret)
				showln("No device to process this test");
			else
				showln("Test failed: %s", zigbee_error_msg(ret));
			break;

		case OPT_GENERAL_REQUEST_REPORTING: /* General request reporting */
			ret = _general_request_reporting_test();
			if (EZ_OK == ret)
				showln("Done");
			else if (EZ_NOT_SUPPORTED == ret)
				showln("No device to process this test");
			else
				showln("Test failed: %s", zigbee_error_msg(ret));
			break;

		case OPT_GENERAL_STOP_REPORTING: /* General stop reporting */
			ret = _general_stop_reporting_test();
			if (EZ_OK == ret)
				showln("Done");
			else if (EZ_NOT_SUPPORTED == ret)
				showln("No device to process this test");
			else
				showln("Test failed: %s", zigbee_error_msg(ret));
			break;

		case OPT_GENERAL_READ_REPORTING_CONFIG: /* General read reporting config */
			ret = _general_read_reporting_config_test();
			if (EZ_OK == ret)
				showln("Done");
			else if (EZ_NOT_SUPPORTED == ret)
				showln("No device to process this test");
			else
				showln("Test failed: %s", zigbee_error_msg(ret));
			break;

		case OPT_GENERAL_DISCOVERY_ATTRIBUTE: /* General discovery attribute */
			ret = _general_discovery_attribute_test();
			if (EZ_OK == ret)
				showln("Done");
			else if (EZ_NOT_SUPPORTED == ret)
				showln("No device to process this test");
			else
				showln("Test failed: %s", zigbee_error_msg(ret));
			break;

		case OPT_GENERAL_MAIN_TESTING: /* Main testing */
			_func_entry(_func_main);
			break;

		default:
			show_hyphen();
			_func_general_api_show();
			show_select();
			break;
		}
	}
}

static void _func_zdo_show(void)
{
	showln("%d: ZDO node id request", OPT_ZDO_NODE_ID_REQUEST);
	showln("%d: ZDO ieee addr request", OPT_ZDO_IEEE_REQUEST);
	showln("%d: ZDO node descriptor request", OPT_ZDO_NODE_DESCRIPTOR_REQUEST);
	showln("%d: ZDO power descriptor request", OPT_ZDO_POWER_DESCRIPTOR_REQUEST);
	showln("%d: ZDO active endpoints request", OPT_ZDO_ACTIVE_ENDPOINTS_REQUEST);
	showln("%d: ZDO simple descriptor request", OPT_ZDO_SIMPLE_DESCRIPTOR_REQUEST);
	showln("%d: ZDO match descriptor request - On/off server or client cluster",
			OPT_ZDO_MATCH_DESCRIPTOR_BROADCAST_REQUEST);
	showln("%d: ZDO routing table request", OPT_ZDO_ROUTING_TABLE_REQUEST);
	showln("%d: ZDO lqi table request", OPT_ZDO_LQI_TABLE_REQUEST);
	showln("%d: ZDO leave request", OPT_ZDO_LEAVE_REQUEST);
	showln("0: Main testing");
	showln("e: Exit (Quit with calling clean and reset device)");
	showln("q: Quit (Quit without calling clean and reset device)");
}

static zigbee_error _zdo_test(enum operation_zdo_test opt_zdo)
{
	zigbee_error ret = EZ_ERROR;

	switch (opt_zdo) {
	case OPT_ZDO_NODE_ID_REQUEST:
		ret = _zdo_node_id_request();
		break;

	case OPT_ZDO_IEEE_REQUEST:
		ret = _zdo_ieee_request();
		break;

	case OPT_ZDO_NODE_DESCRIPTOR_REQUEST:
		ret = _zdo_node_descriptor_request();
		break;

	case OPT_ZDO_POWER_DESCRIPTOR_REQUEST:
		ret = _zdo_power_descriptor_request();
		break;

	case OPT_ZDO_ACTIVE_ENDPOINTS_REQUEST:
		ret = _zdo_active_endpoints_request();
		break;

	case OPT_ZDO_SIMPLE_DESCRIPTOR_REQUEST:
		ret = _zdo_simple_descriptor_request();
		break;

	case OPT_ZDO_MATCH_DESCRIPTOR_BROADCAST_REQUEST:
		ret = _zdo_match_descriptor_broadcast_request();
		break;

	case OPT_ZDO_LQI_TABLE_REQUEST:
		ret = _zdo_lqi_table_request();
		break;

	case OPT_ZDO_ROUTING_TABLE_REQUEST:
		ret = _zdo_routing_table_request();
		break;

	case OPT_ZDO_LEAVE_REQUEST:
		ret = _zdo_leave_request();
		break;

	default:
		showln("Unknown operation %d in zdo test\nDone", opt_zdo);
		return EZ_ERROR;
	}

	return ret;
}

static void _func_zdo(char *input, int max_size)
{
	static int step;
	int n = 0;
	zigbee_error ret = EZ_OK;

	if (input == NULL)
		step = 0;

	switch (step) {
	case 0:
		show_hyphen();
		_func_zdo_show();
		show_select();
		step = 1;
		break;

	case 1:
		if (read_q(input, max_size) == true) {
			g_main_loop_quit(mainloop);
			return;
		}

		if (read_e(input, max_size) == true) {
			ret = zigbee_reset_local();
			if (ret != EZ_OK)
				fprintf(stderr, "clean and reset device failed:%s", zigbee_error_msg(ret));
			else
				showln("clean and reset device success");
			g_main_loop_quit(mainloop);
			return;
		}

		if (read_lf(input, max_size) == true) {
			show_hyphen();
			_func_zdo_show();
			show_select();
			break;
		}

		n = read_int(input, max_size, -1);

		switch (n) {
		case 0: /* Main testing */
			_func_entry(_func_main);
			break;

		default:
			_zdo_test((enum operation_zdo_test)n);
			break;
		}
		break;

	default:
		fprintf(stderr, "Unknown step %d", step);
		break;
	}
}

static void _func_reporting_api_show()
{
	showln("%d: On/off Light - Request Occupancy Reporting", OPT_REPORTING_OCCUPANCY_REPORTING);
	showln("%d: Request Measured Temperature Reporting", OPT_REPORTING_MEASURED_TEMPERATURE_REPORTING);
	showln("%d: Request Measured Illuminance Reporting", OPT_REPORTING_MEASURED_ILLUMINANCE_REPORTING);
	showln("%d: Request Measured Humidity Reporting", OPT_REPORTING_MEASURED_HUMIDITY_REPORTING);
	showln("%d: Main testing", OPT_REPORTING_MAIN_TESTING);
	showln("e: Exit (Quit with calling clean and reset device)");
	showln("q: Quit (Quit without calling clean and reset device)");
}

static void _func_reporting_api(char *input, int max_size)
{
	static int step = 0;
	int n = 0;
	zigbee_error ret = EZ_OK;

	if (input == NULL)
		step = 0;

	switch (step) {
	case 0:
		show_hyphen();
		_func_reporting_api_show();
		show_select();
		step = 1;
		break;

	case 1:
		if (read_q(input, max_size) == true) {
			g_main_loop_quit(mainloop);
			return;
		}

		if (read_e(input, max_size) == true) {
			ret = zigbee_reset_local();
			if (ret != EZ_OK)
				fprintf(stderr, "clean and reset device failed:%s\n", zigbee_error_msg(ret));
			else
				showln("clean and reset device success");
			g_main_loop_quit(mainloop);
			return;
		}

		if (read_lf(input, max_size) == true) {
			show_hyphen();
			_func_reporting_api_show();
			show_select();
			break;
		}

		n = read_int(input, max_size, -1);

		switch (n) {
		case OPT_REPORTING_OCCUPANCY_REPORTING: /* Request occupancy reporting */
			ret = _occypancy_reporting_test();
			if (ret == EZ_OK)
				showln("Done");
			else if (ret == EZ_NOT_SUPPORTED)
				showln("No device to process this test");
			else
				showln("Test failed: %s", zigbee_error_msg(ret));
			break;

		case OPT_REPORTING_MEASURED_TEMPERATURE_REPORTING: /* Request measured temperature reporting */
			ret = _measured_temperature_reporting_test();
			if (ret == EZ_OK)
				showln("Done");
			else if (ret == EZ_NOT_SUPPORTED)
				showln("No device to process this test");
			else
				showln("Test failed: %s", zigbee_error_msg(ret));
			break;

		case OPT_REPORTING_MEASURED_ILLUMINANCE_REPORTING: /* Request measured illuminance reporting */
			ret = _measured_illuminance_reporting_test();
			if (ret == EZ_OK)
				showln("Done");
			else if (ret == EZ_NOT_SUPPORTED)
				showln("No device to process this test");
			else
				showln("Test failed: %s", zigbee_error_msg(ret));
			break;

		case OPT_REPORTING_MEASURED_HUMIDITY_REPORTING: /* Request measured humidity reporting */
			ret = _measured_humidity_reporting_test();
			if (ret == EZ_OK)
				showln("Done");
			else if (ret == EZ_NOT_SUPPORTED)
				showln("No device to process this test");
			else
				showln("Test failed: %s", zigbee_error_msg(ret));
			break;

		case OPT_REPORTING_MAIN_TESTING: /* Main testing */
			_func_entry(_func_main);
			break;

		default:
			show_hyphen();
			_func_reporting_api_show();
			show_select();
			break;
		}
	}
}

static void _node_information_test(void)
{
	zigbee_node_info node_info;
	zigbee_local_endpoint_info endpoint_info;
	zigbee_local_endpoint *local_ep = NULL;
	zigbee_error ret = EZ_OK;
	int i = 0, j = 0;

	ret = zigbee_get_node_info(&node_info);
	if (EZ_OK == ret) {
		show_network_status(node_info.network_state);
		show("Eui64: ");
		for (i = 0; i < EUI64_SIZE; i++)
			show("%02X", node_info.eui64[i]);
		showln("");
		if (ZIGBEE_JOINED_NETWORK == node_info.network_state
				|| ZIGBEE_JOINED_NETWORK_NO_PARENT == node_info.network_state) {
			show_node_type(node_info.node_type);
			showln("Node id: 0x%04X pan id: 0x%04X channel: %d tx power: %d", node_info.node_id,
					node_info.network_info.pan_id, node_info.network_info.channel,
					node_info.network_info.tx_power);
		}
	} else
		fprintf(stderr, "Get node info failed: %s\n", zigbee_error_msg(ret));

	memset(&endpoint_info, 0, sizeof(zigbee_local_endpoint_info));
	ret = zigbee_get_local_endpoint(&endpoint_info);
	if (EZ_OK == ret) {
		showln("Found %d local endpoints", endpoint_info.count);
		for (i = 0; i < endpoint_info.count; i++) {
			showln("");
			local_ep = &endpoint_info.endpoints[i];
			showln("Profile 0x%04X endpoint %d device id 0x%04X device version 0x%02X",
					local_ep->profile, local_ep->endpoint_id, local_ep->device_id,
					local_ep->device_version);

			for (j = 0; j < MAX_CLUSTER_SIZE && local_ep->server_cluster[j] >= 0; j++)
				showln("Cluster id 0x%04X, SERVER", local_ep->server_cluster[j]);

			for (j = 0; j < MAX_CLUSTER_SIZE && local_ep->client_cluster[j] >= 0; j++)
				showln("Cluster id 0x%04X, CLIENT", local_ep->client_cluster[j]);
		}
	} else
		fprintf(stderr, "Get local endpoint failed: %s\n", zigbee_error_msg(ret));
}

static void _func_main_auto_test()
{
	_node_information_test();
	_identify_test();
	_onoff_test();
	_levelcontrol_test(false);
	_levelcontrol_test(true);
	_illuminance_test();
	_temperature_sensor_test();
	_humidity_test();
	_zdo_end_device_bind_test();
	_zdo_bind_unicast(true);
	_zdo_bind_group(true);
	_zdo_binding_table_request();
	_zdo_node_id_request();
	_zdo_ieee_request();
	_zdo_node_descriptor_request();
	_zdo_active_endpoints_request();
	_zdo_simple_descriptor_request();
	_zdo_match_descriptor_broadcast_request();
	_zdo_routing_table_request();
	_zdo_lqi_table_request();
	_occypancy_reporting_test();
	_measured_temperature_reporting_test();
	_measured_illuminance_reporting_test();
	_measured_humidity_reporting_test();
	_remote_control_test();
	_general_read_local_attribute_test();
	_general_write_local_attribute_test();
	_general_read_remote_attribute_test();
	_general_write_remote_attribute_test();
	_general_request_reporting_test();
	_general_read_reporting_config_test();
	_general_discovery_attribute_test();
}

static zigbee_error _func_main_test(enum operation_main_test opt, bool *show_done, bool *show_prompt)
{
	zigbee_error result;

	*show_done = true;
	result = EZ_OK;
	switch (opt) {
	case OPT_MAIN_IDENDITY:	/* Identify */
		result = _identify_test();
		break;

	case OPT_MAIN_ON_OFF:	/* On/off */
		result = _onoff_test();
		break;

	case OPT_MAIN_LEVEL_CONTROL:	/* Level control */
		result = _levelcontrol_test(false);
		result = _levelcontrol_test(true);
		break;

	case OPT_MAIN_ILLUM_MEASUREMENT:	/* Illuminance measurement */
		result = _illuminance_test();
		break;

	case OPT_MAIN_OCCUPANCY_SENSOR:
		result = _occypancy_sensor_test();
		break;

	case OPT_MAIN_TEMPERATURE_SENSOR:
		result = _temperature_sensor_test();
		break;

	case OPT_MAIN_HUMIDITY:
		result = _humidity_test();
		break;

	case OPT_MAIN_BIND_TEST:
		_func_entry(_func_bind_api);
		result = NO_PROMPT;
		break;

	case OPT_MAIN_REMOTE_CONTROL: /* Remote control */
		result = _remote_control_test();
		break;

	case OPT_MAIN_THERMOSTAT:
		_func_entry(_func_thermostat);
		result = NO_PROMPT;
		break;

	case OPT_MAIN_REPORTING_TEST: /* Request reporting test */
		_func_entry(_func_reporting_api);
		result = NO_PROMPT;
		break;

	case OPT_MAIN_GROUPS:
		result = _groups_test();
		break;

	case OPT_MAIN_GENERAL_TEST:	/* General api test */
		_func_entry(_func_general_api);
		result = NO_PROMPT;
		break;

	case OPT_MAIN_ZDO_TEST:
		_func_entry(_func_zdo);
		result = NO_PROMPT;
		break;

	case OPT_MAIN_ZCL_RAW_COMMAND_TEST:
		_func_entry(_func_zcl_raw_command);
		result = NO_PROMPT;
		break;

	default:
		result = TRY_AGAIN;
		break;
	}

	return result;
}

static void _func_main_show()
{
	showln("%d: Get node information", OPT_MAIN_GET_NODE_INFO);
	showln("%d: Auto test", OPT_MAIN_AUTO_TEST);
	showln("%d: Identify", OPT_MAIN_IDENDITY);
	showln("%d: On/off", OPT_MAIN_ON_OFF);
	showln("%d: Level control", OPT_MAIN_LEVEL_CONTROL);
	showln("%d: Illuminance measurement", OPT_MAIN_ILLUM_MEASUREMENT);
	showln("%d: Occupancy Sensor", OPT_MAIN_OCCUPANCY_SENSOR);
	showln("%d: Temperature Sensor", OPT_MAIN_TEMPERATURE_SENSOR);
	showln("%d: Humidity", OPT_MAIN_HUMIDITY);
	showln("%d: Bind api test", OPT_MAIN_BIND_TEST);
	showln("%d: Remote Control", OPT_MAIN_REMOTE_CONTROL);
	showln("%d: Thermostat", OPT_MAIN_THERMOSTAT);
	showln("%d: Request reporting test", OPT_MAIN_REPORTING_TEST);
	showln("%d: Groups test", OPT_MAIN_GROUPS);
	showln("%d: General api test", OPT_MAIN_GENERAL_TEST);
	showln("%d: ZDO test", OPT_MAIN_ZDO_TEST);
	showln("%d: ZCL raw command api test", OPT_MAIN_ZCL_RAW_COMMAND_TEST);
	showln("%d: Setup network", OPT_MAIN_SETUP_NETWORK);
	showln("e: Exit (Quit with calling clean and reset device)");
	showln("q: Quit (Quit without calling clean and reset device)");
}

static void _func_main(char *input, int max_size)
{
	static int step;
	int n;
	bool show_prompt, show_done;
	zigbee_error ret;

	if (input == NULL)
		step = 0;

	switch (step) {
	case 0:
		show_hyphen();
		_func_main_show();
		show_select();
		step = 1;
		break;

	case 1:
		if (read_q(input, max_size) == true) {
			g_main_loop_quit(mainloop);
			return;
		}

		if (read_e(input, max_size) == true) {
			ret = zigbee_reset_local();
			if (ret != EZ_OK)
				fprintf(stderr, "clean and reset device failed:%s\n", zigbee_error_msg(ret));
			else
				showln("clean and reset device success");
			g_main_loop_quit(mainloop);
			return;
		}

		if (read_lf(input, max_size) == true) {
			show_hyphen();
			_func_main_show();
			show_select();
			break;
		}

		show_prompt = true;
		n = read_int(input, max_size, -1);

		switch (n) {
		case OPT_MAIN_GET_NODE_INFO:
			_node_information_test();
			showln("Done");
			break;

		case OPT_MAIN_AUTO_TEST:	/* Auto test */
			_func_main_auto_test();
			showln("Done");
			break;

		case OPT_MAIN_SETUP_NETWORK:	/* Setup network */
			_func_entry(_func_network);
			show_prompt = false;
			break;

		default:
			ret = _func_main_test(n, &show_done, &show_prompt);
			if (ret == EZ_OK) {
				if (show_done)
					showln("Done");
			} else if (ret == EZ_NOT_SUPPORTED)
				showln("No device to process this test");
			else if (ret == TRY_AGAIN) {
				show_retry();
				show_prompt = false;
			} else if (NO_PROMPT == ret) 
				show_prompt = false;
			else
				showln("Test failed: %s", zigbee_error_msg(ret));
			break;
		}

		if (show_prompt) {
			show_hyphen();
			_func_main_show();
			show_select();
		}
		break;
	}
}

static void _update_commission_devices(bool target)
{
	struct test_device *test_device = NULL;
	int i = 0, count = 0;

	local_commission_devices.count = 0;
	count = get_test_device_count();
	for (i = 0; i < count && local_commission_devices.count < MAX_ENDPOINT_SIZE; i++) {
		test_device = get_test_device(i);

		if (target && NULL != test_device->ezmode_commissioning_target_start) {
			memcpy(&local_commission_devices.device[local_commission_devices.count], test_device,
					sizeof(struct test_device));
			local_commission_devices.count++;
		} else if (!target && NULL != test_device->ezmode_commissioning_initiator_start) {
			memcpy(&local_commission_devices.device[local_commission_devices.count], test_device,
					sizeof(struct test_device));
			local_commission_devices.count++;
		}
	}
}

static void _on_commission_start(int index, bool target)
{
	zigbee_error ret = EZ_OK;
	struct test_device *test_device = NULL;

	test_device = &local_commission_devices.device[index];
	if (target)
		show("Commissioning target start");
	else
		show("Commissioning initiator start");

	showln(" by device id 0x%04X endpoint %d", test_device->device_id, test_device->endpoint_id);
	if (target)
		ret = test_device->ezmode_commissioning_target_start(test_device->endpoint_id);
	else
		ret = test_device->ezmode_commissioning_initiator_start(test_device->endpoint_id);

	if (EZ_OK != ret)
		showln("Commissioning start error %s", zigbee_error_msg(ret));
}

static void _func_commission_start_show(bool target)
{
	int i = 0;

	if (local_commission_devices.count <= 0)
		showln("There is no device to launch commissioning %s",
				target ? "target start" : "initiator start");

	for (i = 0; i < local_commission_devices.count; i++)
		showln("%d: Select device id 0x%04X endpoint %d to launch commissioning %s", i + 1,
				local_commission_devices.device[i].device_id,
				local_commission_devices.device[i].endpoint_id,
				target ? "target start" : "initiator start");

	showln("0: Commissioning operation");
	showln("e: Exit (Quit with calling clean and reset device)");
	showln("q: Quit (Quit without calling clean and reset device)");
}

static void _func_commission_start(char *input, int max_size, bool target)
{
	zigbee_error ret = EZ_OK;
	static int step = 0;
	int n = 0;

	if (NULL == input)
		step = 0;

	switch (step) {
	case 0:
		show_hyphen();
		_update_commission_devices(target);
		_func_commission_start_show(target);
		show_select();
		step = 1;
		break;

	case 1:
		if (read_q(input, max_size) == true) {
			g_main_loop_quit(mainloop);
			return;
		}

		if (read_e(input, max_size) == true) {
			ret = zigbee_reset_local();
			if (EZ_OK != ret)
				fprintf(stderr, "clean and reset device failed:%s\n", zigbee_error_msg(ret));
			else
				showln("clean and reset device success");
			g_main_loop_quit(mainloop);
			return;
		}

		if (read_lf(input, max_size) == true) {
			show_hyphen();
			_func_commission_start_show(target);
			show_select();
			break;
		}

		n = read_int(input, max_size, -1);
		if (0 == n)
			_func_entry(_func_commisioning_operation);
		else if (n > local_commission_devices.count)
			show_retry();
		else
			_on_commission_start(n - 1, target);
		break;

	default:
		showln("Unknow step %d in commission start function", step);
		break;
	}
}

static void _func_commission_target_start(char *input, int max_size)
{
	_func_commission_start(input, max_size, true);
}

static void _func_commission_initiator_start(char *input, int max_size)
{
	_func_commission_start(input, max_size, false);
}

static void _func_network_show()
{
	zigbee_node_info node_info;
	zigbee_error ret;
	bool network;

	network = false;
	ret = zigbee_get_node_info(&node_info);
	if (EZ_OK == ret) {
		show_network_status(node_info.network_state);
		if (ZIGBEE_JOINED_NETWORK == node_info.network_state
				|| ZIGBEE_JOINED_NETWORK_NO_PARENT == node_info.network_state) {
			network = true;
			show_node_type(node_info.node_type);
		} else
			showln("Network: Non Exist");
	} else
		fprintf(stderr, "Get node info failed: %s\n", zigbee_error_msg(ret));

	show_hyphen();
	showln("%d: Form network", OPT_NWK_FOMR);
	showln("%d: Form network (advanced)", OPT_NWK_FORM_ADV);
	showln("%d: Join network", OPT_NWK_JOIN);
	showln("%d: Join network (advanced)", OPT_NWK_JOIN_ADV);
	showln("%d: Network find and join", OPT_NWK_FIND_AND_JOIN);
	showln("%d: Network stop scan", OPT_NWK_STOP_SCAN);
	showln("%d: Leave network", OPT_NWK_LEAVE);
	showln("%d: Network permit join", OPT_NWK_PERMIT_JOIN);
	showln("%d: Discover device", OPT_NWK_DISCOVER_DEVICE);
	showln("%d: Get discovered device", OPT_NWK_GET_DISCOVERED_DEVICE);
	showln("%d: Commissioning operation", OPT_NWK_COMMISSION_OPERATION);

	if (network)
		showln("%d: Start testing", OPT_NWK_START_TEST);
	else
		showln("%d: Start testing without network", OPT_NWK_START_TEST);

	showln("e: Exit (Quit with calling clean and reset device)");
	showln("q: Quit (Quit without calling clean and reset device)");
}

static void _func_network_found_show()
{
	int i = 1;

	show_hyphen();
	if (nwk_find_size <= 0)
		showln("No network found, please find network firstly");
	else {
		showln("Select one network to join");
		for (i = 1; i <= nwk_find_size; i++)
			showln("%d: network channel(%d), tx power(%d), pan id(0x%04X)", i,
					nwk_found_list[i - 1].network_info.channel,
					nwk_found_list[i - 1].network_info.tx_power,
					nwk_found_list[i - 1].network_info.pan_id);
	}
}

static void _func_network_found_end_show()
{
	showln("9: Find Network");
	showln("0: Setup Network");
	showln("e: Exit (Quit with calling clean and reset device)");
	showln("q: Quit (Quit without calling clean and reset device)");
	show_hyphen();
	show_select();
}

static zigbee_error _find_network()
{
	zigbee_error ret;

	showln("Finding network ...");
	showln("Select one network to join");
	nwk_find_size = 0;
	ret = zigbee_network_find();
	if (ret != EZ_OK) {
		fprintf(stderr, "Find network failed:%s\n", zigbee_error_msg(ret));
		showln("Done");
	}
	return ret;
}

static void _func_network_find_join(char *input, int max_size)
{
	static int step;
	int n;

	zigbee_error ret = EZ_ERROR;

	if (input == NULL)
		step = 0;

	switch (step) {
	case 0:
		ret = _find_network();
		step = 1;
		break;

	case 1:
		if (read_q(input, max_size)) {
			g_main_loop_quit(mainloop);
			return;
		}

		if (read_e(input, max_size) == true) {
			ret = zigbee_reset_local();
			if (ret != EZ_OK)
				fprintf(stderr, "clean and reset device failed:%s\n", zigbee_error_msg(ret));
			else
				showln("clean and reset device success");
			g_main_loop_quit(mainloop);
			return;
		}

		if (read_lf(input, max_size) == true) {
			_func_network_found_show();
			_func_network_found_end_show();
			break;
		}

		n = read_int(input, max_size, -1);
		switch (n) {
		case 0:
			_func_entry(_func_network);
			break;

		case 9:
			ret = _find_network();
			break;

		default:
			if (nwk_find_size <= 0)
				showln("No network found, please find network firstly");
			else if (n > nwk_find_size)
				showln("The selection is out of the network found size %d",
						nwk_find_size);
			else if (n < 0)
				showln("Please input legal value");
			else {
				showln("Join network channel(%d), tx power(%d), pan id(0x%04X)",
						nwk_found_list[n - 1].network_info.channel,
						nwk_found_list[n - 1].network_info.tx_power,
						nwk_found_list[n - 1].network_info.pan_id);
				ret = zigbee_network_join_manually(&nwk_found_list[n - 1].network_info);
				if (ret != EZ_OK) {
					fprintf(stderr, "Join network failed: %s\n", zigbee_error_msg(ret));
					showln("Done");
				} else
					showln("Done");
			}
			break;
		}
		break;
	}
}

static bool _network_joined(void)
{
	zigbee_node_info node_info;
	zigbee_error result = EZ_ERROR;

	result = zigbee_get_node_info(&node_info);
	if (EZ_OK != result) {
		showln("Get node info failed: %s", zigbee_error_msg(result));
		return false;
	} else if (ZIGBEE_JOINED_NETWORK != node_info.network_state
			&& ZIGBEE_JOINED_NETWORK_NO_PARENT != node_info.network_state) {
		showln("No network\nDone");
		return false;
	}
	return true;
}

static void _func_bind_api_show()
{
	showln("%d: Get binding entry", OPT_BIND_GET);
	showln("%d: Set binding entry", OPT_BIND_SET);
	showln("%d: Delete binding entry", OPT_BIND_DELETE);
	showln("%d: Clear binding table", OPT_BIND_CLEAR);
	showln("%d: End device bind request", OPT_BIND_END_DEVICE_REQUEST);
	showln("%d: ZDO bind unicast - remote node bind to current node on Illuminance/Occupancy/Temperature cluster",
			OPT_BIND_UNICAST_REQUEST);
	showln("%d: ZDO bind group - remote node bind to group 0x%02X on OnOff/LevelControl cluster",
			OPT_BIND_GROUP_REQUEST, TEST_GROUP_ID);
	showln("%d: ZDO binding table request", OPT_BINDING_TABLE_REQUEST);
	showln("0: Main testing");
	showln("e: Exit (Quit with calling clean and reset device)");
	showln("q: Quit (Quit without calling clean and reset device)");
}

static void _func_bind_api(char *input, int max_size)
{
	int i, j, binding_table_size, cluster_id;
	zigbee_binding_table_entry binding_table;
	static int step = 0;
	int n = 0;
	zigbee_error ret = EZ_ERROR;

	/* Select the first device as default for testing */
	struct test_device *device = get_test_device(0);

	if (input == NULL)
		step = 0;

	switch (step) {
	case 0:
		show_hyphen();
		_func_bind_api_show();
		show_select();
		step = 1;
		break;

	case 1:
		if (read_q(input, max_size) == true) {
			g_main_loop_quit(mainloop);
			return;
		}

		if (read_e(input, max_size) == true) {
			ret = zigbee_reset_local();
			if (ret != EZ_OK)
				fprintf(stderr, "clean and reset device failed:%s\n", zigbee_error_msg(ret));
			else
				showln("clean and reset device success");
			g_main_loop_quit(mainloop);
			return;
		}

		if (read_lf(input, max_size) == true) {
			show_hyphen();
			_func_bind_api_show();
			show_select();
			break;
		}

		n = read_int(input, max_size, -1);
		switch(n) {
		case OPT_BIND_GET:
			ret = zigbee_get_binding_table_size(&binding_table_size);
			if (ret != EZ_OK) {
				showln("Get binding table size failed for result %d\nDone", ret);
				break;
			}

			showln("Get binding");

			for (i = 0; i < binding_table_size; i++) {
				ret = zigbee_get_binding_entry(i, &binding_table);
				if (ret == EZ_OK) {
					if(ZIGBEE_UNUSED_BINDING == binding_table.type)
						continue;
					show("Index %d sucesss cluster 0x%04X, local endpoint %d, remote endpoint %d, "
							"network index %d, type %d, identifier ", i, binding_table.cluster_id,
							binding_table.local, binding_table.remote, binding_table.network_index,
							binding_table.type);
					for (j = 0; j < EUI64_SIZE; j++)
						show("%02X", binding_table.identifier[j]);
					showln("");
				} else
					showln("Index %d failed for result %d", i, ret);
			}
			showln("Done");
			break;

		case OPT_BIND_SET:
			cluster_id = -1;
			for (i = 0;; i++) {
				if (cluster_id >= 0)
					break;

				device = get_test_device(i);
				if (NULL == device)
					break;

				/* Select a default CLUSTER for each device to test set binding */
				switch (device->device_id) {
				case DEVICE_ON_OFF_SWITCH:
				case DEVICE_ON_OFF_LIGHT_SWITCH:
				case DEVICE_ON_OFF_LIGHT:
					cluster_id = ZCL_ON_OFF_CLUSTER_ID;
					break;

				case DEVICE_LEVEL_CONTROL_SWITCH:
				case DEVICE_DIMMER_SWITCH:
				case DEVICE_COLOR_DIMMER_SWITCH:
				case DEVICE_COLOR_DIMMABLE_LIGHT:
				case DEVICE_REMOTE_CONTROL:
				case DEVICE_DIMMABLE_LIGHT:
					cluster_id = ZCL_LEVEL_CONTROL_CLUSTER_ID;
					break;

				case DEVICE_LIGHT_SENSOR:
					cluster_id = ZCL_ILLUM_MEASUREMENT_CLUSTER_ID;
					break;

				case DEVICE_OCCUPANCY_SENSOR:
					cluster_id = ZCL_OCCUPANCY_SENSING_CLUSTER_ID;
					break;

				case DEVICE_HEATING_COOLING_UNIT:
					cluster_id = ZCL_FAN_CONTROL_CLUSTER_ID;
					break;

				case DEVICE_THERMOSTAT:
					cluster_id = ZCL_THERMOSTAT_CLUSTER_ID;
					break;

				case DEVICE_TEMPERATURE_SENSOR:
					cluster_id = ZCL_TEMP_MEASUREMENT_CLUSTER_ID;
					break;

				default:
					break;
				}
			}

			if (cluster_id < 0) {
				ret = EZ_NOT_FOUND;
				showln("No device support\nDone");
				break;
			} else if (identify_endpoint_id < 0 || !got_eui) {
				showln("Please do query device before this operation\nDone");
				break;
			}

			ret = zigbee_get_binding_table_size(&binding_table_size);
			if (ret != EZ_OK) {
				showln("Get binding table size failed for result %d\nDone", ret);
				break;
			}

			if (set_binding_index >= binding_table_size)
				set_binding_index = 0;

			binding_table.type = ZIGBEE_UNICAST_BINDING;
			binding_table.local = device->endpoint_id;
			binding_table.remote = identify_endpoint_id;
			binding_table.cluster_id = cluster_id;
			memcpy(binding_table.identifier, eui64, EUI64_SIZE);

			ret = zigbee_set_binding_entry(set_binding_index, &binding_table);

			if (ret == EZ_OK)
				showln("Set binding entry index %d success", set_binding_index);
			else
				showln("Set binding entry index %d failed for result %d", set_binding_index, ret);

			set_binding_index++;
			showln("Done");
			break;

		case OPT_BIND_DELETE:
			ret = zigbee_get_binding_table_size(&binding_table_size);
			if (ret != EZ_OK) {
				showln("Get binding table size failed for result %d\nDone", ret);
				break;
			}

			if (delete_binding_index >= binding_table_size)
				delete_binding_index = 0;

			ret = zigbee_delete_binding_entry(delete_binding_index);

			if (ret == EZ_OK)
				showln("Delete binding entry index %d success", delete_binding_index);
			else
				showln("Delete binding entry index %d failed for result %d", delete_binding_index, ret);

			delete_binding_index++;
			showln("Done");
			break;

		case OPT_BIND_CLEAR:
			ret = zigbee_clear_binding_table();
			if (ret == EZ_OK)
				showln("Clear binding table success");
			else
				showln("Clear binding table failed for result %d", ret);
			showln("Done");
			break;

		case OPT_BIND_END_DEVICE_REQUEST:
			ret = _zdo_end_device_bind_test();
			if (EZ_OK != ret)
				showln("Done");
			break;

		case OPT_BIND_UNICAST_REQUEST:
			ret = _zdo_bind_unicast(true);
			if (ret == EZ_OK)
				showln("ZDO bind unicast request success");
			else
				showln("ZDO bind unicast request failed for result %s", zigbee_error_msg(ret));
			showln("Done");
			break;

		case OPT_BIND_GROUP_REQUEST:
			ret = _zdo_bind_group(true);
			if (EZ_OK == ret)
				showln("ZDO bind group request success");
			else
				showln("ZDO bind group request failed for result %s", zigbee_error_msg(ret));
			showln("Done");
			break;

		case OPT_BINDING_TABLE_REQUEST:
			ret = _zdo_binding_table_request();
			if (EZ_OK == ret)
				showln("ZDO binding table request success");
			else
				showln("ZDO binding table request failed for result %s", zigbee_error_msg(ret));
			showln("Done");
			break;

		case 0: /* Main testing */
			_func_entry(_func_main);
			break;

		default:
			show_hyphen();
			_func_bind_api_show();
			show_select();
			break;
		}
	}
}

static zigbee_error _commissioning_operation_test(enum commissioning_operation operation)
{
	zigbee_error ret = EZ_ERROR;

	/* Select the first device as default for testing */
	struct test_device *device = get_test_device(0);

	switch (operation) {

	case COMMISSION_OPT_TARGET_START:
		_func_entry(_func_commission_target_start);
		break;

	case COMMISSION_OPT_INITIATOR_START:
		_func_entry(_func_commission_initiator_start);
		break;

	case COMMISSION_OPT_FACTORY_RESET:
		ret = zigbee_factory_reset();
		if (ret == EZ_OK)
			showln("Factory reset sucesss");
		else
			showln("Factory reset failed for result %d", ret);
		showln("Done");
		break;

	case COMMISSION_OPT_NETWORK_STEERING:
		ret = zigbee_network_steering();
		if (ret == EZ_OK)
			showln("Network steering ...");
		else
			showln("Network steering failed for result %d\nDone", ret);
		break;

	case COMMISSION_OPT_BROADCAST_PERMITJOIN:
		ret = zigbee_broadcast_permitjoin(EASY_PJOIN_DURATION);
		if (ret == EZ_OK)
			showln("Broadcast permitjoin %d seconds success", EASY_PJOIN_DURATION);
		else
			showln("Broadcast permitjoin %d seconds failed for result %d", EASY_PJOIN_DURATION,
					ret);
		showln("Done");
		break;

	case COMMISSION_OPT_FIND_BIND_TARGET_START:
		if (!_network_joined())
			break;

		if (NULL == device) {
			ret = EZ_NOT_FOUND;
			showln("No local device\nDone");
			break;
		}
		ret = zigbee_find_bind_target_start(device->endpoint_id);
		if (ret == EZ_OK)
			showln("Find bind target start ...");
		else
			showln("Find bind target start failed for result %d\nDone", ret);
		break;

	case COMMISSION_OPT_FIND_BIND_INITIATOR_START:
		if (!_network_joined())
			break;

		if (NULL == device) {
			ret = EZ_NOT_FOUND;
			showln("No local device\nDone");
			break;
		}
		ret = zigbee_find_bind_initiator_start(device->endpoint_id);
		if (ret == EZ_OK)
			showln("Find bind initiator start ...");
		else
			showln("Find bind initiator start failed for result %d\nDone", ret);
		break;

	case COMMISSION_OPT_QUERY_DEVICE:
		if (!_network_joined())
			break;

		if (NULL == device) {
			ret = EZ_NOT_FOUND;
			showln("No local device\nDone");
			break;
		}

		/* When user calls broadcast_identify_query, reset the identify_endpoint_id
		 * and got_eui values */
		identify_endpoint_id = -1;
		got_eui = false;

		ret = zigbee_broadcast_identify_query(device->endpoint_id);
		if (ret == EZ_OK)
			showln("Broadcast identify query success");
		else
			showln("Broadcast identify query failed for result %d\nDone", ret);
		break;

	case COMMISSION_OPT_BROADCAST_MATCH_DESC_REQUEST:
		if (!_network_joined())
			break;

		/* Using the ZCL_ON_OFF_CLUSTER_ID as default Cluster for testing */
		ret = zigbee_broadcast_match_descriptor_request(ZIGBEE_PROFILE_HA,
				ZCL_ON_OFF_CLUSTER_ID, true);
		if (ret == EZ_OK)
			showln("Broadcast match descriptor request");
		else
			showln("Broadcast match descriptor request failed for result %d\nDone", ret);
		break;

	default:
		showln("Unknow operation %d in commissioning operation test\nDone", operation);
		return EZ_ERROR;
	}

	return ret;
}

static void _func_commissioning_operation_show()
{
	showln("%d: Commissioning target start", COMMISSION_OPT_TARGET_START);
	showln("%d: Commissioning initiator start", COMMISSION_OPT_INITIATOR_START);
	showln("%d: Factory reset", COMMISSION_OPT_FACTORY_RESET);
	showln("%d: Network steering", COMMISSION_OPT_NETWORK_STEERING);
	showln("%d: Broadcast permitjoin", COMMISSION_OPT_BROADCAST_PERMITJOIN);
	showln("%d: Find bind target start", COMMISSION_OPT_FIND_BIND_TARGET_START);
	showln("%d: Find bind initiator start", COMMISSION_OPT_FIND_BIND_INITIATOR_START);
	showln("%d: Query device(including identify request, ieee address request, simple descriptor request)",
			COMMISSION_OPT_QUERY_DEVICE);
	showln("%d: Broadcast match descriptor request", COMMISSION_OPT_BROADCAST_MATCH_DESC_REQUEST);
	showln("0: Setup network");
	showln("e: Exit (Quit with calling clean and reset device)");
	showln("q: Quit (Quit without calling clean and reset device)");
}

static void _func_commisioning_operation(char *input, int max_size)
{
	static int step;
	int n;
	zigbee_error ret;

	if (input == NULL)
		step = 0;

	switch (step) {
	case 0:
		show_hyphen();
		_func_commissioning_operation_show();
		show_select();
		step = 1;
		break;

	case 1:
		if (read_q(input, max_size) == true) {
			g_main_loop_quit(mainloop);
			return;
		}

		if (read_e(input, max_size) == true) {
			ret = zigbee_reset_local();
			if (ret != EZ_OK)
				fprintf(stderr, "clean and reset device failed:%s", zigbee_error_msg(ret));
			else
				showln("clean and reset device success");
			g_main_loop_quit(mainloop);
			return;
		}

		if (read_lf(input, max_size) == true) {
			show_hyphen();
			_func_commissioning_operation_show();
			show_select();
			break;
		}

		n = read_int(input, max_size, -1);

		switch (n) {
		case 0: /* Setup network */
			_func_entry(_func_network);
			break;

		default:
			_commissioning_operation_test((enum commissioning_operation) n);
			break;
		}
		break;

	default:
		fprintf(stderr, "Unknow step %d", step);
		break;
	}
}

static void _func_network(char *input, int max_size)
{
	static zigbee_network_info set_network_info;
	zigbee_device_info device_info;
	static int step;
	int n;
	zigbee_error ret = EZ_ERROR;

	if (input == NULL)
		step = 0;

	switch (step) {
	case 0:
		_func_network_show();
		show_select();
		step = 1;
		break;

	case 1:
		if (read_q(input, max_size)) {
			g_main_loop_quit(mainloop);
			return;
		}

		if (read_e(input, max_size) == true) {
			ret = zigbee_reset_local();
			if (ret != EZ_OK)
				fprintf(stderr, "clean and reset device failed:%s\n", zigbee_error_msg(ret));
			else
				showln("clean and reset device success");
			g_main_loop_quit(mainloop);
			return;
		}

		if (read_lf(input, max_size) == true) {
			show_hyphen();
			_func_network_show();
			show_select();
			break;
		}

		n = read_int(input, max_size, -1);
		switch (n) {
		case OPT_NWK_FOMR:	/* Form network */
			ret = zigbee_network_form();
			if (ret == EZ_OK)
				showln("Wait for response");
			else {
				showln("Network form failed");
				showln("Done");
			}
			break;

		case OPT_NWK_FORM_ADV:	/* Form network (advance) */
			show_request_channel();
			step = 2;
			break;

		case OPT_NWK_JOIN:	/* Join network */
			ret = zigbee_network_join();
			if (ret == EZ_OK)
				showln("Wait for response");
			else {
				showln("Network join failed");
				showln("Done");
			}
			break;

		case OPT_NWK_JOIN_ADV:	/* Join network (advance) */
			show_request_channel();
			step = 5;
			break;

		case OPT_NWK_LEAVE:	/* Leave network */
			ret = zigbee_network_leave();
			if (ret != EZ_OK)
				fprintf(stderr, "Network leave failed: %s\n", zigbee_error_msg(ret));
			showln("Done");
			break;

		case OPT_NWK_DISCOVER_DEVICE:	/* Discover device */
			ret = zigbee_device_discover();
			if (ret == EZ_OK)
				showln("Wait response");
			else {
				fprintf(stderr, "Network discover failed: %s\n", zigbee_error_msg(ret));
				showln("Done");
			}
			break;

		case OPT_NWK_GET_DISCOVERED_DEVICE:
			ret = zigbee_get_discovered_device_list(&device_info);
			if (EZ_OK == ret)
				show_device_info(&device_info);
			else if (EZ_NOT_FOUND == ret)
				showln("No device, please discover device firstly");
			else
				showln("Get discovered device list failed: %s", zigbee_error_msg(ret));
			showln("Done");
			break;

		case OPT_NWK_START_TEST:	/* Start testing */
			_func_entry(_func_main);
			break;

		case OPT_NWK_PERMIT_JOIN:
			ret = zigbee_network_permitjoin(EASY_PJOIN_DURATION);
			if (ret != EZ_OK)
				fprintf(stderr, "Permit join failed:%s\n", zigbee_error_msg(ret));
			else
				showln("Permit join for %d seconds", EASY_PJOIN_DURATION);
			showln("Done");
			break;

		case OPT_NWK_FIND_AND_JOIN:
			_func_entry(_func_network_find_join);
			break;

		case OPT_NWK_STOP_SCAN:
			ret = zigbee_network_stop_scan();
			if (ret != EZ_OK)
				fprintf(stderr, "Network stop scanning failed: %s\n", zigbee_error_msg(ret));
			else
				showln("Network stop scanning success");
			showln("Done");
			break;

		case OPT_NWK_COMMISSION_OPERATION:	/* Commissioning low level operation */
			_func_entry(_func_commisioning_operation);
			break;

		default:
			show_retry();
			break;
		}

		break;

	case 2:	/* network form - set channel */
		ret = read_channel(input, max_size, &set_network_info.channel);
		if (ret == EZ_OK) {
			show_request_tx();
			step = 3;
		}
		break;

	case 3:	/* network form - set tx */
		ret = read_tx(input, max_size, &set_network_info.tx_power);
		if (ret == EZ_OK) {
			show_request_pan_id();
			step = 4;
		}
		break;

	case 4:	/* network form - set pan id */
		ret = read_pan_id(input, max_size, &set_network_info.pan_id);
		if (ret == EZ_OK) {
			showln("Form network channel(%d) TX(%d) PAN ID(0x%x):",
				   set_network_info.channel,
				   set_network_info.tx_power,
				   set_network_info.pan_id);
			ret = zigbee_network_form_manually(&set_network_info);
			if (ret != EZ_OK)
				fprintf(stderr, "Manually form network failed: %s\n", zigbee_error_msg(ret));
			else
				showln("Manually form network success\nDone");
			step = 1;
		}
		break;

	case 5:	/* network join - set channel */
		ret = read_channel(input, max_size, &set_network_info.channel);
		if (ret == EZ_OK) {
			show_request_tx();
			step = 6;
		}
		break;

	case 6:	/* network join - set tx */
		ret = read_tx(input, max_size, &set_network_info.tx_power);
		if (ret == EZ_OK) {
			show_request_pan_id();
			step = 7;
		}
		break;

	case 7:	/* network join - set pan id */
		ret = read_pan_id(input, max_size, &set_network_info.pan_id);
		if (ret == EZ_OK) {
			showln("Join network channel(%d) TX(%d) PAN ID(0x%x):",
				   set_network_info.channel,
				   set_network_info.tx_power,
				   set_network_info.pan_id);
			ret = zigbee_network_join_manually(&set_network_info);
			if (ret != EZ_OK)
				fprintf(stderr, "Manually join network failed: %s\n", zigbee_error_msg(ret));
			showln("Done");

			step = 1;
		}
		break;

	}
}

static zigbee_error _func_endpoint_add(ZIGBEE_PROFILE profile,
									   ZIGBEE_DEVICEID device_id,
									   ZIGBEE_DEVICE_VERSION device_version,
									   int endpoint_id)
{
	struct test_device *test_device;
	zigbee_error result = EZ_OK;

	test_device = add_test_device(profile, device_id, device_version, endpoint_id);
	if (test_device == NULL) {
		fprintf(stderr, "Create test device failed\n");
		return EZ_NO_MEM;
	}

	if (profile == ZIGBEE_PROFILE_HA) {
		/* every device should have such a function */
		test_device->general_read_remote_attribute = zigbee_general_read_remote_attribute;
		test_device->general_write_remote_attribute = zigbee_general_write_remote_attribute;
		test_device->general_discover_attribute = zigbee_general_discover_attribute;
		switch (device_id) {
		case DEVICE_ON_OFF_SWITCH:
			test_device->identify_request = zigbee_identify_command;
			test_device->identify_get_remaining_time = zigbee_identify_get_remaining_time;
			test_device->onoff_command = zigbee_onoff_command;
			test_device->ezmode_commissioning_initiator_start = zigbee_ezmode_commissioning_initiator_start;
			test_device->groups_command = zigbee_groups_command;
			test_device->general_request_reporting = zigbee_general_request_reporting;
			test_device->general_stop_reporting = zigbee_general_stop_reporting;
			test_device->general_read_reporting_config = zigbee_general_read_reporting_config;
			break;

		case DEVICE_LEVEL_CONTROL_SWITCH:
			test_device->identify_request = zigbee_identify_command;
			test_device->identify_get_remaining_time = zigbee_identify_get_remaining_time;
			test_device->onoff_command = zigbee_onoff_command;
			test_device->level_control_request = zigbee_levelcontrol_command;
			test_device->ezmode_commissioning_initiator_start = zigbee_ezmode_commissioning_initiator_start;
			test_device->groups_command = zigbee_groups_command;
			test_device->general_request_reporting = zigbee_general_request_reporting;
			test_device->general_stop_reporting = zigbee_general_stop_reporting;
			test_device->general_read_reporting_config = zigbee_general_read_reporting_config;
			break;

		case DEVICE_ON_OFF_LIGHT:
			test_device->groups_get_local_name_support = zigbee_groups_get_local_name_support;
			test_device->groups_set_local_name_support = zigbee_groups_set_local_name_support;
			test_device->onoff_get_value = zigbee_onoff_get_value;
			test_device->request_reporting = zigbee_request_reporting;
			test_device->stop_reporting = zigbee_stop_reporting;
			test_device->ezmode_commissioning_target_start = zigbee_ezmode_commissioning_target_start;
			test_device->general_read_local_attribute = zigbee_general_read_local_attribute;
			test_device->general_write_local_attribute = zigbee_general_write_local_attribute;
			break;

		case DEVICE_DIMMABLE_LIGHT:
			test_device->groups_get_local_name_support = zigbee_groups_get_local_name_support;
			test_device->groups_set_local_name_support = zigbee_groups_set_local_name_support;
			test_device->onoff_get_value = zigbee_onoff_get_value;
			test_device->level_control_get_value = zigbee_levelcontrol_get_value;
			test_device->ezmode_commissioning_target_start = zigbee_ezmode_commissioning_target_start;
			test_device->general_read_local_attribute = zigbee_general_read_local_attribute;
			test_device->general_write_local_attribute = zigbee_general_write_local_attribute;
			break;

		case DEVICE_LIGHT_SENSOR:
			test_device->identify_request = zigbee_identify_command;
			test_device->identify_get_remaining_time = zigbee_identify_get_remaining_time;
			test_device->illum_set_measured_value = zigbee_illum_set_measured_value;
			test_device->illum_get_measured_value = zigbee_illum_get_measured_value;
			test_device->illum_set_measured_value_range = zigbee_illum_set_measured_value_range;
			test_device->ezmode_commissioning_initiator_start = zigbee_ezmode_commissioning_initiator_start;
			test_device->general_read_local_attribute = zigbee_general_read_local_attribute;
			test_device->general_write_local_attribute = zigbee_general_write_local_attribute;
			break;

		case DEVICE_OCCUPANCY_SENSOR:
			test_device->identify_request = zigbee_identify_command;
			test_device->identify_get_remaining_time = zigbee_identify_get_remaining_time;
			test_device->occupancy_set_type = zigbee_occupancy_set_occypancy_type;
			test_device->occupancy_set_value = zigbee_occupancy_set_occupancy_status;
			test_device->ezmode_commissioning_initiator_start = zigbee_ezmode_commissioning_initiator_start;
			test_device->general_read_local_attribute = zigbee_general_read_local_attribute;
			test_device->general_write_local_attribute = zigbee_general_write_local_attribute;
			break;

		case DEVICE_TEMPERATURE_SENSOR:
			test_device->identify_request = zigbee_identify_command;
			test_device->identify_get_remaining_time = zigbee_identify_get_remaining_time;
			test_device->temperature_set_measured_value = zigbee_temperature_set_measured_value;
			test_device->temperature_set_measured_value_range = zigbee_temperature_set_measured_value_range;
			test_device->ezmode_commissioning_initiator_start = zigbee_ezmode_commissioning_initiator_start;
			test_device->general_read_local_attribute = zigbee_general_read_local_attribute;
			test_device->general_write_local_attribute = zigbee_general_write_local_attribute;
			break;

		case DEVICE_REMOTE_CONTROL:
			test_device->reset_to_factory_default = zigbee_basic_reset_to_factory_defaults;
			test_device->identify_request = zigbee_identify_command;
			test_device->identify_get_remaining_time = zigbee_identify_get_remaining_time;
			test_device->onoff_command = zigbee_onoff_command;
			test_device->level_control_request = zigbee_levelcontrol_command;
			test_device->request_reporting = zigbee_request_reporting;
			test_device->stop_reporting = zigbee_stop_reporting;
			test_device->ezmode_commissioning_target_start = zigbee_ezmode_commissioning_target_start;
			test_device->groups_command = zigbee_groups_command;
			test_device->general_request_reporting = zigbee_general_request_reporting;
			test_device->general_stop_reporting = zigbee_general_stop_reporting;
			test_device->general_read_reporting_config = zigbee_general_read_reporting_config;
			break;

		case DEVICE_IAS_CONTROL_AND_INDICATING_EQUIPMENT:
			test_device->general_write_remote_attribute = NULL;
			test_device->general_discover_attribute = NULL;
			break;

		case DEVICE_THERMOSTAT:
			if (THERMOSTAT_CONTROLLER_DEVICE_VERSION == test_device->device_version) {
				test_device->identify_request = zigbee_identify_command;
				test_device->identify_get_remaining_time = zigbee_identify_get_remaining_time;
				test_device->request_reporting = zigbee_request_reporting;
				test_device->stop_reporting = zigbee_stop_reporting;
				test_device->ezmode_commissioning_target_start = zigbee_ezmode_commissioning_target_start;
			} else if (THERMOSTAT_HUMIDITY_SENSOR_DEVICE_VERSION == test_device->device_version) {
				test_device->identify_request = zigbee_identify_command;
				test_device->identify_get_remaining_time = zigbee_identify_get_remaining_time;
				test_device->humidity_set_measured_value = zigbee_humidity_set_measured_value;
				test_device->humidity_set_measured_value_range = zigbee_humidity_set_measured_value_range;
				test_device->ezmode_commissioning_initiator_start = zigbee_ezmode_commissioning_initiator_start;
			} else {
				fprintf(stderr, "Unsupported device version: %d\n", test_device->device_version);
				result = EZ_BAD_ARGS;
			}

			break;

		default:
			fprintf(stderr, "Unsupported device type: 0x%04X\n", device_id);
			result = EZ_BAD_ARGS;
			break;
		}
	} else {
		fprintf(stderr, "Unsupported profile: %d\n", profile);
		result = EZ_BAD_ARGS;
	}

	if (result != EZ_OK)
		delete_test_device(endpoint_id);

	return result;
}

static zigbee_error _func_endpoint_init()
{
	int endpoint_list[MAX_ENDPOINT_SIZE];
	zigbee_local_endpoint_info endpoint_info;
	int i = 0, size = 0;
	zigbee_error ret = EZ_ERROR;
	struct test_device *device = NULL;

	get_test_device_list(endpoint_list, MAX_ENDPOINT_SIZE, &size);
	if (size <= 0) {
		fprintf(stderr, "device list is NULL\n");
		return EZ_NOT_FOUND;
	}

	memset(&endpoint_info, 0, sizeof(zigbee_local_endpoint_info));
	for (i = 0; i < size; i++) {
		device = get_test_device(i);
		if (NULL != device) {
			endpoint_info.endpoints[endpoint_info.count].profile = device->profile;
			endpoint_info.endpoints[endpoint_info.count].endpoint_id = device->endpoint_id;
			endpoint_info.endpoints[endpoint_info.count].device_id = device->device_id;
			endpoint_info.endpoints[endpoint_info.count].device_version = device->device_version;
			endpoint_info.count++;
		}
	}
	ret = zigbee_set_local_endpoint(&endpoint_info);
	if (EZ_OK != ret)
		fprintf(stderr, "Set local endpoint error %d\n", ret);

	ret = zigbee_initialize(_on_callback, NULL);
	if (EZ_OK != ret)
		fprintf(stderr, "Initialize error %d\n", ret);
	return ret;
}

static void _func_endpoint_show()
{
	struct device_type *device_type;
	int i, count;

	count = _get_device_type_count();
	for (i = 0; i < count; i++) {
		device_type = _get_device_type(i);
		showln("%d: %s", i + 1, device_type->name);
	}
}

static void _func_endpoint(char *input, int max_size)
{
	static int step;
	static struct device_type *select_device_type;
	zigbee_error ret;
	int n;

	if (input == NULL)
		step = 0;

	switch (step) {
	case 0:
		show_hyphen();
		_func_endpoint_show();
		showln("0: ADD DEVICE DONE");
		show("Add device: ");
		step = 1;
		break;

	case 1:	/* add device */
		n = read_int(input, max_size, -1);
		if (n == 0) {
			if (get_test_device_count() == 0) {
				show("\nAt least 1 endpoint, please input again: ");
			} else {
				if (EZ_OK == _func_endpoint_init())
					_func_entry(_func_network);
				else {
					g_main_loop_quit(mainloop);
					return;
				}
			}
		} else if (n >= 1 && n <= _get_device_type_count()) {
			select_device_type = _get_device_type(n - 1);
			show("Set endpoint id (%d): ",
				 select_device_type->default_endpoint_id);
			step = 2;
		} else {
			show_retry();
		}
		break;

	case 2:	/* set endpoint id */
		if (read_lf(input, max_size))
			n = select_device_type->default_endpoint_id;
		else
			n = read_int(input, max_size, -1);

		if (n >= ENDPOINT_ID_MIN && n <= ENDPOINT_ID_MAX) {
			if (check_test_device_endpoint_id(n) == true) {
				ret = _func_endpoint_add(select_device_type->profile,
										 select_device_type->device_id,
										 select_device_type->device_version,
										 n);
				if (ret == EZ_OK)
					show("Added device \"%s\" with ep(%d)\n\n",
						 select_device_type->name, n);
				else
					showln("Add endpoint failed: %s", zigbee_error_msg(ret));

				show("Add device: ");
				step = 1;
			} else {
				show("\nRepeated endpoint id, please input again: ");
			}
		} else {
			show_range(ENDPOINT_ID_MIN, ENDPOINT_ID_MAX);
		}
		break;
	}
}

static void _func_entrance(char *input, int max_size)
{
	static int step;
	static zigbee_local_endpoint_info endpoint_info;
	zigbee_local_endpoint local_ep;
	zigbee_error ret = EZ_OK;
	int i = 0, n = 0;

	if (NULL == input)
		step = 0;

	switch (step) {
	case 0:
		memset(&endpoint_info, 0, sizeof(zigbee_local_endpoint_info));
		ret = zigbee_get_local_endpoint(&endpoint_info);
		if (EZ_OK == ret && endpoint_info.count > 0) {
			showln("Found %d saved local endpoints", endpoint_info.count);
			for (i = 0; i < endpoint_info.count; i++) {
				local_ep = endpoint_info.endpoints[i];
				showln("Profile 0x%04X endpoint %d device id 0x%04X", local_ep.profile,
						local_ep.endpoint_id, local_ep.device_id);
			}
			show_hyphen();
			showln("0: Resume device");
			showln("1: Add new device");
			show_select();
			step = 1;
		} else
			_func_entry(_func_endpoint);
		break;

	case 1: /* Select to resume device or add new device */
		n = read_int(input, max_size, -1);
		if (0 == n) {
			show_hyphen();
			showln("Resume device");
			for (i = 0; i < endpoint_info.count; i++) {
				local_ep = endpoint_info.endpoints[i];
				ret = _func_endpoint_add(local_ep.profile, local_ep.device_id,
						local_ep.device_version, local_ep.endpoint_id);
				if (EZ_OK == ret)
					showln("Added endpoint %d", local_ep.endpoint_id);
				else
					showln("Add endpoint %d failed: %s", local_ep.endpoint_id, zigbee_error_msg(ret));
			}

			ret = _func_endpoint_init();
			if (EZ_OK != ret) {
				g_main_loop_quit(mainloop);
				return;
			}

			_func_entry(_func_network);
		} else if (1 == n)
			_func_entry(_func_endpoint);
		else
			show_retry();
		break;
	}
}

void _on_callback_attr_changed(zigbee_attribute_changed_response *info)
{
	struct test_device *device;
	zigbee_onoff_status status;
	zigbee_error ret = EZ_OK;
	int n;

	device = get_test_device_by_endpoint_id(info->endpoint_id);
	if (device == NULL) {
		showln("Invalid endpoint id: %d\n", info->endpoint_id);
		return;
	}

	switch (info->type) {
	case ZIGBEE_ATTR_ONOFF_STATUS:
		if (device->onoff_get_value != NULL) {
			ret = device->onoff_get_value(device->endpoint_id, &status);
			if (ret == EZ_OK) {
				if (status == ZIGBEE_ONOFF_ON)
					showln("Attribute ONOFF changed to ON by ep(%d)\n",
						   info->endpoint_id);
				else if (status == ZIGBEE_ONOFF_OFF)
					showln("Attribute ONOFF changed to OFF by ep(%d)\n",
						   info->endpoint_id);
				else
					showln("Attribute ONOFF changed to unrecognized value:%d by ep(%d)\n",
						   status, info->endpoint_id);
			} else
				fprintf(stderr, "Attribute ONOFF changed by ep(%d), get value failed: %s\n",
					info->endpoint_id, zigbee_error_msg(ret));
		} else
			fprintf(stderr, "Not support onoff_get_value by ep(%d)\n", info->endpoint_id);
		break;

	case ZIGBEE_ATTR_LEVELCONTROL_LEVEL:
		if (device->level_control_get_value != NULL) {
			ret = device->level_control_get_value(device->endpoint_id, &n);
			if (ret == EZ_OK)
				showln("Attribute LEVEL changed to %d by ep(%d)\n",
					   n, info->endpoint_id);
			else
				fprintf(stderr, "Attribute LEVEL changed by ep(%d), get value failed: %s\n",
					info->endpoint_id, zigbee_error_msg(ret));
		} else
			fprintf(stderr, "Not support level_control_get_value by ep(%d)\n",
					info->endpoint_id);
		break;

	default:
		showln("Attribute(%d) changed by endpoint(%d)", info->type,
			   info->endpoint_id);
		break;
	}
}

static void _on_parent_announce(zigbee_parent_annce_info *payload)
{
	int i = 0;
	int j = 0;

	showln("Parent Announce callback");
	if (NULL == payload)
		showln("Null payload");
	else {
		if (payload->children_number > 0) {
			showln("Node id 0x%04X has %d children", payload->node_id, payload->children_number);
				for (j = 0; j < payload->children_number; j++) {
					show("Eui64: ");
					for (i = 0; i < EUI64_SIZE; i++)
						show("%02X", payload->child_info[j].ieee_address[i]);
					showln("");
				}
		} else
			showln("Node id 0x%04X has no child", payload->node_id);
	}
	showln("Done");
}

static void _on_device_announce(zigbee_device_annce_info *payload)
{
	int i = 0;

	if (NULL == payload) {
		fprintf(stderr, "device announce: payload is null");
		return;
	}

	showln("device announce notification");
	showln("device node id is 0x%04x", payload->node_id);
	show_mac_capability(payload->mac_capability);
	show("Eui64: ");
	for (i = 0; i < EUI64_SIZE; i++)
		show("%02X", payload->ieee_addr[i]);
	showln("");
}

static void _on_level_control_command_callback(zigbee_level_control_command *level_control)
{
	showln("Level control command callback type %d",
			level_control->control_type);

	switch (level_control->control_type) {
	case ZIGBEE_MOVE_TO_LEVEL:
		showln("Move to level %d transition time %d",
				level_control->parameters.move_to_level.level,
				level_control->parameters.move_to_level.transition_time);
		break;

	case ZIGBEE_MOVE:
		showln("Move mode %d rate %d",
				level_control->parameters.move.control_mode,
				level_control->parameters.move.rate);
		break;

	case ZIGBEE_STEP:
		showln("Step mode %d step size %d transition time %d",
				level_control->parameters.step.control_mode,
				level_control->parameters.step.step_size,
				level_control->parameters.step.transition_time);
		break;

	case ZIGBEE_STOP:
		showln("Stop");
		break;

	case ZIGBEE_MOVE_TO_LEVEL_ONOFF:
		showln("On/off move to level %d transition time %d",
				level_control->parameters.move_to_level.level,
				level_control->parameters.move_to_level.transition_time);
		break;

	case ZIGBEE_MOVE_ONOFF:
		showln("On/off move mode %d rate %d",
				level_control->parameters.move.control_mode,
				level_control->parameters.move.rate);
		break;

	case ZIGBEE_STEP_ONOFF:
		showln("On/off step mode %d step size %d transition time %d",
				level_control->parameters.step.control_mode,
				level_control->parameters.step.step_size,
				level_control->parameters.step.transition_time);
		break;

	case ZIGBEE_STOP_ONOFF:
		showln("On/off stop");
		break;
	}
}

static void _on_commission_callback(zigbee_commissioning_state commissioning_state)
{
	switch (commissioning_state) {
	case COMMISSIONING_ERROR:
		showln("Commissioning: error");
		showln("Done");
		break;
	case COMMISSIONING_ERR_IN_PROGRESS:
		showln("Commissioning: error in progress");
		showln("Done");
		break;
	case COMMISSIONING_NETWORK_STEERING_FORM:
		showln("Commissioning: network steering form");
		break;
	case COMMISSIONING_NETWORK_STEERING_SUCCESS:
		showln("Commissioning: network steering success");
		break;
	case COMMISSIONING_NETWORK_STEERING_FAILED:
		showln("Commissioning: network steering failed");
		break;
	case COMMISSIONING_WAIT_NETWORK_STEERING:
		showln("Commissioning: wait for network steering");
		break;
	case COMMISSIONING_INITIATOR_SUCCESS:
		showln("Commissioning: initiator success\nDone");
		break;
	case COMMISSIONING_INITIATOR_FAILED:
		showln("Commissioning: initiator failed\nDone");
		showln("Commissioning target should be run on remote device prior to initiator");
		break;
	case COMMISSIONING_INITIATOR_STOP:
		showln("Commissioning: initiator stopped");
		showln("Done");
		break;
	case COMMISSIONING_TARGET_SUCCESS:
		showln("Commissioning: target success\nDone");
		showln("Please run commissioning initiator on remote device");
		break;
	case COMMISSIONING_TARGET_FAILED:
		showln("Commissioning: target failed\nDone");
		break;
	case COMMISSIONING_TARGET_STOP:
		showln("Commissioning: target stopped");
		showln("Done");
		break;
	default:
		showln("Unhandled commission state %d", commissioning_state);
		break;
	}
}

static void _dequeue_ieee_desc_requests(void)
{
	struct ieee_desc_request *request = ieee_desc_request_head;

	if (NULL != request) {
		ieee_desc_request_head = ieee_desc_request_head->next;
		free(request);
	}
}

static void _enqueue_ieee_desc_requests(int node_id, int target_endpoint)
{
	struct ieee_desc_request *request;

	request = malloc(sizeof(struct ieee_desc_request));
	if (NULL == request) {
		fprintf(stderr, "Malloc error");
		return;
	}

	request->node_id = node_id;
	request->target_endpoint = target_endpoint;
	request->ieee_request = true;
	request->next = NULL;

	if (NULL == ieee_desc_request_head) {
		ieee_desc_request_head = request;
		ieee_desc_request_tail = request;
	} else {
		ieee_desc_request_tail->next = request;
		ieee_desc_request_tail = request;
	}
}

static int _ieee_descriptor_periodic_request(void *user_data)
{
	zigbee_error ret;
	struct ieee_desc_request *request = ieee_desc_request_head;

	if (ieee_descriptor_requesting)
		return 1;

	if (NULL != request) {
		if (true == request->ieee_request) {
			ret = zigbee_ieee_addr_request(request->node_id);
			if (EZ_OK == ret) {
				showln("IEEE addr request to node 0x%04X", request->node_id);
				ieee_descriptor_requesting = true;
			} else {
				showln("IEEE addr request to node 0x%04X failed for result %d", request->node_id,
						ret);
				_dequeue_ieee_desc_requests();
			}
		} else {
			ret = zigbee_simple_descriptor_request(request->node_id,
					request->target_endpoint);
			if (EZ_OK == ret) {
				showln("Simple descriptor request to node 0x%04X endpoint %d", request->node_id,
						request->target_endpoint);
				ieee_descriptor_requesting = true;
			} else {
				showln("Simple descriptor request to node 0x%04X endpoint %d failed for result %d",
						request->node_id, request->target_endpoint, ret);
				_dequeue_ieee_desc_requests();
			}
		}
		return 1;
	} else {
		ieee_descriptor_periodic_id = -1;
		showln("IEEE & Descriptor request finished\nDone");
		return 0;
	}
}

static void _add_periodic_callback(void)
{
	if (ieee_descriptor_periodic_id < 0) {
		ieee_descriptor_periodic_id = add_periodic_timer(
				_on_timer_callback, TIMER_IEEE_DESC_REQUEST, 200, NULL);

		if (0 > ieee_descriptor_periodic_id)
			fprintf(stderr, "Add periodic callback error");
	}
}

static void _show_zone_status(ZIGBEE_IAS_ZONE_STATUS zone_status)
{
	showln(" - ALARM1 : %s", ZIGBEE_IAS_ZONE_STATUS_BIT_ALARM1 & zone_status ?
					"opened or alarmed" : "closed or not alarmed");
	showln(" - ALARM2 : %s", ZIGBEE_IAS_ZONE_STATUS_BIT_ALARM2 & zone_status ?
					"opened or alarmed" : "closed or not alarmed");
	showln(" - TAMPER : %s", ZIGBEE_IAS_ZONE_STATUS_BIT_TAMPER & zone_status ?
					"Tampered" : "Not tampered");
	showln(" - BATTERY : %s", ZIGBEE_IAS_ZONE_STATUS_BIT_BATTERY & zone_status ?
					"Low battery" : "Battery OK");
	showln(" - SUPERVISION_REPORTS : %s",
			ZIGBEE_IAS_ZONE_STATUS_BIT_SUPERVISION_REPORTS & zone_status ?
					"Reports" : "Does not report");
	showln(" - RESTORE_REPORTS : %s",
			ZIGBEE_IAS_ZONE_STATUS_BIT_RESTORE_REPORTS & zone_status ?
					"Reports restore" : "Does not report restore");
	showln(" - TROUBLE : %s", ZIGBEE_IAS_ZONE_STATUS_BIT_TROUBLE & zone_status ?
					"Trouble/Failure" : "OK");
	showln(" - AC : %s", ZIGBEE_IAS_ZONE_STATUS_BIT_AC & zone_status ?
					"AC/Mains fault" : "AC/Mains OK");
	showln(" - TEST : %s", ZIGBEE_IAS_ZONE_STATUS_BIT_TEST & zone_status ?
					"Sensor is in test mode" : "Sensor is in operation mode");
	showln(" - BATTERY_DEFECT : %s", ZIGBEE_IAS_ZONE_STATUS_BIT_BATTERY_DEFECT & zone_status ?
					"Sensor detects a defective battery" :
					"Sensor battery is func-tioning normally");
}

static void _show_alarm_zone_type(enum zigbee_ias_zone_type zone_type)
{
	switch (zone_type) {
	case ZIGBEE_IAS_ZONE_TYPE_STANDARD_CIE:
		showln("Zone Type: STANDARD_CIE, Alarm1: System Alarm, Alarm2: N/A");
		break;

	case ZIGBEE_IAS_ZONE_TYPE_MOTION_SENSOR:
		showln("Zone Type: MOTION_SENSOR, Alarm1: Intrusion indication, Alarm2: Presence indication");
		break;

	case ZIGBEE_IAS_ZONE_TYPE_CONTACT_SWITCH:
		showln("Zone Type: CONTACT_SWITCH, Alarm1: 1st portal Open-Close, Alarm2: 2nd portal Open-Close");
		break;

	case ZIGBEE_IAS_ZONE_TYPE_FIRE_SENSOR:
		showln("Zone Type: FIRE_SENSOR, Alarm1: Fire indication, Alarm2: N/A");
		break;

	case ZIGBEE_IAS_ZONE_TYPE_WATER_SENSOR:
		showln("Zone Type: WATER_SENSOR, Alarm1: Water overflow indication, Alarm2: N/A");
		break;

	case ZIGBEE_IAS_ZONE_TYPE_GAS_SENSOR:
		showln("Zone Type: GAS_SENSOR, Alarm1: Carbon Monoxide(CO) indication, Alarm2: Cooking indication");
		break;

	case ZIGBEE_IAS_ZONE_TYPE_PERSONAL_EMERGENCY_DEVICE:
		showln("Zone Type: PERSONAL_EMERGENCY_DEVICE, Alarm1: Fall/Concussion, Alarm2: Emergency button");
		break;

	case ZIGBEE_IAS_ZONE_TYPE_VIBRATION_MOVEMENT_SENSOR:
		showln("Zone Type: VIBRATION_MOVEMENT_SENSOR, Alarm1: Movement indication, Alarm2: Vibration");
		break;

	case ZIGBEE_IAS_ZONE_TYPE_REMOTE_CONTROL:
		showln("Zone Type: REMOTE_CONTROL, Alarm1: Panic, Alarm2: Emergency");
		break;

	case ZIGBEE_IAS_ZONE_TYPE_KEY_FOB:
		showln("Zone Type: KEY_FOB, Alarm1: Panic, Alarm2: Emergency");
		break;

	case ZIGBEE_IAS_ZONE_TYPE_KEYPAD:
		showln("Zone Type: KEYPAD, Alarm1: Panic, Alarm2: Emergency");
		break;

	case ZIGBEE_IAS_ZONE_TYPE_STANDARD_WARNING_DEVICE:
		showln("Zone Type: STANDARD_WARNING_DEVICE, European Standards Series for Intruder Alarm Systems");
		break;

	case ZIGBEE_IAS_ZONE_TYPE_GLASS_BREAK_SENSOR:
		showln("Zone Type: GLASS_BREAK_SENSOR, Alarm1: Glass breakage detected, Alarm2: N/A");
		break;

	case ZIGBEE_IAS_ZONE_TYPE_SECURITY_REPEATER:
		showln("Zone Type: SECURITY_REPEATER, A ZigBee repeater for security devices");
		break;

	case ZIGBEE_IAS_ZONE_TYPE_INVALID_ZONE_TYPE:
		showln("Zone Type: INVALID_ZONE_TYPE");
		break;

	default:
		showln("Zone Type: unknown 0x%04X", zone_type);
		break;
	}
}

static void _show_zone_type(const int node_id)
{
	zigbee_endpoint_list endpoint_list;
	struct zigbee_sending_info sending_info;
	zigbee_local_endpoint info_point;
	char value[MAX_ATTRIBUTE_SIZE];
	unsigned int value_length = 0;
	int i = 0, count = 0;
	bool support = false;
	zigbee_error ret = EZ_OK;
	struct test_device *test_device = NULL;
	zigbee_attribute_data_type value_type = ZIGBEE_NO_DATA_ATTRIBUTE_TYPE;
	uint16_t zone_type = 0x0000;

	zigbee_device_find_by_cluster(&endpoint_list, ZCL_IAS_ZONE_CLUSTER_ID, 1);
	for (i = 0; i < endpoint_list.num; i++) {
		if (node_id == endpoint_list.endpoint[i].node_id) {
			sending_info.type = ZIGBEE_SENDING_BY_ENDPOINT;
			sending_info.data.dest_endpoint = endpoint_list.endpoint[i];
			support = true;
			break;
		}
	}

	if (false == support) {
		showln("Find no remote device for IAS Zone server cluster");
		return;
	}

	support = false;
	count = get_test_device_count();
	for (i = 0; i < count; i++) {
		test_device = get_test_device(i);

		if (NULL == test_device->general_read_remote_attribute)
			continue;

		ret = zigbee_get_local_endpoint_by_endpointid(&info_point, test_device->endpoint_id);
		if (EZ_OK != ret) {
			showln("wrong device->endpoint_id %d\n", test_device->endpoint_id);
			return;
		}

		if (EZ_OK != zigbee_local_endpoint_contains_cluster(info_point.endpoint_id,
				ZCL_IAS_ZONE_CLUSTER_ID, false))
			continue;

		support = true;
	}

	if (false == support) {
		showln("There is no local device for IAS Zone attribute reading");
		return;
	}

	ret = test_device->general_read_remote_attribute(&sending_info, ZCL_IAS_ZONE_CLUSTER_ID,
			ZCL_ZONE_TYPE_ATTRIBUTE_ID, value, &value_length, &value_type,
			test_device->endpoint_id);

	if (EZ_OK != ret)
		showln("Read IAS Zone Type attribute from node 0x%04X error: %s",
				sending_info.data.dest_endpoint.node_id, zigbee_error_msg(ret));
	else {
		if (ZIGBEE_ENUM16_ATTRIBUTE_TYPE != value_type) {
			showln("Read value type 0x%02X is not the expected type 0x%02X", value_type,
					ZIGBEE_ENUM16_ATTRIBUTE_TYPE);
			return;
		}

		if (ZIGBEE_ENUM16_ATTRIBUTE_SIZE != value_length) {
			showln("Read value length %d is not the expected length %d", value_length,
					ZIGBEE_ENUM16_ATTRIBUTE_SIZE);
			return;
		}

		memcpy(&zone_type, value, value_length);
		_show_alarm_zone_type(zone_type);
	}
}

static void _on_ias_zone_status_changed_callback(struct zigbee_ias_zone_status_changed_notification *changed_info)
{
	if (NULL == changed_info) {
		showln("Null IAS Zone status changed notification");
		return;
	}

	showln("IAS Zone status 0x%04X source node 0x%04X zone id 0x%02X delay %d",
			changed_info->zone_status, changed_info->node_id, changed_info->zone_id,
			changed_info->delay);

	_show_zone_status(changed_info->zone_status);
	_show_zone_type(changed_info->node_id);
}

static void _on_raw_command_callback(zigbee_received_command *received_command)
{
	int i = 0;

	if (received_command->is_global_command)
		showln("receive global command:0x%02X endpoint:%d cluster:0x%04X",
				received_command->command_id,
				received_command->dest_endpoint_id,
				received_command->cluster_id);
	else if (received_command->dest_endpoint_id == ZIGBEE_BROADCAST_ENDPOINT)
		showln("receive broadcast command cluster:0x%04X command:0x%02X",
				received_command->cluster_id,
				received_command->command_id);
	else
		showln("receive command endpoint:%d cluster:0x%04X command:0x%02X",
				received_command->dest_endpoint_id,
				received_command->cluster_id,
				received_command->command_id);
	if (received_command->payload_length > 0) {
		showln("receive command:0x%02X payload length is %d, content is:",
				received_command->command_id,
				received_command->payload_length);
		for (i = 0; i < received_command->payload_length; i++) {
			if (i != 0 && 0 == i % 20)
				showln("");
			show("0x%02X ", received_command->payload[i]);
		}
		showln("");
	} else if (received_command->payload_length == 0)
		showln("receive command:0x%02X payload is empty",
				received_command->command_id);
	else if (received_command->payload_length == -1)
		showln("receive command:0x%02X payload length over:%d",
				received_command->command_id,
				MAX_RECEIVED_COMMAND_PLAYLOAD_LENGTH);
	else
		showln("receive command:0x%02X unrecognized payload length is %d",
				received_command->command_id,
				received_command->payload_length);
}

static void _on_callback(void *user_data,
						 zigbee_response_type response_type,
						 void *payload)
{
	zigbee_local_endpoint info;
	zigbee_network_find_result *net_find;
	zigbee_groups_info *group_info;
	zigbee_reporting_info *reporting_info;
	zigbee_received_command *received_command;
	zigbee_identify_feedback_info *identify_info;
	zigbee_report_attribute_info *report_attr_info;
	struct zigbee_general_report_attribute_info *reporting;
	zigbee_commissioning_target_info *target_info;
	zigbee_commissioning_bound_info *bound_info;
	struct test_device *test_device;
	zigbee_device_discovery *device_discovery;
	zigbee_ieee_addr_response *addr_rsp;
	zigbee_simple_descriptor_response *simple_descriptor;
	zigbee_match_desc_response *match_desc;
	zigbee_broadcast_identify_query_response *identify_response;
	zigbee_error ret;
	zigbee_notification notification;
	zigbee_network_notification network_notification;
	zigbee_zdo_response_status bind_status;
	int i;
	unsigned short val_ushort;
	unsigned char val_uch;
	double illum_lux = ILLUMINANCE_MIN_LUX;
	float temperature_celsius = TEMPERATURE_MIN_CELSIUS;

	printf("In callback, response type : %d\n", response_type);

	switch (response_type) {
	case ZIGBEE_RESPONSE_BROADCAST_IDENTIFY_QUERY:
		identify_response = (zigbee_broadcast_identify_query_response *) payload;
		showln("Identify query response node id 0x%04x, endpoint id %d, timeout %d ",
				identify_response->node_id, identify_response->endpoint_id,
				identify_response->timeout);

		/* Select the first one for default endpoint */
		if (identify_endpoint_id < 0)
			identify_endpoint_id = identify_response->endpoint_id;

		_enqueue_ieee_desc_requests(identify_response->node_id, identify_response->endpoint_id);
		_add_periodic_callback();
		break;
	case ZIGBEE_RESPONSE_IEEE_ADDR_RESP:
		addr_rsp = (zigbee_ieee_addr_response *) payload;

		if (addr_rsp->result == ZIGBEE_SERVICE_DISCOVERY_DONE) {
			show("Ieee address response node id 0x%04x, eui64 ",
					addr_rsp->node_id);
			show("%02x", addr_rsp->eui64[0]);
			for (i = 1; i < EUI64_SIZE; i++)
				show(":%02x", addr_rsp->eui64[i]);
			showln("");

			/* Select the first one for default eui */
			if (false == got_eui) {
				got_eui = true;
				memcpy(eui64, addr_rsp->eui64, EUI64_SIZE);
			}

			ieee_desc_request_head->ieee_request = false;
			ieee_descriptor_requesting = false;
		} else
			showln("Ieee address response fail for result %d", addr_rsp->result);
		break;
	case ZIGBEE_RESPONSE_SIMPLE_DESC_RESP:
		simple_descriptor = (zigbee_simple_descriptor_response *) payload;

		if (simple_descriptor->result == ZIGBEE_SERVICE_DISCOVERY_DONE) {
			showln("Simple descriptor response target node id 0x%04x, target endpoint %d",
					simple_descriptor->target_node_id,
					simple_descriptor->target_endpoint);
			show("Client cluster count %d",
					simple_descriptor->client_cluster_count);
			for (i = 0; i < simple_descriptor->client_cluster_count; i++)
				show(" %d:0x%04x", i, simple_descriptor->client_cluster[i]);
			showln("");
			show("Server cluster count %d",
					simple_descriptor->server_cluster_count);
			for (i = 0; i < simple_descriptor->server_cluster_count; i++)
				show(" %d:0x%04x", i, simple_descriptor->server_cluster[i]);
			showln("");
		} else
			showln("Simple descriptor response fail for result %d",
					simple_descriptor->result);

		_dequeue_ieee_desc_requests();
		ieee_descriptor_requesting = false;
		break;
	case ZIGBEE_RESPONSE_MATCH_DESC_RESP:
		match_desc = (zigbee_match_desc_response *) payload;
		if (match_desc->result == ZIGBEE_SERVICE_DISCOVERY_RECEIVED) {
			show("Match description received node id 0x%04x count %d", match_desc->node_id, match_desc->count);
			for (i = 0; i < match_desc->count; i++)
				show(" endpoint(%d)", match_desc->endpoint_list[i]);
			showln("");
		} else if (match_desc->result == ZIGBEE_SERVICE_DISCOVERY_DONE)
			showln("match description response complete");
		else if (match_desc->result == ZIGBEE_SERVICE_DISCOVERY_NO_RESPONSE)
			showln("match description no response");
		else
			showln("match description response fail for result %d", match_desc->result);
		break;
	case ZIGBEE_RESPONSE_NOTIFICATION:
		notification = *((zigbee_notification *) payload);
		switch (notification) {
		case ZIGBEE_CMD_SUCCESS:
			showln("NOTIFICATION: SUCCESS");
			break;

		case ZIGBEE_CMD_ERR_PORT_PROBLEM:
		case ZIGBEE_CMD_ERR_NO_SUCH_COMMAND:
		case ZIGBEE_CMD_ERR_WRONG_NUMBER_OF_ARGUMENTS:
		case ZIGBEE_CMD_ERR_ARGUMENT_OUT_OF_RANGE:
		case ZIGBEE_CMD_ERR_ARGUMENT_SYNTAX_ERROR:
		case ZIGBEE_CMD_ERR_STRING_TOO_LONG:
		case ZIGBEE_CMD_ERR_INVALID_ARGUMENT_TYPE:
		case ZIGBEE_CMD_ERR:
			showln("NOTIFICATION: ERROR(%d)", notification);
			break;

		default:
			showln("NOTIFICATION: ERROR(%d)", notification);
			break;
		}
		break;

	case ZIGBEE_RESPONSE_NETWORK_NOTIFICATION:
		network_notification = *((zigbee_network_notification *) payload);
		switch (network_notification) {
		case ZIGBEE_NETWORK_JOIN:
			showln("NETWORK_NOTIFICATION: JOIN");
			break;

		case ZIGBEE_NETWORK_LEAVE:
			showln("NETWORK_NOTIFICATION: LEAVE");
			break;

		case ZIGBEE_NETWORK_EXIST:
			showln("NETWORK_NOTIFICATION: Network exist, please leave current network and try again");
			break;

		case ZIGBEE_NETWORK_FIND_FORM_SUCCESS:
			showln("NETWORK_NOTIFICATION: FIND FORM SUCCESS");
			ret = zigbee_network_permitjoin(EASY_PJOIN_DURATION);
			if (ret != EZ_OK)
				fprintf(stderr, "zigbee_network_permitjoin failed:%s\n", zigbee_error_msg(ret));
			break;

		case ZIGBEE_NETWORK_FIND_FORM_FAILED:
			showln("NETWORK_NOTIFICATION: FIND FORM FAILED");
			break;

		case ZIGBEE_NETWORK_FIND_JOIN_SUCCESS:
			showln("NETWORK_NOTIFICATION: FIND JOIN SUCCESS");
			break;

		case ZIGBEE_NETWORK_FIND_JOIN_FAILED:
			showln("NETWORK_NOTIFICATION: FIND JOIN FAILED");
			break;

		default:
			showln("NETWORK_NOTIFICATION: %d", network_notification);
			break;
		}
		break;

	case ZIGBEE_RESPONSE_NETWORK_FIND:
		net_find = (zigbee_network_find_result *)payload;
		switch (net_find->find_status) {
		case ZIGBEE_NETWORK_FOUND:
			if (nwk_find_size < NWK_FIND_MAX_SIZE) {
				memcpy(&nwk_found_list[nwk_find_size], net_find,
						sizeof(zigbee_network_find_result));
				nwk_find_size++;

				showln("%d: network channel(%d), tx power(%d), pan id(0x%04X)",
						nwk_find_size, net_find->network_info.channel,
						net_find->network_info.tx_power,
						net_find->network_info.pan_id);
			} else
				showln("Network found out of max size %d", NWK_FIND_MAX_SIZE);
			break;

		case ZIGBEE_NETWORK_FIND_FINISHED:
			showln("Network find finished");
			if (current_func == _func_network_find_join)
				_func_network_found_end_show();
			break;

		case ZIGBEE_NETWORK_FIND_ERR:
			showln("Network find error");
			if (current_func == _func_network_find_join) {
				_func_network_found_show();
				_func_network_found_end_show();
			}
			break;

		default:
			showln("Network find unknown status");
			break;
		}
		break;

	case ZIGBEE_RESPONSE_DEVICE_DISCOVER:
		device_discovery = (zigbee_device_discovery *) payload;
		switch (device_discovery->status) {
		case ZIGBEE_DEVICE_DISCOVERY_START:
			showln("Device discovery start");
			break;
		case ZIGBEE_DEVICE_DISCOVERY_FOUND:
			showln("Device discovery found:");
			show_device(&(device_discovery->device));
			break;
		case ZIGBEE_DEVICE_DISCOVERY_IN_PROGRESS:
			showln("Device discovery in progress");
			showln("Done");
			break;
		case ZIGBEE_DEVICE_DISCOVERY_DONE:
			showln("Done");
			break;
		case ZIGBEE_DEVICE_DISCOVERY_NO_DEVICE:
			showln("Device discovery no device");
			showln("Done");
			break;
		case ZIGBEE_DEVICE_DISCOVERY_ERROR:
			showln("Device discovery error");
			break;
		case ZIGBEE_DEVICE_DISCOVERY_CHANGED:
			showln("Device discovery changed:");
			show_device(&(device_discovery->device));
			break;
		case ZIGBEE_DEVICE_DISCOVERY_LOST:
			showln("Device discovery lost:");
			show_device(&(device_discovery->device));
			break;
		default:
			showln("Discovery device unknown result");
			showln("Done");
			break;
		}
		break;

	case ZIGBEE_RESPONSE_GROUPS_INFO:
		group_info = (zigbee_groups_info *)payload;
		/* Group command may not include group id, such as REMOVE_ALL */
		showln("GROUPS: cmd(%d)", group_info->group_cmd);

		switch (group_info->group_cmd) {
		case ZIGBEE_GROUPS_ADD_IF_IDENTIFYING:
			showln("receive ZIGBEE_GROUPS_ADD_IF_IDENTIFYING to group id: %d, group name: %s",
					group_info->group_id[0], group_info->group_name);
			break;
		case ZIGBEE_GROUPS_ADD:
			showln("receive ZIGBEE_GROUPS_ADD to group id: %d, group name: %s",
					group_info->group_id[0], group_info->group_name);
			break;
		case ZIGBEE_GROUPS_VIEW:
			show("receive ZIGBEE_GROUPS_VIEW to group id: %d", group_info->group_id[0]);
			if (strlen((char *)group_info->group_name) > 0)
				showln(" group name: %s", group_info->group_name);
			else
				showln("");
			break;
		case ZIGBEE_GROUPS_GET_MEMBERSHIP:
			showln("receive ZIGBEE GET MEMBERSHIP to %d groups", group_info->group_count);
			for (i = 0; i < group_info->group_count; i++)
				showln("the response group id: %d", group_info->group_id[i]);
			showln("response remaining capacity of group table is %d", group_info->capacity);
			break;
		case ZIGBEE_GROUPS_REMOVE:
			showln("receive ZIGBEE_GROUPS_REMOVE to group id: %d", group_info->group_id[0]);
			break;
		case ZIGBEE_GROUPS_REMOVE_ALL:
			showln("receive ZIGBEE_GROUPS_REMOVE_ALL");
			break;
		default:
			showln("Groups command not support");
		}
		test_device = get_test_device_by_endpoint_id(group_info->endpoint_id);
		if (test_device == NULL) {
			fprintf(stderr, "Not found endpoint id:%d\n", group_info->endpoint_id);
			break;
		}

		ret = test_device->groups_get_local_name_support(group_info->endpoint_id);

		ret = zigbee_get_local_endpoint_by_endpointid(&info, test_device->endpoint_id);
		if (EZ_OK != ret) {
			showln("wrong endpoint_id %d\n", test_device->endpoint_id);
			ret = EZ_ERROR;
		}

		if (zigbee_local_endpoint_contains_cluster(info.endpoint_id, ZCL_GROUPS_CLUSTER_ID,
				true) != EZ_OK) {
			showln("not supported operation\n");
			ret = EZ_ERROR;
		}

		if (ret == EZ_OK) {
			showln("ZIGBEE_GROUPS: name supported by ep(%d)",
					 group_info->endpoint_id);
			ret = test_device->groups_set_local_name_support(info.endpoint_id, false);
			if (ret != EZ_OK)
				showln("Setting local groups name support attribute value to FALSE failed: %s", zigbee_error_msg(ret));
			else
				showln("Setting local groups name support attribute value to FALSE succeeded");
		} else if (ret == EZ_NOT_SUPPORTED) {
			showln("ZIGBEE_GROUPS: name not supported by ep(%d)",
					 group_info->endpoint_id);
			ret = test_device->groups_set_local_name_support(info.endpoint_id, true);
			if (ret != EZ_OK)
				showln("Setting local groups name support attribute value to TRUE failed: %s", zigbee_error_msg(ret));
			else
				showln("Setting local groups name support attribute value to TRUE succeeded");
		} else
			showln("ZIGBEE_GROUPS: get name support failed: %s",
					 zigbee_error_msg(ret));
		break;

	case ZIGBEE_RESPONSE_ATTRIBUTE_CHANGE:
		_on_callback_attr_changed((zigbee_attribute_changed_response *)payload);
		break;

	case ZIGBEE_RESPONSE_DEVICE_ANNOUNCE:
		_on_device_announce((zigbee_device_annce_info *)payload);
		break;

	case ZIGBEE_RESPONSE_CLIENT_TO_SERVER_COMMAND_RECEIVED:
		showln("Receive a client to server command");

		received_command = (zigbee_received_command *)payload;
		_on_raw_command_callback(received_command);
		break;

	case ZIGBEE_RESPONSE_SERVER_TO_CLIENT_COMMAND_RECEIVED:
		showln("Receive a server to client command");

		received_command = (zigbee_received_command *)payload;
		_on_raw_command_callback(received_command);
		break;

	case ZIGBEE_RESPONSE_REPORTING_CONFIGURE:
		reporting_info = (zigbee_reporting_info *)payload;
		if (reporting_info->used == true)
			showln("get reporting configure ep:%d cluster:%d attr:%d min_interval:%d max_interval:%d reportable_change:%d",
				   reporting_info->endpoint_id,
				   reporting_info->cluster_id,
				   reporting_info->attribute_id,
				   reporting_info->reported.min_interval,
				   reporting_info->reported.max_interval,
				   reporting_info->reported.reportable_change);
		else
			showln("removed reporting configure cluster:%d attr:%d min_interval:%d max_interval:%d reportable_change:%d",
				   reporting_info->cluster_id,
				   reporting_info->attribute_id,
				   reporting_info->reported.min_interval,
				   reporting_info->reported.max_interval,
				   reporting_info->reported.reportable_change);
		break;

	case ZIGBEE_RESPONSE_PARENT_ANNOUNCE:
		_on_parent_announce((zigbee_parent_annce_info *)payload);
		break;

	case ZIGBEE_RESPONSE_REPORT_ATTRIBUTE:
		report_attr_info = (zigbee_report_attribute_info *)payload;
		switch (report_attr_info->attribute_type) {
		case ZIGBEE_ATTR_ILLUMINANCE:
			ret = zigbee_illum_measured_value_to_lux(report_attr_info->data.value, &illum_lux);
			if (EZ_OK == ret)
				showln("Report attribute: Illuminance measured value %d lux %f lx",
						report_attr_info->data.value, illum_lux);
			else
				showln("Report attribute: Illuminance measured value %d get lux error: %s",
						report_attr_info->data.value, zigbee_error_msg(ret));

			reporting_measured_illum_count++;
			if (reporting_measured_illum_count > REPORTING_MAX_COUNT) {
				_stop_reporting(ZIGBEE_REPORTING_MEASURED_ILLUMINANCE);
				reporting_measured_illum_count = 0;
			}
			break;

		case ZIGBEE_ATTR_OCCUPANCY:
			showln("Report attribute: Occupancy: %s",
					(report_attr_info->data.occupancy == ZIGBEE_OCCUPIED)?
							"OCCUPIED":"UNOCCUPIED");
			reporting_occupancy_count++;
			if (reporting_occupancy_count > REPORTING_MAX_COUNT) {
				_stop_reporting(ZIGBEE_REPORTING_OCCUPANCY_SENSING);
				reporting_occupancy_count = 0;
			}

			_update_onoff_test(report_attr_info->data.occupancy);
			break;

		case ZIGBEE_ATTR_TEMPERATURE:
			ret = zigbee_temperature_to_celsius(report_attr_info->data.value, &temperature_celsius);
			if (EZ_OK == ret)
				showln("Report attribute: Temperature value %d Celsius %.2f",
						report_attr_info->data.value, temperature_celsius);
			else
				showln("Report attribute: Temperature value %d get Celsius error: %s",
						report_attr_info->data.value, zigbee_error_msg(ret));

			reporting_measured_temp_count++;
			if (reporting_measured_temp_count > REPORTING_MAX_COUNT) {
				_stop_reporting(ZIGBEE_REPORTING_MEASURED_TEMPERATURE);
				reporting_measured_temp_count = 0;
			}
			break;

		case ZIGBEE_ATTR_HUMIDITY:
			showln("Report attribute: Humidity value %d", report_attr_info->data.value);

			reporting_measured_humidity_count++;
			if (reporting_measured_humidity_count > REPORTING_MAX_COUNT) {
				_stop_reporting(ZIGBEE_REPORTING_MEASURED_HUMIDITY);
				reporting_measured_humidity_count = 0;
			}
			break;

		default:
			fprintf(stderr, "Not supported attribute\n");
			break;
		}
		break;

	case ZIGBEE_RESPONSE_GENERAL_REPORT_ATTRIBUTE:
		reporting = (struct zigbee_general_report_attribute_info *)payload;
		show("Genearl reporting cluster 0x%04X attribute 0x%04X ", reporting->cluster_id,
				reporting->attribute_id);
		if (ZIGBEE_INT16U_ATTRIBUTE_TYPE == reporting->data_type
				&& sizeof(val_ushort) == reporting->data_length) {
			memcpy(&val_ushort, reporting->data, reporting->data_length);
			showln("value 0x%04X", val_ushort);
		} else if ((ZIGBEE_ENUM8_ATTRIBUTE_TYPE == reporting->data_type
					|| ZIGBEE_INT8U_ATTRIBUTE_TYPE == reporting->data_type
					|| ZIGBEE_BOOLEAN_ATTRIBUTE_TYPE == reporting->data_type)
				&& sizeof(val_uch) == reporting->data_length) {
			memcpy(&val_uch, reporting->data, reporting->data_length);
			showln("value 0x%02X", val_uch);
		} else {
			showln("with unhandled data type 0x%02X, data length %d", reporting->data_type,
					reporting->data_length);
		}
		break;

	case ZIGBEE_RESPONSE_IDENTIFY_FEEDBACK_START:
		identify_info = (zigbee_identify_feedback_info *)payload;
		showln("Identify feedback start with %d seconds by ep(%d)",
			   identify_info->duration, identify_info->endpoint_id);
		break;

	case ZIGBEE_RESPONSE_IDENTIFY_FEEDBACK_STOP:
		identify_info = (zigbee_identify_feedback_info *)payload;
		showln("Identify feedback stop by ep(%d)", identify_info->endpoint_id);
		break;

	case ZIGBEE_RESPONSE_COMMISSIONING_STATUS:
		_on_commission_callback(*((zigbee_commissioning_state *) payload));
		break;

	case ZIGBEE_RESPONSE_END_DEVICE_BIND:
		bind_status = *((zigbee_zdo_response_status *)payload);
		if (ZIGBEE_ZDP_SUCCESS == bind_status)
			showln("End device bind success\nDone");
		else
			showln("End device bind failed for %s\nDone", zigbee_zdp_msg(bind_status));
		break;

	case ZIGBEE_RESPONSE_COMMISSIONING_TARGET_INFO:
		target_info = (zigbee_commissioning_target_info *)payload;
		showln("Commissioning: found target id:0x%04X, endpoint:%d",
			   target_info->node_id, target_info->endpoint_id);
		break;

	case ZIGBEE_RESPONSE_COMMISSIONING_BOUND_INFO:
		bound_info = (zigbee_commissioning_bound_info *)payload;
		showln("Commissioning: bound target endpoint:%d, clusterId:0x%04X",
			   bound_info->endpoint_id, bound_info->cluster_id);
		break;

	case ZIGBEE_RESPONSE_BASIC_RESET_TO_FACTORY:
		showln("Basic reset to factory defauts by endpoint %d", *((int *) payload));
		break;

	case ZIGBEE_RESPONSE_LEVEL_CONTROL:
		_on_level_control_command_callback((zigbee_level_control_command *) payload);
		break;

	case ZIGBEE_RESPONSE_IAS_ZONE_STATUS_CHANGED:
		_on_ias_zone_status_changed_callback((struct zigbee_ias_zone_status_changed_notification *)payload);
		break;

	default:
		break;
	}

	printf("[testzigbee] callback end\n");
}

static int _on_timer_callback(enum timer_command cmd, int id, void *user_data)
{
	switch (cmd) {
	case TIMER_IEEE_DESC_REQUEST:	/* periodic request */
		return _ieee_descriptor_periodic_request(user_data);
		break;
	default:
		fprintf(stderr, "Unexpected timer callback:%d\n", cmd);
		if (user_data != NULL)
			free(user_data);
		break;
	}

	return 0;
}

static gboolean _on_keyboard_received(GIOChannel *channel, GIOCondition cond, gpointer user_data)
{
	char input[KEYBOARD_INPUT_SIZE];
	int fd = g_io_channel_unix_get_fd(channel);

	if (fd != STDIN_FILENO)
		fprintf(stderr, "Wrong fd: %d\n", fd);

	if (cond != G_IO_IN && cond != G_IO_ERR && cond != G_IO_HUP &&
		cond != G_IO_NVAL)
		fprintf(stderr, "Wrong cond: %d\n", cond);

	if (user_data)
		fprintf(stderr, "Wrong user data: %p\n", user_data);

	if (fgets(input, KEYBOARD_INPUT_SIZE, stdin) == NULL)
		return TRUE;

	current_func(input, KEYBOARD_INPUT_SIZE);

	return TRUE;
}


int main(int argc, char *argv[])
{
	GIOChannel *channel;

	mainloop = g_main_loop_new(NULL, FALSE);

	_func_entry(_func_entrance);

	channel = g_io_channel_unix_new(STDIN_FILENO);
	g_io_add_watch(channel, G_IO_IN | G_IO_ERR | G_IO_HUP | G_IO_NVAL,
			_on_keyboard_received, NULL);
	g_io_channel_set_flags(channel, G_IO_FLAG_NONBLOCK, NULL);
	g_io_channel_unref(channel);

	g_main_loop_run(mainloop);

	release_all_test_devices();

	return 0;
}
