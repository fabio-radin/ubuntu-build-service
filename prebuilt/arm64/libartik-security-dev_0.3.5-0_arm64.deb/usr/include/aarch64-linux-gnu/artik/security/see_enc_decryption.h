/*
 * Copyright (c) 2016 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the License);
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef __ARTIK_SEE_ENC_DECRYPTION__H
#define __ARTIK_SEE_ENC_DECRYPTION__H

#include <artik/security/see_common.h>

/**
 * @file see_enc_decryption.h
 * @brief Data encryption decryption API
 *
 * @example see-encdec-test.c
 */

/**
 * @ingroup security
 * @defgroup see_enc_decryption See_Enc_Decryption
 * @brief Data encryption decryption API
 *
 * This API provides functions to use data encryption and decryption.
 * @{
 */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief AES Encryption
 *
 * - Encrypt input data using an AES key located in secure storage.
 * - Because ISO9797_M1 has decryption problem with zero byte at the end of input data,
 *   zero padding will not be removed from decrypted data in case of ISO9797_M1.
 * - If a user wants to encrypt a data using a key in special storage,
 *   the user should prefix a location with index.
 * <PRE>
 * 	1. SE Storage       : SE/
 * 	2. TEMP Storage     : TMP/
 * 	   TEMP Storage save a data on volatile memory,
 * 	   so the data is discarded when finalizing API.
 * </PRE>
 * - Limitations
 * <PRE>
 * 	1. Mode : AES_ECB_NOPAD,
 * 	          AES_ECB_ISO9797_M1,
 * 	          AES_ECB_ISO9797_M2,
 * 	          AES_ECB_PKCS5,
 * 	          AES_ECB_PKCS7,
 * 	          AES_CBC_NOPAD,
 * 	          AES_CBC_ISO9797_M1,
 * 	          AES_CBC_ISO9797_M2
 * 	          AES_CBC_PKCS5,
 * 	          AES_CBC_PKCS7,
 * 	          AES_CTR
 * 	2. Key name :
 * 		1) TEE Storage : 20 characters max length
 * 		2) SE Storage  :  5 characters max length include “SE/” prefix (“SE/”)
 * 		3) TEMP Storage:  6 characters max length include “TMP/” prefix (“TMP/”)
 * 	3. Initial vector  : 16 Bytes.
 * 	4. Input data size : 10 MB max size
 * </PRE>
 *
 * @param[in] mode     : AES encryption mode.
 * @param[in] key_name : AES Key name in secure storage.
 * @param[in] iv       : Initial Vector.
 * @param[in] input    : Input data.
 * @param[in] output   : Encrypted data will be returned.
 * @returns 0 if succeeded. Returns other value if failed.
 * @see enum see_aes_mode
 * @see struct see_data
 */
int see_aes_encryption(see_aes_mode mode, const char *key_name, see_data iv,
		see_data input, see_data *output);

/**
 * @brief AES Decryption
 *
 * - Decrypt the encrypted data using an AES key.
 *   Because ISO9797_M1 has decryption problem with zero byte at the end of input data,
 *   zero padding will not be removed from decrypted data in case of ISO9797_M1.
 * - If a user wants to decrypt a data using a key in special storage,
 *   the user should prefix a location with index.
 * <PRE>
 * 	1. SE Storage       : SE/
 * 	2. TEMP Storage     : TMP/
 * 	   TEMP Storage save a data on volatile memory,
 * 	   so the data is discarded when finalizing API.
 * </PRE>
 * - Limitations
 * <PRE>
 * 	1. Mode : AES_ECB_NOPAD,
 * 	          AES_ECB_ISO9797_M1,
 * 	          AES_ECB_ISO9797_M2,
 * 	          AES_ECB_PKCS5,
 * 	          AES_ECB_PKCS7,
 * 	          AES_CBC_NOPAD,
 * 	          AES_CBC_ISO9797_M1,
 * 	          AES_CBC_ISO9797_M2
 * 	          AES_CBC_PKCS5,
 * 	          AES_CBC_PKCS7,
 * 	          AES_CTR
 * 	2. Key name :
 * 		1) TEE Storage : 20 characters max length
 * 		2) SE Storage  :  5 characters max length include “SE/” prefix (“SE/”)
 * 		3) TEMP Storage:  6 characters max length include “TMP/” prefix (“TMP/”)
 * 	3. Initial vector  : 16 Bytes.
 * </PRE>
 *
 * @param[in] mode     : AES mode.
 * @param[in] key_name : AES Key name in secure storage.
 * @param[in] iv       : Initial Vector.
 * @param[in] input    : Encrypted data.
 * @param[in] output   : Decypted data will be returned.
 * @returns 0 if succeeded. Returns other value if failed.
 * @see enum see_aes_mode
 * @see struct see_data
 */
int see_aes_decryption(see_aes_mode mode, const char *key_name, see_data iv,
		see_data input, see_data *output);

/**
 * @brief RSA Encryption
 *
 * - Encrypt input data using an RSA Key from secure storage.
 * - If a user wants to encrypt a data using a key in special storage,
 *   the user should prefix a location with index.
 * <PRE>
 * 	1. TEMP Storage     : TMP/
 * 	   TEMP Storage save a data on volatile memory,
 * 	   so the data is discarded when finalizing API.
 * </PRE>
 * - Limitations
 * <PRE>
 * 	1. Mode : RSAES_PKCS1_V1_5,
 * 	          RSAES_PKCS1_OAEP_MGF1_SHA1,
 * 	          RSAES_PKCS1_OAEP_MGF1_SHA224,
 * 	          RSAES_PKCS1_OAEP_MGF1_SHA256,
 * 	          RSAES_PKCS1_OAEP_MGF1_SHA384,
 * 	          RSAES_PKCS1_OAEP_MGF1_SHA512
 * 	2. Key name :
 * 		1) TEE Storage : 20 characters max length
 * 		2) TEMP Storage:  6 characters max length include “TMP/” prefix (“TMP/”)
 * 	3. Input data size :  4 KB max size
 * </PRE>
 *
 * @param[in] mode     : RSA mode.
 * @param[in] key_name : RSA Key name for encryption.
 * @param[in] input    : Input data which a user enter.
 * @param[in] output   : Encrypted data will be returned.
 * @returns 0 if succeeded. Returns other value if failed.
 * @see enum see_rsa_mode
 * @see struct see_data
 */
int see_rsa_encryption(see_rsa_mode mode, const char *key_name, see_data input,
		see_data *output);

/**
 * @brief RSA Decryption
 *
 * - Decrypt input data using an RSA Key from secure storage.
 * - If a user wants to decrypt a data using a key in special storage,
 *   the user should prefix a location with index.
 * <PRE>
 * 	1. TEMP Storage     : TMP/
 * 	   TEMP Storage save a data on volatile memory,
 * 	   so the data is discarded when finalizing API.
 * </PRE>
 * - Limitations
 * <PRE>
 * 	1. Mode : RSAES_PKCS1_V1_5,
 * 	          RSAES_PKCS1_OAEP_MGF1_SHA1,
 * 	          RSAES_PKCS1_OAEP_MGF1_SHA224,
 * 	          RSAES_PKCS1_OAEP_MGF1_SHA256,
 * 	          RSAES_PKCS1_OAEP_MGF1_SHA384,
 * 	          RSAES_PKCS1_OAEP_MGF1_SHA512
 * 	2. Key name :
 * 		1) TEE Storage : 20 characters max length
 * 		2) TEMP Storage:  6 characters max length include “TMP/” prefix (“TMP/”)
 * </PRE>
 * @param[in] mode     : RSA mode.
 * @param[in] key_name : RSA Key name in secure storage.
 * @param[in] input    : Encrypted data.
 * @param[in] output   : Decrypted data will be returned.
 * @returns 0 if succeeded. Returns other value if failed.
 * @see enum see_rsa_mode
 * @see struct see_data
 */
int see_rsa_decryption(see_rsa_mode mode, const char *key_name, see_data input,
		see_data *output);

#ifdef __cplusplus
}
#endif
/**
 * @}
 */
#endif
